import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MContainerComponent } from '../../m-framework/m-container/m-container.component';
import { MTableComponent } from '../../m-framework/m-table/m-table.component';
import { CanvasJSAngularChartsModule } from '@canvasjs/angular-charts';
import { MSearchButtonComponent } from '../../m-framework/m-search-button/m-search-button.component';
import { LocaldataService } from '../../services/localdata.service';
import { Reading } from '../../data/Reading';

@Component({
  selector: 'app-feature1',
  standalone: true,
  imports: [
    MSearchButtonComponent,
    CanvasJSAngularChartsModule,
    CommonModule,
    FormsModule,
    MContainerComponent,
    MTableComponent,
  ],
  templateUrl: './feature1.component.html',
  styleUrl: './feature1.component.css',
})
export class Feature1Component implements OnInit {
  ids: number;
  voltage: string;
  current: string;
  power: string;
  frequency: string;
  listOfVoltageReading: Reading[];
  listOfCurrentReading: Reading[];
  listOfPowerReading: Reading[];
  listOfFrequencyReading: Reading[];
  chartOptions: any;
  chart: any;
  filterTerm: string = '';
  tableHeaders: string[];

  constructor(private localData: LocaldataService, private router: Router) {
    this.ids = 0;
    this.voltage = '';
    this.current = '';
    this.power = '';
    this.frequency = '';
    this.listOfVoltageReading = [];
    this.listOfCurrentReading = [];
    this.listOfPowerReading = [];
    this.listOfFrequencyReading = [];
    this.chartOptions = {
      theme: 'light2',
      title: { text: 'Live Data' },
      data: [
        { type: 'line', dataPoints: this.listOfVoltageReading },
        { type: 'line', dataPoints: this.listOfCurrentReading },
        { type: 'line', dataPoints: this.listOfPowerReading },
        { type: 'line', dataPoints: this.listOfFrequencyReading },
      ],
    };
    this.tableHeaders = ['Reading ID', 'TimeStamp', 'Value', 'Type'];
  }
  ngOnInit(): void {
    this.listOfVoltageReading = this.localData.getVolt();
    this.listOfCurrentReading = this.localData.getCurr();
    this.listOfPowerReading = this.localData.getPow();
    this.listOfFrequencyReading = this.localData.getFreq();
    this.ids = this.localData.getID();
    this.listOfVoltageReading.forEach(
      (reading) => (reading.x = new Date(reading.x))
    );
    this.listOfCurrentReading.forEach(
      (reading) => (reading.x = new Date(reading.x))
    );
    this.listOfPowerReading.forEach(
      (reading) => (reading.x = new Date(reading.x))
    );
    this.listOfFrequencyReading.forEach(
      (reading) => (reading.x = new Date(reading.x))
    );
    this.chartOptions.data = [
      { type: 'line', dataPoints: this.listOfVoltageReading },
      { type: 'line', dataPoints: this.listOfCurrentReading },
      { type: 'line', dataPoints: this.listOfPowerReading },
      { type: 'line', dataPoints: this.listOfFrequencyReading },
    ];
  }
  getChartInstance(chart: object) {
    this.chart = chart;
  }
  resetDB() {
    this.listOfVoltageReading = [];
    this.listOfCurrentReading = [];
    this.listOfPowerReading = [];
    this.listOfFrequencyReading = [];
    this.chartOptions.data = [
      { type: 'line', dataPoints: this.listOfVoltageReading },
      { type: 'line', dataPoints: this.listOfCurrentReading },
      { type: 'line', dataPoints: this.listOfPowerReading },
      { type: 'line', dataPoints: this.listOfFrequencyReading },
    ];
    this.chart.render();
    this.localData.reset();
  }
  addReading() {
    if (this.voltage)
      this.listOfVoltageReading.push(
        new Reading(this.ids++, +this.voltage, 'Voltage')
      );

    if (this.current)
      this.listOfCurrentReading.push(
        new Reading(this.ids++, +this.current, 'Current Flow')
      );

    if (this.power)
      this.listOfPowerReading.push(
        new Reading(this.ids++, +this.power, 'Power Factor')
      );

    if (this.frequency)
      this.listOfFrequencyReading.push(
        new Reading(this.ids++, +this.frequency, 'Frequency')
      );

    this.chart.render();
    this.localData.updateLocalStorage(
      this.ids,
      this.listOfVoltageReading,
      this.listOfCurrentReading,
      this.listOfPowerReading,
      this.listOfFrequencyReading
    );
  }

  get allReadings() {
    return this.listOfVoltageReading
      .concat(this.listOfCurrentReading)
      .concat(this.listOfPowerReading)
      .concat(this.listOfFrequencyReading)
      .sort((a, b) => new Date(a.x).getTime() - new Date(b.x).getTime());
  }

  removeReading(readingId: number) {
    const index1 = this.listOfVoltageReading.findIndex(
      (obj) => obj.id === readingId
    );
    if (index1 != -1) this.listOfVoltageReading.splice(index1, 1);

    const index2 = this.listOfCurrentReading.findIndex(
      (obj) => obj.id === readingId
    );
    if (index2 != -1) this.listOfCurrentReading.splice(index2, 1);

    const index3 = this.listOfPowerReading.findIndex(
      (obj) => obj.id === readingId
    );
    if (index3 != -1) this.listOfPowerReading.splice(index3, 1);

    const index4 = this.listOfFrequencyReading.findIndex(
      (obj) => obj.id === readingId
    );
    if (index4 != -1) this.listOfFrequencyReading.splice(index3, 1);

    this.chart.render();
    this.localData.updateLocalStorage(
      this.ids,
      this.listOfVoltageReading,
      this.listOfCurrentReading,
      this.listOfPowerReading,
      this.listOfFrequencyReading
    );
  }

  navigateToDetails(readingId: number) {
    const index = this.allReadings.findIndex((obj) => obj.id === readingId);
    this.router.navigate(['details'], {
      queryParams: { reading: JSON.stringify(this.allReadings[index]) },
    });
  }
}
