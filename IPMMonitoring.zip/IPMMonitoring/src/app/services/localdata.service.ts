import { Injectable } from '@angular/core';
import { Reading } from '../data/Reading';
@Injectable({
  providedIn: 'root',
})
export class LocaldataService {
  listOfVoltageReading: Reading[];
  listOfCurrentReading: Reading[];
  listOfPowerReading: Reading[];
  listOfFrequencyReading: Reading[];
  private nextId: number;

  constructor() {
    this.nextId = parseInt(localStorage.getItem('nextId') || '1', 10);
    this.listOfVoltageReading = JSON.parse(
      localStorage.getItem('Volt') ?? '[]'
    );
    this.listOfCurrentReading = JSON.parse(
      localStorage.getItem('Curr') ?? '[]'
    );
    this.listOfPowerReading = JSON.parse(localStorage.getItem('Pow') ?? '[]');
    this.listOfFrequencyReading = JSON.parse(
      localStorage.getItem('Freq') ?? '[]'
    );
    if (typeof this.listOfVoltageReading === 'string')
      this.listOfVoltageReading = [];
    if (typeof this.listOfCurrentReading === 'string')
      this.listOfCurrentReading = [];
    if (typeof this.listOfPowerReading === 'string')
      this.listOfPowerReading = [];
    if (typeof this.listOfFrequencyReading === 'string')
      this.listOfFrequencyReading = [];
  }
  getVolt(): Reading[] {
    return this.listOfVoltageReading;
  }
  getCurr(): Reading[] {
    return this.listOfCurrentReading;
  }
  getPow(): Reading[] {
    return this.listOfPowerReading;
  }
  getFreq(): Reading[] {
    return this.listOfFrequencyReading;
  }

  getID() {
    return this.nextId;
  }

  updateLocalStorage(
    id: number,
    VoltList: Reading[],
    CurrList: Reading[],
    PowList: Reading[],
    FreqList: Reading[]
  ) {
    localStorage.setItem('Volt', JSON.stringify(VoltList));
    localStorage.setItem('Curr', JSON.stringify(CurrList));
    localStorage.setItem('Pow', JSON.stringify(PowList));
    localStorage.setItem('Freq', JSON.stringify(FreqList));
    localStorage.setItem('nextId', '' + id);
  }
  reset() {
    localStorage.setItem('Volt', JSON.stringify('[]'));
    localStorage.setItem('Curr', JSON.stringify('[]'));
    localStorage.setItem('Pow', JSON.stringify('[]'));
    localStorage.setItem('Freq', JSON.stringify('[]'));
    localStorage.setItem('nextId', '' + 1);
  }
}
