import { Component } from '@angular/core';

@Component({
  selector: 'm-container',
  standalone: true,
  imports: [],
  templateUrl: './m-container.component.html',
  styleUrl: './m-container.component.css'
})
export class MContainerComponent {

}
