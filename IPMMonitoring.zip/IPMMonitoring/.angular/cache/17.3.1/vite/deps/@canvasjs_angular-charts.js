import {
  CommonModule,
  NgIf,
  NgStyle
} from "./chunk-F7YCE4AL.js";
import {
  Component,
  EventEmitter,
  Input,
  NgModule,
  Output,
  __commonJS,
  setClassMetadata,
  ɵɵNgOnChangesFeature,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵelement,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpropertyInterpolate,
  ɵɵtemplate
} from "./chunk-NBQ4IHRG.js";

// node_modules/@canvasjs/charts/canvasjs.min.js
var require_canvasjs_min = __commonJS({
  "node_modules/@canvasjs/charts/canvasjs.min.js"(exports, module) {
    (function() {
      function qa(h, n) {
        h.prototype = db(n.prototype);
        h.prototype.constructor = h;
        h.base = n.prototype;
      }
      function db(h) {
        function n() {
        }
        n.prototype = h;
        return new n();
      }
      function Xa(h, n, P) {
        "millisecond" === P ? h.setMilliseconds(h.getMilliseconds() + 1 * n) : "second" === P ? h.setSeconds(h.getSeconds() + 1 * n) : "minute" === P ? h.setMinutes(h.getMinutes() + 1 * n) : "hour" === P ? h.setHours(h.getHours() + 1 * n) : "day" === P ? h.setDate(h.getDate() + 1 * n) : "week" === P ? h.setDate(h.getDate() + 7 * n) : "month" === P ? h.setMonth(h.getMonth() + 1 * n) : "year" === P && h.setFullYear(h.getFullYear() + 1 * n);
        return h;
      }
      function ea(h, n) {
        var P = false;
        0 > h && (P = true, h *= -1);
        h = "" + h;
        for (n = n ? n : 1; h.length < n; )
          h = "0" + h;
        return P ? "-" + h : h;
      }
      function Ha(h) {
        if (!h)
          return h;
        h = h.replace(/^\s\s*/, "");
        for (var n = /\s/, P = h.length; n.test(h.charAt(--P)); )
          ;
        return h.slice(0, P + 1);
      }
      function Aa(h) {
        h.roundRect = function(h2, P, m2, t2, sa, D, z2, w2) {
          z2 && (this.fillStyle = z2);
          w2 && (this.strokeStyle = w2);
          "undefined" === typeof sa && (sa = 5);
          this.lineWidth = D;
          this.beginPath();
          this.moveTo(h2 + sa, P);
          this.lineTo(h2 + m2 - sa, P);
          this.quadraticCurveTo(h2 + m2, P, h2 + m2, P + sa);
          this.lineTo(h2 + m2, P + t2 - sa);
          this.quadraticCurveTo(h2 + m2, P + t2, h2 + m2 - sa, P + t2);
          this.lineTo(h2 + sa, P + t2);
          this.quadraticCurveTo(h2, P + t2, h2, P + t2 - sa);
          this.lineTo(h2, P + sa);
          this.quadraticCurveTo(h2, P, h2 + sa, P);
          this.closePath();
          z2 && this.fill();
          w2 && 0 < D && this.stroke();
        };
      }
      function Ra(h, n) {
        return h - n;
      }
      function Z(h) {
        var n = ((h & 16711680) >> 16).toString(16), P = ((h & 65280) >> 8).toString(16);
        h = ((h & 255) >> 0).toString(16);
        n = 2 > n.length ? "0" + n : n;
        P = 2 > P.length ? "0" + P : P;
        h = 2 > h.length ? "0" + h : h;
        return "#" + n + P + h;
      }
      function eb(h, n) {
        var P = this.length >>> 0, m2 = Number(n) || 0, m2 = 0 > m2 ? Math.ceil(m2) : Math.floor(m2);
        for (0 > m2 && (m2 += P); m2 < P; m2++)
          if (m2 in this && this[m2] === h)
            return m2;
        return -1;
      }
      function m(h) {
        return null === h || "undefined" === typeof h;
      }
      function Ea(h) {
        h.indexOf || (h.indexOf = eb);
        return h;
      }
      function fb(h) {
        if (xa.fSDec)
          h[ka("`eeDwdouMhrudods")](ka("e`u`@ohl`uhnoHuds`uhnoDoe"), function() {
            xa._fTWm && xa._fTWm(h);
          });
      }
      function Ya(h, n, P) {
        P = P || "normal";
        var m2 = h + "_" + n + "_" + P, t2 = Za[m2];
        if (isNaN(t2)) {
          try {
            if (!ta) {
              var sa = document.body;
              ta = document.createElement("span");
              ta.innerHTML = "";
              var D = document.createTextNode("Mpgyi");
              ta.appendChild(D);
              sa.appendChild(ta);
            }
            ta.style.display = "";
            Y(ta, { position: "absolute", left: "0px", top: "-20000px", padding: "0px", margin: "0px", border: "none", whiteSpace: "pre", lineHeight: "normal", fontFamily: h, fontSize: n + "px", fontWeight: P });
            t2 = Math.round(ta.offsetHeight);
            ta.style.display = "none";
          } catch (z2) {
            t2 = Math.ceil(1.1 * n);
          }
          t2 = Math.max(t2, n);
          Za[m2] = t2;
        }
        return t2;
      }
      function H(h, n) {
        var m2 = [];
        if (m2 = { solid: [], shortDash: [3, 1], shortDot: [1, 1], shortDashDot: [3, 1, 1, 1], shortDashDotDot: [3, 1, 1, 1, 1, 1], dot: [1, 2], dash: [4, 2], dashDot: [
          4,
          2,
          1,
          2
        ], longDash: [8, 2], longDashDot: [8, 2, 1, 2], longDashDotDot: [8, 2, 1, 2, 1, 2] }[h || "solid"])
          for (var t2 = 0; t2 < m2.length; t2++)
            m2[t2] *= n;
        else
          m2 = [];
        return m2;
      }
      function S(h, n, P, t2, ja) {
        t2 = t2 || [];
        ja = m(ja) ? gb ? { passive: false, capture: false } : false : ja;
        t2.push([h, n, P, ja]);
        return h.addEventListener ? (h.addEventListener(n, P, ja), P) : h.attachEvent ? (t2 = function(n2) {
          n2 = n2 || window.event;
          n2.preventDefault = n2.preventDefault || function() {
            n2.returnValue = false;
          };
          n2.stopPropagation = n2.stopPropagation || function() {
            n2.cancelBubble = true;
          };
          P.call(h, n2);
        }, h.attachEvent(
          "on" + n,
          t2
        ), t2) : false;
      }
      function hb(h) {
        if (h._menuButton)
          h.exportEnabled ? (Y(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), Ma(h._menuButton), ua(h, h._menuButton, "menu")) : ya(h._menuButton);
        else if (h.exportEnabled && t) {
          var n = false;
          h._menuButton = document.createElement("button");
          ua(h, h._menuButton, "menu");
          h._toolBar.appendChild(h._menuButton);
          S(h._menuButton, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers);
          S(h._menuButton, "click", function() {
            "none" !== h._dropdownMenu.style.display || h._dropDownCloseTime && 500 >= (/* @__PURE__ */ new Date()).getTime() - h._dropDownCloseTime.getTime() || (h._dropdownMenu.style.display = "block", h._menuButton.blur(), h._dropdownMenu.focus());
          }, h.allDOMEventHandlers, true);
          S(h._menuButton, "mousemove", function() {
            n || (Y(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColorOnHover, color: h.toolbar.fontColorOnHover }), 0 >= navigator.userAgent.search("MSIE") && Y(h._menuButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
          }, h.allDOMEventHandlers, true);
          S(
            h._menuButton,
            "mouseout",
            function() {
              n || (Y(h._menuButton, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), 0 >= navigator.userAgent.search("MSIE") && Y(h._menuButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
            },
            h.allDOMEventHandlers,
            true
          );
        }
        if (h.exportEnabled && h._dropdownMenu) {
          Y(h._dropdownMenu, { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor });
          for (var m2 = h._dropdownMenu.childNodes, $ = [h._cultureInfo.printText, h._cultureInfo.saveJPGText, h._cultureInfo.savePNGText], ja = 0; ja < m2.length; ja++)
            Y(m2[ja], { backgroundColor: h.toolbar.itemBackgroundColor, color: h.toolbar.fontColor }), m2[ja].innerHTML = $[ja];
        } else
          !h._dropdownMenu && (h.exportEnabled && t) && (n = false, h._dropdownMenu = document.createElement("div"), h._dropdownMenu.setAttribute("tabindex", -1), m2 = -1 !== h.theme.indexOf("dark") ? "black" : "#888888", Y(h._dropdownMenu, {
            position: "absolute",
            zIndex: 1,
            userSelect: "none",
            MozUserSeelct: "none",
            WebkitUserSelect: "none",
            msUserSelect: "none",
            cursor: "pointer",
            right: "0px",
            top: "25px",
            minWidth: "120px",
            outline: 0,
            fontSize: "14px",
            fontFamily: "Arial, Helvetica, sans-serif",
            padding: "5px 0px 5px 0px",
            textAlign: "left",
            lineHeight: "10px",
            backgroundColor: h.toolbar.itemBackgroundColor,
            boxShadow: "2px 2px 10px" + m2
          }), h._dropdownMenu.style.display = "none", h._toolBar.appendChild(h._dropdownMenu), S(h._dropdownMenu, "blur", function() {
            ya(h._dropdownMenu);
            h._dropDownCloseTime = /* @__PURE__ */ new Date();
          }, h.allDOMEventHandlers, true), m2 = document.createElement("div"), Y(m2, { padding: "12px 8px 12px 8px" }), m2.innerHTML = h._cultureInfo.printText, m2.style.backgroundColor = h.toolbar.itemBackgroundColor, m2.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(m2), S(m2, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers), S(m2, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), S(m2, "mouseout", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
          }, h.allDOMEventHandlers, true), S(m2, "click", function() {
            h.print();
            ya(h._dropdownMenu);
          }, h.allDOMEventHandlers, true), m2 = document.createElement("div"), Y(m2, { padding: "12px 8px 12px 8px" }), m2.innerHTML = h._cultureInfo.saveJPGText, m2.style.backgroundColor = h.toolbar.itemBackgroundColor, m2.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(m2), S(m2, "touchstart", function(h2) {
            n = true;
          }, h.allDOMEventHandlers), S(m2, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), S(
            m2,
            "mouseout",
            function() {
              n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
            },
            h.allDOMEventHandlers,
            true
          ), S(m2, "click", function() {
            h.exportChart({ format: "jpeg", fileName: h.exportFileName });
            ya(h._dropdownMenu);
          }, h.allDOMEventHandlers, true), m2 = document.createElement("div"), Y(m2, { padding: "12px 8px 12px 8px" }), m2.innerHTML = h._cultureInfo.savePNGText, m2.style.backgroundColor = h.toolbar.itemBackgroundColor, m2.style.color = h.toolbar.fontColor, h._dropdownMenu.appendChild(m2), S(
            m2,
            "touchstart",
            function(h2) {
              n = true;
            },
            h.allDOMEventHandlers
          ), S(m2, "mousemove", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColorOnHover, this.style.color = h.toolbar.fontColorOnHover);
          }, h.allDOMEventHandlers, true), S(m2, "mouseout", function() {
            n || (this.style.backgroundColor = h.toolbar.itemBackgroundColor, this.style.color = h.toolbar.fontColor);
          }, h.allDOMEventHandlers, true), S(m2, "click", function() {
            h.exportChart({ format: "png", fileName: h.exportFileName });
            ya(h._dropdownMenu);
          }, h.allDOMEventHandlers, true));
      }
      function $a(h, n, m2) {
        h *= na;
        n *= na;
        h = m2.getImageData(h, n, 2, 2).data;
        n = true;
        for (m2 = 0; 4 > m2; m2++)
          if (h[m2] !== h[m2 + 4] | h[m2] !== h[m2 + 8] | h[m2] !== h[m2 + 12]) {
            n = false;
            break;
          }
        return n ? h[0] << 16 | h[1] << 8 | h[2] : 0;
      }
      function oa(h, n, m2) {
        return h in n ? n[h] : m2[h];
      }
      function Na(h, n, P, $) {
        t && ab ? ($ = !m($) && $ ? h.getContext("2d", { willReadFrequently: true }) : h.getContext("2d"), Oa = $.webkitBackingStorePixelRatio || $.mozBackingStorePixelRatio || $.msBackingStorePixelRatio || $.oBackingStorePixelRatio || $.backingStorePixelRatio || 1, na = Sa / Oa, h.width = n * na, h.height = P * na, Sa !== Oa && (h.style.width = n + "px", h.style.height = P + "px", $.scale(na, na))) : (h.width = n, h.height = P);
      }
      function ib(h) {
        if (!jb) {
          var n = false, m2 = false;
          "undefined" === typeof ra.Chart.creditHref ? (h.creditHref = ka("iuuqr;..b`ow`rkr/bnl."), h.creditText = ka("B`ow`rKR/bnl")) : (n = h.updateOption("creditText"), m2 = h.updateOption("creditHref"));
          if (h.creditHref && h.creditText) {
            h._creditLink || (h._creditLink = document.createElement("a"), h._creditLink.setAttribute("class", "canvasjs-chart-credit"), h._creditLink.setAttribute("title", "JavaScript Charts"), Y(
              h._creditLink,
              { outline: "none", margin: "0px", position: "absolute", right: "2px", top: h.height - 14 + "px", color: "dimgrey", textDecoration: "none", fontSize: "11px", fontFamily: "Calibri, Lucida Grande, Lucida Sans Unicode, Arial, sans-serif" }
            ), h._creditLink.setAttribute("tabIndex", -1), h._creditLink.setAttribute("target", "_blank"));
            if (0 === h.renderCount || n || m2)
              h._creditLink.setAttribute("href", h.creditHref), h._creditLink.innerHTML = h.creditText;
            h._creditLink && h.creditHref && h.creditText ? (h._creditLink.parentElement || h._canvasJSContainer.appendChild(h._creditLink), h._creditLink.style.top = h.height - 14 + "px") : h._creditLink.parentElement && h._canvasJSContainer.removeChild(h._creditLink);
          }
        }
      }
      function wa(h, n, m2) {
        Ia && (this.canvasCount |= 0, window.console.log(++this.canvasCount));
        var $ = document.createElement("canvas");
        $.setAttribute("class", "canvasjs-chart-canvas");
        Na($, h, n, m2);
        t || "undefined" === typeof G_vmlCanvasManager || G_vmlCanvasManager.initElement($);
        return $;
      }
      function Y(h, n) {
        for (var m2 in n)
          h.style[m2] = n[m2];
      }
      function ua(h, n, m2) {
        n.getAttribute("state") || (n.style.backgroundColor = h.toolbar.itemBackgroundColor, n.style.color = h.toolbar.fontColor, n.style.border = "none", Y(n, { WebkitUserSelect: "none", MozUserSelect: "none", msUserSelect: "none", userSelect: "none" }));
        n.getAttribute("state") !== m2 && (n.setAttribute("state", m2), n.setAttribute("type", "button"), Y(n, { padding: "5px 12px", cursor: "pointer", "float": "left", width: "40px", height: "25px", outline: "0px", verticalAlign: "baseline", lineHeight: "0" }), n.innerHTML = "<img src='" + kb[m2].image + "' alt='" + h._cultureInfo[m2 + "Text"] + "' />", Y(
          n.childNodes[0],
          { height: "95%", pointerEvents: "none" }
        ));
        n.setAttribute("title", h._cultureInfo[m2 + "Text"]);
      }
      function Ma() {
        for (var h = null, n = 0; n < arguments.length; n++)
          h = arguments[n], h.style && (h.style.display = "inline");
      }
      function ya() {
        for (var h = null, n = 0; n < arguments.length; n++)
          (h = arguments[n]) && h.style && (h.style.display = "none");
      }
      function Ta(h, n, m2, t2, ja) {
        if (null === h || "undefined" === typeof h)
          return "undefined" === typeof m2 ? n : m2;
        h = parseFloat(h.toString()) * (0 <= h.toString().indexOf("%") ? n / 100 : 1);
        "undefined" !== typeof t2 && (h = Math.min(t2, h), "undefined" !== typeof ja && (h = Math.max(ja, h)));
        return !isNaN(h) && h <= n && 0 <= h ? h : "undefined" === typeof m2 ? n : m2;
      }
      function L(h, n, t2, $, ja) {
        this._defaultsKey = h;
        this._themeOptionsKey = n;
        this._index = $;
        this.parent = ja;
        this._eventListeners = [];
        h = {};
        this.theme && m(this.parent) && m(n) && m($) ? h = m(this.predefinedThemes[this.theme]) ? this.predefinedThemes.light1 : this.predefinedThemes[this.theme] : this.parent && (this.parent.themeOptions && this.parent.themeOptions[n]) && (null === $ ? h = this.parent.themeOptions[n] : 0 < this.parent.themeOptions[n].length && ($ = Math.min(this.parent.themeOptions[n].length - 1, $), h = this.parent.themeOptions[n][$]));
        this.themeOptions = h;
        this.options = t2 ? t2 : { _isPlaceholder: true };
        this.setOptions(this.options, h);
      }
      function Fa(h, n, m2, t2, ja) {
        "undefined" === typeof ja && (ja = 0);
        this._padding = ja;
        this._x1 = h;
        this._y1 = n;
        this._x2 = m2;
        this._y2 = t2;
        this._rightOccupied = this._leftOccupied = this._bottomOccupied = this._topOccupied = this._padding;
      }
      function la(h, n) {
        la.base.constructor.call(this, "TextBlock", null, n, null, null);
        this.ctx = h;
        this._isDirty = true;
        this._wrappedText = null;
        this._initialize();
      }
      function Ua(h, n) {
        Ua.base.constructor.call(this, "Toolbar", "toolbar", n, null, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "toolbar";
      }
      function Ba(h, n) {
        Ba.base.constructor.call(this, "Title", "title", n, null, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "title";
        if (m(this.options.margin) && h.options.subtitles) {
          for (var t2 = h.options.subtitles, $ = 0; $ < t2.length; $++)
            if ((m(t2[$].horizontalAlign) && "center" === this.horizontalAlign || t2[$].horizontalAlign === this.horizontalAlign) && (m(t2[$].verticalAlign) && "top" === this.verticalAlign || t2[$].verticalAlign === this.verticalAlign) && !t2[$].dockInsidePlotArea === !this.dockInsidePlotArea) {
              this.margin = 0;
              break;
            }
        }
        "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
        this.height = this.width = null;
        this.bounds = { x1: null, y1: null, x2: null, y2: null };
      }
      function Ja(h, n, m2) {
        Ja.base.constructor.call(this, "Subtitle", "subtitles", n, m2, h);
        this.chart = h;
        this.canvas = h.canvas;
        this.ctx = this.chart.ctx;
        this.optionsName = "subtitles";
        this.isOptionsInArray = true;
        "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
        this.height = this.width = null;
        this.bounds = { x1: null, y1: null, x2: null, y2: null };
      }
      function Va() {
        this.pool = [];
      }
      function Ka(h) {
        var n;
        h && La[h] && (n = La[h]);
        Ka.base.constructor.call(this, "CultureInfo", null, n, null, null);
      }
      var Ia = false, xa = {}, t = !!document.createElement("canvas").getContext, ra = {
        Chart: {
          width: 500,
          height: 400,
          zoomEnabled: false,
          zoomType: "x",
          backgroundColor: "white",
          theme: "light1",
          animationEnabled: false,
          animationDuration: 1200,
          dataPointWidth: null,
          dataPointMinWidth: null,
          dataPointMaxWidth: null,
          colorSet: "colorSet1",
          culture: "en",
          creditText: "CanvasJS",
          interactivityEnabled: true,
          exportEnabled: false,
          exportFileName: "Chart",
          rangeChanging: null,
          rangeChanged: null,
          publicProperties: {
            title: "readWrite",
            subtitles: "readWrite",
            toolbar: "readWrite",
            toolTip: "readWrite",
            legend: "readWrite",
            axisX: "readWrite",
            axisY: "readWrite",
            axisX2: "readWrite",
            axisY2: "readWrite",
            data: "readWrite",
            options: "readWrite",
            bounds: "readOnly",
            container: "readOnly",
            selectedColorSet: "readOnly"
          }
        },
        Title: { padding: 0, text: null, verticalAlign: "top", horizontalAlign: "center", fontSize: 20, fontFamily: "Calibri", fontWeight: "normal", fontColor: "black", fontStyle: "normal", borderThickness: 0, borderColor: "black", cornerRadius: 0, backgroundColor: t ? "transparent" : null, margin: 5, wrap: true, maxWidth: null, dockInsidePlotArea: false, publicProperties: { options: "readWrite", bounds: "readOnly", chart: "readOnly" } },
        Subtitle: {
          padding: 0,
          text: null,
          verticalAlign: "top",
          horizontalAlign: "center",
          fontSize: 14,
          fontFamily: "Calibri",
          fontWeight: "normal",
          fontColor: "black",
          fontStyle: "normal",
          borderThickness: 0,
          borderColor: "black",
          cornerRadius: 0,
          backgroundColor: null,
          margin: 2,
          wrap: true,
          maxWidth: null,
          dockInsidePlotArea: false,
          publicProperties: { options: "readWrite", bounds: "readOnly", chart: "readOnly" }
        },
        Toolbar: { itemBackgroundColor: "white", itemBackgroundColorOnHover: "#2196f3", buttonBorderColor: "#2196f3", buttonBorderThickness: 1, fontColor: "black", fontColorOnHover: "white", publicProperties: { options: "readWrite", chart: "readOnly" } },
        Legend: { name: null, verticalAlign: "center", horizontalAlign: "right", fontSize: 14, fontFamily: "calibri", fontWeight: "normal", fontColor: "black", fontStyle: "normal", cursor: null, itemmouseover: null, itemmouseout: null, itemmousemove: null, itemclick: null, dockInsidePlotArea: false, reversed: false, backgroundColor: t ? "transparent" : null, borderColor: t ? "transparent" : null, borderThickness: 0, cornerRadius: 0, maxWidth: null, maxHeight: null, markerMargin: null, itemMaxWidth: null, itemWidth: null, itemWrap: true, itemTextFormatter: null, publicProperties: {
          options: "readWrite",
          bounds: "readOnly",
          chart: "readOnly"
        } },
        ToolTip: { enabled: true, shared: false, animationEnabled: true, content: null, contentFormatter: null, reversed: false, backgroundColor: t ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", borderColor: null, borderThickness: 2, cornerRadius: 5, fontSize: 14, fontColor: "black", fontFamily: "Calibri, Arial, Georgia, serif;", fontWeight: "normal", fontStyle: "italic", updated: null, hidden: null, publicProperties: { options: "readWrite", chart: "readOnly" } },
        Axis: {
          minimum: null,
          maximum: null,
          viewportMinimum: null,
          viewportMaximum: null,
          interval: null,
          intervalType: null,
          reversed: false,
          logarithmic: false,
          logarithmBase: 10,
          title: null,
          titleFontColor: "black",
          titleFontSize: 20,
          titleFontFamily: "arial",
          titleFontWeight: "normal",
          titleFontStyle: "normal",
          titleWrap: true,
          titleMaxWidth: null,
          titleBackgroundColor: t ? "transparent" : null,
          titleBorderColor: t ? "transparent" : null,
          titleBorderThickness: 0,
          titleCornerRadius: 0,
          labelAngle: 0,
          labelFontFamily: "arial",
          labelFontColor: "black",
          labelFontSize: 12,
          labelFontWeight: "normal",
          labelFontStyle: "normal",
          labelAutoFit: true,
          labelWrap: true,
          labelMaxWidth: null,
          labelFormatter: null,
          labelBackgroundColor: t ? "transparent" : null,
          labelBorderColor: t ? "transparent" : null,
          labelBorderThickness: 0,
          labelCornerRadius: 0,
          labelPlacement: "outside",
          labelTextAlign: "left",
          prefix: "",
          suffix: "",
          includeZero: false,
          tickLength: 5,
          tickColor: "black",
          tickThickness: 1,
          tickPlacement: "outside",
          lineColor: "black",
          lineThickness: 1,
          lineDashType: "solid",
          gridColor: "#A0A0A0",
          gridThickness: 0,
          gridDashType: "solid",
          interlacedColor: t ? "transparent" : null,
          valueFormatString: null,
          margin: 2,
          publicProperties: {
            options: "readWrite",
            stripLines: "readWrite",
            scaleBreaks: "readWrite",
            crosshair: "readWrite",
            bounds: "readOnly",
            chart: "readOnly"
          }
        },
        StripLine: {
          value: null,
          startValue: null,
          endValue: null,
          color: "orange",
          opacity: null,
          thickness: 2,
          lineDashType: "solid",
          label: "",
          labelPlacement: "inside",
          labelAlign: "far",
          labelWrap: true,
          labelMaxWidth: null,
          labelBackgroundColor: null,
          labelBorderColor: t ? "transparent" : null,
          labelBorderThickness: 0,
          labelCornerRadius: 0,
          labelFontFamily: "arial",
          labelFontColor: "orange",
          labelFontSize: 12,
          labelFontWeight: "normal",
          labelFontStyle: "normal",
          labelFormatter: null,
          showOnTop: false,
          publicProperties: { options: "readWrite", axis: "readOnly", bounds: "readOnly", chart: "readOnly" }
        },
        ScaleBreaks: { autoCalculate: false, collapsibleThreshold: "25%", maxNumberOfAutoBreaks: 2, spacing: 8, type: "straight", color: "#FFFFFF", fillOpacity: 0.9, lineThickness: 2, lineColor: "#E16E6E", lineDashType: "solid", publicProperties: { options: "readWrite", customBreaks: "readWrite", axis: "readOnly", autoBreaks: "readOnly", bounds: "readOnly", chart: "readOnly" } },
        Break: {
          startValue: null,
          endValue: null,
          spacing: 8,
          type: "straight",
          color: "#FFFFFF",
          fillOpacity: 0.9,
          lineThickness: 2,
          lineColor: "#E16E6E",
          lineDashType: "solid",
          publicProperties: { options: "readWrite", scaleBreaks: "readOnly", bounds: "readOnly", chart: "readOnly" }
        },
        Crosshair: { enabled: false, snapToDataPoint: false, color: "grey", opacity: null, thickness: 2, lineDashType: "solid", label: "", labelWrap: true, labelMaxWidth: null, labelBackgroundColor: t ? "grey" : null, labelBorderColor: t ? "grey" : null, labelBorderThickness: 0, labelCornerRadius: 0, labelFontFamily: t ? "Calibri, Optima, Candara, Verdana, Geneva, sans-serif" : "calibri", labelFontSize: 12, labelFontColor: "#fff", labelFontWeight: "normal", labelFontStyle: "normal", labelFormatter: null, valueFormatString: null, updated: null, hidden: null, publicProperties: { options: "readWrite", axis: "readOnly", bounds: "readOnly", chart: "readOnly" } },
        DataSeries: {
          name: null,
          dataPoints: null,
          label: "",
          bevelEnabled: false,
          highlightEnabled: true,
          cursor: "default",
          indexLabel: "",
          indexLabelPlacement: "auto",
          indexLabelOrientation: "horizontal",
          indexLabelTextAlign: "left",
          indexLabelFontColor: "black",
          indexLabelFontSize: 12,
          indexLabelFontStyle: "normal",
          indexLabelFontFamily: "Arial",
          indexLabelFontWeight: "normal",
          indexLabelBackgroundColor: null,
          indexLabelLineColor: "gray",
          indexLabelLineThickness: 1,
          indexLabelLineDashType: "solid",
          indexLabelMaxWidth: null,
          indexLabelWrap: true,
          indexLabelFormatter: null,
          lineThickness: 2,
          lineDashType: "solid",
          connectNullData: false,
          nullDataLineDashType: "dash",
          color: null,
          lineColor: null,
          risingColor: "white",
          fallingColor: "red",
          fillOpacity: null,
          startAngle: 0,
          radius: null,
          innerRadius: null,
          neckHeight: null,
          neckWidth: null,
          reversed: false,
          valueRepresents: null,
          linkedDataSeriesIndex: null,
          whiskerThickness: 2,
          whiskerDashType: "solid",
          whiskerColor: null,
          whiskerLength: null,
          stemThickness: 2,
          stemColor: null,
          stemDashType: "solid",
          upperBoxColor: "white",
          lowerBoxColor: "white",
          type: "column",
          xValueType: "number",
          axisXType: "primary",
          axisYType: "primary",
          axisXIndex: 0,
          axisYIndex: 0,
          xValueFormatString: null,
          yValueFormatString: null,
          zValueFormatString: null,
          percentFormatString: null,
          showInLegend: null,
          legendMarkerType: null,
          legendMarkerColor: null,
          legendText: null,
          legendMarkerBorderColor: t ? "transparent" : null,
          legendMarkerBorderThickness: 0,
          markerType: "circle",
          markerColor: null,
          markerSize: null,
          markerBorderColor: t ? "transparent" : null,
          markerBorderThickness: 0,
          mouseover: null,
          mouseout: null,
          mousemove: null,
          click: null,
          toolTipContent: null,
          visible: true,
          publicProperties: { options: "readWrite", axisX: "readWrite", axisY: "readWrite", chart: "readOnly" }
        },
        TextBlock: {
          x: 0,
          y: 0,
          width: null,
          height: null,
          maxWidth: null,
          maxHeight: null,
          padding: 0,
          angle: 0,
          text: "",
          horizontalAlign: "center",
          textAlign: "left",
          fontSize: 12,
          fontFamily: "calibri",
          fontWeight: "normal",
          fontColor: "black",
          fontStyle: "normal",
          borderThickness: 0,
          borderColor: "black",
          cornerRadius: 0,
          backgroundColor: null,
          textBaseline: "top"
        },
        CultureInfo: {
          decimalSeparator: ".",
          digitGroupSeparator: ",",
          zoomText: "Zoom",
          panText: "Pan",
          resetText: "Reset",
          menuText: "More Options",
          saveJPGText: "Save as JPEG",
          savePNGText: "Save as PNG",
          printText: "Print",
          days: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
          shortDays: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
          months: "January February March April May June July August September October November December".split(" "),
          shortMonths: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ")
        }
      }, La = { en: {} }, z = t ? "Trebuchet MS, Helvetica, sans-serif" : "Arial", Ga = t ? "Impact, Charcoal, sans-serif" : "Arial", Ca = {
        colorSet1: "#4F81BC #C0504E #9BBB58 #23BFAA #8064A1 #4AACC5 #F79647 #7F6084 #77A033 #33558B #E59566".split(" "),
        colorSet2: "#6D78AD #51CDA0 #DF7970 #4C9CA0 #AE7D99 #C9D45C #5592AD #DF874D #52BCA8 #8E7AA3 #E3CB64 #C77B85 #C39762 #8DD17E #B57952 #FCC26C".split(" "),
        colorSet3: "#8CA1BC #36845C #017E82 #8CB9D0 #708C98 #94838D #F08891 #0366A7 #008276 #EE7757 #E5BA3A #F2990B #03557B #782970".split(" ")
      }, E, da, Q, W, aa;
      da = "#333333";
      Q = "#000000";
      E = "#666666";
      aa = W = "#000000";
      var fa = 20, w = 14, Wa = { colorSet: "colorSet1", backgroundColor: "#FFFFFF", title: { fontFamily: Ga, fontSize: 32, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 }, subtitles: [{ fontFamily: Ga, fontSize: w, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 }], data: [{
        indexLabelFontFamily: z,
        indexLabelFontSize: w,
        indexLabelFontColor: da,
        indexLabelFontWeight: "normal",
        indexLabelLineThickness: 1
      }], axisX: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: da, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 0, gridColor: E, stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#EEEEEE",
        labelFontWeight: "normal",
        labelBackgroundColor: aa,
        color: W,
        thickness: 1,
        lineDashType: "dash"
      }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], axisX2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: da, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 0, gridColor: E, stripLines: [{
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#FF7300",
        labelFontWeight: "normal",
        labelBackgroundColor: null,
        color: "#FF7300",
        thickness: 1
      }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], axisY: [{
        titleFontFamily: z,
        titleFontSize: fa,
        titleFontColor: da,
        titleFontWeight: "normal",
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: Q,
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: E,
        tickThickness: 1,
        tickColor: E,
        gridThickness: 1,
        gridColor: E,
        stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
        crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" },
        scaleBreaks: {
          type: "zigzag",
          spacing: "2%",
          lineColor: "#BBBBBB",
          lineThickness: 1,
          lineDashType: "solid"
        }
      }], axisY2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: da, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 1, gridColor: E, stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#EEEEEE",
        labelFontWeight: "normal",
        labelBackgroundColor: aa,
        color: W,
        thickness: 1,
        lineDashType: "dash"
      }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], legend: { fontFamily: z, fontSize: 14, fontColor: da, fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" }, toolTip: { fontFamily: z, fontSize: 14, fontStyle: "normal", cornerRadius: 0, borderThickness: 1 }, toolbar: {
        itemBackgroundColor: "white",
        itemBackgroundColorOnHover: "#2196f3",
        buttonBorderColor: "#2196f3",
        buttonBorderThickness: 1,
        fontColor: "black",
        fontColorOnHover: "white"
      } };
      Q = da = "#F5F5F5";
      E = "#FFFFFF";
      W = "#40BAF1";
      aa = "#F5F5F5";
      var fa = 20, w = 14, bb = { colorSet: "colorSet2", title: { fontFamily: z, fontSize: 33, fontColor: "#3A3A3A", fontWeight: "bold", verticalAlign: "top", margin: 5 }, subtitles: [{ fontFamily: z, fontSize: w, fontColor: "#3A3A3A", fontWeight: "normal", verticalAlign: "top", margin: 5 }], data: [{ indexLabelFontFamily: z, indexLabelFontSize: w, indexLabelFontColor: "#666666", indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }], axisX: [{
        titleFontFamily: z,
        titleFontSize: fa,
        titleFontColor: "#666666",
        titleFontWeight: "normal",
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#666666",
        labelFontWeight: "normal",
        lineThickness: 1,
        lineColor: "#BBBBBB",
        tickThickness: 1,
        tickColor: "#BBBBBB",
        gridThickness: 1,
        gridColor: "#BBBBBB",
        stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FFA500", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FFA500", thickness: 1 }],
        crosshair: {
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#EEEEEE",
          labelFontWeight: "normal",
          labelBackgroundColor: "black",
          color: "black",
          thickness: 1,
          lineDashType: "dot"
        },
        scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" }
      }], axisX2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: "#666666", titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: "#666666", labelFontWeight: "normal", lineThickness: 1, lineColor: "#BBBBBB", tickColor: "#BBBBBB", tickThickness: 1, gridThickness: 1, gridColor: "#BBBBBB", stripLines: [{
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#FFA500",
        labelFontWeight: "normal",
        labelBackgroundColor: null,
        color: "#FFA500",
        thickness: 1
      }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: "black", color: "black", thickness: 1, lineDashType: "dot" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], axisY: [{
        titleFontFamily: z,
        titleFontSize: fa,
        titleFontColor: "#666666",
        titleFontWeight: "normal",
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#666666",
        labelFontWeight: "normal",
        lineThickness: 0,
        lineColor: "#BBBBBB",
        tickColor: "#BBBBBB",
        tickThickness: 1,
        gridThickness: 1,
        gridColor: "#BBBBBB",
        stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FFA500", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FFA500", thickness: 1 }],
        crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#EEEEEE", labelFontWeight: "normal", labelBackgroundColor: "black", color: "black", thickness: 1, lineDashType: "dot" },
        scaleBreaks: {
          type: "zigzag",
          spacing: "2%",
          lineColor: "#BBBBBB",
          lineThickness: 1,
          lineDashType: "solid"
        }
      }], axisY2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: "#666666", titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: "#666666", labelFontWeight: "normal", lineThickness: 0, lineColor: "#BBBBBB", tickColor: "#BBBBBB", tickThickness: 1, gridThickness: 1, gridColor: "#BBBBBB", stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FFA500", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FFA500", thickness: 1 }], crosshair: {
        labelFontFamily: z,
        labelFontSize: w,
        labelFontColor: "#EEEEEE",
        labelFontWeight: "normal",
        labelBackgroundColor: "black",
        color: "black",
        thickness: 1,
        lineDashType: "dot"
      }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#BBBBBB", lineThickness: 1, lineDashType: "solid" } }], legend: { fontFamily: z, fontSize: 14, fontColor: "#3A3A3A", fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" }, toolTip: { fontFamily: z, fontSize: 14, fontStyle: "normal", cornerRadius: 0, borderThickness: 1 }, toolbar: {
        itemBackgroundColor: "white",
        itemBackgroundColorOnHover: "#2196f3",
        buttonBorderColor: "#2196f3",
        buttonBorderThickness: 1,
        fontColor: "black",
        fontColorOnHover: "white"
      } };
      Q = da = "#F5F5F5";
      E = "#FFFFFF";
      W = "#40BAF1";
      aa = "#F5F5F5";
      fa = 20;
      w = 14;
      Ga = {
        colorSet: "colorSet12",
        backgroundColor: "#2A2A2A",
        title: { fontFamily: Ga, fontSize: 32, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 },
        subtitles: [{ fontFamily: Ga, fontSize: w, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 }],
        toolbar: {
          itemBackgroundColor: "#666666",
          itemBackgroundColorOnHover: "#FF7372",
          buttonBorderColor: "#FF7372",
          buttonBorderThickness: 1,
          fontColor: "#F5F5F5",
          fontColorOnHover: "#F5F5F5"
        },
        data: [{ indexLabelFontFamily: z, indexLabelFontSize: w, indexLabelFontColor: Q, indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }],
        axisX: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 0, gridColor: E, stripLines: [{
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisX2: [{
          titleFontFamily: z,
          titleFontSize: fa,
          titleFontColor: Q,
          titleFontWeight: "normal",
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: Q,
          labelFontWeight: "normal",
          lineThickness: 1,
          lineColor: E,
          tickThickness: 1,
          tickColor: E,
          gridThickness: 0,
          gridColor: E,
          stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
          crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" },
          scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
        }],
        axisY: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 1, gridColor: E, stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#000000",
          labelFontWeight: "normal",
          labelBackgroundColor: aa,
          color: W,
          thickness: 1,
          lineDashType: "dash"
        }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisY2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 1, gridColor: E, stripLines: [{
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        legend: { fontFamily: z, fontSize: 14, fontColor: da, fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" },
        toolTip: {
          fontFamily: z,
          fontSize: 14,
          fontStyle: "normal",
          cornerRadius: 0,
          borderThickness: 1,
          fontColor: Q,
          backgroundColor: "rgba(0, 0, 0, .7)"
        }
      };
      E = "#FFFFFF";
      Q = da = "#FAFAFA";
      W = "#40BAF1";
      aa = "#F5F5F5";
      var fa = 20, w = 14, cb = { light1: Wa, light2: bb, dark1: Ga, dark2: {
        colorSet: "colorSet2",
        backgroundColor: "#32373A",
        title: { fontFamily: z, fontSize: 32, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 },
        subtitles: [{ fontFamily: z, fontSize: w, fontColor: da, fontWeight: "normal", verticalAlign: "top", margin: 5 }],
        toolbar: {
          itemBackgroundColor: "#666666",
          itemBackgroundColorOnHover: "#FF7372",
          buttonBorderColor: "#FF7372",
          buttonBorderThickness: 1,
          fontColor: "#F5F5F5",
          fontColorOnHover: "#F5F5F5"
        },
        data: [{ indexLabelFontFamily: z, indexLabelFontSize: w, indexLabelFontColor: Q, indexLabelFontWeight: "normal", indexLabelLineThickness: 1 }],
        axisX: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 1, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 0, gridColor: E, stripLines: [{
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisX2: [{
          titleFontFamily: z,
          titleFontSize: fa,
          titleFontColor: Q,
          titleFontWeight: "normal",
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: Q,
          labelFontWeight: "normal",
          lineThickness: 1,
          lineColor: E,
          tickThickness: 1,
          tickColor: E,
          gridThickness: 0,
          gridColor: E,
          stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }],
          crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" },
          scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" }
        }],
        axisY: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 0, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 1, gridColor: E, stripLines: [{ labelFontFamily: z, labelFontSize: w, labelFontColor: "#FF7300", labelFontWeight: "normal", labelBackgroundColor: null, color: "#FF7300", thickness: 1 }], crosshair: {
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#000000",
          labelFontWeight: "normal",
          labelBackgroundColor: aa,
          color: W,
          thickness: 1,
          lineDashType: "dash"
        }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        axisY2: [{ titleFontFamily: z, titleFontSize: fa, titleFontColor: Q, titleFontWeight: "normal", labelFontFamily: z, labelFontSize: w, labelFontColor: Q, labelFontWeight: "normal", lineThickness: 0, lineColor: E, tickThickness: 1, tickColor: E, gridThickness: 1, gridColor: E, stripLines: [{
          labelFontFamily: z,
          labelFontSize: w,
          labelFontColor: "#FF7300",
          labelFontWeight: "normal",
          labelBackgroundColor: null,
          color: "#FF7300",
          thickness: 1
        }], crosshair: { labelFontFamily: z, labelFontSize: w, labelFontColor: "#000000", labelFontWeight: "normal", labelBackgroundColor: aa, color: W, thickness: 1, lineDashType: "dash" }, scaleBreaks: { type: "zigzag", spacing: "2%", lineColor: "#777777", lineThickness: 1, lineDashType: "solid", color: "#111111" } }],
        legend: { fontFamily: z, fontSize: 14, fontColor: da, fontWeight: "bold", verticalAlign: "bottom", horizontalAlign: "center" },
        toolTip: {
          fontFamily: z,
          fontSize: 14,
          fontStyle: "normal",
          cornerRadius: 0,
          borderThickness: 1,
          fontColor: Q,
          backgroundColor: "rgba(0, 0, 0, .7)"
        }
      }, theme1: Wa, theme2: bb, theme3: Wa }, U = { numberDuration: 1, yearDuration: 314496e5, monthDuration: 2592e6, weekDuration: 6048e5, dayDuration: 864e5, hourDuration: 36e5, minuteDuration: 6e4, secondDuration: 1e3, millisecondDuration: 1, dayOfWeekFromInt: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" ") };
      (function() {
        xa.fSDec = function(h) {
          for (var n = "", m2 = 0; m2 < h.length; m2++)
            n += String.fromCharCode(Math.ceil(h.length / 57 / 5) ^ h.charCodeAt(m2));
          return n;
        };
        delete ra[xa.fSDec("Bi`su")][xa.fSDec("bsdehuIsdg")];
        xa.pro = { sCH: ra[xa.fSDec("Bi`su")][xa.fSDec("bsdehuIsdg")] };
      })();
      var gb = function() {
        var h = false;
        try {
          var n = Object.defineProperty && Object.defineProperty({}, "passive", { get: function() {
            h = true;
            return false;
          } });
          window.addEventListener && (window.addEventListener("test", null, n), window.removeEventListener("test", null, n));
        } catch (m2) {
          h = false;
        }
        return h;
      }(), Za = {}, ta = null, lb = function() {
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.backgroundColor && (this.ctx.fillStyle = this.backgroundColor, this.ctx.fillRect(0, 0, this.width, this.height));
      }, za = function(h) {
        h.width = 1;
        h.height = 1;
        h.getContext("2d") && h.getContext("2d").clearRect(0, 0, 1, 1);
      }, mb = function(h, n, m2) {
        n = Math.min(this.width, this.height);
        return Math.max("theme4" === this.theme ? 0 : 300 <= n ? 12 : 11, Math.round(n * (h / 400)));
      }, Da = function() {
        var h = /D{1,4}|M{1,4}|Y{1,4}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|f{1,3}|t{1,2}|T{1,2}|K|z{1,3}|"[^"]*"|'[^']*'/g, n = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "), m2 = "Sun Mon Tue Wed Thu Fri Sat".split(" "), t2 = "January February March April May June July August September October November December".split(" "), ja = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "), z2 = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g, D = /[^-+\dA-Z]/g;
        return function(w2, H2, O) {
          var E2 = O ? O.days : n, Z2 = O ? O.months : t2, S2 = O ? O.shortDays : m2, U2 = O ? O.shortMonths : ja;
          O = "";
          var Y2 = false;
          w2 = w2 && w2.getTime ? w2 : w2 ? new Date(w2) : /* @__PURE__ */ new Date();
          if (isNaN(w2))
            throw SyntaxError("invalid date");
          "UTC:" === H2.slice(0, 4) && (H2 = H2.slice(4), Y2 = true);
          O = Y2 ? "getUTC" : "get";
          var L2 = w2[O + "Date"](), N = w2[O + "Day"](), X = w2[O + "Month"](), a = w2[O + "FullYear"](), d = w2[O + "Hours"](), c = w2[O + "Minutes"](), b = w2[O + "Seconds"](), e = w2[O + "Milliseconds"](), g = Y2 ? 0 : w2.getTimezoneOffset();
          return O = H2.replace(h, function(r) {
            switch (r) {
              case "D":
                return L2;
              case "DD":
                return ea(L2, 2);
              case "DDD":
                return S2[N];
              case "DDDD":
                return E2[N];
              case "M":
                return X + 1;
              case "MM":
                return ea(X + 1, 2);
              case "MMM":
                return U2[X];
              case "MMMM":
                return Z2[X];
              case "Y":
                return parseInt(String(a).slice(-2));
              case "YY":
                return ea(String(a).slice(-2), 2);
              case "YYY":
                return ea(
                  String(a).slice(-3),
                  3
                );
              case "YYYY":
                return ea(a, 4);
              case "h":
                return d % 12 || 12;
              case "hh":
                return ea(d % 12 || 12, 2);
              case "H":
                return d;
              case "HH":
                return ea(d, 2);
              case "m":
                return c;
              case "mm":
                return ea(c, 2);
              case "s":
                return b;
              case "ss":
                return ea(b, 2);
              case "f":
                return ea(String(e), 3).slice(0, 1);
              case "ff":
                return ea(String(e), 3).slice(0, 2);
              case "fff":
                return ea(String(e), 3).slice(0, 3);
              case "t":
                return 12 > d ? "a" : "p";
              case "tt":
                return 12 > d ? "am" : "pm";
              case "T":
                return 12 > d ? "A" : "P";
              case "TT":
                return 12 > d ? "AM" : "PM";
              case "K":
                return Y2 ? "UTC" : (String(w2).match(z2) || [""]).pop().replace(D, "");
              case "z":
                return (0 < g ? "-" : "+") + Math.floor(Math.abs(g) / 60);
              case "zz":
                return (0 < g ? "-" : "+") + ea(Math.floor(Math.abs(g) / 60), 2);
              case "zzz":
                return (0 < g ? "-" : "+") + ea(Math.floor(Math.abs(g) / 60), 2) + ea(Math.abs(g) % 60, 2);
              default:
                return r.slice(1, r.length - 1);
            }
          });
        };
      }(), nb = function(h) {
        var n = 0 > h;
        if (1 > Math.abs(h)) {
          var m2 = parseInt(h.toString().split("e-")[1]);
          m2 && (h = (n ? -1 * h : h) * Math.pow(10, m2 - 1), h = "0." + Array(m2).join("0") + h.toString().substring(2), h = n ? "-" + h : h);
        } else
          m2 = parseInt(h.toString().split("+")[1]), 20 < m2 && (m2 -= 20, h /= Math.pow(10, m2), h = h.toString() + Array(m2 + 1).join("0"));
        return String(h);
      }, ga = function(h, n, m2) {
        if (null === h)
          return "";
        if (!isFinite(h))
          return h;
        h = Number(h);
        var t2 = 0 > h ? true : false;
        t2 && (h *= -1);
        var z2 = m2 ? m2.decimalSeparator : ".", w2 = m2 ? m2.digitGroupSeparator : ",", D = "";
        n = String(n);
        var D = 1, H2 = m2 = "", E2 = -1, O = [], Z2 = [], S2 = 0, U2 = 0, Y2 = 0, L2 = false, Q2 = 0, H2 = n.match(/"[^"]*"|'[^']*'|[eE][+-]*[0]+|[,]+[.]|\u2030|./g);
        n = null;
        for (var N = 0; H2 && N < H2.length; N++)
          if (n = H2[N], "." === n && 0 > E2)
            E2 = N;
          else {
            if ("%" === n)
              D *= 100;
            else if ("‰" === n) {
              D *= 1e3;
              continue;
            } else if ("," === n[0] && "." === n[n.length - 1]) {
              D /= Math.pow(1e3, n.length - 1);
              E2 = N + n.length - 1;
              continue;
            } else
              "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || (L2 = true);
            0 > E2 ? (O.push(n), "#" === n || "0" === n ? S2++ : "," === n && Y2++) : (Z2.push(n), "#" !== n && "0" !== n || U2++);
          }
        L2 && (n = Math.floor(h), H2 = -Math.floor(Math.log(h) / Math.LN10 + 1), Q2 = 0 === h ? 0 : 0 === n ? -(S2 + H2) : nb(n).length - S2, D /= Math.pow(10, Q2));
        0 > E2 && (E2 = N);
        D = (h * D).toFixed(U2);
        n = D.split(".");
        D = (n[0] + "").split("");
        h = (n[1] + "").split("");
        D && "0" === D[0] && D.shift();
        for (L2 = H2 = N = U2 = E2 = 0; 0 < O.length; )
          if (n = O.pop(), "#" === n || "0" === n)
            if (E2++, E2 === S2) {
              var X = D, D = [];
              if ("0" === n)
                for (n = S2 - U2 - (X ? X.length : 0); 0 < n; )
                  X.unshift("0"), n--;
              for (; 0 < X.length; )
                m2 = X.pop() + m2, L2++, 0 === L2 % H2 && (N === Y2 && 0 < X.length) && (m2 = w2 + m2);
            } else
              0 < D.length ? (m2 = D.pop() + m2, U2++, L2++) : "0" === n && (m2 = "0" + m2, U2++, L2++), 0 === L2 % H2 && (N === Y2 && 0 < D.length) && (m2 = w2 + m2);
          else
            "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || !/[eE][+-]*[0]+/.test(n) ? "," === n ? (N++, H2 = L2, L2 = 0, 0 < D.length && (m2 = w2 + m2)) : m2 = 1 < n.length && ('"' === n[0] && '"' === n[n.length - 1] || "'" === n[0] && "'" === n[n.length - 1]) ? n.slice(1, n.length - 1) + m2 : n + m2 : (n = 0 > Q2 ? n.replace(
              "+",
              ""
            ).replace("-", "") : n.replace("-", ""), m2 += n.replace(/[0]+/, function(a) {
              return ea(Q2, a.length);
            }));
        w2 = "";
        for (O = false; 0 < Z2.length; )
          n = Z2.shift(), "#" === n || "0" === n ? 0 < h.length && 0 !== Number(h.join("")) ? (w2 += h.shift(), O = true) : "0" === n && (w2 += "0", O = true) : 1 < n.length && ('"' === n[0] && '"' === n[n.length - 1] || "'" === n[0] && "'" === n[n.length - 1]) ? w2 += n.slice(1, n.length - 1) : "E" !== n[0] && "e" !== n[0] || "0" !== n[n.length - 1] || !/[eE][+-]*[0]+/.test(n) ? w2 += n : (n = 0 > Q2 ? n.replace("+", "").replace("-", "") : n.replace("-", ""), w2 += n.replace(/[0]+/, function(a) {
            return ea(
              Q2,
              a.length
            );
          }));
        m2 += (O ? z2 : "") + w2;
        return t2 ? "-" + m2 : m2;
      }, Pa = function(h) {
        var n = 0, m2 = 0;
        h = h || window.event;
        h.offsetX || 0 === h.offsetX ? (n = h.offsetX, m2 = h.offsetY) : h.layerX || 0 == h.layerX ? (n = h.layerX, m2 = h.layerY) : (n = h.pageX - h.target.offsetLeft, m2 = h.pageY - h.target.offsetTop);
        return { x: n, y: m2 };
      }, ab = true, Sa = window.devicePixelRatio || 1, Oa = 1, na = ab ? Sa / Oa : 1, ba = function(h, n, m2, t2, w2, z2, D, H2, E2, O, Z2, U2, S2) {
        "undefined" === typeof S2 && (S2 = 1);
        D = D || 0;
        H2 = H2 || "black";
        var L2 = 15 < t2 - n && 15 < w2 - m2 ? 8 : 0.35 * Math.min(t2 - n, w2 - m2);
        h.beginPath();
        h.moveTo(n, m2);
        h.save();
        h.fillStyle = z2;
        h.globalAlpha = S2;
        h.fillRect(n, m2, t2 - n, w2 - m2);
        h.globalAlpha = 1;
        0 < D && (S2 = 0 === D % 2 ? 0 : 0.5, h.beginPath(), h.lineWidth = D, h.strokeStyle = H2, h.moveTo(n, m2), h.rect(n - S2, m2 - S2, t2 - n + 2 * S2, w2 - m2 + 2 * S2), h.stroke());
        h.restore();
        true === E2 && (h.save(), h.beginPath(), h.moveTo(n, m2), h.lineTo(n + L2, m2 + L2), h.lineTo(t2 - L2, m2 + L2), h.lineTo(t2, m2), h.closePath(), D = h.createLinearGradient((t2 + n) / 2, m2 + L2, (t2 + n) / 2, m2), D.addColorStop(0, z2), D.addColorStop(1, "rgba(255, 255, 255, .4)"), h.fillStyle = D, h.fill(), h.restore());
        true === O && (h.save(), h.beginPath(), h.moveTo(n, w2), h.lineTo(n + L2, w2 - L2), h.lineTo(t2 - L2, w2 - L2), h.lineTo(t2, w2), h.closePath(), D = h.createLinearGradient((t2 + n) / 2, w2 - L2, (t2 + n) / 2, w2), D.addColorStop(0, z2), D.addColorStop(1, "rgba(255, 255, 255, .4)"), h.fillStyle = D, h.fill(), h.restore());
        true === Z2 && (h.save(), h.beginPath(), h.moveTo(n, m2), h.lineTo(n + L2, m2 + L2), h.lineTo(n + L2, w2 - L2), h.lineTo(n, w2), h.closePath(), D = h.createLinearGradient(n + L2, (w2 + m2) / 2, n, (w2 + m2) / 2), D.addColorStop(0, z2), D.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = D, h.fill(), h.restore());
        true === U2 && (h.save(), h.beginPath(), h.moveTo(
          t2,
          m2
        ), h.lineTo(t2 - L2, m2 + L2), h.lineTo(t2 - L2, w2 - L2), h.lineTo(t2, w2), D = h.createLinearGradient(t2 - L2, (w2 + m2) / 2, t2, (w2 + m2) / 2), D.addColorStop(0, z2), D.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = D, D.addColorStop(0, z2), D.addColorStop(1, "rgba(255, 255, 255, 0.1)"), h.fillStyle = D, h.fill(), h.closePath(), h.restore());
      }, ka = function(h) {
        for (var m2 = "", t2 = 0; t2 < h.length; t2++)
          m2 += String.fromCharCode(Math.ceil(h.length / 57 / 5) ^ h.charCodeAt(t2));
        return m2;
      }, jb = window && (window[ka("mnb`uhno")] && window[ka("mnb`uhno")].href && window[ka("mnb`uhno")].href.indexOf && (-1 !== window[ka("mnb`uhno")].href.indexOf(ka("b`ow`rkr/bnl")) || -1 !== window[ka("mnb`uhno")].href.indexOf(ka("gdonqhy/bnl")) || -1 !== window[ka("mnb`uhno")].href.indexOf(ka("gheemd")))) && -1 === window[ka("mnb`uhno")].href.indexOf(ka("gheemd")), kb = {
        reset: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAeCAYAAABJ/8wUAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAPjSURBVFhHxVdJaFNRFP1J/jwkP5MxsbaC1WJEglSxOFAXIsFpVRE3ggi1K90obioRRBA33XXnQnciirhQcMCdorgQxBkXWlREkFKsWkv5npvckp/XnzRpKh64kLw733fffe9L/wrL0+mVUdO8uTSZ3MBL/we2qg4rkuSpodCELstXE46ziVkLQ6FQcGOmeSSq6wd4aV50d3drWjj8kQKZJTUc9kxFGenv79dZrDksTSTWWJp2QYtEPiErysyzdX0LsxsCQR8keX8gs6RHIk8ysdgKFg2G53mhuOPsshTlBjKaFo1g7SqLNoShKLdFXT8huQ/paLSbxatYnc2mHMM4hr18Vi8TIvCmXF3vYrW6cF23gGTOk0M1wA4RKvOmq6vLZRVJipvmSWT6tZ6CSEYkco5V50VPT4+D7RwOqi6RiSZm0fJ+vggSqkeoypdsNmuyelNwbXsbgvkWYMtzDWNvWaijoyOBqE+hVK8abcssUeXQ/YfKyi0gFYv1Ipgfoj34fYGTJLOYJA0ODirok32GLN8XhUWCwSes1hIwBg6LydJ/tEeRRapAdUp+wSAiZchtZZWWgAZ+JNpD8peYXQVK9UwUxNpzOK8pq97kURZhYTCKBwPD7h2zK+js7Myi7D8Fod+0TkMI8+EMAngLGc/WtBFWawkFHFnoj/t9KLgGmF0B3QfkxC+EarxkdhnFYlFLY06USqUwL7UMjICHfh/wOc2sCqhpxGbCkLvL7EUDbF73+6DkmVWB6zi7xUDQSLeYvWjAILvm9zEnkJhlbRcDQZcv6Kg2AipyT/Axw6wKlqVSqxDdjF8Izfod13qURdrG/nxehY+xGh+h0CSzKygGvSNQIcc097BI24jb9hax6kj2E7OrMFX1il+ICEf2NrPbhiXLl+fYl+U7zK4iYdsDcyLGf+ofFlkwcN+s10KhmpuYhhtm0hCLVIFL0MDsqNlDIqy9x2CLs1jL6OvrI7vPRbtohXG6eFmsFnHDGAp6n9AgyuVySRZrGvROxRgIfLXhzjrNYnNBUxNX/dMgRWT1mt4XLDovaApD53E9W3ilNX5M55LJHpRtIsgAvciR4WWcgK2Dvb1YqgXevmF8z2zEBTcKG39EfSKsT9EbhVUaI2FZO+oZIqImxol6j66/hcAu4sSN4vc1ZPoKeoE6RGhYL2YYA+ymOSSi0Z0wWntbtkGUWCvfSDXIxONraZ/FY90KUfNTpfC5spnNLgxoYNnR9RO4F8ofXEHOgogCQE99w+fF2Xw+b7O59rEOsyRqGEfpVoaDMQQ1CZrG46bcM6AZ0C/wPqNfHliqejyTySxh9TqQpL+xmbIlkB9SlAAAAABJRU5ErkJggg==" },
        pan: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAICSURBVEhLxZbPahNRGMUn/5MpuAiBEAIufQGfzr5E40YptBXajYzudCEuGqS+gGlrFwquDGRTutBdYfydzJ3LzeQmJGZue+Dw/Z17Mnfmu5Pof9Hr9Z61Wq0bWZMKj263O6xWq99wU9lOpzPMKgEhEcRucNOcioOK+0RzBhNvt9tPV4nmVF19+OWhVqt9xXgFXZq+8lCv119UKpUJ7iX2FmvFTKz8RH34YdBsNk8wVtjE4fGYwm8wrrDi3WBG5oKXZGRSS9hGuNFojLTe2lFz5xThWZIktayyiE2FdT3rzXBXz7krKiL8c17wAKFDjCus2AvW+YGZ9y2JF0VFRuMPfI//rsCE/C+s26s4gQu9ul7r4NteKx7H8XOC724xNNGbaNu++IrBqbOV7Tj3FgMRvc/YKOr3+3sE47wgEt/Bl/gaK5cHbNU11vYSXylfpK7XOvjuumPp4Wcoipu30Qsez2uMXYz4lfI+mOmwothY+SLiXJy7mKVpWs3Si0CoOMfeI9Od43Wic+jO+ZVv+crsm9QSNhUW9LXSeoPBYLXopthGuFQgdIxxhY+UDwlt1x5CZ1hX+NTUdt/OIvjKaDSmuOJfaIVNPKX+W18j/PLA2/kR44p5Sd8HbHngT/yTfNRWUXX14ZcL3wmX0+TLf8YO7CGT8yFE5zB3/gney25/OETRP9CtPDFe5jShAAAAAElFTkSuQmCC" },
        zoom: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAALWSURBVEhLvZZLaBNRFIabyftBIgEfqCCBoCC6MYqiXYiIj4U76U4X7sUHbhQhUBfixhZEUBDB16YuFERaUaQLK7ooCOJj4UKtYEFU0EptShO/A9Ph3js3k8lo/eHnP7n3nP/M3LlzMz1hkUwmNziOcyKRSFyFt+LxeD/c2Wq1Ym7Kv0M2m11Os1OxWGycn1OwZXCGuXfwIhezkd9/jRgNT2L4ldhs1pbkX5OLJe4euVxuGQaPCa3mnUjtJx7BDuKusJTCV6jVVGHTMuYRjxma7yIOhTgFY6jNaAKew2xPKpVay9ganmkvj+M448/MfJdT5K5Gg4HJacRngPFgqVRaRNwW1B4i7yehWfsEDdz1K+A01AoxPIqGAiuwGfkOTY8+1A6u7AyiFTB2Hu0KPIrdiOnzHLWDybeImvy+Wq2mZa5bUHsD0Zpz+KxHdWQymV6kAb1ElqeORgJLvgnRdj1+R1AfzkIvSUjxVjQSarVakrueIPT8+H1F5jSUy+WXiJrUYBVWyVxU4PEU8TzhfaijUqnMIWrjaY492eWRwdKOIqrnIxnXwLLeRLwk2GQzrEMjg0avEbXxkIxr4OoOImpj2QwyFgms1koa/SZUG8s+0iGnEhNfCNXEhzIXBVz0McTzEvJ+70P9oNFtxEzei3aFYrFYxmuSUPWSv9Yi9IMm2xE1We56Mp1OV4nDwqFmBDV9gk9AEh4gZtFHNt8W4kAUCoXF5MorY9Z/kDni9nDv7hc0i2fhgLvTtX8a99PoMPPagTFPxofRzmDJ9yM+AyEmTfgGysYbQcfhDzPPJDmX0c7gDg4gs9BqFIWhm/Nct5H8gtBq1I7UfIbtvmIuoaGQcp+fdpbbSM43eEH5wrwLbXmhm/fU63VHXjcuok7hEByFY/AeHGC8L5/PL3HT5xGH1uYwfPOICGo+CBcU0vwO1BqzUqILDl/z/9VYIMfpddiAc47jDP8BsUpb13wOLRwAAAAASUVORK5CYII=" },
        menu: { image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAeCAYAAABE4bxTAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADoSURBVFhH7dc9CsJAFATgRxIIBCwCqZKATX5sbawsY2MvWOtF9AB6AU8gguAJbD2AnZ2VXQT/Ko2TYGCL2OYtYQc+BuYA+1hCtnCVwMm27SGaXpDJIAiCvCkVR05hGOZNN3HkFMdx3nQRR06+76/R1IcFLJlNQEWlmWlBTwJtKLKHynehZqnjOGM0PYWRVXk61C37p7xlZ3Hk5HneCk1dmMH811xGoKLSzDiQwIBZB4ocoPJdqNkDt2yKlueWRVGUtzy3rPwo3sWRU3nLjuLI6OO67oZM00wMw3hrmpZx0XU9syxrR0T0BeMpb9dneSR2AAAAAElFTkSuQmCC" }
      };
      L.prototype.setOptions = function(h, m2) {
        if (ra[this._defaultsKey]) {
          var t2 = ra[this._defaultsKey], w2;
          for (w2 in t2)
            "publicProperties" !== w2 && t2.hasOwnProperty(w2) && (this[w2] = h && w2 in h ? h[w2] : m2 && w2 in m2 ? m2[w2] : t2[w2]);
        } else
          Ia && window.console && console.log("defaults not set");
      };
      L.prototype.get = function(h) {
        var m2 = ra[this._defaultsKey];
        if ("options" === h)
          return this.options && this.options._isPlaceholder ? null : this.options;
        if (m2.hasOwnProperty(h) || m2.publicProperties && m2.publicProperties.hasOwnProperty(h))
          return this[h];
        window.console && window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`);
      };
      L.prototype.set = function(h, m2, t2) {
        t2 = "undefined" === typeof t2 ? true : t2;
        var w2 = ra[this._defaultsKey];
        if ("options" === h)
          this.createUserOptions(m2);
        else if (w2.hasOwnProperty(h) || w2.publicProperties && w2.publicProperties.hasOwnProperty(h) && "readWrite" === w2.publicProperties[h])
          this.options._isPlaceholder && this.createUserOptions(), this.options[h] = m2;
        else {
          window.console && (w2.publicProperties && w2.publicProperties.hasOwnProperty(h) && "readOnly" === w2.publicProperties[h] ? window.console.log('Property "' + h + '" is read-only.') : window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`));
          return;
        }
        t2 && (this.stockChart || this.chart || this).render();
      };
      L.prototype.addTo = function(h, m2, t2, w2) {
        w2 = "undefined" === typeof w2 ? true : w2;
        var z2 = ra[this._defaultsKey];
        z2.hasOwnProperty(h) || z2.publicProperties && z2.publicProperties.hasOwnProperty(h) && "readWrite" === z2.publicProperties[h] ? (this.options._isPlaceholder && this.createUserOptions(), "undefined" === typeof this.options[h] && (this.options[h] = []), h = this.options[h], t2 = "undefined" === typeof t2 || null === t2 ? h.length : t2, h.splice(t2, 0, m2), w2 && (this.stockChart || this.chart || this).render()) : window.console && (z2.publicProperties && z2.publicProperties.hasOwnProperty(h) && "readOnly" === z2.publicProperties[h] ? window.console.log('Property "' + h + '" is read-only.') : window.console.log('Property "' + h + `" doesn't exist. Please check for typo.`));
      };
      L.prototype.createUserOptions = function(h) {
        if ("undefined" !== typeof h || this.options._isPlaceholder)
          if (this.parent.options._isPlaceholder && this.parent.createUserOptions(), this.isOptionsInArray) {
            this.parent.options[this.optionsName] || (this.parent.options[this.optionsName] = []);
            var m2 = this.parent.options[this.optionsName], t2 = m2.length;
            this.options._isPlaceholder || (Ea(m2), t2 = m2.indexOf(this.options));
            this.options = "undefined" === typeof h ? {} : h;
            m2[t2] = this.options;
          } else
            this.options = "undefined" === typeof h ? {} : h, h = this.parent.options, this.optionsName ? m2 = this.optionsName : (m2 = this._defaultsKey) && 0 !== m2.length ? (t2 = m2.charAt(0).toLowerCase(), 1 < m2.length && (t2 = t2.concat(m2.slice(1))), m2 = t2) : m2 = void 0, h[m2] = this.options;
      };
      L.prototype.remove = function(h) {
        h = "undefined" === typeof h ? true : h;
        if (this.isOptionsInArray) {
          var m2 = this.parent.options[this.optionsName];
          Ea(m2);
          var t2 = m2.indexOf(this.options);
          0 <= t2 && m2.splice(t2, 1);
        } else
          delete this.parent.options[this.optionsName];
        h && (this.stockChart || this.chart || this).render();
      };
      L.prototype.updateOption = function(h) {
        !ra[this._defaultsKey] && (Ia && window.console) && console.log("defaults not set");
        var n = ra[this._defaultsKey], t2 = {}, w2 = this[h], z2 = this._themeOptionsKey, H2 = this._index;
        this.theme && m(this.parent) && m(z2) && m(H2) ? t2 = m(this.predefinedThemes[this.theme]) ? this.predefinedThemes.light1 : this.predefinedThemes[this.theme] : this.parent && (this.parent.themeOptions && this.parent.themeOptions[z2]) && (null === H2 ? t2 = this.parent.themeOptions[z2] : 0 < this.parent.themeOptions[z2].length && (t2 = Math.min(this.parent.themeOptions[z2].length - 1, H2), t2 = this.parent.themeOptions[z2][t2]));
        this.themeOptions = t2;
        h in n && (w2 = h in this.options ? this.options[h] : t2 && h in t2 ? t2[h] : n[h]);
        if (w2 === this[h])
          return false;
        this[h] = w2;
        return true;
      };
      L.prototype.trackChanges = function(h) {
        if (!this.sessionVariables)
          throw "Session Variable Store not set";
        this.sessionVariables[h] = this.options[h];
      };
      L.prototype.isBeingTracked = function(h) {
        this.options._oldOptions || (this.options._oldOptions = {});
        return this.options._oldOptions[h] ? true : false;
      };
      L.prototype.hasOptionChanged = function(h) {
        if (!this.sessionVariables)
          throw "Session Variable Store not set";
        return this.sessionVariables[h] !== this.options[h];
      };
      L.prototype.addEventListener = function(h, m2, t2) {
        h && m2 && (this._eventListeners[h] = this._eventListeners[h] || [], this._eventListeners[h].push({ context: t2 || this, eventHandler: m2 }));
      };
      L.prototype.removeEventListener = function(h, m2) {
        if (h && m2 && this._eventListeners[h]) {
          for (var t2 = this._eventListeners[h], w2 = 0; w2 < t2.length; w2++)
            if (t2[w2].eventHandler === m2) {
              t2[w2].splice(w2, 1);
              break;
            }
        }
      };
      L.prototype.removeAllEventListeners = function() {
        this._eventListeners = [];
      };
      L.prototype.dispatchEvent = function(h, m2, t2) {
        if (h && this._eventListeners[h]) {
          m2 = m2 || {};
          for (var w2 = this._eventListeners[h], z2 = 0; z2 < w2.length; z2++)
            w2[z2].eventHandler.call(
              w2[z2].context,
              m2
            );
        }
        "function" === typeof this[h] && this[h].call(t2 || this.chart, m2);
      };
      Fa.prototype.registerSpace = function(h, m2) {
        "top" === h ? this._topOccupied += m2.height : "bottom" === h ? this._bottomOccupied += m2.height : "left" === h ? this._leftOccupied += m2.width : "right" === h && (this._rightOccupied += m2.width);
      };
      Fa.prototype.unRegisterSpace = function(h, m2) {
        "top" === h ? this._topOccupied -= m2.height : "bottom" === h ? this._bottomOccupied -= m2.height : "left" === h ? this._leftOccupied -= m2.width : "right" === h && (this._rightOccupied -= m2.width);
      };
      Fa.prototype.getFreeSpace = function() {
        return { x1: this._x1 + this._leftOccupied, y1: this._y1 + this._topOccupied, x2: this._x2 - this._rightOccupied, y2: this._y2 - this._bottomOccupied, width: this._x2 - this._x1 - this._rightOccupied - this._leftOccupied, height: this._y2 - this._y1 - this._bottomOccupied - this._topOccupied };
      };
      Fa.prototype.reset = function() {
        this._rightOccupied = this._leftOccupied = this._bottomOccupied = this._topOccupied = this._padding;
      };
      qa(la, L);
      la.prototype._initialize = function() {
        m(this.padding) || "object" !== typeof this.padding ? this.topPadding = this.rightPadding = this.bottomPadding = this.leftPadding = Number(this.padding) | 0 : (this.topPadding = m(this.padding.top) ? 0 : Number(this.padding.top) | 0, this.rightPadding = m(this.padding.right) ? 0 : Number(this.padding.right) | 0, this.bottomPadding = m(this.padding.bottom) ? 0 : Number(this.padding.bottom) | 0, this.leftPadding = m(this.padding.left) ? 0 : Number(this.padding.left) | 0);
      };
      la.prototype.render = function(h) {
        if (0 !== this.fontSize) {
          h && this.ctx.save();
          var m2 = this.ctx.font;
          this.ctx.textBaseline = this.textBaseline;
          var t2 = 0;
          this._isDirty && this.measureText(this.ctx);
          this.ctx.translate(this.x, this.y + t2);
          "middle" === this.textBaseline && (t2 = -this._lineHeight / 2);
          this.ctx.font = this._getFontString();
          this.ctx.rotate(Math.PI / 180 * this.angle);
          var w2 = 0, z2 = this.topPadding, H2 = null;
          this.ctx.roundRect || Aa(this.ctx);
          (0 < this.borderThickness && this.borderColor || this.backgroundColor) && this.ctx.roundRect(0, t2, this.width, this.height, this.cornerRadius, this.borderThickness, this.backgroundColor, this.borderColor);
          this.ctx.fillStyle = this.fontColor;
          for (t2 = 0; t2 < this._wrappedText.lines.length; t2++) {
            H2 = this._wrappedText.lines[t2];
            if ("right" === this.horizontalAlign || "right" === this.textAlign)
              w2 = this.width - H2.width - this.rightPadding;
            else if ("left" === this.horizontalAlign || "left" === this.textAlign)
              w2 = this.leftPadding;
            else if ("center" === this.horizontalAlign || "center" === this.textAlign)
              w2 = (this.width - (this.leftPadding + this.rightPadding)) / 2 - H2.width / 2 + this.leftPadding;
            this.ctx.fillText(H2.text, w2, z2);
            z2 += H2.height;
          }
          this.ctx.font = m2;
          h && this.ctx.restore();
        }
      };
      la.prototype.setText = function(h) {
        this.text = h;
        this._isDirty = true;
        this._wrappedText = null;
      };
      la.prototype.measureText = function() {
        this._lineHeight = Ya(this.fontFamily, this.fontSize, this.fontWeight);
        if (null === this.maxWidth)
          throw "Please set maxWidth and height for TextBlock";
        this._wrapText(this.ctx);
        this._isDirty = false;
        return { width: this.width, height: this.height };
      };
      la.prototype._getLineWithWidth = function(h, m2, t2) {
        h = String(h);
        if (!h)
          return { text: "", width: 0 };
        var w2 = t2 = 0, z2 = h.length - 1, H2 = Infinity;
        for (this.ctx.font = this._getFontString(); w2 <= z2; ) {
          var H2 = Math.floor((w2 + z2) / 2), D = h.substr(0, H2 + 1);
          t2 = this.ctx.measureText(D).width;
          if (t2 < m2)
            w2 = H2 + 1;
          else if (t2 > m2)
            z2 = H2 - 1;
          else
            break;
        }
        t2 > m2 && 1 < D.length && (D = D.substr(0, D.length - 1), t2 = this.ctx.measureText(D).width);
        m2 = true;
        if (D.length === h.length || " " === h[D.length])
          m2 = false;
        m2 && (h = D.split(" "), 1 < h.length && h.pop(), D = h.join(" "), t2 = this.ctx.measureText(D).width);
        return { text: D, width: t2 };
      };
      la.prototype._wrapText = function() {
        var h = new String(Ha(String(this.text))), m2 = [], t2 = this.ctx.font, w2 = 0, z2 = 0;
        this.ctx.font = this._getFontString();
        if (0 === this.frontSize)
          z2 = w2 = 0;
        else
          for (; 0 < h.length; ) {
            var H2 = this.maxHeight - (this.topPadding + this.bottomPadding), D = this._getLineWithWidth(h, this.maxWidth - (this.leftPadding + this.rightPadding), false);
            D.height = this._lineHeight;
            m2.push(D);
            var L2 = z2, z2 = Math.max(z2, D.width), w2 = w2 + D.height, h = Ha(h.slice(D.text.length, h.length));
            H2 && w2 > H2 && (D = m2.pop(), w2 -= D.height, z2 = L2);
          }
        this._wrappedText = { lines: m2, width: z2, height: w2 };
        this.width = z2 + (this.leftPadding + this.rightPadding);
        this.height = w2 + (this.topPadding + this.bottomPadding);
        this.ctx.font = t2;
      };
      la.prototype._getFontString = function() {
        var h;
        h = this.fontStyle ? this.fontStyle + " " : "";
        h += this.fontWeight ? this.fontWeight + " " : "";
        h += this.fontSize ? this.fontSize + "px " : "";
        var m2 = this.fontFamily ? this.fontFamily + "" : "";
        !t && m2 && (m2 = m2.split(",")[0], "'" !== m2[0] && '"' !== m2[0] && (m2 = "'" + m2 + "'"));
        return h += m2;
      };
      qa(Ua, L);
      qa(Ba, L);
      Ba.prototype.setLayout = function() {
        if (this.text) {
          var h = this.dockInsidePlotArea ? this.chart.plotArea : this.chart, n = h.layoutManager.getFreeSpace(), t2 = n.x1, w2 = n.y1, z2 = 0, H2 = 0, D = this.chart._menuButton && this.chart.exportEnabled && "top" === this.verticalAlign ? 40 : 0, L2, E2;
          "top" === this.verticalAlign || "bottom" === this.verticalAlign ? (null === this.maxWidth && (this.maxWidth = n.width - 4 - D * ("center" === this.horizontalAlign ? 2 : 1)), H2 = 0.5 * n.height - this.margin - 2, z2 = 0) : "center" === this.verticalAlign && ("left" === this.horizontalAlign || "right" === this.horizontalAlign ? (null === this.maxWidth && (this.maxWidth = n.height - 4), H2 = 0.5 * n.width - this.margin - 2) : "center" === this.horizontalAlign && (null === this.maxWidth && (this.maxWidth = n.width - 4), H2 = 0.5 * n.height - 4));
          var O;
          m(this.padding) || "number" !== typeof this.padding ? m(this.padding) || "object" !== typeof this.padding || (O = this.padding.top ? this.padding.top : this.padding.bottom ? this.padding.bottom : 0, O += this.padding.bottom ? this.padding.bottom : this.padding.top ? this.padding.top : 0) : O = 2 * this.padding;
          this.wrap || (H2 = Math.min(H2, 1.5 * this.fontSize + O));
          H2 = new la(this.ctx, {
            fontSize: this.fontSize,
            fontFamily: this.fontFamily,
            fontColor: this.fontColor,
            fontStyle: this.fontStyle,
            fontWeight: this.fontWeight,
            horizontalAlign: this.horizontalAlign,
            textAlign: this.horizontalAlign,
            verticalAlign: this.verticalAlign,
            borderColor: this.borderColor,
            borderThickness: this.borderThickness,
            backgroundColor: this.backgroundColor,
            maxWidth: this.maxWidth,
            maxHeight: H2,
            cornerRadius: this.cornerRadius,
            text: this.text,
            padding: this.padding,
            textBaseline: "middle"
          });
          O = H2.measureText();
          "top" === this.verticalAlign || "bottom" === this.verticalAlign ? ("top" === this.verticalAlign ? (w2 = n.y1 + 2 + this.fontSize / 2 + 4, E2 = "top") : "bottom" === this.verticalAlign && (w2 = n.y2 - 2 - O.height + this.fontSize / 2 + 4, E2 = "bottom"), "left" === this.horizontalAlign ? t2 = n.x1 + 2 : "center" === this.horizontalAlign ? t2 = n.x1 + n.width / 2 - O.width / 2 : "right" === this.horizontalAlign && (t2 = n.x2 - 2 - O.width - D), L2 = this.horizontalAlign, this.width = O.width, this.height = O.height) : "center" === this.verticalAlign && ("left" === this.horizontalAlign ? (t2 = n.x1 + 2 + (this.fontSize / 2 + 4), w2 = n.y2 - 2 - (this.maxWidth / 2 - O.width / 2), z2 = -90, E2 = "left", this.width = O.height, this.height = O.width) : "right" === this.horizontalAlign ? (t2 = n.x2 - 2 - (this.fontSize / 2 + 4), w2 = n.y1 + 2 + (this.maxWidth / 2 - O.width / 2), z2 = 90, E2 = "right", this.width = O.height, this.height = O.width) : "center" === this.horizontalAlign && (w2 = h.y1 + (h.height / 2 - O.height / 2) + this.fontSize / 2 + 4, t2 = h.x1 + (h.width / 2 - O.width / 2), E2 = "center", this.width = O.width, this.height = O.height), L2 = "center");
          H2.x = t2;
          H2.y = w2;
          H2.angle = z2;
          H2.horizontalAlign = L2;
          this._textBlock = H2;
          h.layoutManager.registerSpace(E2, { width: this.width + ("left" === E2 || "right" === E2 ? this.margin + 2 : 0), height: this.height + ("top" === E2 || "bottom" === E2 ? this.margin + 2 : 0) });
          this.bounds = { x1: t2, y1: w2, x2: t2 + this.width, y2: w2 + this.height };
          this.ctx.textBaseline = "top";
        }
      };
      Ba.prototype.render = function() {
        this._textBlock && this._textBlock.render(true);
      };
      qa(Ja, L);
      Ja.prototype.setLayout = Ba.prototype.setLayout;
      Ja.prototype.render = Ba.prototype.render;
      Va.prototype.get = function(h, m2) {
        var t2 = null;
        0 < this.pool.length ? (t2 = this.pool.pop(), Na(t2, h, m2)) : t2 = wa(h, m2);
        return t2;
      };
      Va.prototype.release = function(h) {
        this.pool.push(h);
      };
      qa(Ka, L);
      var Qa = { addTheme: function(h, m2) {
        cb[h] = m2;
      }, addColorSet: function(h, m2) {
        Ca[h] = m2;
      }, addCultureInfo: function(h, m2) {
        La[h] = m2;
      }, formatNumber: function(h, m2, t2) {
        t2 = t2 || "en";
        if (La[t2])
          return ga(h, m2 || "#,##0.##", new Ka(t2));
        throw "Unknown Culture Name";
      }, formatDate: function(h, m2, t2) {
        t2 = t2 || "en";
        if (La[t2])
          return Da(h, m2 || "DD MMM YYYY", new Ka(t2));
        throw "Unknown Culture Name";
      } };
      "undefined" !== typeof module && "undefined" !== typeof module.exports ? module.exports = Qa : "function" === typeof define && define.amd ? define([], function() {
        return Qa;
      }) : (window.CanvasJS && window.console && window.console.log("CanvasJS namespace already exists. If you are loading both chart and stockchart scripts, just load stockchart alone as it includes all chart features."), window.CanvasJS = window.CanvasJS ? window.CanvasJS : Qa);
      z = Qa.Chart = function() {
        function h(a, d) {
          return a.x - d.x;
        }
        function n(a, d, c) {
          d = d || {};
          m(c) ? (this.predefinedThemes = cb, this.optionsName = this.parent = this.index = null) : (this.parent = c.parent, this.index = c.index, this.predefinedThemes = c.predefinedThemes, this.optionsName = c.optionsName, this.stockChart = c.stockChart, this.panel = a, this.isOptionsInArray = c.isOptionsInArray);
          this.theme = m(d.theme) || m(this.predefinedThemes[d.theme]) ? "light1" : d.theme;
          n.base.constructor.call(this, "Chart", this.optionsName, d, this.index, this.parent);
          var b = this;
          this._containerId = a;
          this._objectsInitialized = false;
          this.overlaidCanvasCtx = this.ctx = null;
          this._indexLabels = [];
          this._panTimerId = 0;
          this._lastTouchEventType = "";
          this._lastTouchData = null;
          this.isAnimating = false;
          this.renderCount = 0;
          this.disableToolTip = this.animatedRender = false;
          this.canvasPool = new Va();
          this.allDOMEventHandlers = [];
          this.panEnabled = false;
          this._defaultCursor = "default";
          this.plotArea = { canvas: null, ctx: null, x1: 0, y1: 0, x2: 0, y2: 0, width: 0, height: 0 };
          this._dataInRenderedOrder = [];
          (this.container = "string" === typeof this._containerId ? document.getElementById(this._containerId) : this._containerId) ? (this.container.innerHTML = "", d = a = 0, a = this.options.width ? this.width : 0 < this.container.clientWidth ? this.container.clientWidth : this.width, d = this.options.height ? this.height : 0 < this.container.clientHeight ? this.container.clientHeight : this.height, this.width = a, this.height = d, this.x1 = this.y1 = 0, this.x2 = this.width, this.y2 = this.height, this.selectedColorSet = "undefined" !== typeof Ca[this.colorSet] ? Ca[this.colorSet] : Ca.colorSet1, this._canvasJSContainer = document.createElement("div"), this._canvasJSContainer.setAttribute("class", "canvasjs-chart-container"), this._canvasJSContainer.style.position = "relative", this._canvasJSContainer.style.textAlign = "left", this._canvasJSContainer.style.cursor = "auto", this._canvasJSContainer.style.direction = "ltr", t || (this._canvasJSContainer.style.height = "0px"), this.container.appendChild(this._canvasJSContainer), this.canvas = wa(a, d), this._preRenderCanvas = wa(a, d), this.canvas.style.position = "absolute", this.canvas.style.WebkitUserSelect = "none", this.canvas.style.MozUserSelect = "none", this.canvas.style.msUserSelect = "none", this.canvas.style.userSelect = "none", this.canvas.getContext && (this._canvasJSContainer.appendChild(this.canvas), this.ctx = this.canvas.getContext("2d"), this.ctx.textBaseline = "top", Aa(this.ctx), this._preRenderCtx = this._preRenderCanvas.getContext("2d"), this._preRenderCtx.textBaseline = "top", Aa(this._preRenderCtx), t ? this.plotArea.ctx = this.ctx : (this.plotArea.canvas = wa(a, d), this.plotArea.canvas.style.position = "absolute", this.plotArea.canvas.setAttribute("class", "plotAreaCanvas"), this._canvasJSContainer.appendChild(this.plotArea.canvas), this.plotArea.ctx = this.plotArea.canvas.getContext("2d")), this.overlaidCanvas = wa(a, d), this.overlaidCanvas.style.position = "absolute", this.overlaidCanvas.style.webkitTapHighlightColor = "transparent", this.overlaidCanvas.style.WebkitUserSelect = "none", this.overlaidCanvas.style.MozUserSelect = "none", this.overlaidCanvas.style.msUserSelect = "none", this.overlaidCanvas.style.userSelect = "none", this.overlaidCanvas.getContext && (this._canvasJSContainer.appendChild(this.overlaidCanvas), this.overlaidCanvasCtx = this.overlaidCanvas.getContext("2d"), this.overlaidCanvasCtx.textBaseline = "top", Aa(this.overlaidCanvasCtx)), this._eventManager = new aa2(this), this.windowResizeHandler = S(window, "resize", function() {
            b._updateSize() && b.render();
          }, this.allDOMEventHandlers), this._toolBar = document.createElement("div"), this._toolBar.setAttribute("class", "canvasjs-chart-toolbar"), Y(this._toolBar, {
            position: "absolute",
            right: "1px",
            top: "1px"
          }), this._canvasJSContainer.appendChild(this._toolBar), this.bounds = { x1: 0, y1: 0, x2: this.width, y2: this.height }, S(this.overlaidCanvas, "click", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), S(this.overlaidCanvas, "mousemove", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), S(this.overlaidCanvas, "mouseup", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), S(
            this.overlaidCanvas,
            "mousedown",
            function(a2) {
              b._mouseEventHandler(a2);
              ya(b._dropdownMenu);
            },
            this.allDOMEventHandlers
          ), S(this.overlaidCanvas, "mouseout", function(a2) {
            b._mouseEventHandler(a2);
          }, this.allDOMEventHandlers), S(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerDown" : "touchstart", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), S(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerMove" : "touchmove", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), S(
            this.overlaidCanvas,
            window.navigator.msPointerEnabled ? "MSPointerUp" : "touchend",
            function(a2) {
              b._touchEventHandler(a2);
            },
            this.allDOMEventHandlers
          ), S(this.overlaidCanvas, window.navigator.msPointerEnabled ? "MSPointerCancel" : "touchcancel", function(a2) {
            b._touchEventHandler(a2);
          }, this.allDOMEventHandlers), this.toolTip = new W2(this, this.options.toolTip), this.data = null, this.axisX = [], this.axisX2 = [], this.axisY = [], this.axisY2 = [], this.sessionVariables = { axisX: [], axisX2: [], axisY: [], axisY2: [] })) : window.console && window.console.log('CanvasJS Error: Chart Container with id "' + this._containerId + '" was not found');
        }
        function w2(a, d) {
          for (var c = [], b, e = 0; e < a.length; e++)
            if (0 == e)
              c.push(a[0]);
            else {
              var g, r, u;
              u = e - 1;
              g = 0 === u ? 0 : u - 1;
              r = u === a.length - 1 ? u : u + 1;
              b = Math.abs((a[r].x - a[g].x) / (0 === a[r].x - a[u].x ? 0.01 : a[r].x - a[u].x)) * (d - 1) / 2 + 1;
              var B = (a[r].x - a[g].x) / b;
              b = (a[r].y - a[g].y) / b;
              c[c.length] = a[u].x > a[g].x && 0 < B || a[u].x < a[g].x && 0 > B ? { x: a[u].x + B / 3, y: a[u].y + b / 3 } : { x: a[u].x, y: a[u].y + (1 === c.length ? 0 : b / 9) };
              u = e;
              g = 0 === u ? 0 : u - 1;
              r = u === a.length - 1 ? u : u + 1;
              b = Math.abs((a[r].x - a[g].x) / (0 === a[u].x - a[g].x ? 0.01 : a[u].x - a[g].x)) * (d - 1) / 2 + 1;
              B = (a[r].x - a[g].x) / b;
              b = (a[r].y - a[g].y) / b;
              c[c.length] = a[u].x > a[g].x && 0 < B || a[u].x < a[g].x && 0 > B ? { x: a[u].x - B / 3, y: a[u].y - b / 3 } : { x: a[u].x, y: a[u].y - b / 9 };
              c[c.length] = a[e];
            }
          return c;
        }
        function z2(a, d, c, b, e, g, r, u, B, k) {
          var l = 0;
          k ? (r.color = g, u.color = g) : k = 1;
          l = B ? Math.abs(e - c) : Math.abs(b - d);
          l = 0 < r.trimLength ? Math.abs(l * r.trimLength / 100) : Math.abs(l - r.length);
          B ? (c += l / 2, e -= l / 2) : (d += l / 2, b -= l / 2);
          var l = 1 === Math.round(r.thickness) % 2 ? 0.5 : 0, p = 1 === Math.round(u.thickness) % 2 ? 0.5 : 0;
          a.save();
          a.globalAlpha = k;
          a.strokeStyle = u.color || g;
          a.lineWidth = u.thickness || 2;
          a.setLineDash && a.setLineDash(H(u.dashType, u.thickness));
          a.beginPath();
          B && 0 < u.thickness ? (a.moveTo(b - r.thickness / 2, Math.round((c + e) / 2) - p), a.lineTo(d + r.thickness / 2, Math.round((c + e) / 2) - p)) : 0 < u.thickness && (a.moveTo(Math.round((d + b) / 2) - p, c + r.thickness / 2), a.lineTo(Math.round((d + b) / 2) - p, e - r.thickness / 2));
          a.stroke();
          a.strokeStyle = r.color || g;
          a.lineWidth = r.thickness || 2;
          a.setLineDash && a.setLineDash(H(r.dashType, r.thickness));
          a.beginPath();
          B && 0 < r.thickness ? (a.moveTo(b - l, c), a.lineTo(b - l, e), a.moveTo(d + l, c), a.lineTo(d + l, e)) : 0 < r.thickness && (a.moveTo(d, c + l), a.lineTo(b, c + l), a.moveTo(d, e - l), a.lineTo(b, e - l));
          a.stroke();
          a.restore();
        }
        function E2(a, d) {
          E2.base.constructor.call(this, "Legend", "legend", d, null, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = this.chart.ctx;
          this.ghostCtx = this.chart._eventManager.ghostCtx;
          this.items = [];
          this.optionsName = "legend";
          this.height = this.width = 0;
          this.orientation = null;
          this.dataSeries = [];
          this.bounds = { x1: null, y1: null, x2: null, y2: null };
          "undefined" === typeof this.options.fontSize && (this.fontSize = this.chart.getAutoFontSize(this.fontSize));
          this.lineHeight = Ya(this.fontFamily, this.fontSize, this.fontWeight);
          this.horizontalSpacing = this.fontSize;
        }
        function Q2(a, d, c, b) {
          Q2.base.constructor.call(this, "DataSeries", "data", d, c, a);
          this.chart = a;
          this.canvas = a.canvas;
          this._ctx = a.canvas.ctx;
          this.index = c;
          this.noDataPointsInPlotArea = 0;
          this.id = b;
          this.chart._eventManager.objectMap[b] = { id: b, objectType: "dataSeries", dataSeriesIndex: c };
          a = d.dataPoints ? d.dataPoints.length : 0;
          this.dataPointEOs = [];
          for (d = 0; d < a; d++)
            this.dataPointEOs[d] = {};
          this.dataPointIds = [];
          this.plotUnit = [];
          this.axisY = this.axisX = null;
          this.optionsName = "data";
          this.isOptionsInArray = true;
          null === this.fillOpacity && (this.type.match(/area/i) ? this.fillOpacity = 0.7 : this.fillOpacity = 1);
          this.axisPlacement = this.getDefaultAxisPlacement();
          "undefined" === typeof this.options.indexLabelFontSize && (this.indexLabelFontSize = this.chart.getAutoFontSize(this.indexLabelFontSize));
        }
        function D(a, d, c, b, e, g) {
          D.base.constructor.call(this, "Axis", d, c, b, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = a.ctx;
          this.intervalStartPosition = this.maxHeight = this.maxWidth = 0;
          this.labels = [];
          this.dataSeries = [];
          this._stripLineLabels = this._ticks = this._labels = null;
          this.dataInfo = { min: Infinity, max: -Infinity, viewPortMin: Infinity, viewPortMax: -Infinity, minDiff: Infinity };
          this.isOptionsInArray = true;
          "axisX" === e ? ("left" === g || "bottom" === g ? (this.optionsName = "axisX", m(this.chart.sessionVariables.axisX[b]) && (this.chart.sessionVariables.axisX[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisX[b]) : (this.optionsName = "axisX2", m(this.chart.sessionVariables.axisX2[b]) && (this.chart.sessionVariables.axisX2[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisX2[b]), this.options.interval || (this.intervalType = null)) : "left" === g || "bottom" === g ? (this.optionsName = "axisY", m(this.chart.sessionVariables.axisY[b]) && (this.chart.sessionVariables.axisY[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisY[b]) : (this.optionsName = "axisY2", m(this.chart.sessionVariables.axisY2[b]) && (this.chart.sessionVariables.axisY2[b] = {}), this.sessionVariables = this.chart.sessionVariables.axisY2[b]);
          "undefined" === typeof this.options.titleFontSize && (this.titleFontSize = this.chart.getAutoFontSize(this.titleFontSize));
          "undefined" === typeof this.options.labelFontSize && (this.labelFontSize = this.chart.getAutoFontSize(this.labelFontSize));
          this.type = e;
          "axisX" !== e || c && "undefined" !== typeof c.gridThickness || (this.gridThickness = 0);
          this._position = g;
          this.lineCoordinates = { x1: null, y1: null, x2: null, y2: null, width: null };
          this.labelAngle = (this.labelAngle % 360 + 360) % 360;
          90 < this.labelAngle && 270 > this.labelAngle ? this.labelAngle -= 180 : 270 <= this.labelAngle && 360 >= this.labelAngle && (this.labelAngle -= 360);
          this.options.scaleBreaks && (this.scaleBreaks = new fa2(this.chart, this.options.scaleBreaks, ++this.chart._eventManager.lastObjectId, this));
          this.stripLines = [];
          if (this.options.stripLines && 0 < this.options.stripLines.length)
            for (a = 0; a < this.options.stripLines.length; a++)
              this.stripLines.push(new O(this.chart, this.options.stripLines[a], a, ++this.chart._eventManager.lastObjectId, this));
          this.options.crosshair && (this.crosshair = new ea2(
            this.chart,
            this.options.crosshair,
            this
          ));
          this._titleTextBlock = null;
          this.hasOptionChanged("viewportMinimum") && null === this.viewportMinimum && (this.options.viewportMinimum = void 0, this.sessionVariables.viewportMinimum = null);
          this.hasOptionChanged("viewportMinimum") || isNaN(this.sessionVariables.newViewportMinimum) || null === this.sessionVariables.newViewportMinimum ? this.sessionVariables.newViewportMinimum = null : this.viewportMinimum = this.sessionVariables.newViewportMinimum;
          this.hasOptionChanged("viewportMaximum") && null === this.viewportMaximum && (this.options.viewportMaximum = void 0, this.sessionVariables.viewportMaximum = null);
          this.hasOptionChanged("viewportMaximum") || isNaN(this.sessionVariables.newViewportMaximum) || null === this.sessionVariables.newViewportMaximum ? this.sessionVariables.newViewportMaximum = null : this.viewportMaximum = this.sessionVariables.newViewportMaximum;
          null !== this.minimum && null !== this.viewportMinimum && (this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum));
          null !== this.maximum && null !== this.viewportMaximum && (this.viewportMaximum = Math.min(this.viewportMaximum, this.maximum));
          this.trackChanges("viewportMinimum");
          this.trackChanges("viewportMaximum");
        }
        function fa2(a, d, c, b) {
          fa2.base.constructor.call(this, "ScaleBreaks", "scaleBreaks", d, null, b);
          this.id = c;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.axis = b;
          this.optionsName = "scaleBreaks";
          this.isOptionsInArray = false;
          this._appliedBreaks = [];
          this.customBreaks = [];
          this.autoBreaks = [];
          "string" === typeof this.spacing ? (this.spacing = parseFloat(this.spacing), this.spacing = isNaN(this.spacing) ? 8 : (10 < this.spacing ? 10 : this.spacing) + "%") : "number" !== typeof this.spacing && (this.spacing = 8);
          this.autoCalculate && (this.maxNumberOfAutoBreaks = Math.min(this.maxNumberOfAutoBreaks, 5));
          if (this.options.customBreaks && 0 < this.options.customBreaks.length) {
            for (a = 0; a < this.options.customBreaks.length; a++)
              this.customBreaks.push(new da2(this.chart, "customBreaks", this.options.customBreaks[a], a, ++this.chart._eventManager.lastObjectId, this)), "number" === typeof this.customBreaks[a].startValue && ("number" === typeof this.customBreaks[a].endValue && this.customBreaks[a].endValue !== this.customBreaks[a].startValue) && this._appliedBreaks.push(this.customBreaks[a]);
            this._appliedBreaks.sort(function(a2, b2) {
              return a2.startValue - b2.startValue;
            });
            for (a = 0; a < this._appliedBreaks.length - 1; a++)
              this._appliedBreaks[a].endValue >= this._appliedBreaks[a + 1].startValue && (this._appliedBreaks[a].endValue = Math.max(this._appliedBreaks[a].endValue, this._appliedBreaks[a + 1].endValue), window.console && window.console.log("CanvasJS Error: Breaks " + a + " and " + (a + 1) + " are overlapping."), this._appliedBreaks.splice(a, 2), a--);
          }
        }
        function da2(a, d, c, b, e, g) {
          da2.base.constructor.call(this, "Break", d, c, b, g);
          this.id = e;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.scaleBreaks = g;
          this.optionsName = d;
          this.isOptionsInArray = true;
          this.type = c.type ? this.type : g.type;
          this.fillOpacity = m(c.fillOpacity) ? g.fillOpacity : this.fillOpacity;
          this.lineThickness = m(c.lineThickness) ? g.lineThickness : this.lineThickness;
          this.color = c.color ? this.color : g.color;
          this.lineColor = c.lineColor ? this.lineColor : g.lineColor;
          this.lineDashType = c.lineDashType ? this.lineDashType : g.lineDashType;
          !m(this.startValue) && this.startValue.getTime && (this.startValue = this.startValue.getTime());
          !m(this.endValue) && this.endValue.getTime && (this.endValue = this.endValue.getTime());
          "number" === typeof this.startValue && ("number" === typeof this.endValue && this.endValue < this.startValue) && (a = this.startValue, this.startValue = this.endValue, this.endValue = a);
          this.spacing = "undefined" === typeof c.spacing ? g.spacing : c.spacing;
          "string" === typeof this.options.spacing ? (this.spacing = parseFloat(this.spacing), this.spacing = isNaN(this.spacing) ? 0 : (10 < this.spacing ? 10 : this.spacing) + "%") : "number" !== typeof this.options.spacing && (this.spacing = g.spacing);
          this.size = g.parent.logarithmic ? 1 : 0;
        }
        function O(a, d, c, b, e) {
          O.base.constructor.call(this, "StripLine", "stripLines", d, c, e);
          this.id = b;
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.label = this.label;
          this.axis = e;
          this.optionsName = "stripLines";
          this.isOptionsInArray = true;
          this._thicknessType = "pixel";
          null !== this.startValue && null !== this.endValue && (this.value = e.logarithmic ? Math.sqrt((this.startValue.getTime ? this.startValue.getTime() : this.startValue) * (this.endValue.getTime ? this.endValue.getTime() : this.endValue)) : ((this.startValue.getTime ? this.startValue.getTime() : this.startValue) + (this.endValue.getTime ? this.endValue.getTime() : this.endValue)) / 2, this._thicknessType = null);
        }
        function ea2(a, d, c) {
          ea2.base.constructor.call(this, "Crosshair", "crosshair", d, null, c);
          this.chart = a;
          this.ctx = this.chart.ctx;
          this.axis = c;
          this.optionsName = "crosshair";
          this._thicknessType = "pixel";
        }
        function W2(a, d) {
          W2.base.constructor.call(this, "ToolTip", "toolTip", d, null, a);
          this.chart = a;
          this.canvas = a.canvas;
          this.ctx = this.chart.ctx;
          this.currentDataPointIndex = this.currentSeriesIndex = -1;
          this._prevY = this._prevX = NaN;
          this.containerTransitionDuration = 0.1;
          this.mozContainerTransition = this.getContainerTransition(this.containerTransitionDuration);
          this.optionsName = "toolTip";
          this._initialize();
        }
        function aa2(a) {
          this.chart = a;
          this.lastObjectId = 0;
          this.objectMap = [];
          this.rectangularRegionEventSubscriptions = [];
          this.previousDataPointEventObject = null;
          this.ghostCanvas = wa(this.chart.width, this.chart.height, true);
          this.ghostCtx = this.ghostCanvas.getContext("2d");
          this.mouseoveredObjectMaps = [];
        }
        function ka2(a) {
          this.chart = a;
          this.ctx = this.chart.plotArea.ctx;
          this.animations = [];
          this.animationRequestId = null;
        }
        qa(n, L);
        n.prototype.destroy = function() {
          var a = this.allDOMEventHandlers;
          this._animator && this._animator.cancelAllAnimations();
          this._panTimerId && clearTimeout(this._panTimerId);
          for (var d = 0; d < a.length; d++) {
            var c = a[d][0], b = a[d][1], e = a[d][2], g = a[d][3], g = g || false;
            c.removeEventListener ? c.removeEventListener(b, e, g) : c.detachEvent && c.detachEvent("on" + b, e);
          }
          this.allDOMEventHandlers = [];
          for (this.removeAllEventListeners(); this._canvasJSContainer && this._canvasJSContainer.hasChildNodes(); )
            this._canvasJSContainer.removeChild(this._canvasJSContainer.lastChild);
          for (; this.container && this.container.hasChildNodes(); )
            this.container.removeChild(this.container.lastChild);
          for (; this._dropdownMenu && this._dropdownMenu.hasChildNodes(); )
            this._dropdownMenu.removeChild(this._dropdownMenu.lastChild);
          this.container = this._canvasJSContainer = null;
          this.toolTip.container = null;
          this.canvas && za(this.canvas);
          this.overlaidCanvas && za(this.overlaidCanvas);
          this._preRenderCanvas && za(this._preRenderCanvas);
          this._breaksCanvas && za(this._breaksCanvas);
          this._eventManager && this._eventManager.ghostCanvas && za(this._eventManager.ghostCanvas);
          this._toolBar = this._dropdownMenu = this._menuButton = this._resetButton = this._zoomButton = null;
        };
        n.prototype._updateOptions = function() {
          var a = this;
          this.updateOption("width");
          this.updateOption("height");
          this.updateOption("dataPointWidth");
          this.updateOption("dataPointMinWidth");
          this.updateOption("dataPointMaxWidth");
          this.updateOption("interactivityEnabled");
          this.updateOption("theme");
          this.updateOption("colorSet") && (this.selectedColorSet = "undefined" !== typeof Ca[this.colorSet] ? Ca[this.colorSet] : Ca.colorSet1);
          this.updateOption("backgroundColor");
          this.backgroundColor || (this.backgroundColor = "rgba(0,0,0,0)");
          this.updateOption("culture");
          this._cultureInfo = new Ka(this.options.culture);
          this.updateOption("animationEnabled");
          this.animationEnabled = this.animationEnabled && t;
          this.updateOption("animationDuration");
          this.updateOption("rangeChanging");
          this.updateOption("rangeChanged");
          this.updateOption("exportEnabled");
          this.updateOption("exportFileName");
          this.updateOption("zoomType");
          this.toolbar = new Ua(this, this.options.toolbar);
          if (this.options.zoomEnabled || this.panEnabled) {
            if (this._zoomButton)
              Y(this._zoomButton, {
                borderRight: this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor,
                backgroundColor: a.toolbar.itemBackgroundColor,
                color: a.toolbar.fontColor
              }), ua(this, this._zoomButton, "zoom");
            else {
              var d = false;
              ya(this._zoomButton = document.createElement("button"));
              ua(this, this._zoomButton, "pan");
              this._toolBar.appendChild(this._zoomButton);
              this._zoomButton.style.borderRight = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor;
              S(this._zoomButton, "touchstart", function(a2) {
                d = true;
              }, this.allDOMEventHandlers);
              S(this._zoomButton, "click", function() {
                a.zoomEnabled ? (a.zoomEnabled = false, a.panEnabled = true, ua(a, a._zoomButton, "zoom")) : (a.zoomEnabled = true, a.panEnabled = false, ua(a, a._zoomButton, "pan"));
                a.render();
              }, this.allDOMEventHandlers);
              S(this._zoomButton, "mousemove", function() {
                d ? d = false : (Y(a._zoomButton, { backgroundColor: a.toolbar.itemBackgroundColorOnHover, color: a.toolbar.fontColorOnHover, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && Y(a._zoomButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
              }, this.allDOMEventHandlers);
              S(this._zoomButton, "mouseout", function() {
                d || (Y(
                  a._zoomButton,
                  { backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor, transition: "0.4s", WebkitTransition: "0.4s" }
                ), 0 >= navigator.userAgent.search("MSIE") && Y(a._zoomButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
              }, this.allDOMEventHandlers);
            }
            this._resetButton ? (Y(this._resetButton, { borderRight: this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor }), this._resetButton.title = this._cultureInfo.resetText) : (d = false, ya(this._resetButton = document.createElement("button")), ua(this, this._resetButton, "reset"), this._resetButton.style.borderRight = (this.exportEnabled ? this.toolbar.buttonBorderThickness : 0) + "px solid " + this.toolbar.buttonBorderColor, this._toolBar.appendChild(this._resetButton), S(this._resetButton, "touchstart", function(a2) {
              d = true;
            }, this.allDOMEventHandlers), S(this._resetButton, "click", function() {
              a.toolTip.hide();
              a.toolTip && a.toolTip.enabled && a.toolTip.dispatchEvent(
                "hidden",
                { chart: a, toolTip: a.toolTip },
                a.toolTip
              );
              a.zoomEnabled || a.panEnabled ? (a.zoomEnabled = true, a.panEnabled = false, ua(a, a._zoomButton, "pan"), a._defaultCursor = "default", a.overlaidCanvas.style.cursor = a._defaultCursor) : (a.zoomEnabled = false, a.panEnabled = false);
              if (a.sessionVariables.axisX)
                for (var b = 0; b < a.sessionVariables.axisX.length; b++)
                  a.sessionVariables.axisX[b].newViewportMinimum = null, a.sessionVariables.axisX[b].newViewportMaximum = null;
              if (a.sessionVariables.axisX2)
                for (b = 0; b < a.sessionVariables.axisX2.length; b++)
                  a.sessionVariables.axisX2[b].newViewportMinimum = null, a.sessionVariables.axisX2[b].newViewportMaximum = null;
              if (a.sessionVariables.axisY)
                for (b = 0; b < a.sessionVariables.axisY.length; b++)
                  a.sessionVariables.axisY[b].newViewportMinimum = null, a.sessionVariables.axisY[b].newViewportMaximum = null;
              if (a.sessionVariables.axisY2)
                for (b = 0; b < a.sessionVariables.axisY2.length; b++)
                  a.sessionVariables.axisY2[b].newViewportMinimum = null, a.sessionVariables.axisY2[b].newViewportMaximum = null;
              a.resetOverlayedCanvas();
              0 >= navigator.userAgent.search("MSIE") && Y(
                a._resetButton.childNodes[0],
                { WebkitFilter: "invert(0%)", filter: "invert(0%)" }
              );
              ya(a._zoomButton, a._resetButton);
              a.stockChart && (a.stockChart._rangeEventParameter = { stockChart: a.stockChart, source: "chart", index: a.stockChart.charts.indexOf(a), minimum: null, maximum: null });
              a._dispatchRangeEvent("rangeChanging", "reset");
              a.stockChart && (a.stockChart._rangeEventParameter.type = "rangeChanging", a.stockChart.dispatchEvent("rangeChanging", a.stockChart._rangeEventParameter, a.stockChart));
              a.render();
              a.syncCharts && a.syncCharts(null, null);
              a._dispatchRangeEvent(
                "rangeChanged",
                "reset"
              );
              a.stockChart && (a.stockChart._rangeEventParameter.type = "rangeChanged", a.stockChart.dispatchEvent("rangeChanged", a.stockChart._rangeEventParameter, a.stockChart));
            }, this.allDOMEventHandlers), S(
              this._resetButton,
              "mousemove",
              function() {
                d || (Y(a._resetButton, { backgroundColor: a.toolbar.itemBackgroundColorOnHover, color: a.toolbar.fontColorOnHover, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && Y(a._resetButton.childNodes[0], { WebkitFilter: "invert(100%)", filter: "invert(100%)" }));
              },
              this.allDOMEventHandlers
            ), S(this._resetButton, "mouseout", function() {
              d || (Y(a._resetButton, { backgroundColor: a.toolbar.itemBackgroundColor, color: a.toolbar.fontColor, transition: "0.4s", WebkitTransition: "0.4s" }), 0 >= navigator.userAgent.search("MSIE") && Y(a._resetButton.childNodes[0], { WebkitFilter: "invert(0%)", filter: "invert(0%)" }));
            }, this.allDOMEventHandlers), this.overlaidCanvas.style.cursor = a._defaultCursor);
            this.zoomEnabled || this.panEnabled || (this._zoomButton ? (a._zoomButton.getAttribute("state") === a._cultureInfo.zoomText ? (this.panEnabled = true, this.zoomEnabled = false) : (this.zoomEnabled = true, this.panEnabled = false), Ma(a._zoomButton, a._resetButton)) : (this.zoomEnabled = true, this.panEnabled = false));
          } else
            this.panEnabled = this.zoomEnabled = false;
          hb(this);
          "none" !== this._toolBar.style.display && this._zoomButton && (this.panEnabled ? ua(a, a._zoomButton, "zoom") : ua(a, a._zoomButton, "pan"), a._resetButton.getAttribute("state") !== a._cultureInfo.resetText && ua(a, a._resetButton, "reset"));
          this.options.toolTip && this.toolTip.options !== this.options.toolTip && (this.toolTip.options = this.options.toolTip);
          for (var c in this.toolTip.options)
            this.toolTip.options.hasOwnProperty(c) && this.toolTip.updateOption(c);
        };
        n.prototype._updateSize = function() {
          var a;
          a = [this.canvas, this.overlaidCanvas, this._eventManager.ghostCanvas];
          var d = 0, c = 0;
          this.options.width ? d = this.width : this.width = d = 0 < this.container.clientWidth ? this.container.clientWidth : this.width;
          this.options.height ? c = this.height : this.height = c = 0 < this.container.clientHeight ? this.container.clientHeight : this.height;
          if (this.canvas.width !== d * na || this.canvas.height !== c * na) {
            for (var b = 0; b < a.length; b++)
              Na(a[b], d, c);
            this.bounds = { x1: 0, y1: 0, x2: this.width, y2: this.height, width: this.width, height: this.height };
            a = true;
          } else
            a = false;
          return a;
        };
        n.prototype._initialize = function() {
          this.isNavigator = m(this.parent) || m(this.parent._defaultsKey) || "Navigator" !== this.parent._defaultsKey ? false : true;
          this._animator ? this._animator.cancelAllAnimations() : this._animator = new ka2(this);
          this.removeAllEventListeners();
          this.disableToolTip = false;
          this._axes = [];
          this.funnelPyramidClickHandler = this.pieDoughnutClickHandler = null;
          this._updateOptions();
          this.animatedRender = t && this.animationEnabled && 0 === this.renderCount;
          this._updateSize();
          this.clearCanvas();
          this.ctx.beginPath();
          this.axisX = [];
          this.axisX2 = [];
          this.axisY = [];
          this.axisY2 = [];
          this._indexLabels = [];
          this._dataInRenderedOrder = [];
          this._events = [];
          this._eventManager && this._eventManager.reset();
          this.plotInfo = { axisPlacement: null, plotTypes: [] };
          this.layoutManager = new Fa(0, 0, this.width, this.height, this.isNavigator ? 0 : 2);
          this.plotArea.layoutManager && this.plotArea.layoutManager.reset();
          this.data = [];
          this.title = null;
          this.subtitles = [];
          var a = 0, d = null;
          if (this.options.data) {
            for (var c = 0; c < this.options.data.length; c++)
              if (a++, !this.options.data[c].type || 0 <= n._supportedChartTypes.indexOf(this.options.data[c].type)) {
                var b = new Q2(this, this.options.data[c], a - 1, ++this._eventManager.lastObjectId);
                if (!m(b) && b.dataPoints) {
                  for (var e = 0; e < b.dataPoints.length; e++)
                    if (b.dataPoints[e].x && b.dataPoints[e].x.getTime) {
                      b.xValueType = "dateTime";
                      break;
                    }
                }
                "error" === b.type && (b.linkedDataSeriesIndex = m(this.options.data[c].linkedDataSeriesIndex) ? c - 1 : this.options.data[c].linkedDataSeriesIndex, 0 > b.linkedDataSeriesIndex || b.linkedDataSeriesIndex >= this.options.data.length || "number" !== typeof b.linkedDataSeriesIndex || "error" === this.options.data[b.linkedDataSeriesIndex].type) && (b.linkedDataSeriesIndex = null);
                null === b.name && (b.name = "DataSeries " + a);
                null === b.color ? 1 < this.options.data.length ? (b._colorSet = [this.selectedColorSet[b.index % this.selectedColorSet.length]], b.color = this.selectedColorSet[b.index % this.selectedColorSet.length]) : b._colorSet = "line" === b.type || "stepLine" === b.type || "spline" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "stackedArea" === b.type || "stackedArea100" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "candlestick" === b.type || "ohlc" === b.type || "waterfall" === b.type || "boxAndWhisker" === b.type ? [this.selectedColorSet[0]] : this.selectedColorSet : b._colorSet = [b.color];
                null === b.markerSize && (("line" === b.type || "stepLine" === b.type || "spline" === b.type || 0 <= b.type.toLowerCase().indexOf("area")) && b.dataPoints && b.dataPoints.length < this.width / 16 || "scatter" === b.type) && (b.markerSize = 8);
                "bubble" !== b.type && "scatter" !== b.type || !b.dataPoints || (b.dataPoints.some ? b.dataPoints.some(function(a2) {
                  return a2.x;
                }) && b.dataPoints.sort(h) : b.dataPoints.sort(h));
                this.data.push(b);
                var e = b.axisPlacement, d = d || e, g;
                "normal" === e ? "xySwapped" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with bar chart' : "none" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with pie chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "normal") : "xySwapped" === e ? "normal" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with line, area, column or pie chart' : "none" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with pie chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "xySwapped") : "none" === e ? "normal" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with line, area, column or bar chart' : "xySwapped" === this.plotInfo.axisPlacement ? g = 'You cannot combine "' + b.type + '" with bar chart' : null === this.plotInfo.axisPlacement && (this.plotInfo.axisPlacement = "none") : null === e && "none" === this.plotInfo.axisPlacement && (g = 'You cannot combine "' + b.type + '" with pie chart');
                if (g && window.console) {
                  window.console.log(g);
                  return;
                }
              }
            for (c = 0; c < this.data.length; c++) {
              if ("none" == d && "error" === this.data[c].type && window.console) {
                window.console.log('You cannot combine "' + b.type + '" with error chart');
                return;
              }
              "error" === this.data[c].type && (this.data[c].axisPlacement = this.plotInfo.axisPlacement = d || "normal", this.data[c]._linkedSeries = null === this.data[c].linkedDataSeriesIndex ? null : this.data[this.data[c].linkedDataSeriesIndex]);
            }
          }
          this._objectsInitialized = true;
          this._plotAreaElements = [];
        };
        n._supportedChartTypes = Ea("line stepLine spline column area stepArea splineArea bar bubble scatter stackedColumn stackedColumn100 stackedBar stackedBar100 stackedArea stackedArea100 candlestick ohlc boxAndWhisker rangeColumn error rangeBar rangeArea rangeSplineArea pie doughnut funnel pyramid waterfall".split(" "));
        n.prototype.setLayout = function() {
          for (var a = this._plotAreaElements, d = 0; d < this.data.length; d++)
            if ("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement) {
              if (!this.data[d].axisYType || "primary" === this.data[d].axisYType)
                if (this.options.axisY && 0 < this.options.axisY.length) {
                  if (!this.axisY.length)
                    for (var c = 0; c < this.options.axisY.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY[c] = new D(this, "axisY", this.options.axisY[c], c, "axisY", "left")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY[c] = new D(this, "axisY", this.options.axisY[c], c, "axisY", "bottom"));
                  this.data[d].axisY = this.axisY[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY.length ? this.data[d].axisYIndex : 0];
                  this.axisY[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY.length ? this.data[d].axisYIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisY.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY[0] = new D(
                    this,
                    "axisY",
                    this.options.axisY,
                    0,
                    "axisY",
                    "left"
                  )) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY[0] = new D(this, "axisY", this.options.axisY, 0, "axisY", "bottom"))), this.data[d].axisY = this.axisY[0], this.axisY[0].dataSeries.push(this.data[d]);
              if ("secondary" === this.data[d].axisYType)
                if (this.options.axisY2 && 0 < this.options.axisY2.length) {
                  if (!this.axisY2.length)
                    for (c = 0; c < this.options.axisY2.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY2[c] = new D(
                        this,
                        "axisY2",
                        this.options.axisY2[c],
                        c,
                        "axisY",
                        "right"
                      )) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY2[c] = new D(this, "axisY2", this.options.axisY2[c], c, "axisY", "top"));
                  this.data[d].axisY = this.axisY2[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY2.length ? this.data[d].axisYIndex : 0];
                  this.axisY2[0 <= this.data[d].axisYIndex && this.data[d].axisYIndex < this.axisY2.length ? this.data[d].axisYIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisY2.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisY2[0] = new D(this, "axisY2", this.options.axisY2, 0, "axisY", "right")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisY2[0] = new D(this, "axisY2", this.options.axisY2, 0, "axisY", "top"))), this.data[d].axisY = this.axisY2[0], this.axisY2[0].dataSeries.push(this.data[d]);
              if (!this.data[d].axisXType || "primary" === this.data[d].axisXType)
                if (this.options.axisX && 0 < this.options.axisX.length) {
                  if (!this.axisX.length)
                    for (c = 0; c < this.options.axisX.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX[c] = new D(this, "axisX", this.options.axisX[c], c, "axisX", "bottom")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX[c] = new D(this, "axisX", this.options.axisX[c], c, "axisX", "left"));
                  this.data[d].axisX = this.axisX[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX.length ? this.data[d].axisXIndex : 0];
                  this.axisX[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX.length ? this.data[d].axisXIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisX.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX[0] = new D(this, "axisX", this.options.axisX, 0, "axisX", "bottom")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX[0] = new D(this, "axisX", this.options.axisX, 0, "axisX", "left"))), this.data[d].axisX = this.axisX[0], this.axisX[0].dataSeries.push(this.data[d]);
              if ("secondary" === this.data[d].axisXType)
                if (this.options.axisX2 && 0 < this.options.axisX2.length) {
                  if (!this.axisX2.length)
                    for (c = 0; c < this.options.axisX2.length; c++)
                      "normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX2[c] = new D(this, "axisX2", this.options.axisX2[c], c, "axisX", "top")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX2[c] = new D(this, "axisX2", this.options.axisX2[c], c, "axisX", "right"));
                  this.data[d].axisX = this.axisX2[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX2.length ? this.data[d].axisXIndex : 0];
                  this.axisX2[0 <= this.data[d].axisXIndex && this.data[d].axisXIndex < this.axisX2.length ? this.data[d].axisXIndex : 0].dataSeries.push(this.data[d]);
                } else
                  this.axisX2.length || ("normal" === this.plotInfo.axisPlacement ? this._axes.push(this.axisX2[0] = new D(this, "axisX2", this.options.axisX2, 0, "axisX", "top")) : "xySwapped" === this.plotInfo.axisPlacement && this._axes.push(this.axisX2[0] = new D(this, "axisX2", this.options.axisX2, 0, "axisX", "right"))), this.data[d].axisX = this.axisX2[0], this.axisX2[0].dataSeries.push(this.data[d]);
            }
          if (this.axisY) {
            for (c = 1; c < this.axisY.length; c++)
              "undefined" === typeof this.axisY[c].options.gridThickness && (this.axisY[c].gridThickness = 0);
            for (c = 0; c < this.axisY.length - 1; c++)
              "undefined" === typeof this.axisY[c].options.margin && (this.axisY[c].margin = 10);
          }
          if (this.axisY2) {
            for (c = 1; c < this.axisY2.length; c++)
              "undefined" === typeof this.axisY2[c].options.gridThickness && (this.axisY2[c].gridThickness = 0);
            for (c = 0; c < this.axisY2.length - 1; c++)
              "undefined" === typeof this.axisY2[c].options.margin && (this.axisY2[c].margin = 10);
          }
          this.axisY && 0 < this.axisY.length && (this.axisY2 && 0 < this.axisY2.length) && (0 < this.axisY[0].gridThickness && "undefined" === typeof this.axisY2[0].options.gridThickness ? this.axisY2[0].gridThickness = 0 : 0 < this.axisY2[0].gridThickness && "undefined" === typeof this.axisY[0].options.gridThickness && (this.axisY[0].gridThickness = 0));
          if (this.axisX)
            for (c = 0; c < this.axisX.length; c++)
              "undefined" === typeof this.axisX[c].options.gridThickness && (this.axisX[c].gridThickness = 0);
          if (this.axisX2)
            for (c = 0; c < this.axisX2.length; c++)
              "undefined" === typeof this.axisX2[c].options.gridThickness && (this.axisX2[c].gridThickness = 0);
          this.axisX && 0 < this.axisX.length && (this.axisX2 && 0 < this.axisX2.length) && (0 < this.axisX[0].gridThickness && "undefined" === typeof this.axisX2[0].options.gridThickness ? this.axisX2[0].gridThickness = 0 : 0 < this.axisX2[0].gridThickness && "undefined" === typeof this.axisX[0].options.gridThickness && (this.axisX[0].gridThickness = 0));
          c = false;
          if (0 < this._axes.length && this.options.zoomEnabled && (this.zoomEnabled || this.panEnabled)) {
            for (d = 0; d < this._axes.length; d++)
              if (!m(this._axes[d].viewportMinimum) || !m(this._axes[d].viewportMaximum)) {
                c = true;
                break;
              }
          }
          c ? (Ma(this._zoomButton, this._resetButton), this._toolBar.style.border = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, this._zoomButton.style.borderRight = this.toolbar.buttonBorderThickness + "px solid " + this.toolbar.buttonBorderColor, this._resetButton.style.borderRight = (this.exportEnabled ? this.toolbar.buttonBorderThickness : 0) + "px solid " + this.toolbar.buttonBorderColor) : (ya(this._zoomButton, this._resetButton), this._toolBar.style.border = this.toolbar.buttonBorderThickness + "px solid transparent", this.options.zoomEnabled && (this.zoomEnabled = true, this.panEnabled = false));
          fb(this);
          this._processData();
          this.options.title && (this.title = new Ba(this, this.options.title), this.title.dockInsidePlotArea ? a.push(this.title) : this.title.setLayout());
          if (this.options.subtitles)
            for (d = 0; d < this.options.subtitles.length; d++)
              c = new Ja(this, this.options.subtitles[d], d), this.subtitles.push(c), c.dockInsidePlotArea ? a.push(c) : c.setLayout();
          this.legend = new E2(this, this.options.legend);
          for (d = 0; d < this.data.length; d++)
            (this.data[d].showInLegend || "pie" === this.data[d].type || "doughnut" === this.data[d].type || "funnel" === this.data[d].type || "pyramid" === this.data[d].type) && this.legend.dataSeries.push(this.data[d]);
          this.legend.dockInsidePlotArea ? a.push(this.legend) : this.legend.setLayout();
          for (d = 0; d < this._axes.length; d++)
            if (this._axes[d].scaleBreaks && this._axes[d].scaleBreaks._appliedBreaks.length) {
              t ? (this._breaksCanvas = wa(this.width, this.height, true), this._breaksCanvasCtx = this._breaksCanvas.getContext("2d")) : (this._breaksCanvas = this.canvas, this._breaksCanvasCtx = this.ctx);
              break;
            }
          this._preRenderCanvas = wa(this.width, this.height);
          this._preRenderCtx = this._preRenderCanvas.getContext("2d");
          "normal" !== this.plotInfo.axisPlacement && "xySwapped" !== this.plotInfo.axisPlacement || D.setLayout(this.axisX, this.axisX2, this.axisY, this.axisY2, this.plotInfo.axisPlacement, this.layoutManager.getFreeSpace());
        };
        n.prototype.renderElements = function() {
          if (this.height) {
            var a = this._plotAreaElements;
            this.title && !this.title.dockInsidePlotArea && this.title.render();
            for (var d = 0; d < this.subtitles.length; d++)
              this.subtitles[d].dockInsidePlotArea || this.subtitles[d].render();
            this.legend.dockInsidePlotArea || this.legend.render();
            if ("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement)
              D.render(this.axisX, this.axisX2, this.axisY, this.axisY2, this.plotInfo.axisPlacement);
            else if ("none" === this.plotInfo.axisPlacement)
              this.preparePlotArea();
            else
              return;
            for (d = 0; d < a.length; d++)
              a[d].setLayout(), a[d].render();
            var c = [];
            if (this.animatedRender) {
              var b = wa(this.width, this.height);
              b.getContext("2d").drawImage(this.canvas, 0, 0, this.width, this.height);
            }
            ib(this);
            var a = this.ctx.miterLimit, e;
            this.ctx.miterLimit = 3;
            t && this._breaksCanvas && (this._preRenderCtx.drawImage(this.canvas, 0, 0, this.width, this.height), this._preRenderCtx.drawImage(this._breaksCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx.globalCompositeOperation = "source-atop", this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), this._preRenderCtx.clearRect(0, 0, this.width, this.height));
            for (d = 0; d < this.plotInfo.plotTypes.length; d++)
              for (var g = this.plotInfo.plotTypes[d], r = 0; r < g.plotUnits.length; r++) {
                var u = g.plotUnits[r], B = null;
                u.targetCanvas && za(u.targetCanvas);
                u.targetCanvas = null;
                this.animatedRender && (u.targetCanvas = wa(this.width, this.height), u.targetCanvasCtx = u.targetCanvas.getContext("2d"), e = u.targetCanvasCtx.miterLimit, u.targetCanvasCtx.miterLimit = 3);
                "line" === u.type ? B = this.renderLine(u) : "stepLine" === u.type ? B = this.renderStepLine(u) : "spline" === u.type ? B = this.renderSpline(u) : "column" === u.type ? B = this.renderColumn(u) : "bar" === u.type ? B = this.renderBar(u) : "area" === u.type ? B = this.renderArea(u) : "stepArea" === u.type ? B = this.renderStepArea(u) : "splineArea" === u.type ? B = this.renderSplineArea(u) : "stackedColumn" === u.type ? B = this.renderStackedColumn(u) : "stackedColumn100" === u.type ? B = this.renderStackedColumn100(u) : "stackedBar" === u.type ? B = this.renderStackedBar(u) : "stackedBar100" === u.type ? B = this.renderStackedBar100(u) : "stackedArea" === u.type ? B = this.renderStackedArea(u) : "stackedArea100" === u.type ? B = this.renderStackedArea100(u) : "bubble" === u.type ? B = B = this.renderBubble(u) : "scatter" === u.type ? B = this.renderScatter(u) : "pie" === u.type ? this.renderPie(u) : "doughnut" === u.type ? this.renderPie(u) : "funnel" === u.type ? B = this.renderFunnel(u) : "pyramid" === u.type ? B = this.renderFunnel(u) : "candlestick" === u.type ? B = this.renderCandlestick(u) : "ohlc" === u.type ? B = this.renderCandlestick(u) : "rangeColumn" === u.type ? B = this.renderRangeColumn(u) : "error" === u.type ? B = this.renderError(u) : "rangeBar" === u.type ? B = this.renderRangeBar(u) : "rangeArea" === u.type ? B = this.renderRangeArea(u) : "rangeSplineArea" === u.type ? B = this.renderRangeSplineArea(u) : "waterfall" === u.type ? B = this.renderWaterfall(u) : "boxAndWhisker" === u.type && (B = this.renderBoxAndWhisker(u));
                for (var k = 0; k < u.dataSeriesIndexes.length; k++)
                  this._dataInRenderedOrder.push(this.data[u.dataSeriesIndexes[k]]);
                this.animatedRender && (u.targetCanvasCtx.miterLimit = e, B && c.push(B));
              }
            this.ctx.miterLimit = a;
            this.animatedRender && this._breaksCanvasCtx && c.push({ source: this._breaksCanvasCtx, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0, startTimePercent: 0.7 });
            this.animatedRender && 0 < this._indexLabels.length && (e = wa(this.width, this.height).getContext("2d"), Aa(e), c.push(this.renderIndexLabels(e)));
            var l = this;
            if (0 < c.length)
              l.disableToolTip = true, l._animator.animate(200, l.animationDuration, function(a2) {
                l.ctx.clearRect(0, 0, l.width, l.height);
                l.ctx.drawImage(b, 0, 0, Math.floor(l.width * na), Math.floor(l.height * na), 0, 0, l.width, l.height);
                for (var e2 = 0; e2 < c.length; e2++)
                  B = c[e2], 1 > a2 && "undefined" !== typeof B.startTimePercent ? a2 >= B.startTimePercent && B.animationCallback(
                    B.easingFunction(a2 - B.startTimePercent, 0, 1, 1 - B.startTimePercent),
                    B
                  ) : B.animationCallback(B.easingFunction(a2, 0, 1, 1), B);
                l.dispatchEvent("dataAnimationIterationEnd", { chart: l });
              }, function() {
                c = [];
                for (var a2 = 0; a2 < l.plotInfo.plotTypes.length; a2++)
                  for (var e2 = l.plotInfo.plotTypes[a2], f = 0; f < e2.plotUnits.length; f++) {
                    var d2 = e2.plotUnits[f];
                    d2.targetCanvas && za(d2.targetCanvas);
                    d2.targetCanvas = null;
                  }
                b = null;
                l.disableToolTip = false;
                l.dispatchEvent("dataAnimationEnd", { chart: l });
              });
            else {
              if (l._breaksCanvas)
                if (t)
                  l.plotArea.ctx.drawImage(l._breaksCanvas, 0, 0, this.width, this.height);
                else
                  for (k = 0; k < l._axes.length; k++)
                    l._axes[k].createMask();
              0 < l._indexLabels.length && l.renderIndexLabels();
              l.dispatchEvent("dataAnimationIterationEnd", { chart: l });
              l.dispatchEvent("dataAnimationEnd", { chart: l });
            }
            this.attachPlotAreaEventHandlers();
            this.zoomEnabled || (this.panEnabled || !this._zoomButton || "none" === this._zoomButton.style.display) || ya(this._zoomButton, this._resetButton);
            this.toolTip._updateToolTip();
            this.renderCount++;
            Ia && (l = this, setTimeout(function() {
              var a2 = document.getElementById("ghostCanvasCopy");
              a2 && (Na(a2, l.width, l.height), a2.getContext("2d").drawImage(
                l._eventManager.ghostCanvas,
                0,
                0
              ));
            }, 2e3));
            this._breaksCanvas && (delete this._breaksCanvas, delete this._breaksCanvasCtx);
            for (k = 0; k < this._axes.length; k++)
              this._axes[k].maskCanvas && (delete this._axes[k].maskCanvas, delete this._axes[k].maskCtx);
          }
        };
        n.prototype.render = function(a) {
          a && (this.options = a);
          this._initialize();
          this.setLayout();
          this.renderElements();
          this._preRenderCanvas && za(this._preRenderCanvas);
        };
        n.prototype.attachPlotAreaEventHandlers = function() {
          this.attachEvent({
            context: this,
            chart: this,
            mousedown: this._plotAreaMouseDown,
            mouseup: this._plotAreaMouseUp,
            mousemove: this._plotAreaMouseMove,
            cursor: this.panEnabled ? "move" : "default",
            capture: true,
            bounds: this.plotArea
          });
        };
        n.prototype.categoriseDataSeries = function() {
          for (var a = "", d = 0; d < this.data.length; d++)
            if (a = this.data[d], a.dataPoints && (0 !== a.dataPoints.length && a.visible) && 0 <= n._supportedChartTypes.indexOf(a.type)) {
              for (var c = null, b = false, e = null, g = false, r = 0; r < this.plotInfo.plotTypes.length; r++)
                if (this.plotInfo.plotTypes[r].type === a.type) {
                  b = true;
                  c = this.plotInfo.plotTypes[r];
                  break;
                }
              b || (c = {
                type: a.type,
                totalDataSeries: 0,
                plotUnits: []
              }, this.plotInfo.plotTypes.push(c));
              for (r = 0; r < c.plotUnits.length; r++)
                if (c.plotUnits[r].axisYType === a.axisYType && c.plotUnits[r].axisXType === a.axisXType && c.plotUnits[r].axisYIndex === a.axisYIndex && c.plotUnits[r].axisXIndex === a.axisXIndex) {
                  g = true;
                  e = c.plotUnits[r];
                  break;
                }
              g || (e = { type: a.type, previousDataSeriesCount: 0, index: c.plotUnits.length, plotType: c, axisXType: a.axisXType, axisYType: a.axisYType, axisYIndex: a.axisYIndex, axisXIndex: a.axisXIndex, axisY: "primary" === a.axisYType ? this.axisY[0 <= a.axisYIndex && a.axisYIndex < this.axisY.length ? a.axisYIndex : 0] : this.axisY2[0 <= a.axisYIndex && a.axisYIndex < this.axisY2.length ? a.axisYIndex : 0], axisX: "primary" === a.axisXType ? this.axisX[0 <= a.axisXIndex && a.axisXIndex < this.axisX.length ? a.axisXIndex : 0] : this.axisX2[0 <= a.axisXIndex && a.axisXIndex < this.axisX2.length ? a.axisXIndex : 0], dataSeriesIndexes: [], yTotals: [], yAbsTotals: [] }, c.plotUnits.push(e));
              c.totalDataSeries++;
              e.dataSeriesIndexes.push(d);
              a.plotUnit = e;
            }
          for (d = 0; d < this.plotInfo.plotTypes.length; d++)
            for (c = this.plotInfo.plotTypes[d], r = a = 0; r < c.plotUnits.length; r++)
              c.plotUnits[r].previousDataSeriesCount = a, a += c.plotUnits[r].dataSeriesIndexes.length;
        };
        n.prototype.assignIdToDataPoints = function() {
          for (var a = 0; a < this.data.length; a++) {
            var d = this.data[a];
            if (d.dataPoints)
              for (var c = d.dataPoints.length, b = 0; b < c; b++)
                d.dataPointIds[b] = ++this._eventManager.lastObjectId;
          }
        };
        n.prototype._processData = function() {
          this.assignIdToDataPoints();
          this.categoriseDataSeries();
          for (var a = 0; a < this.plotInfo.plotTypes.length; a++)
            for (var d = this.plotInfo.plotTypes[a], c = 0; c < d.plotUnits.length; c++) {
              var b = d.plotUnits[c];
              "line" === b.type || "stepLine" === b.type || "spline" === b.type || "column" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "bar" === b.type || "bubble" === b.type || "scatter" === b.type ? this._processMultiseriesPlotUnit(b) : "stackedColumn" === b.type || "stackedBar" === b.type || "stackedArea" === b.type ? this._processStackedPlotUnit(b) : "stackedColumn100" === b.type || "stackedBar100" === b.type || "stackedArea100" === b.type ? this._processStacked100PlotUnit(b) : "candlestick" === b.type || "ohlc" === b.type || "rangeColumn" === b.type || "rangeBar" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "error" === b.type || "boxAndWhisker" === b.type ? this._processMultiYPlotUnit(b) : "waterfall" === b.type && this._processSpecificPlotUnit(b);
            }
          this.calculateAutoBreaks();
        };
        n.prototype._processMultiseriesPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, g = false, r = 0; r < a.dataSeriesIndexes.length; r++) {
              var u = this.data[a.dataSeriesIndexes[r]], B = 0, k = false, l = false, p;
              if ("normal" === u.axisPlacement || "xySwapped" === u.axisPlacement)
                var q = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, f = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (u.dataPoints[B].x && u.dataPoints[B].x.getTime || "dateTime" === u.xValueType)
                g = true;
              for (B = 0; B < u.dataPoints.length; B++) {
                "undefined" === typeof u.dataPoints[B].x && (u.dataPoints[B].x = B + (a.axisX.logarithmic ? 1 : 0));
                u.dataPoints[B].x.getTime ? (g = true, b = u.dataPoints[B].x.getTime()) : b = u.dataPoints[B].x;
                e = u.dataPoints[B].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                e < d.min && "number" === typeof e && (d.min = e);
                e > d.max && "number" === typeof e && (d.max = e);
                if (0 < B) {
                  if (a.axisX.logarithmic) {
                    var V = b / u.dataPoints[B - 1].x;
                    1 > V && (V = 1 / V);
                    c.minDiff > V && 1 !== V && (c.minDiff = V);
                  } else
                    V = b - u.dataPoints[B - 1].x, 0 > V && (V *= -1), c.minDiff > V && 0 !== V && (c.minDiff = V);
                  null !== e && null !== u.dataPoints[B - 1].y && (a.axisY.logarithmic ? (V = e / u.dataPoints[B - 1].y, 1 > V && (V = 1 / V), d.minDiff > V && 1 !== V && (d.minDiff = V)) : (V = e - u.dataPoints[B - 1].y, 0 > V && (V *= -1), d.minDiff > V && 0 !== V && (d.minDiff = V)));
                }
                if (b < q && !k)
                  null !== e && (p = b);
                else {
                  if (!k && (k = true, 0 < B)) {
                    B -= 2;
                    continue;
                  }
                  if (b > f && !l)
                    l = true;
                  else if (b > f && l)
                    continue;
                  u.dataPoints[B].label && (a.axisX.labels[b] = u.dataPoints[B].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === e ? c.viewPortMin === b && p < b && (c.viewPortMin = p) : (e < d.viewPortMin && "number" === typeof e && (d.viewPortMin = e), e > d.viewPortMax && "number" === typeof e && (d.viewPortMax = e));
                }
              }
              u.axisX.valueType = u.xValueType = g ? "dateTime" : "number";
            }
        };
        n.prototype._processStackedPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length)) {
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, g = false, r = [], u = [], B = Infinity, k = -Infinity, l = {}, p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = this.data[a.dataSeriesIndexes[p]], f = 0, V = false, h2 = false, x;
              if ("normal" === q.axisPlacement || "xySwapped" === q.axisPlacement)
                var s = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : -Infinity, y = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (q.dataPoints[f].x && q.dataPoints[f].x.getTime || "dateTime" === q.xValueType)
                g = true;
              for (f = 0; f < q.dataPoints.length; f++) {
                "undefined" === typeof q.dataPoints[f].x && (q.dataPoints[f].x = f + (a.axisX.logarithmic ? 1 : 0));
                q.dataPoints[f].x.getTime ? (g = true, b = q.dataPoints[f].x.getTime()) : b = q.dataPoints[f].x;
                e = m(q.dataPoints[f].y) ? 0 : q.dataPoints[f].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                if (0 < f) {
                  if (a.axisX.logarithmic) {
                    var v = b / q.dataPoints[f - 1].x;
                    1 > v && (v = 1 / v);
                    c.minDiff > v && 1 !== v && (c.minDiff = v);
                  } else
                    v = b - q.dataPoints[f - 1].x, 0 > v && (v *= -1), c.minDiff > v && 0 !== v && (c.minDiff = v);
                  null !== e && null !== q.dataPoints[f - 1].y && (a.axisY.logarithmic ? 0 < e && (v = e / q.dataPoints[f - 1].y, 1 > v && (v = 1 / v), d.minDiff > v && 1 !== v && (d.minDiff = v)) : (v = e - q.dataPoints[f - 1].y, 0 > v && (v *= -1), d.minDiff > v && 0 !== v && (d.minDiff = v)));
                }
                if (b < s && !V)
                  null !== q.dataPoints[f].y && (x = b);
                else {
                  if (!V && (V = true, 0 < f)) {
                    f -= 2;
                    continue;
                  }
                  if (b > y && !h2)
                    h2 = true;
                  else if (b > y && h2)
                    continue;
                  q.dataPoints[f].label && (a.axisX.labels[b] = q.dataPoints[f].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === q.dataPoints[f].y ? c.viewPortMin === b && x < b && (c.viewPortMin = x) : (l[b] = (l[b] || 0) + q.dataPoints[f].y, q.dataPointEOs[f].cumulativeY = l[b], a.yTotals[b] = (a.yTotals[b] ? a.yTotals[b] : 0) + e, a.yAbsTotals[b] = (a.yAbsTotals[b] ? a.yAbsTotals[b] : 0) + Math.abs(e), 0 <= e ? r[b] ? r[b] += e : (r[b] = e, B = Math.min(e, B)) : u[b] ? u[b] += e : (u[b] = e, k = Math.max(e, k)));
                }
              }
              a.axisY.scaleBreaks && (a.axisY.scaleBreaks.autoCalculate && 1 <= a.axisY.scaleBreaks.maxNumberOfAutoBreaks) && (d.dataPointYPositiveSums ? (d.dataPointYPositiveSums.push.apply(d.dataPointYPositiveSums, r), d.dataPointYNegativeSums.push.apply(d.dataPointYPositiveSums, u)) : (d.dataPointYPositiveSums = r, d.dataPointYNegativeSums = u));
              q.axisX.valueType = q.xValueType = g ? "dateTime" : "number";
            }
            for (f in r)
              r.hasOwnProperty(f) && !isNaN(f) && (a = r[f], a < d.min && (d.min = Math.min(a, B)), a > d.max && (d.max = a), f < c.viewPortMin || f > c.viewPortMax || (a < d.viewPortMin && (d.viewPortMin = Math.min(a, B)), a > d.viewPortMax && (d.viewPortMax = a)));
            for (f in u)
              u.hasOwnProperty(f) && !isNaN(f) && (a = u[f], a < d.min && (d.min = a), a > d.max && (d.max = Math.max(a, k)), f < c.viewPortMin || f > c.viewPortMax || (a < d.viewPortMin && (d.viewPortMin = a), a > d.viewPortMax && (d.viewPortMax = Math.max(a, k))));
          }
        };
        n.prototype._processStacked100PlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length)) {
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, g = false, r = false, u = false, B = {}, k = [], l = 0; l < a.dataSeriesIndexes.length; l++) {
              var p = this.data[a.dataSeriesIndexes[l]], q = 0, f = false, V = false, h2;
              if ("normal" === p.axisPlacement || "xySwapped" === p.axisPlacement)
                var x = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : -Infinity, s = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (p.dataPoints[q].x && p.dataPoints[q].x.getTime || "dateTime" === p.xValueType)
                g = true;
              for (q = 0; q < p.dataPoints.length; q++) {
                "undefined" === typeof p.dataPoints[q].x && (p.dataPoints[q].x = q + (a.axisX.logarithmic ? 1 : 0));
                p.dataPoints[q].x.getTime ? (g = true, b = p.dataPoints[q].x.getTime()) : b = p.dataPoints[q].x;
                e = m(p.dataPoints[q].y) ? null : p.dataPoints[q].y;
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                if (0 < q) {
                  if (a.axisX.logarithmic) {
                    var y = b / p.dataPoints[q - 1].x;
                    1 > y && (y = 1 / y);
                    c.minDiff > y && 1 !== y && (c.minDiff = y);
                  } else
                    y = b - p.dataPoints[q - 1].x, 0 > y && (y *= -1), c.minDiff > y && 0 !== y && (c.minDiff = y);
                  m(e) || null === p.dataPoints[q - 1].y || (a.axisY.logarithmic ? 0 < e && (y = e / p.dataPoints[q - 1].y, 1 > y && (y = 1 / y), d.minDiff > y && 1 !== y && (d.minDiff = y)) : (y = e - p.dataPoints[q - 1].y, 0 > y && (y *= -1), d.minDiff > y && 0 !== y && (d.minDiff = y)));
                }
                if (b < x && !f)
                  null !== e && (h2 = b);
                else {
                  if (!f && (f = true, 0 < q)) {
                    q -= 2;
                    continue;
                  }
                  if (b > s && !V)
                    V = true;
                  else if (b > s && V)
                    continue;
                  p.dataPoints[q].label && (a.axisX.labels[b] = p.dataPoints[q].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  null === e ? c.viewPortMin === b && h2 < b && (c.viewPortMin = h2) : (B[b] = (B[b] || 0) + p.dataPoints[q].y, p.dataPointEOs[q].cumulativeY = B[b], a.yTotals[b] = (a.yTotals[b] ? a.yTotals[b] : 0) + e, a.yAbsTotals[b] = (a.yAbsTotals[b] ? a.yAbsTotals[b] : 0) + Math.abs(e), 0 <= e ? r = true : 0 > e && (u = true), k[b] = k[b] ? k[b] + Math.abs(e) : Math.abs(e));
                }
              }
              p.axisX.valueType = p.xValueType = g ? "dateTime" : "number";
            }
            a.axisY.logarithmic ? (d.max = m(d.viewPortMax) ? 99 * Math.pow(a.axisY.logarithmBase, -0.05) : Math.max(
              d.viewPortMax,
              99 * Math.pow(a.axisY.logarithmBase, -0.05)
            ), d.min = m(d.viewPortMin) ? 1 : Math.min(d.viewPortMin, 1)) : r && !u ? (d.max = m(d.viewPortMax) ? 99 : Math.max(d.viewPortMax, 99), d.min = m(d.viewPortMin) ? 1 : Math.min(d.viewPortMin, 1)) : r && u ? (d.max = m(d.viewPortMax) ? 99 : Math.max(d.viewPortMax, 99), d.min = m(d.viewPortMin) ? -99 : Math.min(d.viewPortMin, -99)) : !r && u && (d.max = m(d.viewPortMax) ? -1 : Math.max(d.viewPortMax, -1), d.min = m(d.viewPortMin) ? -99 : Math.min(d.viewPortMin, -99));
            d.viewPortMin = d.min;
            d.viewPortMax = d.max;
            a.dataPointYSums = k;
          }
        };
        n.prototype._processMultiYPlotUnit = function(a) {
          if (a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, g, r, u = false, B = 0; B < a.dataSeriesIndexes.length; B++) {
              var k = this.data[a.dataSeriesIndexes[B]], l = 0, p = false, q = false, f, V, h2;
              if ("normal" === k.axisPlacement || "xySwapped" === k.axisPlacement)
                var m2 = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, s = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (k.dataPoints[l].x && k.dataPoints[l].x.getTime || "dateTime" === k.xValueType)
                u = true;
              for (l = 0; l < k.dataPoints.length; l++) {
                "undefined" === typeof k.dataPoints[l].x && (k.dataPoints[l].x = l + (a.axisX.logarithmic ? 1 : 0));
                k.dataPoints[l].x.getTime ? (u = true, b = k.dataPoints[l].x.getTime()) : b = k.dataPoints[l].x;
                if ((e = k.dataPoints[l].y) && e.length) {
                  g = Math.min.apply(null, e);
                  r = Math.max.apply(null, e);
                  V = true;
                  for (var y = 0; y < e.length; y++)
                    null === e.k && (V = false);
                  V && (p || (h2 = f), f = b);
                }
                b < c.min && (c.min = b);
                b > c.max && (c.max = b);
                g < d.min && (d.min = g);
                r > d.max && (d.max = r);
                0 < l && (a.axisX.logarithmic ? (V = b / k.dataPoints[l - 1].x, 1 > V && (V = 1 / V), c.minDiff > V && 1 !== V && (c.minDiff = V)) : (V = b - k.dataPoints[l - 1].x, 0 > V && (V *= -1), c.minDiff > V && 0 !== V && (c.minDiff = V)), e && (null !== e[0] && k.dataPoints[l - 1].y && null !== k.dataPoints[l - 1].y[0]) && (a.axisY.logarithmic ? (V = e[0] / k.dataPoints[l - 1].y[0], 1 > V && (V = 1 / V), d.minDiff > V && 1 !== V && (d.minDiff = V)) : (V = e[0] - k.dataPoints[l - 1].y[0], 0 > V && (V *= -1), d.minDiff > V && 0 !== V && (d.minDiff = V))));
                if (!(b < m2) || p) {
                  if (!p && (p = true, 0 < l)) {
                    l -= 2;
                    f = h2;
                    continue;
                  }
                  if (b > s && !q)
                    q = true;
                  else if (b > s && q)
                    continue;
                  k.dataPoints[l].label && (a.axisX.labels[b] = k.dataPoints[l].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  if (c.viewPortMin === b && e) {
                    for (y = 0; y < e.length; y++)
                      if (null === e[y] && f < b) {
                        c.viewPortMin = f;
                        break;
                      }
                  }
                  null === e ? c.viewPortMin === b && f < b && (c.viewPortMin = f) : (g < d.viewPortMin && (d.viewPortMin = g), r > d.viewPortMax && (d.viewPortMax = r));
                }
              }
              k.axisX.valueType = k.xValueType = u ? "dateTime" : "number";
            }
        };
        n.prototype._processSpecificPlotUnit = function(a) {
          if ("waterfall" === a.type && a.dataSeriesIndexes && !(1 > a.dataSeriesIndexes.length))
            for (var d = a.axisY.dataInfo, c = a.axisX.dataInfo, b, e, g = false, r = 0; r < a.dataSeriesIndexes.length; r++) {
              var u = this.data[a.dataSeriesIndexes[r]], B = 0, k = false, l = false, p = b = 0;
              if ("normal" === u.axisPlacement || "xySwapped" === u.axisPlacement)
                var q = a.axisX.sessionVariables.newViewportMinimum ? a.axisX.sessionVariables.newViewportMinimum : a.axisX.options && a.axisX.options.viewportMinimum ? a.axisX.options.viewportMinimum : a.axisX.options && a.axisX.options.minimum ? a.axisX.options.minimum : a.axisX.logarithmic ? 0 : -Infinity, f = a.axisX.sessionVariables.newViewportMaximum ? a.axisX.sessionVariables.newViewportMaximum : a.axisX.options && a.axisX.options.viewportMaximum ? a.axisX.options.viewportMaximum : a.axisX.options && a.axisX.options.maximum ? a.axisX.options.maximum : Infinity;
              if (u.dataPoints[B].x && u.dataPoints[B].x.getTime || "dateTime" === u.xValueType)
                g = true;
              for (B = 0; B < u.dataPoints.length; B++)
                "undefined" !== typeof u.dataPoints[B].isCumulativeSum && true === u.dataPoints[B].isCumulativeSum ? (u.dataPointEOs[B].cumulativeSumYStartValue = 0, u.dataPointEOs[B].cumulativeSum = 0 === B ? 0 : u.dataPointEOs[B - 1].cumulativeSum, u.dataPoints[B].y = 0 === B ? 0 : u.dataPointEOs[B - 1].cumulativeSum) : "undefined" !== typeof u.dataPoints[B].isIntermediateSum && true === u.dataPoints[B].isIntermediateSum ? (u.dataPointEOs[B].cumulativeSumYStartValue = p, u.dataPointEOs[B].cumulativeSum = 0 === B ? 0 : u.dataPointEOs[B - 1].cumulativeSum, u.dataPoints[B].y = 0 === B ? 0 : b, p = 0 === B ? 0 : u.dataPointEOs[B - 1].cumulativeSum, b = 0) : (e = "number" !== typeof u.dataPoints[B].y ? 0 : u.dataPoints[B].y, u.dataPointEOs[B].cumulativeSumYStartValue = 0 === B ? 0 : u.dataPointEOs[B - 1].cumulativeSum, u.dataPointEOs[B].cumulativeSum = 0 === B ? e : u.dataPointEOs[B - 1].cumulativeSum + e, b += e);
              for (B = 0; B < u.dataPoints.length; B++)
                if ("undefined" === typeof u.dataPoints[B].x && (u.dataPoints[B].x = B + (a.axisX.logarithmic ? 1 : 0)), u.dataPoints[B].x.getTime ? (g = true, b = u.dataPoints[B].x.getTime()) : b = u.dataPoints[B].x, e = u.dataPoints[B].y, b < c.min && (c.min = b), b > c.max && (c.max = b), u.dataPointEOs[B].cumulativeSum < d.min && (d.min = u.dataPointEOs[B].cumulativeSum), u.dataPointEOs[B].cumulativeSum > d.max && (d.max = u.dataPointEOs[B].cumulativeSum), 0 < B && (a.axisX.logarithmic ? (p = b / u.dataPoints[B - 1].x, 1 > p && (p = 1 / p), c.minDiff > p && 1 !== p && (c.minDiff = p)) : (p = b - u.dataPoints[B - 1].x, 0 > p && (p *= -1), c.minDiff > p && 0 !== p && (c.minDiff = p)), null !== e && null !== u.dataPoints[B - 1].y && (a.axisY.logarithmic ? (e = u.dataPointEOs[B].cumulativeSum / u.dataPointEOs[B - 1].cumulativeSum, 1 > e && (e = 1 / e), d.minDiff > e && 1 !== e && (d.minDiff = e)) : (e = u.dataPointEOs[B].cumulativeSum - u.dataPointEOs[B - 1].cumulativeSum, 0 > e && (e *= -1), d.minDiff > e && 0 !== e && (d.minDiff = e)))), !(b < q) || k) {
                  if (!k && (k = true, 0 < B)) {
                    B -= 2;
                    continue;
                  }
                  if (b > f && !l)
                    l = true;
                  else if (b > f && l)
                    continue;
                  u.dataPoints[B].label && (a.axisX.labels[b] = u.dataPoints[B].label);
                  b < c.viewPortMin && (c.viewPortMin = b);
                  b > c.viewPortMax && (c.viewPortMax = b);
                  0 < B && (u.dataPointEOs[B - 1].cumulativeSum < d.viewPortMin && (d.viewPortMin = u.dataPointEOs[B - 1].cumulativeSum), u.dataPointEOs[B - 1].cumulativeSum > d.viewPortMax && (d.viewPortMax = u.dataPointEOs[B - 1].cumulativeSum));
                  u.dataPointEOs[B].cumulativeSum < d.viewPortMin && (d.viewPortMin = u.dataPointEOs[B].cumulativeSum);
                  u.dataPointEOs[B].cumulativeSum > d.viewPortMax && (d.viewPortMax = u.dataPointEOs[B].cumulativeSum);
                }
              u.axisX.valueType = u.xValueType = g ? "dateTime" : "number";
            }
        };
        n.prototype.calculateAutoBreaks = function() {
          function a(a2, b2, c2, e2) {
            if (e2)
              return c2 = Math.pow(Math.min(c2 * a2 / b2, b2 / a2), 0.2), 1 >= c2 && (c2 = Math.pow(1 > a2 ? 1 / a2 : Math.min(b2 / a2, a2), 0.25)), { startValue: a2 * c2, endValue: b2 / c2 };
            c2 = 0.2 * Math.min(c2 - b2 + a2, b2 - a2);
            0 >= c2 && (c2 = 0.25 * Math.min(b2 - a2, Math.abs(a2)));
            return { startValue: a2 + c2, endValue: b2 - c2 };
          }
          function d(a2) {
            if (a2.dataSeriesIndexes && !(1 > a2.dataSeriesIndexes.length)) {
              var b2 = a2.axisX.scaleBreaks && a2.axisX.scaleBreaks.autoCalculate && 1 <= a2.axisX.scaleBreaks.maxNumberOfAutoBreaks, c2 = a2.axisY.scaleBreaks && a2.axisY.scaleBreaks.autoCalculate && 1 <= a2.axisY.scaleBreaks.maxNumberOfAutoBreaks;
              if (b2 || c2)
                for (var d2 = a2.axisY.dataInfo, f2 = a2.axisX.dataInfo, g2, r2 = f2.min, k2 = f2.max, l2 = d2.min, q2 = d2.max, f2 = f2._dataRanges, d2 = d2._dataRanges, p2, u2 = 0, B2 = 0; B2 < a2.dataSeriesIndexes.length; B2++) {
                  var h2 = e.data[a2.dataSeriesIndexes[B2]];
                  if (!(4 > h2.dataPoints.length)) {
                    for (u2 = 0; u2 < h2.dataPoints.length; u2++)
                      if (b2 && (p2 = (k2 + 1 - r2) * Math.max(parseFloat(a2.axisX.scaleBreaks.collapsibleThreshold) || 10, 10) / 100, g2 = h2.dataPoints[u2].x.getTime ? h2.dataPoints[u2].x.getTime() : h2.dataPoints[u2].x, p2 = Math.floor((g2 - r2) / p2), g2 < f2[p2].min && (f2[p2].min = g2), g2 > f2[p2].max && (f2[p2].max = g2)), c2) {
                        var t2 = (q2 + 1 - l2) * Math.max(parseFloat(a2.axisY.scaleBreaks.collapsibleThreshold) || 10, 10) / 100;
                        if ((g2 = "waterfall" === a2.type ? h2.dataPointEOs[u2].cumulativeSum : h2.dataPoints[u2].y) && g2.length)
                          for (var n2 = 0; n2 < g2.length; n2++)
                            p2 = Math.floor((g2[n2] - l2) / t2), g2[n2] < d2[p2].min && (d2[p2].min = g2[n2]), g2[n2] > d2[p2].max && (d2[p2].max = g2[n2]);
                        else
                          m(g2) || (p2 = Math.floor((g2 - l2) / t2), g2 < d2[p2].min && (d2[p2].min = g2), g2 > d2[p2].max && (d2[p2].max = g2));
                      }
                  }
                }
            }
          }
          function c(a2) {
            if (a2.dataSeriesIndexes && !(1 > a2.dataSeriesIndexes.length) && a2.axisX.scaleBreaks && a2.axisX.scaleBreaks.autoCalculate && 1 <= a2.axisX.scaleBreaks.maxNumberOfAutoBreaks)
              for (var b2 = a2.axisX.dataInfo, c2 = b2.min, d2 = b2.max, f2 = b2._dataRanges, g2, r2 = 0, k2 = 0; k2 < a2.dataSeriesIndexes.length; k2++) {
                var l2 = e.data[a2.dataSeriesIndexes[k2]];
                if (!(4 > l2.dataPoints.length))
                  for (r2 = 0; r2 < l2.dataPoints.length; r2++)
                    g2 = (d2 + 1 - c2) * Math.max(parseFloat(a2.axisX.scaleBreaks.collapsibleThreshold) || 10, 10) / 100, b2 = l2.dataPoints[r2].x.getTime ? l2.dataPoints[r2].x.getTime() : l2.dataPoints[r2].x, g2 = Math.floor((b2 - c2) / g2), b2 < f2[g2].min && (f2[g2].min = b2), b2 > f2[g2].max && (f2[g2].max = b2);
              }
          }
          for (var b, e = this, g = false, r = 0; r < this._axes.length; r++)
            if (this._axes[r].scaleBreaks && this._axes[r].scaleBreaks.autoCalculate && 1 <= this._axes[r].scaleBreaks.maxNumberOfAutoBreaks) {
              g = true;
              this._axes[r].dataInfo._dataRanges = [];
              for (var u = 0; u < 100 / Math.max(parseFloat(this._axes[r].scaleBreaks.collapsibleThreshold) || 10, 10); u++)
                this._axes[r].dataInfo._dataRanges.push({ min: Infinity, max: -Infinity });
            }
          if (g) {
            for (r = 0; r < this.plotInfo.plotTypes.length; r++)
              for (g = this.plotInfo.plotTypes[r], u = 0; u < g.plotUnits.length; u++)
                b = g.plotUnits[u], "line" === b.type || "stepLine" === b.type || "spline" === b.type || "column" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "bar" === b.type || "bubble" === b.type || "scatter" === b.type || "candlestick" === b.type || "ohlc" === b.type || "rangeColumn" === b.type || "rangeBar" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type || "waterfall" === b.type || "error" === b.type || "boxAndWhisker" === b.type ? d(b) : 0 <= b.type.indexOf("stacked") && c(b);
            for (r = 0; r < this._axes.length; r++)
              if (this._axes[r].dataInfo._dataRanges) {
                var B = this._axes[r].dataInfo.min;
                b = (this._axes[r].dataInfo.max + 1 - B) * Math.max(parseFloat(this._axes[r].scaleBreaks.collapsibleThreshold) || 10, 10) / 100;
                var k = this._axes[r].dataInfo._dataRanges, l, p, g = [];
                if (this._axes[r].dataInfo.dataPointYPositiveSums) {
                  var q = this._axes[r].dataInfo.dataPointYPositiveSums;
                  l = k;
                  for (u in q)
                    if (q.hasOwnProperty(u) && !isNaN(u) && (p = q[u], !m(p))) {
                      var f = Math.floor((p - B) / b);
                      p < l[f].min && (l[f].min = p);
                      p > l[f].max && (l[f].max = p);
                    }
                  delete this._axes[r].dataInfo.dataPointYPositiveSums;
                }
                if (this._axes[r].dataInfo.dataPointYNegativeSums) {
                  q = this._axes[r].dataInfo.dataPointYNegativeSums;
                  l = k;
                  for (u in q)
                    q.hasOwnProperty(u) && !isNaN(u) && (p = -1 * q[u], m(p) || (f = Math.floor((p - B) / b), p < l[f].min && (l[f].min = p), p > l[f].max && (l[f].max = p)));
                  delete this._axes[r].dataInfo.dataPointYNegativeSums;
                }
                for (u = 0; u < k.length - 1; u++)
                  if (l = k[u].max, isFinite(l))
                    for (; u < k.length - 1; )
                      if (B = k[u + 1].min, isFinite(B)) {
                        p = B - l;
                        p > b && g.push({ diff: p, start: l, end: B });
                        break;
                      } else
                        u++;
                if (this._axes[r].scaleBreaks.customBreaks) {
                  for (u = 0; u < this._axes[r].scaleBreaks.customBreaks.length; u++)
                    for (b = 0; b < g.length; b++)
                      if (this._axes[r].scaleBreaks.customBreaks[u].startValue <= g[b].start && g[b].start <= this._axes[r].scaleBreaks.customBreaks[u].endValue || this._axes[r].scaleBreaks.customBreaks[u].startValue <= g[b].start && g[b].start <= this._axes[r].scaleBreaks.customBreaks[u].endValue || g[b].start <= this._axes[r].scaleBreaks.customBreaks[u].startValue && this._axes[r].scaleBreaks.customBreaks[u].startValue <= g[b].end || g[b].start <= this._axes[r].scaleBreaks.customBreaks[u].endValue && this._axes[r].scaleBreaks.customBreaks[u].endValue <= g[b].end)
                        g.splice(b, 1), b--;
                }
                g.sort(function(a2, b2) {
                  return b2.diff - a2.diff;
                });
                for (u = 0; u < Math.min(g.length, this._axes[r].scaleBreaks.maxNumberOfAutoBreaks); u++)
                  b = a(g[u].start, g[u].end, this._axes[r].logarithmic ? this._axes[r].dataInfo.max / this._axes[r].dataInfo.min : this._axes[r].dataInfo.max - this._axes[r].dataInfo.min, this._axes[r].logarithmic), this._axes[r].scaleBreaks.autoBreaks.push(new da2(this, "autoBreaks", b, u, ++this._eventManager.lastObjectId, this._axes[r].scaleBreaks)), this._axes[r].scaleBreaks._appliedBreaks.push(this._axes[r].scaleBreaks.autoBreaks[this._axes[r].scaleBreaks.autoBreaks.length - 1]);
                this._axes[r].scaleBreaks._appliedBreaks.sort(function(a2, b2) {
                  return a2.startValue - b2.startValue;
                });
              }
          }
        };
        n.prototype.renderCrosshairs = function(a) {
          for (var d = 0; d < this.axisX.length; d++)
            this.axisX[d] != a && (this.axisX[d].crosshair && this.axisX[d].crosshair.enabled && !this.axisX[d].crosshair._hidden) && this.axisX[d].showCrosshair(this.axisX[d].crosshair._updatedValue);
          for (d = 0; d < this.axisX2.length; d++)
            this.axisX2[d] != a && (this.axisX2[d].crosshair && this.axisX2[d].crosshair.enabled && !this.axisX2[d].crosshair._hidden) && this.axisX2[d].showCrosshair(this.axisX2[d].crosshair._updatedValue);
          for (d = 0; d < this.axisY.length; d++)
            this.axisY[d] != a && (this.axisY[d].crosshair && this.axisY[d].crosshair.enabled && !this.axisY[d].crosshair._hidden) && this.axisY[d].showCrosshair(this.axisY[d].crosshair._updatedValue);
          for (d = 0; d < this.axisY2.length; d++)
            this.axisY2[d] != a && (this.axisY2[d].crosshair && this.axisY2[d].crosshair.enabled && !this.axisY2[d].crosshair._hidden) && this.axisY2[d].showCrosshair(this.axisY2[d].crosshair._updatedValue);
        };
        n.prototype.getDataPointAtXY = function(a, d, c) {
          c = c || false;
          for (var b = [], e = this._dataInRenderedOrder.length - 1; 0 <= e; e--) {
            var g = null;
            (g = this._dataInRenderedOrder[e].getDataPointAtXY(a, d, c)) && b.push(g);
          }
          a = null;
          d = false;
          for (c = 0; c < b.length; c++)
            if ("line" === b[c].dataSeries.type || "stepLine" === b[c].dataSeries.type || "area" === b[c].dataSeries.type || "stepArea" === b[c].dataSeries.type) {
              if (e = oa("markerSize", b[c].dataPoint, b[c].dataSeries) || 8, b[c].distance <= e / 2) {
                d = true;
                break;
              }
            }
          for (c = 0; c < b.length; c++)
            d && "line" !== b[c].dataSeries.type && "stepLine" !== b[c].dataSeries.type && "area" !== b[c].dataSeries.type && "stepArea" !== b[c].dataSeries.type || (a ? b[c].distance <= a.distance && (a = b[c]) : a = b[c]);
          return a;
        };
        n.prototype.getObjectAtXY = function(a, d, c) {
          var b = null;
          if (c = this.getDataPointAtXY(a, d, c || false))
            b = c.dataSeries.dataPointIds[c.dataPointIndex];
          else if (t)
            b = $a(a, d, this._eventManager.ghostCtx);
          else
            for (c = 0; c < this.legend.items.length; c++) {
              var e = this.legend.items[c];
              a >= e.x1 && (a <= e.x2 && d >= e.y1 && d <= e.y2) && (b = e.id);
            }
          return b;
        };
        n.prototype.getAutoFontSize = mb;
        n.prototype.resetOverlayedCanvas = function() {
          this.overlaidCanvasCtx.clearRect(0, 0, this.width, this.height);
        };
        n.prototype.clearCanvas = lb;
        n.prototype.attachEvent = function(a) {
          this._events.push(a);
        };
        n.prototype._touchEventHandler = function(a) {
          if (a.changedTouches && this.interactivityEnabled) {
            var d = [], c = a.changedTouches, b = c ? c[0] : a, e = null;
            switch (a.type) {
              case "touchstart":
              case "MSPointerDown":
                d = ["mousemove", "mousedown"];
                this._lastTouchData = Pa(b);
                this._lastTouchData.time = /* @__PURE__ */ new Date();
                break;
              case "touchmove":
              case "MSPointerMove":
                d = ["mousemove"];
                break;
              case "touchend":
              case "MSPointerUp":
                var g = this._lastTouchData && this._lastTouchData.time ? /* @__PURE__ */ new Date() - this._lastTouchData.time : 0, d = "touchstart" === this._lastTouchEventType || "MSPointerDown" === this._lastTouchEventType || 300 > g ? ["mouseup", "click"] : ["mouseup"];
                break;
              default:
                return;
            }
            if (!(c && 1 < c.length)) {
              e = Pa(b);
              e.time = /* @__PURE__ */ new Date();
              try {
                var r = e.y - this._lastTouchData.y, g = e.time - this._lastTouchData.time;
                if (1 < Math.abs(r) && this._lastTouchData.scroll || 5 < Math.abs(r) && 250 > g)
                  this._lastTouchData.scroll = true;
              } catch (u) {
              }
              this._lastTouchEventType = a.type;
              if (this._lastTouchData.scroll && this.zoomEnabled)
                this.isDrag && this.resetOverlayedCanvas(), this.isDrag = false;
              else
                for (c = 0; c < d.length; c++)
                  if (e = d[c], r = document.createEvent("MouseEvent"), r.initMouseEvent(e, true, true, window, 1, b.screenX, b.screenY, b.clientX, b.clientY, false, false, false, false, 0, null), b.target.dispatchEvent(r), !m(this._lastTouchData.scroll) && !this._lastTouchData.scroll || !this._lastTouchData.scroll && 250 < g || "click" === e)
                    a.preventManipulation && a.preventManipulation(), a.preventDefault && a.cancelable && a.preventDefault();
            }
          }
        };
        n.prototype._dispatchRangeEvent = function(a, d) {
          var c = { chart: this };
          c.type = a;
          c.trigger = d;
          var b = [];
          this.axisX && 0 < this.axisX.length && b.push("axisX");
          this.axisX2 && 0 < this.axisX2.length && b.push("axisX2");
          this.axisY && 0 < this.axisY.length && b.push("axisY");
          this.axisY2 && 0 < this.axisY2.length && b.push("axisY2");
          for (var e = 0; e < b.length; e++)
            if (m(c[b[e]]) && (c[b[e]] = []), "axisY" === b[e])
              for (var g = 0; g < this.axisY.length; g++)
                c[b[e]].push({ viewportMinimum: this[b[e]][g].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][g].sessionVariables.newViewportMaximum });
            else if ("axisY2" === b[e])
              for (g = 0; g < this.axisY2.length; g++)
                c[b[e]].push({ viewportMinimum: this[b[e]][g].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][g].sessionVariables.newViewportMaximum });
            else if ("axisX" === b[e])
              for (g = 0; g < this.axisX.length; g++)
                c[b[e]].push({ viewportMinimum: this[b[e]][g].sessionVariables.newViewportMinimum, viewportMaximum: this[b[e]][g].sessionVariables.newViewportMaximum });
            else if ("axisX2" === b[e])
              for (g = 0; g < this.axisX2.length; g++)
                c[b[e]].push({
                  viewportMinimum: this[b[e]][g].sessionVariables.newViewportMinimum,
                  viewportMaximum: this[b[e]][g].sessionVariables.newViewportMaximum
                });
          this.dispatchEvent(a, c, this);
        };
        n.prototype._mouseEventHandler = function(a) {
          function d() {
            n.capturedEventParam && (e = n.capturedEventParam, r = e.bounds, "mouseup" === b && (n.capturedEventParam = null, e.chart.overlaidCanvas.releaseCapture ? e.chart.overlaidCanvas.releaseCapture() : document.documentElement.removeEventListener("mouseup", e.chart._mouseEventHandler, false)), e.hasOwnProperty(b) && ("mouseup" !== b || e.chart.overlaidCanvas.releaseCapture ? a.target !== e.chart.overlaidCanvas && t || e[b].call(e.context, c.x, c.y) : a.target !== e.chart.overlaidCanvas && (e.chart.isDrag = false)));
          }
          "undefined" === typeof a.target && a.srcElement && (a.target = a.srcElement);
          var c = Pa(a), b = a.type, e, g;
          a.which ? g = 3 == a.which : a.button && (g = 2 == a.button);
          if (this._ignoreNextEvent)
            d(), this._ignoreNextEvent = false;
          else if (d(), this.interactivityEnabled) {
            a.preventManipulation && a.preventManipulation();
            a.preventDefault && a.preventDefault();
            var r;
            Ia && window.console && (window.console.log(b + " --> x: " + c.x + "; y:" + c.y), g && window.console.log(a.which), "mouseup" === b && window.console.log("mouseup"));
            if (!g) {
              if (!n.capturedEventParam && this._events) {
                for (g = 0; g < this._events.length; g++)
                  if (this._events[g].hasOwnProperty(b))
                    if (e = this._events[g], r = e.bounds, c.x >= r.x1 && c.x <= r.x2 && c.y >= r.y1 && c.y <= r.y2) {
                      e[b].call(e.context, c.x, c.y);
                      "mousedown" === b && true === e.capture ? (n.capturedEventParam = e, this.overlaidCanvas.setCapture ? this.overlaidCanvas.setCapture() : document.documentElement.addEventListener(
                        "mouseup",
                        this._mouseEventHandler,
                        false
                      )) : "mouseup" === b && (e.chart.overlaidCanvas.releaseCapture ? e.chart.overlaidCanvas.releaseCapture() : document.documentElement.removeEventListener("mouseup", this._mouseEventHandler, false));
                      break;
                    } else
                      e = null;
                a.target.style.cursor = e && e.cursor ? e.cursor : this._defaultCursor;
              }
              g = this.plotArea;
              if (c.x < g.x1 || c.x > g.x2 || c.y < g.y1 || c.y > g.y2) {
                this.toolTip && this.toolTip.enabled ? (this.toolTip.hide(), this.toolTip.dispatchEvent("hidden", { chart: this, toolTip: this.toolTip }, this.toolTip)) : this.resetOverlayedCanvas();
                for (g = 0; g < this.axisX.length; g++)
                  this.axisX[g].crosshair && this.axisX[g].crosshair.enabled && (this.axisX[g].crosshair.hide(), this.axisX[g].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX[g].options }, this.axisX[g].crosshair));
                for (g = 0; g < this.axisX2.length; g++)
                  this.axisX2[g].crosshair && this.axisX2[g].crosshair.enabled && (this.axisX2[g].crosshair.hide(), this.axisX2[g].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX2[g].options }, this.axisX2[g].crosshair));
                for (g = 0; g < this.axisY.length; g++)
                  this.axisY[g].crosshair && this.axisY[g].crosshair.enabled && (this.axisY[g].crosshair.hide(), this.axisY[g].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY[g].options }, this.axisY[g].crosshair));
                for (g = 0; g < this.axisY2.length; g++)
                  this.axisY2[g].crosshair && this.axisY2[g].crosshair.enabled && (this.axisY2[g].crosshair.hide(), this.axisY2[g].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY2[g].options }, this.axisY2[g].crosshair));
              }
              this.isDrag && this.zoomEnabled || !this._eventManager || this._eventManager.mouseEventHandler(a);
            }
          }
        };
        n.prototype._plotAreaMouseDown = function(a, d) {
          this.isDrag = true;
          this.dragStartPoint = { x: a, y: d };
        };
        n.prototype._plotAreaMouseUp = function(a, d) {
          if (("normal" === this.plotInfo.axisPlacement || "xySwapped" === this.plotInfo.axisPlacement) && this.isDrag) {
            var c = d - this.dragStartPoint.y, b = a - this.dragStartPoint.x, e = 0 <= this.zoomType.indexOf("x"), g = 0 <= this.zoomType.indexOf("y"), r = false;
            this.resetOverlayedCanvas();
            if ("xySwapped" === this.plotInfo.axisPlacement)
              var u = g, g = e, e = u;
            if (this.panEnabled || this.zoomEnabled) {
              if (this.panEnabled)
                for (e = g = 0; e < this._axes.length; e++)
                  c = this._axes[e], c.logarithmic ? c.viewportMinimum < c.minimum ? (g = c.minimum / c.viewportMinimum, c.sessionVariables.newViewportMinimum = c.viewportMinimum * g, c.sessionVariables.newViewportMaximum = c.viewportMaximum * g, r = true) : c.viewportMaximum > c.maximum && (g = c.viewportMaximum / c.maximum, c.sessionVariables.newViewportMinimum = c.viewportMinimum / g, c.sessionVariables.newViewportMaximum = c.viewportMaximum / g, r = true) : c.viewportMinimum < c.minimum ? (g = c.minimum - c.viewportMinimum, c.sessionVariables.newViewportMinimum = c.viewportMinimum + g, c.sessionVariables.newViewportMaximum = c.viewportMaximum + g, r = true) : c.viewportMaximum > c.maximum && (g = c.viewportMaximum - c.maximum, c.sessionVariables.newViewportMinimum = c.viewportMinimum - g, c.sessionVariables.newViewportMaximum = c.viewportMaximum - g, r = true);
              else if ((!e || 2 < Math.abs(b)) && (!g || 2 < Math.abs(c)) && this.zoomEnabled) {
                if (!this.dragStartPoint)
                  return;
                c = e ? this.dragStartPoint.x : this.plotArea.x1;
                b = g ? this.dragStartPoint.y : this.plotArea.y1;
                e = e ? a : this.plotArea.x2;
                g = g ? d : this.plotArea.y2;
                2 < Math.abs(c - e) && 2 < Math.abs(b - g) && this._zoomPanToSelectedRegion(c, b, e, g) && (r = true);
              }
              r && (this._ignoreNextEvent = true, this._dispatchRangeEvent("rangeChanging", "zoom"), this.stockChart && (this.stockChart.navigator && this.stockChart.navigator.enabled) && (this.stockChart._rangeEventParameter || (this.stockChart._rangeEventParameter = { stockChart: this.stockChart, source: "chart", index: this.stockChart.charts.indexOf(this), minimum: this.stockChart.sessionVariables._axisXMin, maximum: this.stockChart.sessionVariables._axisXMax }), this.stockChart._rangeEventParameter.type = "rangeChanging", this.stockChart.dispatchEvent("rangeChanging", this.stockChart._rangeEventParameter, this.stockChart)), this.render(), this._dispatchRangeEvent("rangeChanged", "zoom"), this.stockChart && (this.stockChart.navigator && this.stockChart.navigator.enabled) && (this.stockChart._rangeEventParameter.type = "rangeChanged", this.stockChart.dispatchEvent("rangeChanged", this.stockChart._rangeEventParameter, this.stockChart)), r && (this.zoomEnabled && "none" === this._zoomButton.style.display) && (Ma(
                this._zoomButton,
                this._resetButton
              ), ua(this, this._zoomButton, "pan"), ua(this, this._resetButton, "reset")));
            }
          }
          this.isDrag = false;
          if ("none" !== this.plotInfo.axisPlacement) {
            this.resetOverlayedCanvas();
            if (this.axisX && 0 < this.axisX.length)
              for (r = 0; r < this.axisX.length; r++)
                this.axisX[r].crosshair && this.axisX[r].crosshair.enabled && this.axisX[r].renderCrosshair(a, d);
            if (this.axisX2 && 0 < this.axisX2.length)
              for (r = 0; r < this.axisX2.length; r++)
                this.axisX2[r].crosshair && this.axisX2[r].crosshair.enabled && this.axisX2[r].renderCrosshair(a, d);
            if (this.axisY && 0 < this.axisY.length)
              for (r = 0; r < this.axisY.length; r++)
                this.axisY[r].crosshair && this.axisY[r].crosshair.enabled && this.axisY[r].renderCrosshair(a, d);
            if (this.axisY2 && 0 < this.axisY2.length)
              for (r = 0; r < this.axisY2.length; r++)
                this.axisY2[r].crosshair && this.axisY2[r].crosshair.enabled && this.axisY2[r].renderCrosshair(a, d);
            if (this.axisX && 0 < this.axisX.length)
              for (r = 0; r < this.axisX.length; r++)
                this.axisX[r].crosshair && this.axisX[r].crosshair.enabled && this.axisX[r].crosshair.renderLabel();
            if (this.axisX2 && 0 < this.axisX2.length)
              for (r = 0; r < this.axisX2.length; r++)
                this.axisX2[r].crosshair && this.axisX2[r].crosshair.enabled && this.axisX2[r].crosshair.renderLabel();
            if (this.axisY && 0 < this.axisY.length)
              for (r = 0; r < this.axisY.length; r++)
                this.axisY[r].crosshair && this.axisY[r].crosshair.enabled && this.axisY[r].crosshair.renderLabel();
            if (this.axisY2 && 0 < this.axisY2.length)
              for (r = 0; r < this.axisY2.length; r++)
                this.axisY2[r].crosshair && this.axisY2[r].crosshair.enabled && this.axisY2[r].crosshair.renderLabel();
          }
        };
        n.prototype._plotAreaMouseMove = function(a, d) {
          if (this.isDrag && "none" !== this.plotInfo.axisPlacement) {
            var c = 0, b = 0, e = c = null, e = 0 <= this.zoomType.indexOf("x"), g = 0 <= this.zoomType.indexOf("y"), r = this;
            "xySwapped" === this.plotInfo.axisPlacement && (c = g, g = e, e = c);
            c = this.dragStartPoint.x - a;
            b = this.dragStartPoint.y - d;
            if (2 < Math.abs(c) && 8 > Math.abs(c) && (this.panEnabled || this.zoomEnabled)) {
              this.toolTip.hide();
              this.toolTip && this.toolTip.enabled && this.toolTip.dispatchEvent("hidden", { chart: this, toolTip: this.toolTip }, this.toolTip);
              for (var u = 0; u < this.axisX.length; u++)
                this.axisX[u].crosshair && this.axisX[u].crosshair.enabled && (this.axisX[u].crosshair.hide(), this.axisX[u].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX[u].options }, this.axisX[u].crosshair));
              for (u = 0; u < this.axisX2.length; u++)
                this.axisX2[u].crosshair && this.axisX2[u].crosshair.enabled && (this.axisX2[u].crosshair.hide(), this.axisX2[u].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisX2[u].options }, this.axisX2[u].crosshair));
              for (u = 0; u < this.axisY.length; u++)
                this.axisY[u].crosshair && this.axisY[u].crosshair.enabled && (this.axisY[u].crosshair.hide(), this.axisY[u].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY[u].options }, this.axisY[u].crosshair));
              for (u = 0; u < this.axisY2.length; u++)
                this.axisY2[u].crosshair && this.axisY2[u].crosshair.enabled && (this.axisY2[u].crosshair.hide(), this.axisY2[u].crosshair.dispatchEvent("hidden", { chart: this, axis: this.axisY2[u].options }, this.axisY2[u].crosshair));
            } else
              this.panEnabled || this.zoomEnabled || this.toolTip.mouseMoveHandler(a, d);
            if ((!e || 2 < Math.abs(c) || !g || 2 < Math.abs(b)) && (this.panEnabled || this.zoomEnabled)) {
              if (this.panEnabled)
                e = { x1: e ? this.plotArea.x1 + c : this.plotArea.x1, y1: g ? this.plotArea.y1 + b : this.plotArea.y1, x2: e ? this.plotArea.x2 + c : this.plotArea.x2, y2: g ? this.plotArea.y2 + b : this.plotArea.y2 }, clearTimeout(r._panTimerId), r._panTimerId = setTimeout(/* @__PURE__ */ function(b2, c2, e2, f) {
                  return function() {
                    r._zoomPanToSelectedRegion(b2, c2, e2, f, true) && (r._dispatchRangeEvent("rangeChanging", "pan"), r.stockChart && (r.stockChart.navigator && r.stockChart.navigator.enabled) && (r.stockChart._rangeEventParameter.type = "rangeChanging", r.stockChart.dispatchEvent("rangeChanging", r.stockChart._rangeEventParameter, r.stockChart)), r.render(), r._dispatchRangeEvent("rangeChanged", "pan"), r.stockChart && (r.stockChart.navigator && r.stockChart.navigator.enabled) && (r.stockChart._rangeEventParameter.type = "rangeChanged", r.stockChart.dispatchEvent("rangeChanged", r.stockChart._rangeEventParameter, r.stockChart)), r.dragStartPoint.x = a, r.dragStartPoint.y = d);
                  };
                }(e.x1, e.y1, e.x2, e.y2), 0);
              else if (this.zoomEnabled) {
                this.resetOverlayedCanvas();
                c = this.overlaidCanvasCtx.globalAlpha;
                this.overlaidCanvasCtx.fillStyle = "#A89896";
                var b = e ? this.dragStartPoint.x : this.plotArea.x1, u = g ? this.dragStartPoint.y : this.plotArea.y1, B = e ? a - this.dragStartPoint.x : this.plotArea.x2 - this.plotArea.x1, k = g ? d - this.dragStartPoint.y : this.plotArea.y2 - this.plotArea.y1;
                this.validateRegion(b, u, e ? a : this.plotArea.x2 - this.plotArea.x1, g ? d : this.plotArea.y2 - this.plotArea.y1, "xy" !== this.zoomType).isValid && (this.resetOverlayedCanvas(), this.overlaidCanvasCtx.fillStyle = "#99B2B5");
                this.overlaidCanvasCtx.globalAlpha = 0.7;
                this.overlaidCanvasCtx.fillRect(b, u, B, k);
                this.overlaidCanvasCtx.globalAlpha = c;
              }
            }
          } else if (this.toolTip.mouseMoveHandler(a, d), "none" !== this.plotInfo.axisPlacement) {
            if (this.axisX && 0 < this.axisX.length)
              for (e = 0; e < this.axisX.length; e++)
                this.axisX[e].crosshair && this.axisX[e].crosshair.enabled && this.axisX[e].renderCrosshair(a, d);
            if (this.axisX2 && 0 < this.axisX2.length)
              for (e = 0; e < this.axisX2.length; e++)
                this.axisX2[e].crosshair && this.axisX2[e].crosshair.enabled && this.axisX2[e].renderCrosshair(a, d);
            if (this.axisY && 0 < this.axisY.length)
              for (e = 0; e < this.axisY.length; e++)
                this.axisY[e].crosshair && this.axisY[e].crosshair.enabled && this.axisY[e].renderCrosshair(a, d);
            if (this.axisY2 && 0 < this.axisY2.length)
              for (e = 0; e < this.axisY2.length; e++)
                this.axisY2[e].crosshair && this.axisY2[e].crosshair.enabled && this.axisY2[e].renderCrosshair(a, d);
            if (this.axisX && 0 < this.axisX.length)
              for (e = 0; e < this.axisX.length; e++)
                this.axisX[e].crosshair && this.axisX[e].crosshair.enabled && this.axisX[e].crosshair.renderLabel();
            if (this.axisX2 && 0 < this.axisX2.length)
              for (e = 0; e < this.axisX2.length; e++)
                this.axisX2[e].crosshair && this.axisX2[e].crosshair.enabled && this.axisX2[e].crosshair.renderLabel();
            if (this.axisY && 0 < this.axisY.length)
              for (e = 0; e < this.axisY.length; e++)
                this.axisY[e].crosshair && this.axisY[e].crosshair.enabled && this.axisY[e].crosshair.renderLabel();
            if (this.axisY2 && 0 < this.axisY2.length)
              for (e = 0; e < this.axisY2.length; e++)
                this.axisY2[e].crosshair && this.axisY2[e].crosshair.enabled && this.axisY2[e].crosshair.renderLabel();
          }
        };
        n.prototype._zoomPanToSelectedRegion = function(a, d, c, b, e) {
          a = this.validateRegion(a, d, c, b, e);
          d = a.axesWithValidRange;
          c = a.axesRanges;
          if (a.isValid)
            for (b = 0; b < d.length; b++)
              e = c[b], d[b].setViewPortRange(e.val1, e.val2), this.syncCharts && "y" != this.zoomType && this.syncCharts(e.val1, e.val2), this.stockChart && (this.stockChart._rangeEventParameter = { stockChart: this.stockChart, source: "chart", index: this.stockChart.charts.indexOf(this), minimum: e.val1, maximum: e.val2 });
          return a.isValid;
        };
        n.prototype.validateRegion = function(a, d, c, b, e) {
          e = e || false;
          for (var g = 0 <= this.zoomType.indexOf("x"), r = 0 <= this.zoomType.indexOf("y"), u = false, B = [], k = [], l = [], p = 0; p < this._axes.length; p++)
            ("axisX" === this._axes[p].type && g || "axisY" === this._axes[p].type && r) && k.push(this._axes[p]);
          for (r = 0; r < k.length; r++) {
            var p = k[r], g = false, q = p.convertPixelToValue({ x: a, y: d }), f = p.convertPixelToValue({ x: c, y: b });
            if (q > f)
              var h2 = f, f = q, q = h2;
            if (p.scaleBreaks)
              for (h2 = 0; !g && h2 < p.scaleBreaks._appliedBreaks.length; h2++)
                g = p.scaleBreaks._appliedBreaks[h2].startValue <= q && p.scaleBreaks._appliedBreaks[h2].endValue >= f;
            if (isFinite(p.dataInfo.minDiff)) {
              if (h2 = p.getApparentDifference(q, f, null, true), !(g || !(this.panEnabled && p.scaleBreaks && p.scaleBreaks._appliedBreaks.length) && (p.logarithmic && h2 < Math.pow(p.dataInfo.minDiff, 3) || !p.logarithmic && h2 < 3 * Math.abs(p.dataInfo.minDiff)) || q < p.minimum || f > p.maximum))
                B.push(p), l.push({ val1: q, val2: f }), u = true;
              else if (!e) {
                u = false;
                break;
              }
            }
          }
          return { isValid: u, axesWithValidRange: B, axesRanges: l };
        };
        n.prototype.preparePlotArea = function() {
          var a = this.plotArea;
          !t && (0 < a.x1 || 0 < a.y1) && a.ctx.translate(a.x1, a.y1);
          if ((this.axisX[0] || this.axisX2[0]) && (this.axisY[0] || this.axisY2[0])) {
            var d = this.axisX[0] ? this.axisX[0].lineCoordinates : this.axisX2[0].lineCoordinates;
            if (this.axisY && 0 < this.axisY.length && this.axisY[0]) {
              var c = this.axisY[0];
              a.x1 = d.x1 < d.x2 ? d.x1 : c.lineCoordinates.x1;
              a.y1 = d.y1 < c.lineCoordinates.y1 ? d.y1 : c.lineCoordinates.y1;
              a.x2 = d.x2 > c.lineCoordinates.x2 ? d.x2 : c.lineCoordinates.x2;
              a.y2 = d.y1 > c.lineCoordinates.y2 ? d.y1 : c.lineCoordinates.y2;
              a.width = a.x2 - a.x1;
              a.height = a.y2 - a.y1;
            }
            this.axisY2 && 0 < this.axisY2.length && this.axisY2[0] && (c = this.axisY2[0], a.x1 = d.x1 < d.x2 ? d.x1 : c.lineCoordinates.x1, a.y1 = d.y1 < c.lineCoordinates.y1 ? d.y1 : c.lineCoordinates.y1, a.x2 = d.x2 > c.lineCoordinates.x2 ? d.x2 : c.lineCoordinates.x2, a.y2 = d.y2 > c.lineCoordinates.y2 ? d.y2 : c.lineCoordinates.y2, a.width = a.x2 - a.x1, a.height = a.y2 - a.y1);
          } else
            d = this.layoutManager.getFreeSpace(), a.x1 = d.x1, a.x2 = d.x2, a.y1 = d.y1, a.y2 = d.y2, a.width = d.width, a.height = d.height;
          t || (a.canvas.width = a.width, a.canvas.height = a.height, a.canvas.style.left = a.x1 + "px", a.canvas.style.top = a.y1 + "px", (0 < a.x1 || 0 < a.y1) && a.ctx.translate(
            -a.x1,
            -a.y1
          ));
          a.layoutManager = new Fa(a.x1, a.y1, a.x2, a.y2, 2);
        };
        n.prototype.renderIndexLabels = function(a) {
          var d = a || this.plotArea.ctx, c = this.plotArea, b = 0, e = 0, g = 0, r = g = e = 0, u = 0, B = b = 0, k = 0;
          for (a = 0; a < this._indexLabels.length; a++) {
            var l = this._indexLabels[a], p = l.chartType.toLowerCase(), q, f, r = oa("indexLabelFontColor", l.dataPoint, l.dataSeries), h2 = oa("indexLabelFontSize", l.dataPoint, l.dataSeries), u = oa("indexLabelFontFamily", l.dataPoint, l.dataSeries), B = oa("indexLabelFontStyle", l.dataPoint, l.dataSeries), k = oa(
              "indexLabelFontWeight",
              l.dataPoint,
              l.dataSeries
            ), J = oa("indexLabelBackgroundColor", l.dataPoint, l.dataSeries);
            q = oa("indexLabelMaxWidth", l.dataPoint, l.dataSeries);
            f = oa("indexLabelWrap", l.dataPoint, l.dataSeries);
            var x = oa("indexLabelLineDashType", l.dataPoint, l.dataSeries), s = oa("indexLabelLineColor", l.dataPoint, l.dataSeries), y = m(l.dataPoint.indexLabelLineThickness) ? m(l.dataSeries.options.indexLabelLineThickness) ? 0 : l.dataSeries.options.indexLabelLineThickness : l.dataPoint.indexLabelLineThickness, b = 0 < y ? Math.min(10, ("normal" === this.plotInfo.axisPlacement ? this.plotArea.height : this.plotArea.width) << 0) : 0, v = { percent: null, total: null }, n2 = null;
            if (0 <= l.dataSeries.type.indexOf("stacked") || "pie" === l.dataSeries.type || "doughnut" === l.dataSeries.type)
              v = this.getPercentAndTotal(l.dataSeries, l.dataPoint);
            if (l.dataSeries.indexLabelFormatter || l.dataPoint.indexLabelFormatter)
              n2 = { chart: this, dataSeries: l.dataSeries, dataPoint: l.dataPoint, index: l.indexKeyword, total: v.total, percent: v.percent };
            var A = l.dataPoint.indexLabelFormatter ? l.dataPoint.indexLabelFormatter(n2) : l.dataPoint.indexLabel ? this.replaceKeywordsWithValue(l.dataPoint.indexLabel, l.dataPoint, l.dataSeries, null, l.indexKeyword) : l.dataSeries.indexLabelFormatter ? l.dataSeries.indexLabelFormatter(n2) : l.dataSeries.indexLabel ? this.replaceKeywordsWithValue(l.dataSeries.indexLabel, l.dataPoint, l.dataSeries, null, l.indexKeyword) : null;
            if (null !== A && "" !== A) {
              var v = oa("indexLabelPlacement", l.dataPoint, l.dataSeries), n2 = oa("indexLabelOrientation", l.dataPoint, l.dataSeries), C = oa("indexLabelTextAlign", l.dataPoint, l.dataSeries), w3 = l.direction, e = l.dataSeries.axisX, g = l.dataSeries.axisY, z3 = false, J = new la(d, { x: 0, y: 0, maxWidth: q ? q : 0.5 * this.width, maxHeight: f ? 5 * h2 : 1.5 * h2, angle: "horizontal" === n2 ? 0 : -90, text: A, padding: 0, backgroundColor: J, textAlign: C, fontSize: h2, fontFamily: u, fontWeight: k, fontColor: r, fontStyle: B, textBaseline: "middle" });
              J.measureText();
              l.dataSeries.indexLabelMaxWidth = J.maxWidth;
              if ("stackedarea100" === p) {
                if (l.point.x < c.x1 || l.point.x > c.x2 || l.point.y < c.y1 - 1 || l.point.y > c.y2 + 1)
                  continue;
              } else if ("rangearea" === p || "rangesplinearea" === p) {
                if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum || Math.max.apply(null, l.dataPoint.y) < g.viewportMinimum || Math.min.apply(null, l.dataPoint.y) > g.viewportMaximum)
                  continue;
              } else if (0 <= p.indexOf("line") || 0 <= p.indexOf("area") || 0 <= p.indexOf("bubble") || 0 <= p.indexOf("scatter")) {
                if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum || l.dataPoint.y < g.viewportMinimum || l.dataPoint.y > g.viewportMaximum)
                  continue;
              } else if (0 <= p.indexOf("column") || "waterfall" === p || "error" === p && !l.axisSwapped) {
                if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum || l.bounds.y1 > c.y2 || l.bounds.y2 < c.y1)
                  continue;
              } else if (0 <= p.indexOf("bar") || "error" === p) {
                if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum || l.bounds.x1 > c.x2 || l.bounds.x2 < c.x1)
                  continue;
              } else if ("candlestick" === p || "ohlc" === p) {
                if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum || Math.max.apply(null, l.dataPoint.y) < g.viewportMinimum || Math.min.apply(null, l.dataPoint.y) > g.viewportMaximum)
                  continue;
              } else if (l.dataPoint.x < e.viewportMinimum || l.dataPoint.x > e.viewportMaximum)
                continue;
              r = u = 2;
              "horizontal" === n2 ? (B = J.width, k = J.height) : (k = J.width, B = J.height);
              if ("normal" === this.plotInfo.axisPlacement) {
                if (0 <= p.indexOf("line") || 0 <= p.indexOf("area"))
                  v = "auto", u = 4;
                else if (0 <= p.indexOf("stacked"))
                  "auto" === v && (v = "inside");
                else if ("bubble" === p || "scatter" === p)
                  v = "inside";
                q = l.point.x - ("horizontal" === n2 ? B / 2 : B / 2 - h2 / 2);
                "inside" !== v ? (e = c.y1, g = c.y2, 0 < w3 ? (f = l.point.y + ("horizontal" === n2 ? h2 / 2 : 0) - k - u - b, f < e && (f = "auto" === v ? Math.max(l.point.y, e) + h2 / 2 + u : e + h2 / 2 + u, z3 = f + k > l.point.y)) : (f = l.point.y + h2 / 2 + u + b, f > g - k && (f = "auto" === v ? Math.min(l.point.y, g) + h2 / 2 - k - u : g + h2 / 2 - k, z3 = f < l.point.y))) : (e = Math.max(l.bounds.y1, c.y1), g = Math.min(l.bounds.y2, c.y2 - k + h2 / 2), b = 0 <= p.indexOf("range") || "error" === p ? 0 < w3 ? Math.max(l.bounds.y1, c.y1) + h2 / 2 + u : Math.min(l.bounds.y2, c.y2) + h2 / 2 - k + u : (Math.max(l.bounds.y1, c.y1) + Math.min(l.bounds.y2, c.y2)) / 2 - k / 2 + h2 / 2 + ("horizontal" === n2 ? u : 0), 0 < w3 ? (f = Math.max(l.point.y, b), f < e && ("bubble" === p || "scatter" === p) && (f = Math.max(l.point.y - k - u, c.y1 + u))) : (f = Math.min(l.point.y, b), f > g - k - u && ("bubble" === p || "scatter" === p) && (f = Math.min(l.point.y + u, c.y2 - k - u))), f = Math.min(f, g));
              } else
                0 <= p.indexOf("line") || 0 <= p.indexOf("area") || 0 <= p.indexOf("scatter") ? (v = "auto", r = 4) : 0 <= p.indexOf("stacked") ? "auto" === v && (v = "inside") : "bubble" === p && (v = "inside"), f = l.point.y + h2 / 2 - k / 2 + u, "inside" !== v ? (e = c.x1, g = c.x2, 0 > w3 ? (q = l.point.x - ("horizontal" === n2 ? B : B - h2 / 2) - r - b, q < e && (q = "auto" === v ? Math.max(l.point.x, e) + r : e + r, z3 = q + B > l.point.x)) : (q = l.point.x + ("horizontal" === n2 ? 0 : h2 / 2) + r + b, q > g - B - r - b && (q = "auto" === v ? Math.min(l.point.x, g) - ("horizontal" === n2 ? B : B / 2) - r : g - B - r, z3 = q < l.point.x))) : (e = Math.max(l.bounds.x1, c.x1), Math.min(l.bounds.x2, c.x2), b = 0 <= p.indexOf("range") || "error" === p ? 0 > w3 ? Math.max(l.bounds.x1, c.x1) + h2 / 2 + r : Math.min(l.bounds.x2, c.x2) - B / 2 - r + ("horizontal" === n2 ? 0 : h2 / 2) : (Math.max(l.bounds.x1, c.x1) + Math.min(l.bounds.x2, c.x2)) / 2 + ("horizontal" === n2 ? 0 : h2 / 2), q = 0 > w3 ? Math.max(l.point.x, b) - ("horizontal" === n2 ? B / 2 : 0) : Math.min(l.point.x, b) - B / 2, q = Math.max(q, e));
              "vertical" === n2 && (f += k - h2 / 2);
              J.x = q;
              J.y = f;
              J.render(true);
              y && ("inside" !== v && (0 > p.indexOf("bar") && ("error" !== p || !l.axisSwapped) && l.point.x > c.x1 && l.point.x < c.x2 || !z3) && (0 > p.indexOf("column") && ("error" !== p || l.axisSwapped) && l.point.y > c.y1 && l.point.y < c.y2 || !z3)) && (d.lineWidth = y, d.strokeStyle = s ? s : "gray", d.setLineDash && d.setLineDash(H(x, y)), d.beginPath(), d.moveTo(l.point.x, l.point.y), 0 <= p.indexOf("bar") || "error" === p && l.axisSwapped ? d.lineTo(q + (0 < l.direction ? -r : B + r) + ("vertical" === n2 ? -h2 / 2 : 0), f + ("vertical" === n2 ? -k / 2 : k / 2 - h2 / 2) - u) : 0 <= p.indexOf("column") || "error" === p && !l.axisSwapped ? d.lineTo(q + B / 2 - ("horizontal" === n2 ? 0 : h2 / 2), f + ("vertical" === n2 ? (f - k < l.point.y ? 0 : -k) + u : (f - h2 / 2 < l.point.y ? k : 0) - h2 / 2)) : 0 <= p.indexOf("waterfall") ? d.lineTo(q + B / 2 - ("horizontal" === n2 ? 0 : h2 / 2), "vertical" === n2 ? 0 < w3 && f < l.point.y ? f : 0 > w3 && f - k > l.point.y ? f - k : l.point.y : 0 < w3 && f + k - h2 / 2 < l.point.y ? f + k - h2 / 2 : 0 > w3 && f - h2 / 2 > l.point.y ? f - h2 / 2 - 2 : l.point.y) : d.lineTo(q + B / 2 - ("horizontal" === n2 ? 0 : h2 / 2), f + ("vertical" === n2 ? f - k < l.point.y ? 0 : -k : (f + k < l.point.y ? k : 0) - h2 / 2)), d.stroke());
            }
          }
          d = { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0, startTimePercent: 0.7 };
          for (a = 0; a < this._indexLabels.length; a++)
            l = this._indexLabels[a], J = oa("indexLabelBackgroundColor", l.dataPoint, l.dataSeries), l.dataSeries.indexLabelBackgroundColor = m(J) ? t ? "transparent" : null : J;
          return d;
        };
        n.prototype.renderLine = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx;
            c.save();
            var e = this.plotArea;
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            for (var g = [], r, u = 0; u < a.dataSeriesIndexes.length; u++) {
              var B = a.dataSeriesIndexes[u], k = this.data[B];
              c.lineWidth = k.lineThickness;
              var l = k.dataPoints, p = "solid";
              if (c.setLineDash) {
                var q = H(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, f = H(p, k.lineThickness);
                c.setLineDash(f);
              }
              var h2 = k.id;
              this._eventManager.objectMap[h2] = { objectType: "dataSeries", dataSeriesIndex: B };
              h2 = Z(h2);
              b.strokeStyle = h2;
              b.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var h2 = k._colorSet, m2 = h2 = k.lineColor = k.options.lineColor ? k.options.lineColor : h2[0];
              c.strokeStyle = h2;
              var x = true, s = 0, n2, v;
              c.beginPath();
              if (0 < l.length) {
                for (var I = false, s = 0; s < l.length; s++)
                  if (n2 = l[s].x.getTime ? l[s].x.getTime() : l[s].x, !(n2 < a.axisX.dataInfo.viewPortMin || n2 > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !I)))
                    if ("number" !== typeof l[s].y)
                      0 < s && !(k.connectNullData || I || x) && (c.stroke(), t && b.stroke()), I = true;
                    else {
                      n2 = a.axisX.convertValueToPixel(n2);
                      v = a.axisY.convertValueToPixel(l[s].y);
                      var A = k.dataPointIds[s];
                      this._eventManager.objectMap[A] = { id: A, objectType: "dataPoint", dataSeriesIndex: B, dataPointIndex: s, x1: n2, y1: v };
                      x || I ? (!x && k.connectNullData ? (c.setLineDash && (k.options.nullDataLineDashType || p === k.lineDashType && k.lineDashType !== k.nullDataLineDashType) && (c.stroke(), c.beginPath(), c.moveTo(r.x, r.y), p = k.nullDataLineDashType, c.setLineDash(q)), c.lineTo(n2, v), t && b.lineTo(n2, v)) : (c.beginPath(), c.moveTo(n2, v), t && (b.beginPath(), b.moveTo(n2, v))), I = x = false) : (c.lineTo(n2, v), t && b.lineTo(n2, v), 0 == s % 500 && (c.stroke(), c.beginPath(), c.moveTo(n2, v), t && (b.stroke(), b.beginPath(), b.moveTo(n2, v))));
                      r = { x: n2, y: v };
                      s < l.length - 1 && (m2 !== (l[s].lineColor || h2) || p !== (l[s].lineDashType || k.lineDashType)) && (c.stroke(), c.beginPath(), c.moveTo(n2, v), m2 = l[s].lineColor || h2, c.strokeStyle = m2, c.setLineDash && (l[s].lineDashType ? (p = l[s].lineDashType, c.setLineDash(H(p, k.lineThickness))) : (p = k.lineDashType, c.setLineDash(f))));
                      if (0 !== l[s].markerSize && (0 < l[s].markerSize || 0 < k.markerSize)) {
                        var C = k.getMarkerProperties(s, n2, v, c);
                        g.push(C);
                        A = Z(A);
                        t && g.push({ x: n2, y: v, ctx: b, type: C.type, size: C.size, color: A, borderColor: A, borderThickness: C.borderThickness });
                      }
                      (l[s].indexLabel || k.indexLabel || l[s].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "line", dataPoint: l[s], dataSeries: k, point: { x: n2, y: v }, direction: 0 > l[s].y === a.axisY.reversed ? 1 : -1, color: h2 });
                    }
                c.stroke();
                t && b.stroke();
              }
            }
            X.drawMarkers(g);
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.clearRect(e.x1, e.y1, e.width, e.height), b.beginPath());
            c.restore();
            c.beginPath();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStepLine = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx;
            c.save();
            var e = this.plotArea;
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            for (var g = [], r, u = 0; u < a.dataSeriesIndexes.length; u++) {
              var h2 = a.dataSeriesIndexes[u], k = this.data[h2];
              c.lineWidth = k.lineThickness;
              var l = k.dataPoints, p = "solid";
              if (c.setLineDash) {
                var q = H(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, f = H(p, k.lineThickness);
                c.setLineDash(f);
              }
              var m2 = k.id;
              this._eventManager.objectMap[m2] = { objectType: "dataSeries", dataSeriesIndex: h2 };
              m2 = Z(m2);
              b.strokeStyle = m2;
              b.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var m2 = k._colorSet, n2 = m2 = k.lineColor = k.options.lineColor ? k.options.lineColor : m2[0];
              c.strokeStyle = m2;
              var x = true, s = 0, y, v;
              c.beginPath();
              if (0 < l.length) {
                for (var I = false, s = 0; s < l.length; s++)
                  if (y = l[s].getTime ? l[s].x.getTime() : l[s].x, !(y < a.axisX.dataInfo.viewPortMin || y > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !I)))
                    if ("number" !== typeof l[s].y)
                      0 < s && !(k.connectNullData || I || x) && (c.stroke(), t && b.stroke()), I = true;
                    else {
                      var A = v;
                      y = a.axisX.convertValueToPixel(y);
                      v = a.axisY.convertValueToPixel(l[s].y);
                      var C = k.dataPointIds[s];
                      this._eventManager.objectMap[C] = {
                        id: C,
                        objectType: "dataPoint",
                        dataSeriesIndex: h2,
                        dataPointIndex: s,
                        x1: y,
                        y1: v
                      };
                      x || I ? (!x && k.connectNullData ? (c.setLineDash && (k.options.nullDataLineDashType || p === k.lineDashType && k.lineDashType !== k.nullDataLineDashType) && (c.stroke(), c.beginPath(), c.moveTo(r.x, r.y), p = k.nullDataLineDashType, c.setLineDash(q)), c.lineTo(y, A), c.lineTo(y, v), t && (b.lineTo(y, A), b.lineTo(y, v))) : (c.beginPath(), c.moveTo(y, v), t && (b.beginPath(), b.moveTo(y, v))), I = x = false) : (c.lineTo(y, A), t && b.lineTo(y, A), c.lineTo(y, v), t && b.lineTo(y, v), 0 == s % 500 && (c.stroke(), c.beginPath(), c.moveTo(y, v), t && (b.stroke(), b.beginPath(), b.moveTo(y, v))));
                      r = { x: y, y: v };
                      s < l.length - 1 && (n2 !== (l[s].lineColor || m2) || p !== (l[s].lineDashType || k.lineDashType)) && (c.stroke(), c.beginPath(), c.moveTo(y, v), n2 = l[s].lineColor || m2, c.strokeStyle = n2, c.setLineDash && (l[s].lineDashType ? (p = l[s].lineDashType, c.setLineDash(H(p, k.lineThickness))) : (p = k.lineDashType, c.setLineDash(f))));
                      0 !== l[s].markerSize && (0 < l[s].markerSize || 0 < k.markerSize) && (A = k.getMarkerProperties(s, y, v, c), g.push(A), C = Z(C), t && g.push({
                        x: y,
                        y: v,
                        ctx: b,
                        type: A.type,
                        size: A.size,
                        color: C,
                        borderColor: C,
                        borderThickness: A.borderThickness
                      }));
                      (l[s].indexLabel || k.indexLabel || l[s].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "stepLine", dataPoint: l[s], dataSeries: k, point: { x: y, y: v }, direction: 0 > l[s].y === a.axisY.reversed ? 1 : -1, color: m2 });
                    }
                c.stroke();
                t && b.stroke();
              }
            }
            X.drawMarkers(g);
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), b.beginPath());
            c.restore();
            c.beginPath();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderSpline = function(a) {
          function d(a2) {
            a2 = w2(a2, 2);
            if (0 < a2.length) {
              b.beginPath();
              t && e.beginPath();
              b.moveTo(
                a2[0].x,
                a2[0].y
              );
              a2[0].newStrokeStyle && (b.strokeStyle = a2[0].newStrokeStyle);
              a2[0].newLineDashArray && b.setLineDash(a2[0].newLineDashArray);
              t && e.moveTo(a2[0].x, a2[0].y);
              for (var c2 = 0; c2 < a2.length - 3; c2 += 3)
                if (b.bezierCurveTo(a2[c2 + 1].x, a2[c2 + 1].y, a2[c2 + 2].x, a2[c2 + 2].y, a2[c2 + 3].x, a2[c2 + 3].y), t && e.bezierCurveTo(a2[c2 + 1].x, a2[c2 + 1].y, a2[c2 + 2].x, a2[c2 + 2].y, a2[c2 + 3].x, a2[c2 + 3].y), 0 < c2 && 0 === c2 % 3e3 || a2[c2 + 3].newStrokeStyle || a2[c2 + 3].newLineDashArray)
                  b.stroke(), b.beginPath(), b.moveTo(a2[c2 + 3].x, a2[c2 + 3].y), a2[c2 + 3].newStrokeStyle && (b.strokeStyle = a2[c2 + 3].newStrokeStyle), a2[c2 + 3].newLineDashArray && b.setLineDash(a2[c2 + 3].newLineDashArray), t && (e.stroke(), e.beginPath(), e.moveTo(a2[c2 + 3].x, a2[c2 + 3].y));
              b.stroke();
              t && e.stroke();
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx;
            b.save();
            var g = this.plotArea;
            b.beginPath();
            b.rect(g.x1, g.y1, g.width, g.height);
            b.clip();
            for (var r = [], u = 0; u < a.dataSeriesIndexes.length; u++) {
              var h2 = a.dataSeriesIndexes[u], k = this.data[h2];
              b.lineWidth = k.lineThickness;
              var l = k.dataPoints, p = "solid";
              if (b.setLineDash) {
                var q = H(k.nullDataLineDashType, k.lineThickness), p = k.lineDashType, f = H(p, k.lineThickness);
                b.setLineDash(f);
              }
              var m2 = k.id;
              this._eventManager.objectMap[m2] = { objectType: "dataSeries", dataSeriesIndex: h2 };
              m2 = Z(m2);
              e.strokeStyle = m2;
              e.lineWidth = 0 < k.lineThickness ? Math.max(k.lineThickness, 4) : 0;
              var m2 = k._colorSet, n2 = m2 = k.lineColor = k.options.lineColor ? k.options.lineColor : m2[0];
              b.strokeStyle = m2;
              var x = 0, s, y, v = [];
              b.beginPath();
              if (0 < l.length) {
                for (y = false, x = 0; x < l.length; x++)
                  if (s = l[x].getTime ? l[x].x.getTime() : l[x].x, !(s < a.axisX.dataInfo.viewPortMin || s > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !y)))
                    if ("number" !== typeof l[x].y)
                      0 < x && !y && (k.connectNullData ? b.setLineDash && (0 < v.length && (k.options.nullDataLineDashType || !l[x - 1].lineDashType)) && (v[v.length - 1].newLineDashArray = q, p = k.nullDataLineDashType) : (d(v), v = [])), y = true;
                    else {
                      s = a.axisX.convertValueToPixel(s);
                      y = a.axisY.convertValueToPixel(l[x].y);
                      var I = k.dataPointIds[x];
                      this._eventManager.objectMap[I] = {
                        id: I,
                        objectType: "dataPoint",
                        dataSeriesIndex: h2,
                        dataPointIndex: x,
                        x1: s,
                        y1: y
                      };
                      v[v.length] = { x: s, y };
                      x < l.length - 1 && (n2 !== (l[x].lineColor || m2) || p !== (l[x].lineDashType || k.lineDashType)) && (n2 = l[x].lineColor || m2, v[v.length - 1].newStrokeStyle = n2, b.setLineDash && (l[x].lineDashType ? (p = l[x].lineDashType, v[v.length - 1].newLineDashArray = H(p, k.lineThickness)) : (p = k.lineDashType, v[v.length - 1].newLineDashArray = f)));
                      if (0 !== l[x].markerSize && (0 < l[x].markerSize || 0 < k.markerSize)) {
                        var A = k.getMarkerProperties(x, s, y, b);
                        r.push(A);
                        I = Z(I);
                        t && r.push({
                          x: s,
                          y,
                          ctx: e,
                          type: A.type,
                          size: A.size,
                          color: I,
                          borderColor: I,
                          borderThickness: A.borderThickness
                        });
                      }
                      (l[x].indexLabel || k.indexLabel || l[x].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "spline", dataPoint: l[x], dataSeries: k, point: { x: s, y }, direction: 0 > l[x].y === a.axisY.reversed ? 1 : -1, color: m2 });
                      y = false;
                    }
              }
              d(v);
            }
            X.drawMarkers(r);
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(g.x1, g.y1, g.width, g.height), e.beginPath());
            b.restore();
            b.beginPath();
            return { source: c, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = 0, r, u, h2, k = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), g = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, l = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.width, 0.9 * (this.plotArea.width / a.plotType.totalDataSeries)) << 0, p = a.axisX.dataInfo.minDiff;
            isFinite(p) || (p = 0.3 * Math.abs(a.axisX.range));
            p = this.dataPointWidth = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(p) / Math.log(a.axisX.range) : Math.abs(p) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && g > l && (g = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, l));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && l < g) && (l = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, g));
            p < g && (p = g);
            p > l && (p = l);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (l = 0; l < a.dataSeriesIndexes.length; l++) {
              var q = a.dataSeriesIndexes[l], f = this.data[q], m2 = f.dataPoints;
              if (0 < m2.length) {
                for (var n2 = 5 < p && f.bevelEnabled ? true : false, g = 0; g < m2.length; g++)
                  if (m2[g].getTime ? h2 = m2[g].x.getTime() : h2 = m2[g].x, !(h2 < a.axisX.dataInfo.viewPortMin || h2 > a.axisX.dataInfo.viewPortMax) && "number" === typeof m2[g].y) {
                    r = a.axisX.convertValueToPixel(h2);
                    u = a.axisY.convertValueToPixel(m2[g].y);
                    r = a.axisX.reversed ? r + a.plotType.totalDataSeries * p / 2 - (a.previousDataSeriesCount + l) * p << 0 : r - a.plotType.totalDataSeries * p / 2 + (a.previousDataSeriesCount + l) * p << 0;
                    var x = a.axisX.reversed ? r - p << 0 : r + p << 0, s;
                    0 <= m2[g].y ? s = k : (s = u, u = k);
                    u > s && (b = u, u = s, s = b);
                    b = m2[g].color ? m2[g].color : f._colorSet[g % f._colorSet.length];
                    ba(c, a.axisX.reversed ? x : r, u, a.axisX.reversed ? r : x, s, b, 0, null, n2 && (a.axisY.reversed ? 0 > m2[g].y : 0 <= m2[g].y), (a.axisY.reversed ? 0 <= m2[g].y : 0 > m2[g].y) && n2, false, false, f.fillOpacity);
                    b = f.dataPointIds[g];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: g, x1: r, y1: u, x2: x, y2: s };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, a.axisX.reversed ? x : r, u, a.axisX.reversed ? r : x, s, b, 0, null, false, false, false, false);
                    (m2[g].indexLabel || f.indexLabel || m2[g].indexLabelFormatter || f.indexLabelFormatter) && this._indexLabels.push({ chartType: "column", dataPoint: m2[g], dataSeries: f, point: { x: r + (x - r) / 2, y: 0 > m2[g].y === a.axisY.reversed ? u : s }, direction: 0 > m2[g].y === a.axisY.reversed ? 1 : -1, bounds: { x1: r, y1: Math.min(u, s), x2: x, y2: Math.max(u, s) }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: N.yScaleAnimation,
              easingFunction: N.easing.easeOutQuart,
              animationBase: k < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : k > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : k
            };
          }
        };
        n.prototype.renderStackedColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = [], r = [], u = [], h2 = [], k = 0, l, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, f = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.width << 0, m2 = a.axisX.dataInfo.minDiff;
            isFinite(m2) || (m2 = 0.3 * Math.abs(a.axisX.range));
            m2 = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(m2) / Math.log(a.axisX.range) : Math.abs(m2) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > f && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, f));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && f < k) && (f = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            m2 < k && (m2 = k);
            m2 > f && (m2 = f);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (f = 0; f < a.dataSeriesIndexes.length; f++) {
              var n2 = a.dataSeriesIndexes[f], x = this.data[n2], s = x.dataPoints;
              if (0 < s.length) {
                var y = 5 < m2 && x.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < s.length; k++)
                  if (b = s[k].x.getTime ? s[k].x.getTime() : s[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof s[k].y) {
                    l = a.axisX.convertValueToPixel(b);
                    l = l - a.plotType.plotUnits.length * m2 / 2 + a.index * m2 << 0;
                    var v = l + m2 << 0, I;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < s[k].y)
                      u[b] = s[k].y + (u[b] ? u[b] : 0), 0 < u[b] && (p = a.axisY.convertValueToPixel(u[b]), I = "undefined" !== typeof g[b] ? g[b] : q, g[b] = p);
                    else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= s[k].y)
                      h2[b] = s[k].y + (h2[b] ? h2[b] : 0), I = a.axisY.convertValueToPixel(h2[b]), p = "undefined" !== typeof r[b] ? r[b] : q, r[b] = I;
                    else if (p = a.axisY.convertValueToPixel(s[k].y), 0 <= s[k].y) {
                      var A = "undefined" !== typeof g[b] ? g[b] : 0;
                      p -= A;
                      I = q - A;
                      g[b] = A + (I - p);
                    } else
                      A = r[b] ? r[b] : 0, I = p + A, p = q + A, r[b] = A + (I - p);
                    b = s[k].color ? s[k].color : x._colorSet[k % x._colorSet.length];
                    ba(c, l, a.axisY.reversed ? I : p, v, a.axisY.reversed ? p : I, b, 0, null, y && (a.axisY.reversed ? 0 > s[k].y : 0 <= s[k].y), (a.axisY.reversed ? 0 <= s[k].y : 0 > s[k].y) && y, false, false, x.fillOpacity);
                    b = x.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: n2, dataPointIndex: k, x1: l, y1: p, x2: v, y2: I };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, l, p, v, I, b, 0, null, false, false, false, false);
                    (s[k].indexLabel || x.indexLabel || s[k].indexLabelFormatter || x.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedColumn", dataPoint: s[k], dataSeries: x, point: { x: l + (v - l) / 2, y: 0 <= s[k].y ? p : I }, direction: 0 > s[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: l, y1: Math.min(p, I), x2: v, y2: Math.max(p, I) }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.yScaleAnimation, easingFunction: N.easing.easeOutQuart, animationBase: q < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : q > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : q };
          }
        };
        n.prototype.renderStackedColumn100 = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = [], r = [], u = [], h2 = [], k = 0, l, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, f = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.width << 0, m2 = a.axisX.dataInfo.minDiff;
            isFinite(m2) || (m2 = 0.3 * Math.abs(a.axisX.range));
            m2 = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(m2) / Math.log(a.axisX.range) : Math.abs(m2) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > f && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, f));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && f < k) && (f = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            m2 < k && (m2 = k);
            m2 > f && (m2 = f);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (f = 0; f < a.dataSeriesIndexes.length; f++) {
              var n2 = a.dataSeriesIndexes[f], x = this.data[n2], s = x.dataPoints;
              if (0 < s.length) {
                for (var y = 5 < m2 && x.bevelEnabled ? true : false, k = 0; k < s.length; k++)
                  if (b = s[k].x.getTime ? s[k].x.getTime() : s[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof s[k].y) {
                    l = a.axisX.convertValueToPixel(b);
                    p = 0 !== a.dataPointYSums[b] ? 100 * (s[k].y / a.dataPointYSums[b]) : 0;
                    l = l - a.plotType.plotUnits.length * m2 / 2 + a.index * m2 << 0;
                    var v = l + m2 << 0, I;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < s[k].y) {
                      u[b] = p + ("undefined" !== typeof u[b] ? u[b] : 0);
                      if (0 >= u[b])
                        continue;
                      p = a.axisY.convertValueToPixel(u[b]);
                      I = g[b] ? g[b] : q;
                      g[b] = p;
                    } else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= s[k].y)
                      h2[b] = p + ("undefined" !== typeof h2[b] ? h2[b] : 0), I = a.axisY.convertValueToPixel(h2[b]), p = r[b] ? r[b] : q, r[b] = I;
                    else if (p = a.axisY.convertValueToPixel(p), 0 <= s[k].y) {
                      var A = "undefined" !== typeof g[b] ? g[b] : 0;
                      p -= A;
                      I = q - A;
                      a.dataSeriesIndexes.length - 1 === f && 1 >= Math.abs(e.y1 - p) && (p = e.y1);
                      g[b] = A + (I - p);
                    } else
                      A = "undefined" !== typeof r[b] ? r[b] : 0, I = p + A, p = q + A, a.dataSeriesIndexes.length - 1 === f && 1 >= Math.abs(e.y2 - I) && (I = e.y2), r[b] = A + (I - p);
                    b = s[k].color ? s[k].color : x._colorSet[k % x._colorSet.length];
                    ba(c, l, a.axisY.reversed ? I : p, v, a.axisY.reversed ? p : I, b, 0, null, y && (a.axisY.reversed ? 0 > s[k].y : 0 <= s[k].y), (a.axisY.reversed ? 0 <= s[k].y : 0 > s[k].y) && y, false, false, x.fillOpacity);
                    b = x.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: n2, dataPointIndex: k, x1: l, y1: p, x2: v, y2: I };
                    b = Z(b);
                    t && ba(
                      this._eventManager.ghostCtx,
                      l,
                      p,
                      v,
                      I,
                      b,
                      0,
                      null,
                      false,
                      false,
                      false,
                      false
                    );
                    (s[k].indexLabel || x.indexLabel || s[k].indexLabelFormatter || x.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedColumn100", dataPoint: s[k], dataSeries: x, point: { x: l + (v - l) / 2, y: 0 <= s[k].y ? p : I }, direction: 0 > s[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: l, y1: Math.min(p, I), x2: v, y2: Math.max(p, I) }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.yScaleAnimation, easingFunction: N.easing.easeOutQuart, animationBase: q < a.axisY.bounds.y1 ? a.axisY.bounds.y1 : q > a.axisY.bounds.y2 ? a.axisY.bounds.y2 : q };
          }
        };
        n.prototype.renderBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = 0, r, u, h2, k = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), g = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, l = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / a.plotType.totalDataSeries)) << 0, p = a.axisX.dataInfo.minDiff;
            isFinite(p) || (p = 0.3 * Math.abs(a.axisX.range));
            p = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(p) / Math.log(a.axisX.range) : Math.abs(p) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && g > l && (g = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, l));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && l < g) && (l = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, g));
            p < g && (p = g);
            p > l && (p = l);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (l = 0; l < a.dataSeriesIndexes.length; l++) {
              var q = a.dataSeriesIndexes[l], f = this.data[q], m2 = f.dataPoints;
              if (0 < m2.length) {
                var n2 = 5 < p && f.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (g = 0; g < m2.length; g++)
                  if (m2[g].getTime ? h2 = m2[g].x.getTime() : h2 = m2[g].x, !(h2 < a.axisX.dataInfo.viewPortMin || h2 > a.axisX.dataInfo.viewPortMax) && "number" === typeof m2[g].y) {
                    u = a.axisX.convertValueToPixel(h2);
                    r = a.axisY.convertValueToPixel(m2[g].y);
                    u = a.axisX.reversed ? u + a.plotType.totalDataSeries * p / 2 - (a.previousDataSeriesCount + l) * p << 0 : u - a.plotType.totalDataSeries * p / 2 + (a.previousDataSeriesCount + l) * p << 0;
                    var x = a.axisX.reversed ? u - p << 0 : u + p << 0, s;
                    0 <= m2[g].y ? s = k : (s = r, r = k);
                    b = m2[g].color ? m2[g].color : f._colorSet[g % f._colorSet.length];
                    ba(c, a.axisY.reversed ? r : s, a.axisX.reversed ? x : u, a.axisY.reversed ? s : r, a.axisX.reversed ? u : x, b, 0, null, n2, false, false, false, f.fillOpacity);
                    b = f.dataPointIds[g];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: g, x1: s, y1: u, x2: r, y2: x };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, s, a.axisX.reversed ? x : u, r, a.axisX.reversed ? u : x, b, 0, null, false, false, false, false);
                    (m2[g].indexLabel || f.indexLabel || m2[g].indexLabelFormatter || f.indexLabelFormatter) && this._indexLabels.push({ chartType: "bar", dataPoint: m2[g], dataSeries: f, point: { x: 0 <= m2[g].y ? r : s, y: u + (x - u) / 2 }, direction: 0 > m2[g].y === a.axisY.reversed ? 1 : -1, bounds: { x1: Math.min(s, r), y1: u, x2: Math.max(s, r), y2: x }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.xScaleAnimation, easingFunction: N.easing.easeOutQuart, animationBase: k < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : k > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : k };
          }
        };
        n.prototype.renderStackedBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = [], r = [], u = [], h2 = [], k = 0, l, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, f = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.height << 0, m2 = a.axisX.dataInfo.minDiff;
            isFinite(m2) || (m2 = 0.3 * Math.abs(a.axisX.range));
            m2 = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(m2) / Math.log(a.axisX.range) : Math.abs(m2) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > f && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, f));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && f < k) && (f = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            m2 < k && (m2 = k);
            m2 > f && (m2 = f);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (f = 0; f < a.dataSeriesIndexes.length; f++) {
              var n2 = a.dataSeriesIndexes[f], x = this.data[n2], s = x.dataPoints;
              if (0 < s.length) {
                var y = 5 < m2 && x.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < s.length; k++)
                  if (b = s[k].x.getTime ? s[k].x.getTime() : s[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof s[k].y) {
                    p = a.axisX.convertValueToPixel(b);
                    p = p - a.plotType.plotUnits.length * m2 / 2 + a.index * m2 << 0;
                    var v = p + m2 << 0, I;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < s[k].y)
                      u[b] = s[k].y + (u[b] ? u[b] : 0), 0 < u[b] && (I = g[b] ? g[b] : q, g[b] = l = a.axisY.convertValueToPixel(u[b]));
                    else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= s[k].y)
                      h2[b] = s[k].y + (h2[b] ? h2[b] : 0), l = r[b] ? r[b] : q, r[b] = I = a.axisY.convertValueToPixel(h2[b]);
                    else if (l = a.axisY.convertValueToPixel(s[k].y), 0 <= s[k].y) {
                      var A = g[b] ? g[b] : 0;
                      I = q + A;
                      l += A;
                      g[b] = A + (l - I);
                    } else
                      A = r[b] ? r[b] : 0, I = l - A, l = q - A, r[b] = A + (l - I);
                    b = s[k].color ? s[k].color : x._colorSet[k % x._colorSet.length];
                    ba(c, a.axisY.reversed ? l : I, p, a.axisY.reversed ? I : l, v, b, 0, null, y, false, false, false, x.fillOpacity);
                    b = x.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: n2, dataPointIndex: k, x1: I, y1: p, x2: l, y2: v };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, I, p, l, v, b, 0, null, false, false, false, false);
                    (s[k].indexLabel || x.indexLabel || s[k].indexLabelFormatter || x.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedBar", dataPoint: s[k], dataSeries: x, point: { x: 0 <= s[k].y ? l : I, y: p + (v - p) / 2 }, direction: 0 > s[k].y === a.axisY.reversed ? 1 : -1, bounds: { x1: Math.min(
                      I,
                      l
                    ), y1: p, x2: Math.max(I, l), y2: v }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.xScaleAnimation, easingFunction: N.easing.easeOutQuart, animationBase: q < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : q > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : q };
          }
        };
        n.prototype.renderStackedBar100 = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = [], r = [], u = [], h2 = [], k = 0, l, p, q = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), k = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, f = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.15 * this.height << 0, m2 = a.axisX.dataInfo.minDiff;
            isFinite(m2) || (m2 = 0.3 * Math.abs(a.axisX.range));
            m2 = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(m2) / Math.log(a.axisX.range) : Math.abs(m2) / Math.abs(a.axisX.range)) / a.plotType.plotUnits.length) << 0;
            this.dataPointMaxWidth && k > f && (k = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, f));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && f < k) && (f = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, k));
            m2 < k && (m2 = k);
            m2 > f && (m2 = f);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (f = 0; f < a.dataSeriesIndexes.length; f++) {
              var n2 = a.dataSeriesIndexes[f], x = this.data[n2], s = x.dataPoints;
              if (0 < s.length) {
                var y = 5 < m2 && x.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (k = 0; k < s.length; k++)
                  if (b = s[k].x.getTime ? s[k].x.getTime() : s[k].x, !(b < a.axisX.dataInfo.viewPortMin || b > a.axisX.dataInfo.viewPortMax) && "number" === typeof s[k].y) {
                    p = a.axisX.convertValueToPixel(b);
                    var v;
                    v = 0 !== a.dataPointYSums[b] ? 100 * (s[k].y / a.dataPointYSums[b]) : 0;
                    p = p - a.plotType.plotUnits.length * m2 / 2 + a.index * m2 << 0;
                    var I = p + m2 << 0;
                    if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 < s[k].y) {
                      u[b] = v + (u[b] ? u[b] : 0);
                      if (0 >= u[b])
                        continue;
                      v = g[b] ? g[b] : q;
                      g[b] = l = a.axisY.convertValueToPixel(u[b]);
                    } else if (a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length && 0 >= s[k].y)
                      h2[b] = v + (h2[b] ? h2[b] : 0), l = r[b] ? r[b] : q, r[b] = v = a.axisY.convertValueToPixel(h2[b]);
                    else if (l = a.axisY.convertValueToPixel(v), 0 <= s[k].y) {
                      var A = g[b] ? g[b] : 0;
                      v = q + A;
                      l += A;
                      a.dataSeriesIndexes.length - 1 === f && 1 >= Math.abs(e.x2 - l) && (l = e.x2);
                      g[b] = A + (l - v);
                    } else
                      A = r[b] ? r[b] : 0, v = l - A, l = q - A, a.dataSeriesIndexes.length - 1 === f && 1 >= Math.abs(e.x1 - v) && (v = e.x1), r[b] = A + (l - v);
                    b = s[k].color ? s[k].color : x._colorSet[k % x._colorSet.length];
                    ba(c, a.axisY.reversed ? l : v, p, a.axisY.reversed ? v : l, I, b, 0, null, y, false, false, false, x.fillOpacity);
                    b = x.dataPointIds[k];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: n2, dataPointIndex: k, x1: v, y1: p, x2: l, y2: I };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, v, p, l, I, b, 0, null, false, false, false, false);
                    (s[k].indexLabel || x.indexLabel || s[k].indexLabelFormatter || x.indexLabelFormatter) && this._indexLabels.push({
                      chartType: "stackedBar100",
                      dataPoint: s[k],
                      dataSeries: x,
                      point: { x: 0 <= s[k].y ? l : v, y: p + (I - p) / 2 },
                      direction: 0 > s[k].y === a.axisY.reversed ? 1 : -1,
                      bounds: { x1: Math.min(v, l), y1: p, x2: Math.max(v, l), y2: I },
                      color: b
                    });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.xScaleAnimation, easingFunction: N.easing.easeOutQuart, animationBase: q < a.axisY.bounds.x1 ? a.axisY.bounds.x1 : q > a.axisY.bounds.x2 ? a.axisY.bounds.x2 : q };
          }
        };
        n.prototype.renderArea = function(a) {
          var d, c;
          function b() {
            A && (0 < f.lineThickness && g.stroke(), a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? I = v : 0 > a.axisY.viewportMaximum ? I = u.y1 : 0 < a.axisY.viewportMinimum && (I = v), g.lineTo(x, I), g.lineTo(A.x, I), g.closePath(), g.globalAlpha = f.fillOpacity, g.fill(), g.globalAlpha = 1, t && (r.lineTo(x, I), r.lineTo(A.x, I), r.closePath(), r.fill()), g.beginPath(), g.moveTo(x, s), r.beginPath(), r.moveTo(x, s), A = { x, y: s });
          }
          var e = a.targetCanvasCtx || this.plotArea.ctx, g = t ? this._preRenderCtx : e;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var r = this._eventManager.ghostCtx, u = a.axisY.lineCoordinates, h2 = [], k = this.plotArea, l;
            g.save();
            t && r.save();
            g.beginPath();
            g.rect(
              k.x1,
              k.y1,
              k.width,
              k.height
            );
            g.clip();
            t && (r.beginPath(), r.rect(k.x1, k.y1, k.width, k.height), r.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], f = this.data[q], m2 = f.dataPoints, h2 = f.id;
              this._eventManager.objectMap[h2] = { objectType: "dataSeries", dataSeriesIndex: q };
              h2 = Z(h2);
              r.fillStyle = h2;
              h2 = [];
              d = true;
              var n2 = 0, x, s, y, v = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), I, A = null;
              if (0 < m2.length) {
                var C = f._colorSet[n2 % f._colorSet.length], w3 = f.lineColor = f.options.lineColor || C, z3 = w3;
                g.fillStyle = C;
                g.strokeStyle = w3;
                g.lineWidth = f.lineThickness;
                c = "solid";
                if (g.setLineDash) {
                  var K = H(f.nullDataLineDashType, f.lineThickness);
                  c = f.lineDashType;
                  var T = H(c, f.lineThickness);
                  g.setLineDash(T);
                }
                for (var ha = true; n2 < m2.length; n2++)
                  if (y = m2[n2].x.getTime ? m2[n2].x.getTime() : m2[n2].x, !(y < a.axisX.dataInfo.viewPortMin || y > a.axisX.dataInfo.viewPortMax && (!f.connectNullData || !ha)))
                    if ("number" !== typeof m2[n2].y)
                      f.connectNullData || (ha || d) || b(), ha = true;
                    else {
                      x = a.axisX.convertValueToPixel(y);
                      s = a.axisY.convertValueToPixel(m2[n2].y);
                      d || ha ? (!d && f.connectNullData ? (g.setLineDash && (f.options.nullDataLineDashType || c === f.lineDashType && f.lineDashType !== f.nullDataLineDashType) && (d = x, c = s, x = l.x, s = l.y, b(), g.moveTo(l.x, l.y), x = d, s = c, A = l, c = f.nullDataLineDashType, g.setLineDash(K)), g.lineTo(x, s), t && r.lineTo(x, s)) : (g.beginPath(), g.moveTo(x, s), t && (r.beginPath(), r.moveTo(x, s)), A = { x, y: s }), ha = d = false) : (g.lineTo(x, s), t && r.lineTo(x, s), 0 == n2 % 250 && b());
                      l = { x, y: s };
                      n2 < m2.length - 1 && (z3 !== (m2[n2].lineColor || w3) || c !== (m2[n2].lineDashType || f.lineDashType)) && (b(), z3 = m2[n2].lineColor || w3, g.strokeStyle = z3, g.setLineDash && (m2[n2].lineDashType ? (c = m2[n2].lineDashType, g.setLineDash(H(c, f.lineThickness))) : (c = f.lineDashType, g.setLineDash(T))));
                      var ca = f.dataPointIds[n2];
                      this._eventManager.objectMap[ca] = { id: ca, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: n2, x1: x, y1: s };
                      0 !== m2[n2].markerSize && (0 < m2[n2].markerSize || 0 < f.markerSize) && (y = f.getMarkerProperties(n2, x, s, g), h2.push(y), ca = Z(ca), t && h2.push({ x, y: s, ctx: r, type: y.type, size: y.size, color: ca, borderColor: ca, borderThickness: y.borderThickness }));
                      (m2[n2].indexLabel || f.indexLabel || m2[n2].indexLabelFormatter || f.indexLabelFormatter) && this._indexLabels.push({ chartType: "area", dataPoint: m2[n2], dataSeries: f, point: { x, y: s }, direction: 0 > m2[n2].y === a.axisY.reversed ? 1 : -1, color: C });
                    }
                b();
                X.drawMarkers(h2);
              }
            }
            t && (e.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), g.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && g.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && g.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), g.clearRect(k.x1, k.y1, k.width, k.height), this._eventManager.ghostCtx.restore());
            g.restore();
            return { source: e, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderSplineArea = function(a) {
          function d() {
            var c2 = w2(y, 2);
            if (0 < c2.length) {
              if (0 < l.lineThickness) {
                b.beginPath();
                b.moveTo(c2[0].x, c2[0].y);
                c2[0].newStrokeStyle && (b.strokeStyle = c2[0].newStrokeStyle);
                c2[0].newLineDashArray && b.setLineDash(c2[0].newLineDashArray);
                for (var d2 = 0; d2 < c2.length - 3; d2 += 3)
                  if (b.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), t && e.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), c2[d2 + 3].newStrokeStyle || c2[d2 + 3].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(c2[d2 + 3].x, c2[d2 + 3].y), c2[d2 + 3].newStrokeStyle && (b.strokeStyle = c2[d2 + 3].newStrokeStyle), c2[d2 + 3].newLineDashArray && b.setLineDash(c2[d2 + 3].newLineDashArray);
                b.stroke();
              }
              b.beginPath();
              b.moveTo(
                c2[0].x,
                c2[0].y
              );
              t && (e.beginPath(), e.moveTo(c2[0].x, c2[0].y));
              for (d2 = 0; d2 < c2.length - 3; d2 += 3)
                b.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y), t && e.bezierCurveTo(c2[d2 + 1].x, c2[d2 + 1].y, c2[d2 + 2].x, c2[d2 + 2].y, c2[d2 + 3].x, c2[d2 + 3].y);
              a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? x = n2 : 0 > a.axisY.viewportMaximum ? x = g.y1 : 0 < a.axisY.viewportMinimum && (x = n2);
              s = { x: c2[0].x, y: c2[0].y };
              b.lineTo(c2[c2.length - 1].x, x);
              b.lineTo(s.x, x);
              b.closePath();
              b.globalAlpha = l.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              t && (e.lineTo(c2[c2.length - 1].x, x), e.lineTo(s.x, x), e.closePath(), e.fill());
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, g = a.axisY.lineCoordinates, r = [], u = this.plotArea;
            b.save();
            t && e.save();
            b.beginPath();
            b.rect(u.x1, u.y1, u.width, u.height);
            b.clip();
            t && (e.beginPath(), e.rect(u.x1, u.y1, u.width, u.height), e.clip());
            for (var h2 = 0; h2 < a.dataSeriesIndexes.length; h2++) {
              var k = a.dataSeriesIndexes[h2], l = this.data[k], p = l.dataPoints, r = l.id;
              this._eventManager.objectMap[r] = { objectType: "dataSeries", dataSeriesIndex: k };
              r = Z(r);
              e.fillStyle = r;
              var r = [], q = 0, f, m2, n2 = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), x, s = null, y = [];
              if (0 < p.length) {
                var v = l._colorSet[q % l._colorSet.length], I = l.lineColor = l.options.lineColor || v, A = I;
                b.fillStyle = v;
                b.strokeStyle = I;
                b.lineWidth = l.lineThickness;
                var C = "solid";
                if (b.setLineDash) {
                  var z3 = H(l.nullDataLineDashType, l.lineThickness), C = l.lineDashType, D2 = H(C, l.lineThickness);
                  b.setLineDash(D2);
                }
                for (m2 = false; q < p.length; q++)
                  if (f = p[q].x.getTime ? p[q].x.getTime() : p[q].x, !(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax && (!l.connectNullData || !m2)))
                    if ("number" !== typeof p[q].y)
                      0 < q && !m2 && (l.connectNullData ? b.setLineDash && (0 < y.length && (l.options.nullDataLineDashType || !p[q - 1].lineDashType)) && (y[y.length - 1].newLineDashArray = z3, C = l.nullDataLineDashType) : (d(), y = [])), m2 = true;
                    else {
                      f = a.axisX.convertValueToPixel(f);
                      m2 = a.axisY.convertValueToPixel(p[q].y);
                      var K = l.dataPointIds[q];
                      this._eventManager.objectMap[K] = { id: K, objectType: "dataPoint", dataSeriesIndex: k, dataPointIndex: q, x1: f, y1: m2 };
                      y[y.length] = { x: f, y: m2 };
                      q < p.length - 1 && (A !== (p[q].lineColor || I) || C !== (p[q].lineDashType || l.lineDashType)) && (A = p[q].lineColor || I, y[y.length - 1].newStrokeStyle = A, b.setLineDash && (p[q].lineDashType ? (C = p[q].lineDashType, y[y.length - 1].newLineDashArray = H(C, l.lineThickness)) : (C = l.lineDashType, y[y.length - 1].newLineDashArray = D2)));
                      if (0 !== p[q].markerSize && (0 < p[q].markerSize || 0 < l.markerSize)) {
                        var T = l.getMarkerProperties(q, f, m2, b);
                        r.push(T);
                        K = Z(K);
                        t && r.push({ x: f, y: m2, ctx: e, type: T.type, size: T.size, color: K, borderColor: K, borderThickness: T.borderThickness });
                      }
                      (p[q].indexLabel || l.indexLabel || p[q].indexLabelFormatter || l.indexLabelFormatter) && this._indexLabels.push({ chartType: "splineArea", dataPoint: p[q], dataSeries: l, point: { x: f, y: m2 }, direction: 0 > p[q].y === a.axisY.reversed ? 1 : -1, color: v });
                      m2 = false;
                    }
                d();
                X.drawMarkers(r);
              }
            }
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(
              a.axisX.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(u.x1, u.y1, u.width, u.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStepArea = function(a) {
          var d, c;
          function b() {
            A && (0 < f.lineThickness && g.stroke(), a.axisY.logarithmic || 0 >= a.axisY.viewportMinimum && 0 <= a.axisY.viewportMaximum ? I = v : 0 > a.axisY.viewportMaximum ? I = u.y1 : 0 < a.axisY.viewportMinimum && (I = v), g.lineTo(x, I), g.lineTo(A.x, I), g.closePath(), g.globalAlpha = f.fillOpacity, g.fill(), g.globalAlpha = 1, t && (r.lineTo(x, I), r.lineTo(A.x, I), r.closePath(), r.fill()), g.beginPath(), g.moveTo(x, s), r.beginPath(), r.moveTo(x, s), A = { x, y: s });
          }
          var e = a.targetCanvasCtx || this.plotArea.ctx, g = t ? this._preRenderCtx : e;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var r = this._eventManager.ghostCtx, u = a.axisY.lineCoordinates, h2 = [], k = this.plotArea, l;
            g.save();
            t && r.save();
            g.beginPath();
            g.rect(k.x1, k.y1, k.width, k.height);
            g.clip();
            t && (r.beginPath(), r.rect(k.x1, k.y1, k.width, k.height), r.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], f = this.data[q], m2 = f.dataPoints, h2 = f.id;
              this._eventManager.objectMap[h2] = { objectType: "dataSeries", dataSeriesIndex: q };
              h2 = Z(h2);
              r.fillStyle = h2;
              h2 = [];
              d = true;
              var n2 = 0, x, s, y, v = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), I, A = null;
              c = false;
              if (0 < m2.length) {
                var C = f._colorSet[n2 % f._colorSet.length], w3 = f.lineColor = f.options.lineColor || C, z3 = w3;
                g.fillStyle = C;
                g.strokeStyle = w3;
                g.lineWidth = f.lineThickness;
                var K = "solid";
                if (g.setLineDash) {
                  var T = H(f.nullDataLineDashType, f.lineThickness), K = f.lineDashType, D2 = H(K, f.lineThickness);
                  g.setLineDash(D2);
                }
                for (; n2 < m2.length; n2++)
                  if (y = m2[n2].x.getTime ? m2[n2].x.getTime() : m2[n2].x, !(y < a.axisX.dataInfo.viewPortMin || y > a.axisX.dataInfo.viewPortMax && (!f.connectNullData || !c))) {
                    var ca = s;
                    "number" !== typeof m2[n2].y ? (f.connectNullData || (c || d) || b(), c = true) : (x = a.axisX.convertValueToPixel(y), s = a.axisY.convertValueToPixel(m2[n2].y), d || c ? (!d && f.connectNullData ? (g.setLineDash && (f.options.nullDataLineDashType || K === f.lineDashType && f.lineDashType !== f.nullDataLineDashType) && (d = x, c = s, x = l.x, s = l.y, b(), g.moveTo(l.x, l.y), x = d, s = c, A = l, K = f.nullDataLineDashType, g.setLineDash(T)), g.lineTo(x, ca), g.lineTo(x, s), t && (r.lineTo(x, ca), r.lineTo(x, s))) : (g.beginPath(), g.moveTo(x, s), t && (r.beginPath(), r.moveTo(x, s)), A = { x, y: s }), c = d = false) : (g.lineTo(x, ca), t && r.lineTo(
                      x,
                      ca
                    ), g.lineTo(x, s), t && r.lineTo(x, s), 0 == n2 % 250 && b()), l = { x, y: s }, n2 < m2.length - 1 && (z3 !== (m2[n2].lineColor || w3) || K !== (m2[n2].lineDashType || f.lineDashType)) && (b(), z3 = m2[n2].lineColor || w3, g.strokeStyle = z3, g.setLineDash && (m2[n2].lineDashType ? (K = m2[n2].lineDashType, g.setLineDash(H(K, f.lineThickness))) : (K = f.lineDashType, g.setLineDash(D2)))), y = f.dataPointIds[n2], this._eventManager.objectMap[y] = { id: y, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: n2, x1: x, y1: s }, 0 !== m2[n2].markerSize && (0 < m2[n2].markerSize || 0 < f.markerSize) && (ca = f.getMarkerProperties(n2, x, s, g), h2.push(ca), y = Z(y), t && h2.push({ x, y: s, ctx: r, type: ca.type, size: ca.size, color: y, borderColor: y, borderThickness: ca.borderThickness })), (m2[n2].indexLabel || f.indexLabel || m2[n2].indexLabelFormatter || f.indexLabelFormatter) && this._indexLabels.push({ chartType: "stepArea", dataPoint: m2[n2], dataSeries: f, point: { x, y: s }, direction: 0 > m2[n2].y === a.axisY.reversed ? 1 : -1, color: C }));
                  }
                b();
                X.drawMarkers(h2);
              }
            }
            t && (e.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), g.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && g.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && g.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), g.clearRect(k.x1, k.y1, k.width, k.height), this._eventManager.ghostCtx.restore());
            g.restore();
            return { source: e, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderStackedArea = function(a) {
          function d() {
            if (!(1 > k.length)) {
              for (0 < C.lineThickness && b.stroke(); 0 < k.length; ) {
                var a2 = k.pop();
                b.lineTo(a2.x, a2.y);
                t && x.lineTo(a2.x, a2.y);
              }
              b.closePath();
              b.globalAlpha = C.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              b.beginPath();
              t && (x.closePath(), x.fill(), x.beginPath());
              k = [];
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, g = null, r = [], u = this.plotArea, h2 = [], k = [], l = [], p = [], q = 0, f, m2, n2 = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), x = this._eventManager.ghostCtx, s, y, v;
            t && x.beginPath();
            b.save();
            t && x.save();
            b.beginPath();
            b.rect(u.x1, u.y1, u.width, u.height);
            b.clip();
            t && (x.beginPath(), x.rect(u.x1, u.y1, u.width, u.height), x.clip());
            for (var e = [], I = 0; I < a.dataSeriesIndexes.length; I++) {
              var A = a.dataSeriesIndexes[I], C = this.data[A], w3 = C.dataPoints;
              C.dataPointIndexes = [];
              for (q = 0; q < w3.length; q++)
                A = w3[q].x.getTime ? w3[q].x.getTime() : w3[q].x, C.dataPointIndexes[A] = q, e[A] || (l.push(A), e[A] = true);
              l.sort(Ra);
            }
            for (I = 0; I < a.dataSeriesIndexes.length; I++) {
              A = a.dataSeriesIndexes[I];
              C = this.data[A];
              w3 = C.dataPoints;
              y = true;
              k = [];
              q = C.id;
              this._eventManager.objectMap[q] = { objectType: "dataSeries", dataSeriesIndex: A };
              q = Z(q);
              x.fillStyle = q;
              if (0 < l.length) {
                var e = C._colorSet[0], z3 = C.lineColor = C.options.lineColor || e, K = z3;
                b.fillStyle = e;
                b.strokeStyle = z3;
                b.lineWidth = C.lineThickness;
                v = "solid";
                if (b.setLineDash) {
                  var T = H(C.nullDataLineDashType, C.lineThickness);
                  v = C.lineDashType;
                  var D2 = H(v, C.lineThickness);
                  b.setLineDash(D2);
                }
                for (var ca = true, q = 0; q < l.length; q++) {
                  var g = l[q], ia = null, ia = 0 <= C.dataPointIndexes[g] ? w3[C.dataPointIndexes[g]] : { x: g, y: null };
                  if (!(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax && (!C.connectNullData || !ca)))
                    if ("number" !== typeof ia.y)
                      C.connectNullData || (ca || y) || d(), ca = true;
                    else {
                      f = a.axisX.convertValueToPixel(g);
                      var pa = h2[g] ? h2[g] : 0;
                      if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length) {
                        p[g] = ia.y + (p[g] ? p[g] : 0);
                        if (0 >= p[g] && a.axisY.logarithmic)
                          continue;
                        m2 = a.axisY.convertValueToPixel(p[g]);
                      } else
                        m2 = a.axisY.convertValueToPixel(ia.y), m2 -= pa;
                      k.push({ x: f, y: n2 - pa });
                      h2[g] = n2 - m2;
                      y || ca ? (!y && C.connectNullData ? (b.setLineDash && (C.options.nullDataLineDashType || v === C.lineDashType && C.lineDashType !== C.nullDataLineDashType) && (y = k.pop(), v = k[k.length - 1], d(), b.moveTo(s.x, s.y), k.push(v), k.push(y), v = C.nullDataLineDashType, b.setLineDash(T)), b.lineTo(f, m2), t && x.lineTo(f, m2)) : (b.beginPath(), b.moveTo(f, m2), t && (x.beginPath(), x.moveTo(f, m2))), ca = y = false) : (b.lineTo(f, m2), t && x.lineTo(f, m2), 0 == q % 250 && (d(), b.moveTo(f, m2), t && x.moveTo(f, m2), k.push({ x: f, y: n2 - pa })));
                      s = { x: f, y: m2 };
                      q < w3.length - 1 && (K !== (w3[q].lineColor || z3) || v !== (w3[q].lineDashType || C.lineDashType)) && (d(), b.beginPath(), b.moveTo(f, m2), k.push({ x: f, y: n2 - pa }), K = w3[q].lineColor || z3, b.strokeStyle = K, b.setLineDash && (w3[q].lineDashType ? (v = w3[q].lineDashType, b.setLineDash(H(v, C.lineThickness))) : (v = C.lineDashType, b.setLineDash(D2))));
                      if (0 <= C.dataPointIndexes[g]) {
                        var ma = C.dataPointIds[C.dataPointIndexes[g]];
                        this._eventManager.objectMap[ma] = { id: ma, objectType: "dataPoint", dataSeriesIndex: A, dataPointIndex: C.dataPointIndexes[g], x1: f, y1: m2 };
                      }
                      0 <= C.dataPointIndexes[g] && 0 !== ia.markerSize && (0 < ia.markerSize || 0 < C.markerSize) && (pa = C.getMarkerProperties(C.dataPointIndexes[g], f, m2, b), r.push(pa), g = Z(ma), t && r.push({ x: f, y: m2, ctx: x, type: pa.type, size: pa.size, color: g, borderColor: g, borderThickness: pa.borderThickness }));
                      (ia.indexLabel || C.indexLabel || ia.indexLabelFormatter || C.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedArea", dataPoint: ia, dataSeries: C, point: { x: f, y: m2 }, direction: 0 > w3[q].y === a.axisY.reversed ? 1 : -1, color: e });
                    }
                }
                d();
                b.moveTo(f, m2);
                t && x.moveTo(f, m2);
              }
              delete C.dataPointIndexes;
            }
            X.drawMarkers(r);
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(u.x1, u.y1, u.width, u.height), x.restore());
            b.restore();
            return {
              source: c,
              dest: this.plotArea.ctx,
              animationCallback: N.xClipAnimation,
              easingFunction: N.easing.linear,
              animationBase: 0
            };
          }
        };
        n.prototype.renderStackedArea100 = function(a) {
          function d() {
            for (0 < C.lineThickness && b.stroke(); 0 < k.length; ) {
              var a2 = k.pop();
              b.lineTo(a2.x, a2.y);
              t && v.lineTo(a2.x, a2.y);
            }
            b.closePath();
            b.globalAlpha = C.fillOpacity;
            b.fill();
            b.globalAlpha = 1;
            b.beginPath();
            t && (v.closePath(), v.fill(), v.beginPath());
            k = [];
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, g = null, r = this.plotArea, u = [], m2 = [], k = [], l = [], p = [], q = 0, f, h2, n2, x, s, y = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), v = this._eventManager.ghostCtx;
            b.save();
            t && v.save();
            b.beginPath();
            b.rect(r.x1, r.y1, r.width, r.height);
            b.clip();
            t && (v.beginPath(), v.rect(r.x1, r.y1, r.width, r.height), v.clip());
            for (var e = [], I = 0; I < a.dataSeriesIndexes.length; I++) {
              var A = a.dataSeriesIndexes[I], C = this.data[A], w3 = C.dataPoints;
              C.dataPointIndexes = [];
              for (q = 0; q < w3.length; q++)
                A = w3[q].x.getTime ? w3[q].x.getTime() : w3[q].x, C.dataPointIndexes[A] = q, e[A] || (l.push(A), e[A] = true);
              l.sort(Ra);
            }
            for (I = 0; I < a.dataSeriesIndexes.length; I++) {
              A = a.dataSeriesIndexes[I];
              C = this.data[A];
              w3 = C.dataPoints;
              x = true;
              e = C.id;
              this._eventManager.objectMap[e] = { objectType: "dataSeries", dataSeriesIndex: A };
              e = Z(e);
              v.fillStyle = e;
              k = [];
              if (0 < l.length) {
                var e = C._colorSet[q % C._colorSet.length], z3 = C.lineColor = C.options.lineColor || e, K = z3;
                b.fillStyle = e;
                b.strokeStyle = z3;
                b.lineWidth = C.lineThickness;
                s = "solid";
                if (b.setLineDash) {
                  var T = H(C.nullDataLineDashType, C.lineThickness);
                  s = C.lineDashType;
                  var D2 = H(s, C.lineThickness);
                  b.setLineDash(D2);
                }
                for (var ca = true, q = 0; q < l.length; q++) {
                  var g = l[q], ia = null, ia = 0 <= C.dataPointIndexes[g] ? w3[C.dataPointIndexes[g]] : { x: g, y: null };
                  if (!(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax && (!C.connectNullData || !ca)))
                    if ("number" !== typeof ia.y)
                      C.connectNullData || (ca || x) || d(), ca = true;
                    else {
                      var pa;
                      pa = 0 !== a.dataPointYSums[g] ? 100 * (ia.y / a.dataPointYSums[g]) : 0;
                      f = a.axisX.convertValueToPixel(g);
                      var ma = m2[g] ? m2[g] : 0;
                      if (a.axisY.logarithmic || a.axisY.scaleBreaks && 0 < a.axisY.scaleBreaks._appliedBreaks.length) {
                        p[g] = pa + (p[g] ? p[g] : 0);
                        if (0 >= p[g] && a.axisY.logarithmic)
                          continue;
                        h2 = a.axisY.convertValueToPixel(p[g]);
                      } else
                        h2 = a.axisY.convertValueToPixel(pa), h2 -= ma;
                      k.push({ x: f, y: y - ma });
                      m2[g] = y - h2;
                      x || ca ? (!x && C.connectNullData ? (b.setLineDash && (C.options.nullDataLineDashType || s === C.lineDashType && C.lineDashType !== C.nullDataLineDashType) && (x = k.pop(), s = k[k.length - 1], d(), b.moveTo(n2.x, n2.y), k.push(s), k.push(x), s = C.nullDataLineDashType, b.setLineDash(T)), b.lineTo(f, h2), t && v.lineTo(f, h2)) : (b.beginPath(), b.moveTo(f, h2), t && (v.beginPath(), v.moveTo(f, h2))), ca = x = false) : (b.lineTo(f, h2), t && v.lineTo(f, h2), 0 == q % 250 && (d(), b.moveTo(f, h2), t && v.moveTo(f, h2), k.push({ x: f, y: y - ma })));
                      n2 = { x: f, y: h2 };
                      q < w3.length - 1 && (K !== (w3[q].lineColor || z3) || s !== (w3[q].lineDashType || C.lineDashType)) && (d(), b.beginPath(), b.moveTo(f, h2), k.push({ x: f, y: y - ma }), K = w3[q].lineColor || z3, b.strokeStyle = K, b.setLineDash && (w3[q].lineDashType ? (s = w3[q].lineDashType, b.setLineDash(H(s, C.lineThickness))) : (s = C.lineDashType, b.setLineDash(D2))));
                      if (0 <= C.dataPointIndexes[g]) {
                        var F = C.dataPointIds[C.dataPointIndexes[g]];
                        this._eventManager.objectMap[F] = { id: F, objectType: "dataPoint", dataSeriesIndex: A, dataPointIndex: C.dataPointIndexes[g], x1: f, y1: h2 };
                      }
                      0 <= C.dataPointIndexes[g] && 0 !== ia.markerSize && (0 < ia.markerSize || 0 < C.markerSize) && (ma = C.getMarkerProperties(q, f, h2, b), u.push(ma), g = Z(F), t && u.push({ x: f, y: h2, ctx: v, type: ma.type, size: ma.size, color: g, borderColor: g, borderThickness: ma.borderThickness }));
                      (ia.indexLabel || C.indexLabel || ia.indexLabelFormatter || C.indexLabelFormatter) && this._indexLabels.push({ chartType: "stackedArea100", dataPoint: ia, dataSeries: C, point: {
                        x: f,
                        y: h2
                      }, direction: 0 > w3[q].y === a.axisY.reversed ? 1 : -1, color: e });
                    }
                }
                d();
                b.moveTo(f, h2);
                t && v.moveTo(f, h2);
              }
              delete C.dataPointIndexes;
            }
            X.drawMarkers(u);
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(r.x1, r.y1, r.width, r.height), v.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderBubble = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this.plotArea, e = 0, g, r;
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(b.x1, b.y1, b.width, b.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.clip());
            for (var u = -Infinity, h2 = Infinity, k = 0; k < a.dataSeriesIndexes.length; k++)
              for (var l = a.dataSeriesIndexes[k], p = this.data[l], q = p.dataPoints, f = 0, e = 0; e < q.length; e++)
                g = q[e].getTime ? g = q[e].x.getTime() : g = q[e].x, g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax || "undefined" === typeof q[e].z || (f = q[e].z, f > u && (u = f), f < h2 && (h2 = f));
            for (var m2 = 25 * Math.PI, n2 = Math.max(
              Math.pow(0.25 * Math.min(b.height, b.width) / 2, 2) * Math.PI,
              m2
            ), k = 0; k < a.dataSeriesIndexes.length; k++)
              if (l = a.dataSeriesIndexes[k], p = this.data[l], q = p.dataPoints, 0 < q.length) {
                for (c.strokeStyle = "#4572A7 ", e = 0; e < q.length; e++)
                  if (g = q[e].getTime ? g = q[e].x.getTime() : g = q[e].x, !(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax) && "number" === typeof q[e].y) {
                    g = a.axisX.convertValueToPixel(g);
                    r = a.axisY.convertValueToPixel(q[e].y);
                    var f = q[e].z, x = 2 * Math.max(Math.sqrt((u === h2 ? n2 / 2 : m2 + (n2 - m2) / (u - h2) * (f - h2)) / Math.PI) << 0, 1), f = p.getMarkerProperties(e, c);
                    f.size = x;
                    c.globalAlpha = p.fillOpacity;
                    X.drawMarker(g, r, c, f.type, f.size, f.color, f.borderColor, f.borderThickness);
                    c.globalAlpha = 1;
                    var s = p.dataPointIds[e];
                    this._eventManager.objectMap[s] = { id: s, objectType: "dataPoint", dataSeriesIndex: l, dataPointIndex: e, x1: g, y1: r, size: x };
                    x = Z(s);
                    t && X.drawMarker(g, r, this._eventManager.ghostCtx, f.type, f.size, x, x, f.borderThickness);
                    (q[e].indexLabel || p.indexLabel || q[e].indexLabelFormatter || p.indexLabelFormatter) && this._indexLabels.push({
                      chartType: "bubble",
                      dataPoint: q[e],
                      dataSeries: p,
                      point: { x: g, y: r },
                      direction: 1,
                      bounds: { x1: g - f.size / 2, y1: r - f.size / 2, x2: g + f.size / 2, y2: r + f.size / 2 },
                      color: null
                    });
                  }
              }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderScatter = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this.plotArea, e = 0, g, r;
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(b.x1, b.y1, b.width, b.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(
              b.x1,
              b.y1,
              b.width,
              b.height
            ), this._eventManager.ghostCtx.clip());
            for (var u = 0; u < a.dataSeriesIndexes.length; u++) {
              var h2 = a.dataSeriesIndexes[u], k = this.data[h2], l = k.dataPoints;
              if (0 < l.length) {
                c.strokeStyle = "#4572A7 ";
                Math.pow(0.3 * Math.min(b.height, b.width) / 2, 2);
                for (var p = 0, q = 0, e = 0; e < l.length; e++)
                  if (g = l[e].getTime ? g = l[e].x.getTime() : g = l[e].x, !(g < a.axisX.dataInfo.viewPortMin || g > a.axisX.dataInfo.viewPortMax) && "number" === typeof l[e].y) {
                    g = a.axisX.convertValueToPixel(g);
                    r = a.axisY.convertValueToPixel(l[e].y);
                    var f = k.getMarkerProperties(
                      e,
                      g,
                      r,
                      c
                    );
                    c.globalAlpha = k.fillOpacity;
                    X.drawMarker(f.x, f.y, f.ctx, f.type, f.size, f.color, f.borderColor, f.borderThickness);
                    c.globalAlpha = 1;
                    Math.sqrt((p - g) * (p - g) + (q - r) * (q - r)) < Math.min(f.size, 5) && l.length > Math.min(this.plotArea.width, this.plotArea.height) || (p = k.dataPointIds[e], this._eventManager.objectMap[p] = { id: p, objectType: "dataPoint", dataSeriesIndex: h2, dataPointIndex: e, x1: g, y1: r }, p = Z(p), t && X.drawMarker(f.x, f.y, this._eventManager.ghostCtx, f.type, f.size, p, p, f.borderThickness), (l[e].indexLabel || k.indexLabel || l[e].indexLabelFormatter || k.indexLabelFormatter) && this._indexLabels.push({ chartType: "scatter", dataPoint: l[e], dataSeries: k, point: { x: g, y: r }, direction: 1, bounds: { x1: g - f.size / 2, y1: r - f.size / 2, x2: g + f.size / 2, y2: r + f.size / 2 }, color: null }), p = g, q = r);
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(b.x1, b.y1, b.width, b.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderCandlestick = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d, b = this._eventManager.ghostCtx;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, g = null, r = this.plotArea, u = 0, h2, k, l, p, q, f, e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, g = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.015 * this.width, n2 = a.axisX.dataInfo.minDiff;
            isFinite(n2) || (n2 = 0.3 * Math.abs(a.axisX.range));
            n2 = this.options.dataPointWidth ? this.dataPointWidth : 0.7 * r.width * (a.axisX.logarithmic ? Math.log(n2) / Math.log(a.axisX.range) : Math.abs(n2) / Math.abs(a.axisX.range)) << 0;
            this.dataPointMaxWidth && e > g && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, g));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && g < e) && (g = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
            n2 < e && (n2 = e);
            n2 > g && (n2 = g);
            c.save();
            t && b.save();
            c.beginPath();
            c.rect(r.x1, r.y1, r.width, r.height);
            c.clip();
            t && (b.beginPath(), b.rect(r.x1, r.y1, r.width, r.height), b.clip());
            for (var J = 0; J < a.dataSeriesIndexes.length; J++) {
              var x = a.dataSeriesIndexes[J], s = this.data[x], y = s.dataPoints;
              if (0 < y.length) {
                for (var v = 5 < n2 && s.bevelEnabled ? true : false, u = 0; u < y.length; u++)
                  if (y[u].getTime ? f = y[u].x.getTime() : f = y[u].x, !(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax) && !m(y[u].y) && y[u].y.length && "number" === typeof y[u].y[0] && "number" === typeof y[u].y[1] && "number" === typeof y[u].y[2] && "number" === typeof y[u].y[3]) {
                    h2 = a.axisX.convertValueToPixel(f);
                    k = a.axisY.convertValueToPixel(y[u].y[0]);
                    l = a.axisY.convertValueToPixel(y[u].y[1]);
                    p = a.axisY.convertValueToPixel(y[u].y[2]);
                    q = a.axisY.convertValueToPixel(y[u].y[3]);
                    var w3 = h2 - n2 / 2 << 0, A = w3 + n2 << 0, g = s.options.fallingColor ? s.fallingColor : s._colorSet[0], e = y[u].color ? y[u].color : s._colorSet[0], C = Math.round(Math.max(1, 0.15 * n2)), z3 = 0 === C % 2 ? 0 : 0.5, D2 = s.dataPointIds[u];
                    this._eventManager.objectMap[D2] = { id: D2, objectType: "dataPoint", dataSeriesIndex: x, dataPointIndex: u, x1: w3, y1: k, x2: A, y2: l, x3: h2, y3: p, x4: h2, y4: q, borderThickness: C, color: e };
                    c.strokeStyle = e;
                    c.beginPath();
                    c.lineWidth = C;
                    b.lineWidth = Math.max(C, 4);
                    "candlestick" === s.type ? (c.moveTo(h2 - z3, l), c.lineTo(h2 - z3, Math.min(k, q)), c.stroke(), c.moveTo(h2 - z3, Math.max(k, q)), c.lineTo(h2 - z3, p), c.stroke(), ba(c, w3, Math.min(k, q), A, Math.max(k, q), y[u].y[0] <= y[u].y[3] ? s.risingColor : g, C, e, v, v, false, false, s.fillOpacity), t && (e = Z(D2), b.strokeStyle = e, b.moveTo(h2 - z3, l), b.lineTo(h2 - z3, Math.min(k, q)), b.stroke(), b.moveTo(h2 - z3, Math.max(k, q)), b.lineTo(h2 - z3, p), b.stroke(), ba(b, w3, Math.min(k, q), A, Math.max(k, q), e, 0, null, false, false, false, false))) : "ohlc" === s.type && (c.moveTo(h2 - z3, l), c.lineTo(h2 - z3, p), c.stroke(), c.beginPath(), c.moveTo(h2, k), c.lineTo(w3, k), c.stroke(), c.beginPath(), c.moveTo(h2, q), c.lineTo(A, q), c.stroke(), t && (e = Z(D2), b.strokeStyle = e, b.moveTo(h2 - z3, l), b.lineTo(h2 - z3, p), b.stroke(), b.beginPath(), b.moveTo(h2, k), b.lineTo(w3, k), b.stroke(), b.beginPath(), b.moveTo(h2, q), b.lineTo(A, q), b.stroke()));
                    (y[u].indexLabel || s.indexLabel || y[u].indexLabelFormatter || s.indexLabelFormatter) && this._indexLabels.push({ chartType: s.type, dataPoint: y[u], dataSeries: s, point: { x: w3 + (A - w3) / 2, y: a.axisY.reversed ? p : l }, direction: 1, bounds: { x1: w3, y1: Math.min(l, p), x2: A, y2: Math.max(l, p) }, color: e });
                  }
              }
            }
            t && (d.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(r.x1, r.y1, r.width, r.height), b.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: N.fadeInAnimation,
              easingFunction: N.easing.easeInQuad,
              animationBase: 0
            };
          }
        };
        n.prototype.renderBoxAndWhisker = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d, b = this._eventManager.ghostCtx;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, g = this.plotArea, r = 0, u, h2, k, l, p, q, f, e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1, r = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.015 * this.width, n2 = a.axisX.dataInfo.minDiff;
            isFinite(n2) || (n2 = 0.3 * Math.abs(a.axisX.range));
            n2 = this.options.dataPointWidth ? this.dataPointWidth : 0.7 * g.width * (a.axisX.logarithmic ? Math.log(n2) / Math.log(a.axisX.range) : Math.abs(n2) / Math.abs(a.axisX.range)) << 0;
            this.dataPointMaxWidth && e > r && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, r));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && r < e) && (r = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
            n2 < e && (n2 = e);
            n2 > r && (n2 = r);
            c.save();
            t && b.save();
            c.beginPath();
            c.rect(
              g.x1,
              g.y1,
              g.width,
              g.height
            );
            c.clip();
            t && (b.beginPath(), b.rect(g.x1, g.y1, g.width, g.height), b.clip());
            for (var J = false, J = !!a.axisY.reversed, x = 0; x < a.dataSeriesIndexes.length; x++) {
              var s = a.dataSeriesIndexes[x], y = this.data[s], v = y.dataPoints;
              if (0 < v.length) {
                for (var w3 = 5 < n2 && y.bevelEnabled ? true : false, r = 0; r < v.length; r++)
                  if (v[r].getTime ? f = v[r].x.getTime() : f = v[r].x, !(f < a.axisX.dataInfo.viewPortMin || f > a.axisX.dataInfo.viewPortMax) && !m(v[r].y) && v[r].y.length && "number" === typeof v[r].y[0] && "number" === typeof v[r].y[1] && "number" === typeof v[r].y[2] && "number" === typeof v[r].y[3] && "number" === typeof v[r].y[4] && 5 === v[r].y.length) {
                    u = a.axisX.convertValueToPixel(f);
                    h2 = a.axisY.convertValueToPixel(v[r].y[0]);
                    k = a.axisY.convertValueToPixel(v[r].y[1]);
                    l = a.axisY.convertValueToPixel(v[r].y[2]);
                    p = a.axisY.convertValueToPixel(v[r].y[3]);
                    q = a.axisY.convertValueToPixel(v[r].y[4]);
                    var A = u - n2 / 2 << 0, C = u + n2 / 2 << 0, e = v[r].color ? v[r].color : y._colorSet[0], z3 = Math.round(Math.max(1, 0.15 * n2)), D2 = 0 === z3 % 2 ? 0 : 0.5, K = v[r].whiskerColor ? v[r].whiskerColor : v[r].color ? y.whiskerColor ? y.whiskerColor : v[r].color : y.whiskerColor ? y.whiskerColor : e, T = "number" === typeof v[r].whiskerThickness ? v[r].whiskerThickness : "number" === typeof y.options.whiskerThickness ? y.whiskerThickness : z3, ha = v[r].whiskerDashType ? v[r].whiskerDashType : y.whiskerDashType, ca = m(v[r].whiskerLength) ? m(y.options.whiskerLength) ? n2 : y.whiskerLength : v[r].whiskerLength, ca = "number" === typeof ca ? 0 >= ca ? 0 : ca >= n2 ? n2 : ca : "string" === typeof ca ? parseInt(ca) * n2 / 100 > n2 ? n2 : parseInt(ca) * n2 / 100 : n2, ia = 1 === Math.round(T) % 2 ? 0.5 : 0, pa = v[r].stemColor ? v[r].stemColor : v[r].color ? y.stemColor ? y.stemColor : v[r].color : y.stemColor ? y.stemColor : e, ma = "number" === typeof v[r].stemThickness ? v[r].stemThickness : "number" === typeof y.options.stemThickness ? y.stemThickness : z3, F = 1 === Math.round(ma) % 2 ? 0.5 : 0, E3 = v[r].stemDashType ? v[r].stemDashType : y.stemDashType, L2 = v[r].lineColor ? v[r].lineColor : v[r].color ? y.lineColor ? y.lineColor : v[r].color : y.lineColor ? y.lineColor : e, O2 = "number" === typeof v[r].lineThickness ? v[r].lineThickness : "number" === typeof y.options.lineThickness ? y.lineThickness : z3, S2 = v[r].lineDashType ? v[r].lineDashType : y.lineDashType, M = 1 === Math.round(O2) % 2 ? 0.5 : 0, P = y.upperBoxColor, Q3 = y.lowerBoxColor, va = m(y.options.fillOpacity) ? 1 : y.fillOpacity, R = y.dataPointIds[r];
                    this._eventManager.objectMap[R] = { id: R, objectType: "dataPoint", dataSeriesIndex: s, dataPointIndex: r, x1: A, y1: h2, x2: C, y2: k, x3: u, y3: l, x4: u, y4: p, y5: q, borderThickness: z3, color: e, stemThickness: ma, stemColor: pa, whiskerThickness: T, whiskerLength: ca, whiskerColor: K, lineThickness: O2, lineColor: L2 };
                    c.save();
                    0 < ma && (c.beginPath(), c.strokeStyle = pa, c.lineWidth = ma, c.setLineDash && c.setLineDash(H(E3, ma)), c.moveTo(u - F, k), c.lineTo(u - F, h2), c.stroke(), c.moveTo(u - F, p), c.lineTo(u - F, l), c.stroke());
                    c.restore();
                    b.lineWidth = Math.max(z3, 4);
                    c.beginPath();
                    ba(c, A, Math.min(q, k), C, Math.max(k, q), Q3, 0, e, J ? w3 : false, J ? false : w3, false, false, va);
                    c.beginPath();
                    ba(c, A, Math.min(l, q), C, Math.max(q, l), P, 0, e, J ? false : w3, J ? w3 : false, false, false, va);
                    c.beginPath();
                    c.lineWidth = z3;
                    c.strokeStyle = e;
                    c.rect(A - D2, Math.min(k, l) - D2, C - A + 2 * D2, Math.max(k, l) - Math.min(k, l) + 2 * D2);
                    c.stroke();
                    c.save();
                    0 < O2 && (c.beginPath(), c.globalAlpha = 1, c.setLineDash && c.setLineDash(H(
                      S2,
                      O2
                    )), c.strokeStyle = L2, c.lineWidth = O2, c.moveTo(A, q - M), c.lineTo(C, q - M), c.stroke());
                    c.restore();
                    c.save();
                    0 < T && (c.beginPath(), c.setLineDash && c.setLineDash(H(ha, T)), c.strokeStyle = K, c.lineWidth = T, c.moveTo(u - ca / 2 << 0, p - ia), c.lineTo(u + ca / 2 << 0, p - ia), c.stroke(), c.moveTo(u - ca / 2 << 0, h2 + ia), c.lineTo(u + ca / 2 << 0, h2 + ia), c.stroke());
                    c.restore();
                    t && (e = Z(R), b.strokeStyle = e, b.lineWidth = ma, 0 < ma && (b.moveTo(u - D2 - F, k), b.lineTo(u - D2 - F, Math.max(h2, p)), b.stroke(), b.moveTo(u - D2 - F, Math.min(h2, p)), b.lineTo(u - D2 - F, l), b.stroke()), ba(b, A, Math.max(
                      k,
                      l
                    ), C, Math.min(k, l), e, 0, null, false, false, false, false), 0 < T && (b.beginPath(), b.lineWidth = T, b.moveTo(u + ca / 2, p - ia), b.lineTo(u - ca / 2, p - ia), b.stroke(), b.moveTo(u + ca / 2, h2 + ia), b.lineTo(u - ca / 2, h2 + ia), b.stroke()));
                    (v[r].indexLabel || y.indexLabel || v[r].indexLabelFormatter || y.indexLabelFormatter) && this._indexLabels.push({ chartType: y.type, dataPoint: v[r], dataSeries: y, point: { x: A + (C - A) / 2, y: a.axisY.reversed ? h2 : p }, direction: 1, bounds: { x1: A, y1: Math.min(h2, p), x2: C, y2: Math.max(h2, p) }, color: e });
                  }
              }
            }
            t && (d.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(g.x1, g.y1, g.width, g.height), b.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeColumn = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = 0, r, h2, B, g = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            r = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : 0.03 * this.width;
            var k = a.axisX.dataInfo.minDiff;
            isFinite(k) || (k = 0.3 * Math.abs(a.axisX.range));
            k = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.width * (a.axisX.logarithmic ? Math.log(k) / Math.log(a.axisX.range) : Math.abs(k) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && g > r && (g = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, r));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && r < g) && (r = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, g));
            k < g && (k = g);
            k > r && (k = r);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (var l = 0; l < a.dataSeriesIndexes.length; l++) {
              var p = a.dataSeriesIndexes[l], q = this.data[p], f = q.dataPoints;
              if (0 < f.length) {
                for (var n2 = 5 < k && q.bevelEnabled ? true : false, g = 0; g < f.length; g++)
                  if (f[g].getTime ? B = f[g].x.getTime() : B = f[g].x, !(B < a.axisX.dataInfo.viewPortMin || B > a.axisX.dataInfo.viewPortMax) && !m(f[g].y) && f[g].y.length && "number" === typeof f[g].y[0] && "number" === typeof f[g].y[1]) {
                    b = a.axisX.convertValueToPixel(B);
                    r = a.axisY.convertValueToPixel(f[g].y[0]);
                    h2 = a.axisY.convertValueToPixel(f[g].y[1]);
                    var J = a.axisX.reversed ? b + a.plotType.totalDataSeries * k / 2 - (a.previousDataSeriesCount + l) * k << 0 : b - a.plotType.totalDataSeries * k / 2 + (a.previousDataSeriesCount + l) * k << 0, x = a.axisX.reversed ? J - k << 0 : J + k << 0, b = f[g].color ? f[g].color : q._colorSet[g % q._colorSet.length];
                    if (r > h2) {
                      var s = r;
                      r = h2;
                      h2 = s;
                    }
                    s = q.dataPointIds[g];
                    this._eventManager.objectMap[s] = {
                      id: s,
                      objectType: "dataPoint",
                      dataSeriesIndex: p,
                      dataPointIndex: g,
                      x1: J,
                      y1: r,
                      x2: x,
                      y2: h2
                    };
                    ba(c, a.axisX.reversed ? x : J, r, a.axisX.reversed ? J : x, h2, b, 0, b, n2, n2, false, false, q.fillOpacity);
                    b = Z(s);
                    t && ba(this._eventManager.ghostCtx, a.axisX.reversed ? x : J, r, a.axisX.reversed ? J : x, h2, b, 0, null, false, false, false, false);
                    if (f[g].indexLabel || q.indexLabel || f[g].indexLabelFormatter || q.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "rangeColumn", dataPoint: f[g], dataSeries: q, indexKeyword: 0, point: { x: J + (x - J) / 2, y: f[g].y[1] >= f[g].y[0] ? h2 : r }, direction: f[g].y[1] >= f[g].y[0] ? -1 : 1, bounds: { x1: J, y1: Math.min(
                        r,
                        h2
                      ), x2: x, y2: Math.max(r, h2) }, color: b }), this._indexLabels.push({ chartType: "rangeColumn", dataPoint: f[g], dataSeries: q, indexKeyword: 1, point: { x: J + (x - J) / 2, y: f[g].y[1] >= f[g].y[0] ? r : h2 }, direction: f[g].y[1] >= f[g].y[0] ? 1 : -1, bounds: { x1: J, y1: Math.min(r, h2), x2: x, y2: Math.max(r, h2) }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(
              a.axisY.maskCanvas,
              0,
              0,
              this.width,
              this.height
            ), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderError = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d, b = a.axisY._position ? "left" === a.axisY._position || "right" === a.axisY._position ? false : true : false;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = null, g = false, r = this.plotArea, h2 = 0, B, k, l, p, q, f, n2, J = a.axisX.dataInfo.minDiff;
            isFinite(J) || (J = 0.3 * Math.abs(a.axisX.range));
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(r.x1, r.y1, r.width, r.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(r.x1, r.y1, r.width, r.height), this._eventManager.ghostCtx.clip());
            for (var x = 0, s = 0; s < this.data.length; s++)
              !this.data[s].type.match(/(bar|column)/ig) || !this.data[s].visible || this.data[s].type.match(/(stacked)/ig) && x || x++;
            for (var y = 0; y < a.dataSeriesIndexes.length; y++) {
              var v = a.dataSeriesIndexes[y], w3 = this.data[v], A = w3.dataPoints, C = m(w3._linkedSeries) ? false : w3._linkedSeries.type.match(/(bar|column)/ig) && w3._linkedSeries.visible ? true : false, D2 = 0;
              if (C)
                for (e = w3._linkedSeries.id, s = 0; s < e; s++)
                  !this.data[s].type.match(/(bar|column)/ig) || !this.data[s].visible || this.data[s].type.match(/(stacked)/ig) && D2 || (this.data[s].type.match(/(range)/ig) && (g = true), D2++);
              e = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
              h2 = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : b ? Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / (C ? x : 1))) << 0 : 0.3 * this.width;
              g && (h2 = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : b ? Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / (C ? x : 1))) << 0 : 0.03 * this.width);
              s = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * ((b ? r.height : r.width) * (a.axisX.logarithmic ? Math.log(J) / Math.log(a.axisX.range) : Math.abs(J) / Math.abs(a.axisX.range)) / (C ? x : 1)) << 0;
              this.dataPointMaxWidth && e > h2 && (e = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, h2));
              !this.dataPointMaxWidth && (this.dataPointMinWidth && h2 < e) && (h2 = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, e));
              s < e && (s = e);
              s > h2 && (s = h2);
              if (0 < A.length)
                for (var H2 = w3._colorSet, h2 = 0; h2 < A.length; h2++) {
                  var e = w3.lineColor = w3.options.color ? w3.options.color : H2[0], K = { color: A[h2].whiskerColor ? A[h2].whiskerColor : A[h2].color ? w3.whiskerColor ? w3.whiskerColor : A[h2].color : w3.whiskerColor ? w3.whiskerColor : e, thickness: m(A[h2].whiskerThickness) ? w3.whiskerThickness : A[h2].whiskerThickness, dashType: A[h2].whiskerDashType ? A[h2].whiskerDashType : w3.whiskerDashType, length: m(A[h2].whiskerLength) ? m(w3.options.whiskerLength) ? s : w3.options.whiskerLength : A[h2].whiskerLength, trimLength: m(A[h2].whiskerLength) ? m(w3.options.whiskerLength) ? 50 : 0 : 0 };
                  K.length = "number" === typeof K.length ? 0 >= K.length ? 0 : K.length >= s ? s : K.length : "string" === typeof K.length ? parseInt(K.length) * s / 100 > s ? s : parseInt(K.length) * s / 100 > s : s;
                  K.thickness = "number" === typeof K.thickness ? 0 > K.thickness ? 0 : Math.round(K.thickness) : 2;
                  var T = { color: A[h2].stemColor ? A[h2].stemColor : A[h2].color ? w3.stemColor ? w3.stemColor : A[h2].color : w3.stemColor ? w3.stemColor : e, thickness: A[h2].stemThickness ? A[h2].stemThickness : w3.stemThickness, dashType: A[h2].stemDashType ? A[h2].stemDashType : w3.stemDashType };
                  T.thickness = "number" === typeof T.thickness ? 0 > T.thickness ? 0 : Math.round(T.thickness) : 2;
                  A[h2].getTime ? n2 = A[h2].x.getTime() : n2 = A[h2].x;
                  if (!(n2 < a.axisX.dataInfo.viewPortMin || n2 > a.axisX.dataInfo.viewPortMax) && !m(A[h2].y) && A[h2].y.length && "number" === typeof A[h2].y[0] && "number" === typeof A[h2].y[1]) {
                    var ha = a.axisX.convertValueToPixel(n2);
                    b ? k = ha : B = ha;
                    ha = a.axisY.convertValueToPixel(A[h2].y[0]);
                    b ? l = ha : q = ha;
                    ha = a.axisY.convertValueToPixel(A[h2].y[1]);
                    b ? p = ha : f = ha;
                    b ? (q = a.axisX.reversed ? k + (C ? x : 1) * s / 2 - (C ? D2 - 1 : 0) * s << 0 : k - (C ? x : 1) * s / 2 + (C ? D2 - 1 : 0) * s << 0, f = a.axisX.reversed ? q - s << 0 : q + s << 0) : (l = a.axisX.reversed ? B + (C ? x : 1) * s / 2 - (C ? D2 - 1 : 0) * s << 0 : B - (C ? x : 1) * s / 2 + (C ? D2 - 1 : 0) * s << 0, p = a.axisX.reversed ? l - s << 0 : l + s << 0);
                    !b && q > f && (ha = q, q = f, f = ha);
                    b && l > p && (ha = l, l = p, p = ha);
                    ha = w3.dataPointIds[h2];
                    this._eventManager.objectMap[ha] = { id: ha, objectType: "dataPoint", dataSeriesIndex: v, dataPointIndex: h2, x1: Math.min(l, p), y1: Math.min(q, f), x2: Math.max(p, l), y2: Math.max(f, q), isXYSwapped: b, stemProperties: T, whiskerProperties: K };
                    z2(c, Math.min(l, p), Math.min(q, f), Math.max(p, l), Math.max(f, q), e, K, T, b);
                    t && z2(this._eventManager.ghostCtx, l, q, p, f, e, K, T, b);
                    if (A[h2].indexLabel || w3.indexLabel || A[h2].indexLabelFormatter || w3.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "error", dataPoint: A[h2], dataSeries: w3, indexKeyword: 0, point: { x: b ? A[h2].y[1] >= A[h2].y[0] ? l : p : l + (p - l) / 2, y: b ? q + (f - q) / 2 : A[h2].y[1] >= A[h2].y[0] ? f : q }, direction: A[h2].y[1] >= A[h2].y[0] ? -1 : 1, bounds: { x1: b ? Math.min(l, p) : l, y1: b ? q : Math.min(q, f), x2: b ? Math.max(l, p) : p, y2: b ? f : Math.max(q, f) }, color: e, axisSwapped: b }), this._indexLabels.push({ chartType: "error", dataPoint: A[h2], dataSeries: w3, indexKeyword: 1, point: { x: b ? A[h2].y[1] >= A[h2].y[0] ? p : l : l + (p - l) / 2, y: b ? q + (f - q) / 2 : A[h2].y[1] >= A[h2].y[0] ? q : f }, direction: A[h2].y[1] >= A[h2].y[0] ? 1 : -1, bounds: { x1: b ? Math.min(l, p) : l, y1: b ? q : Math.min(q, f), x2: b ? Math.max(l, p) : p, y2: b ? f : Math.max(q, f) }, color: e, axisSwapped: b });
                  }
                }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.clearRect(r.x1, r.y1, r.width, r.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeBar = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = null, e = this.plotArea, g = 0, r, h2, B, k, g = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            r = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.height, 0.9 * (this.plotArea.height / a.plotType.totalDataSeries)) << 0;
            var l = a.axisX.dataInfo.minDiff;
            isFinite(l) || (l = 0.3 * Math.abs(a.axisX.range));
            l = this.options.dataPointWidth ? this.dataPointWidth : 0.9 * (e.height * (a.axisX.logarithmic ? Math.log(l) / Math.log(a.axisX.range) : Math.abs(l) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && g > r && (g = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, r));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && r < g) && (r = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, g));
            l < g && (l = g);
            l > r && (l = r);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(e.x1, e.y1, e.width, e.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.clip());
            for (var p = 0; p < a.dataSeriesIndexes.length; p++) {
              var q = a.dataSeriesIndexes[p], f = this.data[q], n2 = f.dataPoints;
              if (0 < n2.length) {
                var J = 5 < l && f.bevelEnabled ? true : false;
                c.strokeStyle = "#4572A7 ";
                for (g = 0; g < n2.length; g++)
                  if (n2[g].getTime ? k = n2[g].x.getTime() : k = n2[g].x, !(k < a.axisX.dataInfo.viewPortMin || k > a.axisX.dataInfo.viewPortMax) && !m(n2[g].y) && n2[g].y.length && "number" === typeof n2[g].y[0] && "number" === typeof n2[g].y[1]) {
                    r = a.axisY.convertValueToPixel(n2[g].y[0]);
                    h2 = a.axisY.convertValueToPixel(n2[g].y[1]);
                    B = a.axisX.convertValueToPixel(k);
                    B = a.axisX.reversed ? B + a.plotType.totalDataSeries * l / 2 - (a.previousDataSeriesCount + p) * l << 0 : B - a.plotType.totalDataSeries * l / 2 + (a.previousDataSeriesCount + p) * l << 0;
                    var x = a.axisX.reversed ? B - l << 0 : B + l << 0;
                    r > h2 && (b = r, r = h2, h2 = b);
                    b = n2[g].color ? n2[g].color : f._colorSet[g % f._colorSet.length];
                    ba(c, r, a.axisX.reversed ? x : B, h2, a.axisX.reversed ? B : x, b, 0, null, J, false, false, false, f.fillOpacity);
                    b = f.dataPointIds[g];
                    this._eventManager.objectMap[b] = { id: b, objectType: "dataPoint", dataSeriesIndex: q, dataPointIndex: g, x1: r, y1: B, x2: h2, y2: x };
                    b = Z(b);
                    t && ba(this._eventManager.ghostCtx, r, a.axisX.reversed ? x : B, h2, a.axisX.reversed ? B : x, b, 0, null, false, false, false, false);
                    if (n2[g].indexLabel || f.indexLabel || n2[g].indexLabelFormatter || f.indexLabelFormatter)
                      this._indexLabels.push({ chartType: "rangeBar", dataPoint: n2[g], dataSeries: f, indexKeyword: 0, point: { x: n2[g].y[1] >= n2[g].y[0] ? r : h2, y: B + (x - B) / 2 }, direction: n2[g].y[1] >= n2[g].y[0] ? -1 : 1, bounds: { x1: Math.min(r, h2), y1: B, x2: Math.max(r, h2), y2: x }, color: b }), this._indexLabels.push({ chartType: "rangeBar", dataPoint: n2[g], dataSeries: f, indexKeyword: 1, point: { x: n2[g].y[1] >= n2[g].y[0] ? h2 : r, y: B + (x - B) / 2 }, direction: n2[g].y[1] >= n2[g].y[0] ? 1 : -1, bounds: { x1: Math.min(r, h2), y1: B, x2: Math.max(r, h2), y2: x }, color: b });
                  }
              }
            }
            t && (d.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(e.x1, e.y1, e.width, e.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return { source: d, dest: this.plotArea.ctx, animationCallback: N.fadeInAnimation, easingFunction: N.easing.easeInQuad, animationBase: 0 };
          }
        };
        n.prototype.renderRangeArea = function(a) {
          function d() {
            if (y) {
              for (var a2 = null, c2 = m2.length - 1; 0 <= c2; c2--)
                a2 = m2[c2], b.lineTo(a2.x, a2.y2), e.lineTo(a2.x, a2.y2);
              b.closePath();
              b.globalAlpha = l.fillOpacity;
              b.fill();
              b.globalAlpha = 1;
              e.fill();
              if (0 < l.lineThickness) {
                b.beginPath();
                b.moveTo(a2.x, a2.y2);
                for (c2 = 0; c2 < m2.length; c2++)
                  a2 = m2[c2], b.lineTo(a2.x, a2.y2);
                b.moveTo(m2[0].x, m2[0].y1);
                for (c2 = 0; c2 < m2.length; c2++)
                  a2 = m2[c2], b.lineTo(a2.x, a2.y1);
                b.stroke();
              }
              b.beginPath();
              b.moveTo(n2, J);
              e.beginPath();
              e.moveTo(n2, J);
              y = { x: n2, y: J };
              m2 = [];
              m2.push({ x: n2, y1: J, y2: x });
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, g = [], r = this.plotArea;
            b.save();
            t && e.save();
            b.beginPath();
            b.rect(r.x1, r.y1, r.width, r.height);
            b.clip();
            t && (e.beginPath(), e.rect(r.x1, r.y1, r.width, r.height), e.clip());
            for (var h2 = 0; h2 < a.dataSeriesIndexes.length; h2++) {
              var m2 = [], k = a.dataSeriesIndexes[h2], l = this.data[k], p = l.dataPoints, g = l.id;
              this._eventManager.objectMap[g] = { objectType: "dataSeries", dataSeriesIndex: k };
              g = Z(g);
              e.fillStyle = g;
              var g = [], q = true, f = 0, n2, J, x, s, y = null;
              if (0 < p.length) {
                var v = l._colorSet[f % l._colorSet.length], w3 = l.lineColor = l.options.lineColor || v, A = w3;
                b.fillStyle = v;
                b.strokeStyle = w3;
                b.lineWidth = l.lineThickness;
                var C = "solid";
                if (b.setLineDash) {
                  var z3 = H(l.nullDataLineDashType, l.lineThickness), C = l.lineDashType, D2 = H(C, l.lineThickness);
                  b.setLineDash(D2);
                }
                for (var K = true; f < p.length; f++)
                  if (s = p[f].x.getTime ? p[f].x.getTime() : p[f].x, !(s < a.axisX.dataInfo.viewPortMin || s > a.axisX.dataInfo.viewPortMax && (!l.connectNullData || !K)))
                    if (null !== p[f].y && p[f].y.length && "number" === typeof p[f].y[0] && "number" === typeof p[f].y[1]) {
                      n2 = a.axisX.convertValueToPixel(s);
                      J = a.axisY.convertValueToPixel(p[f].y[0]);
                      x = a.axisY.convertValueToPixel(p[f].y[1]);
                      q || K ? (l.connectNullData && !q ? (b.setLineDash && (l.options.nullDataLineDashType || C === l.lineDashType && l.lineDashType !== l.nullDataLineDashType) && (m2[m2.length - 1].newLineDashArray = D2, C = l.nullDataLineDashType, b.setLineDash(z3)), b.lineTo(n2, J), t && e.lineTo(n2, J), m2.push({ x: n2, y1: J, y2: x })) : (b.beginPath(), b.moveTo(n2, J), y = { x: n2, y: J }, m2 = [], m2.push({ x: n2, y1: J, y2: x }), t && (e.beginPath(), e.moveTo(n2, J))), K = q = false) : (b.lineTo(n2, J), m2.push({ x: n2, y1: J, y2: x }), t && e.lineTo(n2, J), 0 == f % 250 && d());
                      s = l.dataPointIds[f];
                      this._eventManager.objectMap[s] = { id: s, objectType: "dataPoint", dataSeriesIndex: k, dataPointIndex: f, x1: n2, y1: J, y2: x };
                      f < p.length - 1 && (A !== (p[f].lineColor || w3) || C !== (p[f].lineDashType || l.lineDashType)) && (d(), A = p[f].lineColor || w3, m2[m2.length - 1].newStrokeStyle = A, b.strokeStyle = A, b.setLineDash && (p[f].lineDashType ? (C = p[f].lineDashType, m2[m2.length - 1].newLineDashArray = H(C, l.lineThickness), b.setLineDash(m2[m2.length - 1].newLineDashArray)) : (C = l.lineDashType, m2[m2.length - 1].newLineDashArray = D2, b.setLineDash(D2))));
                      if (0 !== p[f].markerSize && (0 < p[f].markerSize || 0 < l.markerSize)) {
                        var T = l.getMarkerProperties(f, n2, x, b);
                        g.push(T);
                        var ha = Z(s);
                        t && g.push({ x: n2, y: x, ctx: e, type: T.type, size: T.size, color: ha, borderColor: ha, borderThickness: T.borderThickness });
                        T = l.getMarkerProperties(
                          f,
                          n2,
                          J,
                          b
                        );
                        g.push(T);
                        ha = Z(s);
                        t && g.push({ x: n2, y: J, ctx: e, type: T.type, size: T.size, color: ha, borderColor: ha, borderThickness: T.borderThickness });
                      }
                      if (p[f].indexLabel || l.indexLabel || p[f].indexLabelFormatter || l.indexLabelFormatter)
                        this._indexLabels.push({ chartType: "rangeArea", dataPoint: p[f], dataSeries: l, indexKeyword: 0, point: { x: n2, y: J }, direction: p[f].y[0] > p[f].y[1] === a.axisY.reversed ? -1 : 1, color: v }), this._indexLabels.push({ chartType: "rangeArea", dataPoint: p[f], dataSeries: l, indexKeyword: 1, point: { x: n2, y: x }, direction: p[f].y[0] > p[f].y[1] === a.axisY.reversed ? 1 : -1, color: v });
                    } else
                      K || q || d(), K = true;
                d();
                X.drawMarkers(g);
              }
            }
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(r.x1, r.y1, r.width, r.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderRangeSplineArea = function(a) {
          function d(a2, c2) {
            var d2 = w2(J, 2);
            if (0 < d2.length) {
              if (0 < k.lineThickness) {
                b.strokeStyle = c2;
                b.setLineDash && b.setLineDash(a2);
                b.beginPath();
                b.moveTo(d2[0].x, d2[0].y);
                for (var f2 = 0; f2 < d2.length - 3; f2 += 3) {
                  if (d2[f2].newStrokeStyle || d2[f2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(d2[f2].x, d2[f2].y), d2[f2].newStrokeStyle && (b.strokeStyle = d2[f2].newStrokeStyle), d2[f2].newLineDashArray && b.setLineDash(d2[f2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
              }
              b.beginPath();
              b.moveTo(d2[0].x, d2[0].y);
              t && (e.beginPath(), e.moveTo(d2[0].x, d2[0].y));
              for (f2 = 0; f2 < d2.length - 3; f2 += 3)
                b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y), t && e.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
              d2 = w2(x, 2);
              b.lineTo(x[x.length - 1].x, x[x.length - 1].y);
              for (f2 = d2.length - 1; 2 < f2; f2 -= 3)
                b.bezierCurveTo(
                  d2[f2 - 1].x,
                  d2[f2 - 1].y,
                  d2[f2 - 2].x,
                  d2[f2 - 2].y,
                  d2[f2 - 3].x,
                  d2[f2 - 3].y
                ), t && e.bezierCurveTo(d2[f2 - 1].x, d2[f2 - 1].y, d2[f2 - 2].x, d2[f2 - 2].y, d2[f2 - 3].x, d2[f2 - 3].y);
              b.closePath();
              b.globalAlpha = k.fillOpacity;
              b.fill();
              t && (e.closePath(), e.fill());
              b.globalAlpha = 1;
              if (0 < k.lineThickness) {
                b.strokeStyle = c2;
                b.setLineDash && b.setLineDash(a2);
                b.beginPath();
                b.moveTo(d2[0].x, d2[0].y);
                for (var g2 = f2 = 0; f2 < d2.length - 3; f2 += 3, g2++) {
                  if (J[g2].newStrokeStyle || J[g2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(d2[f2].x, d2[f2].y), J[g2].newStrokeStyle && (b.strokeStyle = J[g2].newStrokeStyle), J[g2].newLineDashArray && b.setLineDash(J[g2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
                d2 = w2(J, 2);
                b.moveTo(d2[0].x, d2[0].y);
                for (g2 = f2 = 0; f2 < d2.length - 3; f2 += 3, g2++) {
                  if (J[g2].newStrokeStyle || J[g2].newLineDashArray)
                    b.stroke(), b.beginPath(), b.moveTo(d2[f2].x, d2[f2].y), J[g2].newStrokeStyle && (b.strokeStyle = J[g2].newStrokeStyle), J[g2].newLineDashArray && b.setLineDash(J[g2].newLineDashArray);
                  b.bezierCurveTo(d2[f2 + 1].x, d2[f2 + 1].y, d2[f2 + 2].x, d2[f2 + 2].y, d2[f2 + 3].x, d2[f2 + 3].y);
                }
                b.stroke();
              }
              b.beginPath();
            }
          }
          var c = a.targetCanvasCtx || this.plotArea.ctx, b = t ? this._preRenderCtx : c;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var e = this._eventManager.ghostCtx, g = [], r = this.plotArea;
            b.save();
            t && e.save();
            b.beginPath();
            b.rect(r.x1, r.y1, r.width, r.height);
            b.clip();
            t && (e.beginPath(), e.rect(r.x1, r.y1, r.width, r.height), e.clip());
            for (var h2 = 0; h2 < a.dataSeriesIndexes.length; h2++) {
              var m2 = a.dataSeriesIndexes[h2], k = this.data[m2], l = k.dataPoints, g = k.id;
              this._eventManager.objectMap[g] = { objectType: "dataSeries", dataSeriesIndex: m2 };
              g = Z(g);
              e.fillStyle = g;
              var g = [], p = 0, q, f, n2, J = [], x = [];
              if (0 < l.length) {
                var s = k._colorSet[p % k._colorSet.length], y = k.lineColor = k.options.lineColor || s, v = y;
                b.fillStyle = s;
                b.lineWidth = k.lineThickness;
                var z3 = "solid", A;
                if (b.setLineDash) {
                  var C = H(k.nullDataLineDashType, k.lineThickness), z3 = k.lineDashType;
                  A = H(z3, k.lineThickness);
                }
                for (f = false; p < l.length; p++)
                  if (q = l[p].x.getTime ? l[p].x.getTime() : l[p].x, !(q < a.axisX.dataInfo.viewPortMin || q > a.axisX.dataInfo.viewPortMax && (!k.connectNullData || !f)))
                    if (null !== l[p].y && l[p].y.length && "number" === typeof l[p].y[0] && "number" === typeof l[p].y[1]) {
                      q = a.axisX.convertValueToPixel(q);
                      f = a.axisY.convertValueToPixel(l[p].y[0]);
                      n2 = a.axisY.convertValueToPixel(l[p].y[1]);
                      var D2 = k.dataPointIds[p];
                      this._eventManager.objectMap[D2] = { id: D2, objectType: "dataPoint", dataSeriesIndex: m2, dataPointIndex: p, x1: q, y1: f, y2: n2 };
                      J[J.length] = { x: q, y: f };
                      x[x.length] = { x: q, y: n2 };
                      p < l.length - 1 && (v !== (l[p].lineColor || y) || z3 !== (l[p].lineDashType || k.lineDashType)) && (v = l[p].lineColor || y, J[J.length - 1].newStrokeStyle = v, b.setLineDash && (l[p].lineDashType ? (z3 = l[p].lineDashType, J[J.length - 1].newLineDashArray = H(z3, k.lineThickness)) : (z3 = k.lineDashType, J[J.length - 1].newLineDashArray = A)));
                      if (0 !== l[p].markerSize && (0 < l[p].markerSize || 0 < k.markerSize)) {
                        var E3 = k.getMarkerProperties(p, q, f, b);
                        g.push(E3);
                        var K = Z(D2);
                        t && g.push({ x: q, y: f, ctx: e, type: E3.type, size: E3.size, color: K, borderColor: K, borderThickness: E3.borderThickness });
                        E3 = k.getMarkerProperties(p, q, n2, b);
                        g.push(E3);
                        K = Z(D2);
                        t && g.push({ x: q, y: n2, ctx: e, type: E3.type, size: E3.size, color: K, borderColor: K, borderThickness: E3.borderThickness });
                      }
                      if (l[p].indexLabel || k.indexLabel || l[p].indexLabelFormatter || k.indexLabelFormatter)
                        this._indexLabels.push({ chartType: "rangeSplineArea", dataPoint: l[p], dataSeries: k, indexKeyword: 0, point: { x: q, y: f }, direction: l[p].y[0] <= l[p].y[1] ? -1 : 1, color: s }), this._indexLabels.push({ chartType: "rangeSplineArea", dataPoint: l[p], dataSeries: k, indexKeyword: 1, point: { x: q, y: n2 }, direction: l[p].y[0] <= l[p].y[1] ? 1 : -1, color: s });
                      f = false;
                    } else
                      0 < p && !f && (k.connectNullData ? b.setLineDash && (0 < J.length && (k.options.nullDataLineDashType || !l[p - 1].lineDashType)) && (J[J.length - 1].newLineDashArray = C, z3 = k.nullDataLineDashType) : (d(A, y), J = [], x = [])), f = true;
                d(A, y);
                X.drawMarkers(g);
              }
            }
            t && (c.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && b.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && b.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), b.clearRect(r.x1, r.y1, r.width, r.height), this._eventManager.ghostCtx.restore());
            b.restore();
            return { source: c, dest: this.plotArea.ctx, animationCallback: N.xClipAnimation, easingFunction: N.easing.linear, animationBase: 0 };
          }
        };
        n.prototype.renderWaterfall = function(a) {
          var d = a.targetCanvasCtx || this.plotArea.ctx, c = t ? this._preRenderCtx : d;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var b = this._eventManager.ghostCtx, e = null, g = this.plotArea, r = 0, h2, m2, k, l, p = a.axisY.convertValueToPixel(a.axisY.logarithmic ? a.axisY.viewportMinimum : 0), r = this.options.dataPointMinWidth ? this.dataPointMinWidth : this.options.dataPointWidth ? this.dataPointWidth : 1;
            m2 = this.options.dataPointMaxWidth ? this.dataPointMaxWidth : this.options.dataPointWidth ? this.dataPointWidth : Math.min(0.15 * this.width, 0.9 * (this.plotArea.width / a.plotType.totalDataSeries)) << 0;
            var q = a.axisX.dataInfo.minDiff;
            isFinite(q) || (q = 0.3 * Math.abs(a.axisX.range));
            q = this.options.dataPointWidth ? this.dataPointWidth : 0.6 * (g.width * (a.axisX.logarithmic ? Math.log(q) / Math.log(a.axisX.range) : Math.abs(q) / Math.abs(a.axisX.range)) / a.plotType.totalDataSeries) << 0;
            this.dataPointMaxWidth && r > m2 && (r = Math.min(this.options.dataPointWidth ? this.dataPointWidth : Infinity, m2));
            !this.dataPointMaxWidth && (this.dataPointMinWidth && m2 < r) && (m2 = Math.max(this.options.dataPointWidth ? this.dataPointWidth : -Infinity, r));
            q < r && (q = r);
            q > m2 && (q = m2);
            c.save();
            t && this._eventManager.ghostCtx.save();
            c.beginPath();
            c.rect(g.x1, g.y1, g.width, g.height);
            c.clip();
            t && (this._eventManager.ghostCtx.beginPath(), this._eventManager.ghostCtx.rect(g.x1, g.y1, g.width, g.height), this._eventManager.ghostCtx.clip());
            for (var f = 0; f < a.dataSeriesIndexes.length; f++) {
              var n2 = a.dataSeriesIndexes[f], w3 = this.data[n2], x = w3.dataPoints, e = w3._colorSet[0];
              w3.risingColor = w3.options.risingColor ? w3.options.risingColor : e;
              w3.fallingColor = w3.options.fallingColor ? w3.options.fallingColor : "#e40a0a";
              var s = "number" === typeof w3.options.lineThickness ? Math.round(w3.lineThickness) : 1, y = 1 === Math.round(s) % 2 ? -0.5 : 0;
              if (0 < x.length)
                for (var v = 5 < q && w3.bevelEnabled ? true : false, z3 = false, A = null, C = null, r = 0; r < x.length; r++)
                  if (x[r].getTime ? l = x[r].x.getTime() : l = x[r].x, "number" !== typeof x[r].y) {
                    if (0 < r && !z3 && w3.connectNullData)
                      var D2 = w3.options.nullDataLineDashType || !x[r - 1].lineDashType ? w3.nullDataLineDashType : x[r - 1].lineDashType;
                    z3 = true;
                  } else {
                    h2 = a.axisX.convertValueToPixel(l);
                    m2 = 0 === w3.dataPointEOs[r].cumulativeSum ? p : a.axisY.convertValueToPixel(w3.dataPointEOs[r].cumulativeSum);
                    k = 0 === w3.dataPointEOs[r].cumulativeSumYStartValue ? p : a.axisY.convertValueToPixel(w3.dataPointEOs[r].cumulativeSumYStartValue);
                    h2 = a.axisX.reversed ? h2 + a.plotType.totalDataSeries * q / 2 - (a.previousDataSeriesCount + f) * q << 0 : h2 - a.plotType.totalDataSeries * q / 2 + (a.previousDataSeriesCount + f) * q << 0;
                    var E3 = a.axisX.reversed ? h2 - q << 0 : h2 + q << 0;
                    m2 > k && (e = m2, m2 = k, k = e);
                    a.axisY.reversed && (e = m2, m2 = k, k = e);
                    e = w3.dataPointIds[r];
                    this._eventManager.objectMap[e] = { id: e, objectType: "dataPoint", dataSeriesIndex: n2, dataPointIndex: r, x1: h2, y1: m2, x2: E3, y2: k };
                    var K = x[r].color ? x[r].color : 0 < x[r].y ? w3.risingColor : w3.fallingColor;
                    ba(c, a.axisX.reversed ? E3 : h2, a.axisY.reversed ? k : m2, a.axisX.reversed ? h2 : E3, a.axisY.reversed ? m2 : k, K, 0, K, v, v, false, false, w3.fillOpacity);
                    e = Z(e);
                    t && ba(this._eventManager.ghostCtx, a.axisX.reversed ? E3 : h2, m2, a.axisX.reversed ? h2 : E3, k, e, 0, null, false, false, false, false);
                    var T, K = h2;
                    T = "undefined" !== typeof x[r].isIntermediateSum && true === x[r].isIntermediateSum || "undefined" !== typeof x[r].isCumulativeSum && true === x[r].isCumulativeSum ? 0 < x[r].y ? m2 : k : 0 < x[r].y ? k : m2;
                    0 < r && A && (!z3 || w3.connectNullData) && (z3 && c.setLineDash && c.setLineDash(H(D2, s)), c.beginPath(), c.moveTo(A, C - y), c.lineTo(K, T - y), 0 < s && c.stroke(), t && (b.beginPath(), b.moveTo(A, C - y), b.lineTo(K, T - y), 0 < s && b.stroke()));
                    z3 = false;
                    A = E3;
                    C = 0 < x[r].y ? m2 : k;
                    K = x[r].lineDashType ? x[r].lineDashType : w3.options.lineDashType ? w3.options.lineDashType : "shortDash";
                    c.strokeStyle = x[r].lineColor ? x[r].lineColor : w3.options.lineColor ? w3.options.lineColor : "#9e9e9e";
                    c.lineWidth = s;
                    c.setLineDash && (K = H(K, s), c.setLineDash(K));
                    (x[r].indexLabel || w3.indexLabel || x[r].indexLabelFormatter || w3.indexLabelFormatter) && this._indexLabels.push({ chartType: "waterfall", dataPoint: x[r], dataSeries: w3, point: { x: h2 + (E3 - h2) / 2, y: 0 <= x[r].y ? m2 : k }, direction: 0 > x[r].y === a.axisY.reversed ? 1 : -1, bounds: { x1: h2, y1: Math.min(m2, k), x2: E3, y2: Math.max(m2, k) }, color: e });
                  }
            }
            t && (d.drawImage(
              this._preRenderCanvas,
              0,
              0,
              this.width,
              this.height
            ), c.globalCompositeOperation = "source-atop", a.axisX.maskCanvas && c.drawImage(a.axisX.maskCanvas, 0, 0, this.width, this.height), a.axisY.maskCanvas && c.drawImage(a.axisY.maskCanvas, 0, 0, this.width, this.height), this._breaksCanvasCtx && this._breaksCanvasCtx.drawImage(this._preRenderCanvas, 0, 0, this.width, this.height), c.clearRect(g.x1, g.y1, g.width, g.height), this._eventManager.ghostCtx.restore());
            c.restore();
            return {
              source: d,
              dest: this.plotArea.ctx,
              animationCallback: N.fadeInAnimation,
              easingFunction: N.easing.easeInQuad,
              animationBase: 0
            };
          }
        };
        var ra2 = function(a, d, c, b, e, g, r, h2, m2) {
          if (!(0 > c)) {
            "undefined" === typeof h2 && (h2 = 1);
            if (!t) {
              var k = Number((r % (2 * Math.PI)).toFixed(8));
              Number((g % (2 * Math.PI)).toFixed(8)) === k && (r -= 1e-4);
            }
            a.save();
            a.globalAlpha = h2;
            "pie" === e ? (a.beginPath(), a.moveTo(d.x, d.y), a.arc(d.x, d.y, c, g, r, false), a.fillStyle = b, a.strokeStyle = "white", a.lineWidth = 2, a.closePath(), a.fill()) : "doughnut" === e && (a.beginPath(), a.arc(d.x, d.y, c, g, r, false), 0 <= m2 && a.arc(d.x, d.y, m2 * c, r, g, true), a.closePath(), a.fillStyle = b, a.strokeStyle = "white", a.lineWidth = 2, a.fill());
            a.globalAlpha = 1;
            a.restore();
          }
        };
        n.prototype.renderPie = function(a) {
          function d() {
            if (k && l) {
              var a2 = 0, b2 = 0, c2 = 0, d2 = 0;
              m(k.options.indexLabelMaxWidth) && (k.indexLabelMaxWidth = 0.33 * q.width);
              for (var e2 = 0; e2 < l.length; e2++) {
                var g2 = l[e2], r2 = k.dataPointIds[e2];
                f[e2].id = r2;
                f[e2].objectType = "dataPoint";
                f[e2].dataPointIndex = e2;
                f[e2].dataSeriesIndex = 0;
                var h3 = f[e2], p2 = { percent: null, total: null }, u = null, p2 = n2.getPercentAndTotal(k, g2);
                if (k.indexLabelFormatter || g2.indexLabelFormatter)
                  u = {
                    chart: n2.options,
                    dataSeries: k,
                    dataPoint: g2,
                    total: p2.total,
                    percent: p2.percent
                  };
                p2 = g2.indexLabelFormatter ? g2.indexLabelFormatter(u) : g2.indexLabel ? n2.replaceKeywordsWithValue(g2.indexLabel, g2, k, e2) : k.indexLabelFormatter ? k.indexLabelFormatter(u) : k.indexLabel ? n2.replaceKeywordsWithValue(k.indexLabel, g2, k, e2) : g2.label ? g2.label : "";
                n2._eventManager.objectMap[r2] = h3;
                h3.center = { x: v.x, y: v.y };
                h3.y = g2.y;
                h3.radius = C;
                h3.percentInnerRadius = E3;
                h3.indexLabelText = p2;
                h3.indexLabelPlacement = k.indexLabelPlacement;
                h3.indexLabelLineColor = g2.indexLabelLineColor ? g2.indexLabelLineColor : k.options.indexLabelLineColor ? k.options.indexLabelLineColor : g2.color ? g2.color : k._colorSet[e2 % k._colorSet.length];
                h3.indexLabelLineThickness = m(g2.indexLabelLineThickness) ? k.indexLabelLineThickness : g2.indexLabelLineThickness;
                h3.indexLabelLineDashType = g2.indexLabelLineDashType ? g2.indexLabelLineDashType : k.indexLabelLineDashType;
                h3.indexLabelFontColor = g2.indexLabelFontColor ? g2.indexLabelFontColor : k.indexLabelFontColor;
                h3.indexLabelFontStyle = g2.indexLabelFontStyle ? g2.indexLabelFontStyle : k.indexLabelFontStyle;
                h3.indexLabelFontWeight = g2.indexLabelFontWeight ? g2.indexLabelFontWeight : k.indexLabelFontWeight;
                h3.indexLabelFontSize = m(g2.indexLabelFontSize) ? k.indexLabelFontSize : g2.indexLabelFontSize;
                h3.indexLabelFontFamily = g2.indexLabelFontFamily ? g2.indexLabelFontFamily : k.indexLabelFontFamily;
                h3.indexLabelBackgroundColor = g2.indexLabelBackgroundColor ? g2.indexLabelBackgroundColor : k.options.indexLabelBackgroundColor ? k.options.indexLabelBackgroundColor : k.indexLabelBackgroundColor;
                h3.indexLabelMaxWidth = g2.indexLabelMaxWidth ? g2.indexLabelMaxWidth : k.indexLabelMaxWidth;
                h3.indexLabelWrap = "undefined" !== typeof g2.indexLabelWrap ? g2.indexLabelWrap : k.indexLabelWrap;
                h3.indexLabelTextAlign = g2.indexLabelTextAlign ? g2.indexLabelTextAlign : k.indexLabelTextAlign ? k.indexLabelTextAlign : "left";
                h3.startAngle = 0 === e2 ? k.startAngle ? k.startAngle / 180 * Math.PI : 0 : f[e2 - 1].endAngle;
                h3.startAngle = (h3.startAngle + 2 * Math.PI) % (2 * Math.PI);
                h3.endAngle = h3.startAngle + 2 * Math.PI / z3 * Math.abs(g2.y);
                g2 = (h3.endAngle + h3.startAngle) / 2;
                g2 = (g2 + 2 * Math.PI) % (2 * Math.PI);
                h3.midAngle = g2;
                if (h3.midAngle > Math.PI / 2 - s && h3.midAngle < Math.PI / 2 + s) {
                  if (0 === a2 || f[c2].midAngle > h3.midAngle)
                    c2 = e2;
                  a2++;
                } else if (h3.midAngle > 3 * Math.PI / 2 - s && h3.midAngle < 3 * Math.PI / 2 + s) {
                  if (0 === b2 || f[d2].midAngle > h3.midAngle)
                    d2 = e2;
                  b2++;
                }
                h3.hemisphere = g2 > Math.PI / 2 && g2 <= 3 * Math.PI / 2 ? "left" : "right";
                h3.indexLabelTextBlock = new la(n2.plotArea.ctx, { fontSize: h3.indexLabelFontSize, fontFamily: h3.indexLabelFontFamily, fontColor: h3.indexLabelFontColor, fontStyle: h3.indexLabelFontStyle, fontWeight: h3.indexLabelFontWeight, textAlign: h3.indexLabelTextAlign, backgroundColor: h3.indexLabelBackgroundColor, maxWidth: h3.indexLabelMaxWidth, maxHeight: h3.indexLabelWrap ? 5 * h3.indexLabelFontSize : 1.5 * h3.indexLabelFontSize, text: h3.indexLabelText, padding: 0, textBaseline: "middle" });
                h3.indexLabelTextBlock.measureText();
              }
              r2 = g2 = 0;
              p2 = false;
              for (e2 = 0; e2 < l.length; e2++)
                h3 = f[(c2 + e2) % l.length], 1 < a2 && (h3.midAngle > Math.PI / 2 - s && h3.midAngle < Math.PI / 2 + s) && (g2 <= a2 / 2 && !p2 ? (h3.hemisphere = "right", g2++) : (h3.hemisphere = "left", p2 = true));
              p2 = false;
              for (e2 = 0; e2 < l.length; e2++)
                h3 = f[(d2 + e2) % l.length], 1 < b2 && (h3.midAngle > 3 * Math.PI / 2 - s && h3.midAngle < 3 * Math.PI / 2 + s) && (r2 <= b2 / 2 && !p2 ? (h3.hemisphere = "left", r2++) : (h3.hemisphere = "right", p2 = true));
            }
          }
          function c(a2, b2) {
            var c2 = n2.plotArea.ctx;
            c2.clearRect(q.x1, q.y1, q.width, q.height);
            c2.fillStyle = n2.backgroundColor;
            c2.fillRect(q.x1, q.y1, q.width, q.height);
            for (c2 = 0; c2 < l.length; c2++) {
              var d2 = f[c2].startAngle, e2 = f[c2].endAngle;
              if (e2 > d2) {
                var g2 = 0.07 * C * Math.cos(f[c2].midAngle), r2 = 0.07 * C * Math.sin(f[c2].midAngle), h3 = false;
                if (l[c2].exploded) {
                  if (1e-9 < Math.abs(f[c2].center.x - (v.x + g2)) || 1e-9 < Math.abs(f[c2].center.y - (v.y + r2)))
                    f[c2].center.x = v.x + g2 * a2, f[c2].center.y = v.y + r2 * a2, h3 = true;
                } else if (0 < Math.abs(f[c2].center.x - v.x) || 0 < Math.abs(f[c2].center.y - v.y))
                  f[c2].center.x = v.x + g2 * (1 - a2), f[c2].center.y = v.y + r2 * (1 - a2), h3 = true;
                h3 && b2 && (g2 = {}, g2.dataSeries = k, g2.dataPoint = k.dataPoints[c2], g2.index = c2, n2.toolTip.highlightObjects([g2]));
                ra2(n2.plotArea.ctx, f[c2].center, f[c2].radius, l[c2].color ? l[c2].color : k._colorSet[c2 % k._colorSet.length], k.type, d2, e2, k.fillOpacity, f[c2].percentInnerRadius);
              }
            }
            c2 = n2.plotArea.ctx;
            c2.save();
            c2.fillStyle = "black";
            c2.strokeStyle = "grey";
            c2.textBaseline = "middle";
            c2.lineJoin = "round";
            for (d2 = d2 = 0; d2 < l.length; d2++)
              e2 = f[d2], e2.indexLabelText && (e2.indexLabelTextBlock.y -= e2.indexLabelTextBlock.height / 2 - e2.indexLabelTextBlock.fontSize / 2, g2 = 0, g2 = "left" === e2.hemisphere ? "inside" !== k.indexLabelPlacement ? -(e2.indexLabelTextBlock.width + p) : -e2.indexLabelTextBlock.width / 2 : "inside" !== k.indexLabelPlacement ? p : -e2.indexLabelTextBlock.width / 2, e2.indexLabelTextBlock.x += g2, e2.indexLabelTextBlock.render(true), e2.indexLabelTextBlock.x -= g2, e2.indexLabelTextBlock.y += e2.indexLabelTextBlock.height / 2 - e2.indexLabelTextBlock.fontSize / 2, "inside" !== e2.indexLabelPlacement && 0 < e2.indexLabelLineThickness && (g2 = e2.center.x + C * Math.cos(e2.midAngle), r2 = e2.center.y + C * Math.sin(e2.midAngle), c2.strokeStyle = e2.indexLabelLineColor, c2.lineWidth = e2.indexLabelLineThickness, c2.setLineDash && c2.setLineDash(H(e2.indexLabelLineDashType, e2.indexLabelLineThickness)), c2.beginPath(), c2.moveTo(g2, r2), c2.lineTo(e2.indexLabelTextBlock.x, e2.indexLabelTextBlock.y), c2.lineTo(e2.indexLabelTextBlock.x + ("left" === e2.hemisphere ? -p : p), e2.indexLabelTextBlock.y), c2.stroke()), c2.lineJoin = "miter");
            c2.save();
          }
          function b(a2, b2) {
            var c2 = 0, c2 = a2.indexLabelTextBlock.y - a2.indexLabelTextBlock.height / 2, e2 = a2.indexLabelTextBlock.y + a2.indexLabelTextBlock.height / 2, d2 = b2.indexLabelTextBlock.y - b2.indexLabelTextBlock.height / 2, f2 = b2.indexLabelTextBlock.y + b2.indexLabelTextBlock.height / 2;
            return c2 = b2.indexLabelTextBlock.y > a2.indexLabelTextBlock.y ? d2 - e2 : c2 - f2;
          }
          function e(a2) {
            for (var c2 = null, e2 = 1; e2 < l.length; e2++)
              if (c2 = (a2 + e2 + f.length) % f.length, f[c2].hemisphere !== f[a2].hemisphere) {
                c2 = null;
                break;
              } else if (f[c2].indexLabelText && c2 !== a2 && (0 > b(f[c2], f[a2]) || ("right" === f[a2].hemisphere ? f[c2].indexLabelTextBlock.y >= f[a2].indexLabelTextBlock.y : f[c2].indexLabelTextBlock.y <= f[a2].indexLabelTextBlock.y)))
                break;
              else
                c2 = null;
            return c2;
          }
          function g(a2, c2, d2) {
            d2 = (d2 || 0) + 1;
            if (1e3 < d2)
              return 0;
            c2 = c2 || 0;
            var r2 = 0, k2 = v.y - 1 * w3, h3 = v.y + 1 * w3;
            if (0 <= a2 && a2 < l.length) {
              var p2 = f[a2];
              if (0 > c2 && p2.indexLabelTextBlock.y < k2 || 0 < c2 && p2.indexLabelTextBlock.y > h3)
                return 0;
              var m2 = 0, q2 = 0, q2 = m2 = m2 = 0;
              0 > c2 ? p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 > k2 && p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 + c2 < k2 && (c2 = -(k2 - (p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 + c2))) : p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 < k2 && p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 + c2 > h3 && (c2 = p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2 + c2 - h3);
              c2 = p2.indexLabelTextBlock.y + c2;
              k2 = 0;
              k2 = "right" === p2.hemisphere ? v.x + Math.sqrt(Math.pow(w3, 2) - Math.pow(c2 - v.y, 2)) : v.x - Math.sqrt(Math.pow(w3, 2) - Math.pow(c2 - v.y, 2));
              q2 = v.x + C * Math.cos(p2.midAngle);
              m2 = v.y + C * Math.sin(p2.midAngle);
              m2 = Math.sqrt(Math.pow(k2 - q2, 2) + Math.pow(c2 - m2, 2));
              q2 = Math.acos(C / w3);
              m2 = Math.acos((w3 * w3 + C * C - m2 * m2) / (2 * C * w3));
              c2 = m2 < q2 ? c2 - p2.indexLabelTextBlock.y : 0;
              k2 = null;
              for (h3 = 1; h3 < l.length; h3++)
                if (k2 = (a2 - h3 + f.length) % f.length, f[k2].hemisphere !== f[a2].hemisphere) {
                  k2 = null;
                  break;
                } else if (f[k2].indexLabelText && f[k2].hemisphere === f[a2].hemisphere && k2 !== a2 && (0 > b(f[k2], f[a2]) || ("right" === f[a2].hemisphere ? f[k2].indexLabelTextBlock.y <= f[a2].indexLabelTextBlock.y : f[k2].indexLabelTextBlock.y >= f[a2].indexLabelTextBlock.y)))
                  break;
                else
                  k2 = null;
              q2 = k2;
              m2 = e(a2);
              h3 = k2 = 0;
              0 > c2 ? (h3 = "right" === p2.hemisphere ? q2 : m2, r2 = c2, null !== h3 && (q2 = -c2, c2 = p2.indexLabelTextBlock.y - p2.indexLabelTextBlock.height / 2 - (f[h3].indexLabelTextBlock.y + f[h3].indexLabelTextBlock.height / 2), c2 - q2 < t2 && (k2 = -q2, h3 = g(h3, k2, d2 + 1), +h3.toFixed(y) > +k2.toFixed(y) && (r2 = c2 > t2 ? -(c2 - t2) : -(q2 - (h3 - k2)))))) : 0 < c2 && (h3 = "right" === p2.hemisphere ? m2 : q2, r2 = c2, null !== h3 && (q2 = c2, c2 = f[h3].indexLabelTextBlock.y - f[h3].indexLabelTextBlock.height / 2 - (p2.indexLabelTextBlock.y + p2.indexLabelTextBlock.height / 2), c2 - q2 < t2 && (k2 = q2, h3 = g(h3, k2, d2 + 1), +h3.toFixed(y) < +k2.toFixed(y) && (r2 = c2 > t2 ? c2 - t2 : q2 - (k2 - h3)))));
              r2 && (d2 = p2.indexLabelTextBlock.y + r2, c2 = 0, c2 = "right" === p2.hemisphere ? v.x + Math.sqrt(Math.pow(w3, 2) - Math.pow(d2 - v.y, 2)) : v.x - Math.sqrt(Math.pow(w3, 2) - Math.pow(d2 - v.y, 2)), p2.midAngle > Math.PI / 2 - s && p2.midAngle < Math.PI / 2 + s ? (k2 = (a2 - 1 + f.length) % f.length, k2 = f[k2], a2 = f[(a2 + 1 + f.length) % f.length], "left" === p2.hemisphere && "right" === k2.hemisphere && c2 > k2.indexLabelTextBlock.x ? c2 = k2.indexLabelTextBlock.x - 15 : "right" === p2.hemisphere && ("left" === a2.hemisphere && c2 < a2.indexLabelTextBlock.x) && (c2 = a2.indexLabelTextBlock.x + 15)) : p2.midAngle > 3 * Math.PI / 2 - s && p2.midAngle < 3 * Math.PI / 2 + s && (k2 = (a2 - 1 + f.length) % f.length, k2 = f[k2], a2 = f[(a2 + 1 + f.length) % f.length], "right" === p2.hemisphere && "left" === k2.hemisphere && c2 < k2.indexLabelTextBlock.x ? c2 = k2.indexLabelTextBlock.x + 15 : "left" === p2.hemisphere && ("right" === a2.hemisphere && c2 > a2.indexLabelTextBlock.x) && (c2 = a2.indexLabelTextBlock.x - 15)), p2.indexLabelTextBlock.y = d2, p2.indexLabelTextBlock.x = c2, p2.indexLabelAngle = Math.atan2(p2.indexLabelTextBlock.y - v.y, p2.indexLabelTextBlock.x - v.x));
            }
            return r2;
          }
          function r() {
            var a2 = n2.plotArea.ctx;
            a2.fillStyle = "grey";
            a2.strokeStyle = "grey";
            a2.font = "16px Arial";
            a2.textBaseline = "middle";
            for (var c2 = a2 = 0, d2 = 0, r2 = true, c2 = 0; 10 > c2 && (1 > c2 || 0 < d2); c2++) {
              if (k.radius || !k.radius && "undefined" !== typeof k.innerRadius && null !== k.innerRadius && C - d2 <= D2)
                r2 = false;
              r2 && (C -= d2);
              d2 = 0;
              if ("inside" !== k.indexLabelPlacement) {
                w3 = C * x;
                for (a2 = 0; a2 < l.length; a2++) {
                  var h3 = f[a2];
                  h3.indexLabelTextBlock.x = v.x + w3 * Math.cos(h3.midAngle);
                  h3.indexLabelTextBlock.y = v.y + w3 * Math.sin(h3.midAngle);
                  h3.indexLabelAngle = h3.midAngle;
                  h3.radius = C;
                  h3.percentInnerRadius = E3;
                }
                for (var m2, u, a2 = 0; a2 < l.length; a2++) {
                  var h3 = f[a2], s2 = e(a2);
                  if (null !== s2) {
                    m2 = f[a2];
                    u = f[s2];
                    var A2 = 0, A2 = b(m2, u) - t2;
                    if (0 > A2) {
                      for (var z4 = u = 0, I = 0; I < l.length; I++)
                        I !== a2 && f[I].hemisphere === h3.hemisphere && (f[I].indexLabelTextBlock.y < h3.indexLabelTextBlock.y ? u++ : z4++);
                      u = A2 / (u + z4 || 1) * z4;
                      var z4 = -1 * (A2 - u), H2 = I = 0;
                      "right" === h3.hemisphere ? (I = g(a2, u), z4 = -1 * (A2 - I), H2 = g(s2, z4), +H2.toFixed(y) < +z4.toFixed(y) && +I.toFixed(y) <= +u.toFixed(y) && g(a2, -(z4 - H2))) : (I = g(s2, u), z4 = -1 * (A2 - I), H2 = g(a2, z4), +H2.toFixed(y) < +z4.toFixed(y) && +I.toFixed(y) <= +u.toFixed(y) && g(s2, -(z4 - H2)));
                    }
                  }
                }
              } else
                for (a2 = 0; a2 < l.length; a2++)
                  h3 = f[a2], w3 = "pie" === k.type ? 0.7 * C : 0.85 * C, s2 = v.x + w3 * Math.cos(h3.midAngle), u = v.y + w3 * Math.sin(h3.midAngle), h3.indexLabelTextBlock.x = s2, h3.indexLabelTextBlock.y = u;
              for (a2 = 0; a2 < l.length; a2++)
                if (h3 = f[a2], s2 = h3.indexLabelTextBlock.measureText(), 0 !== s2.height && 0 !== s2.width)
                  s2 = s2 = 0, "right" === h3.hemisphere ? (s2 = q.x2 - (h3.indexLabelTextBlock.x + h3.indexLabelTextBlock.width + p), s2 *= -1) : s2 = q.x1 - (h3.indexLabelTextBlock.x - h3.indexLabelTextBlock.width - p), 0 < s2 && (!r2 && h3.indexLabelText && (u = "right" === h3.hemisphere ? q.x2 - h3.indexLabelTextBlock.x : h3.indexLabelTextBlock.x - q.x1, 0.3 * h3.indexLabelTextBlock.maxWidth > u ? h3.indexLabelText = "" : h3.indexLabelTextBlock.maxWidth = 0.85 * u, 0.3 * h3.indexLabelTextBlock.maxWidth < u && (h3.indexLabelTextBlock.x -= "right" === h3.hemisphere ? 2 : -2)), Math.abs(h3.indexLabelTextBlock.y - h3.indexLabelTextBlock.height / 2 - v.y) < C || Math.abs(h3.indexLabelTextBlock.y + h3.indexLabelTextBlock.height / 2 - v.y) < C) && (s2 /= Math.abs(Math.cos(h3.indexLabelAngle)), 9 < s2 && (s2 *= 0.3), s2 > d2 && (d2 = s2)), s2 = s2 = 0, 0 < h3.indexLabelAngle && h3.indexLabelAngle < Math.PI ? (s2 = q.y2 - (h3.indexLabelTextBlock.y + h3.indexLabelTextBlock.height / 2 + 5), s2 *= -1) : s2 = q.y1 - (h3.indexLabelTextBlock.y - h3.indexLabelTextBlock.height / 2 - 5), 0 < s2 && (!r2 && h3.indexLabelText && (u = 0 < h3.indexLabelAngle && h3.indexLabelAngle < Math.PI ? -1 : 1, 0 === g(a2, s2 * u) && g(a2, 2 * u)), Math.abs(h3.indexLabelTextBlock.x - v.x) < C && (s2 /= Math.abs(Math.sin(h3.indexLabelAngle)), 9 < s2 && (s2 *= 0.3), s2 > d2 && (d2 = s2)));
              var M = function(a3, b2, c3) {
                for (var e2 = [], d3 = 0; e2.push(f[b2]), b2 !== c3; b2 = (b2 + 1 + l.length) % l.length)
                  ;
                e2.sort(function(a4, b3) {
                  return a4.y - b3.y;
                });
                for (b2 = 0; b2 < e2.length; b2++)
                  if (c3 = e2[b2], d3 < 0.7 * a3)
                    d3 += c3.indexLabelTextBlock.height, c3.indexLabelTextBlock.text = "", c3.indexLabelText = "", c3.indexLabelTextBlock.measureText();
                  else
                    break;
              };
              (function() {
                for (var a3 = -1, c3 = -1, d3 = 0, g2 = false, r3 = 0; r3 < l.length; r3++)
                  if (g2 = false, m2 = f[r3], m2.indexLabelText) {
                    var k2 = e(r3);
                    if (null !== k2) {
                      var h4 = f[k2];
                      A2 = 0;
                      A2 = b(m2, h4);
                      var q2;
                      if (q2 = 0 > A2) {
                        q2 = m2.indexLabelTextBlock.x;
                        var u2 = m2.indexLabelTextBlock.y - m2.indexLabelTextBlock.height / 2, n3 = m2.indexLabelTextBlock.y + m2.indexLabelTextBlock.height / 2, s3 = h4.indexLabelTextBlock.y - h4.indexLabelTextBlock.height / 2, v2 = h4.indexLabelTextBlock.x + h4.indexLabelTextBlock.width, B = h4.indexLabelTextBlock.y + h4.indexLabelTextBlock.height / 2;
                        q2 = m2.indexLabelTextBlock.x + m2.indexLabelTextBlock.width < h4.indexLabelTextBlock.x - p || q2 > v2 + p || u2 > B + p || n3 < s3 - p ? false : true;
                      }
                      q2 ? (0 > a3 && (a3 = r3), k2 !== a3 && (c3 = k2, d3 += -A2), 0 === r3 % Math.max(l.length / 10, 3) && (g2 = true)) : g2 = true;
                      g2 && (0 < d3 && 0 <= a3 && 0 <= c3) && (M(d3, a3, c3), c3 = a3 = -1, d3 = 0);
                    }
                  }
                0 < d3 && M(d3, a3, c3);
              })();
            }
          }
          function h2() {
            n2.plotArea.layoutManager.reset();
            n2.title && (n2.title.dockInsidePlotArea || "center" === n2.title.horizontalAlign && "center" === n2.title.verticalAlign) && n2.title.render();
            if (n2.subtitles)
              for (var a2 = 0; a2 < n2.subtitles.length; a2++) {
                var b2 = n2.subtitles[a2];
                (b2.dockInsidePlotArea || "center" === b2.horizontalAlign && "center" === b2.verticalAlign) && b2.render();
              }
            n2.legend && (n2.legend.dockInsidePlotArea || "center" === n2.legend.horizontalAlign && "center" === n2.legend.verticalAlign) && (n2.legend.setLayout(), n2.legend.render());
          }
          var n2 = this;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            var k = this.data[a.dataSeriesIndexes[0]], l = k.dataPoints, p = 10, q = this.plotArea, f = k.dataPointEOs, t2 = 2, w3, x = 1.3, s = 20 / 180 * Math.PI, y = 6, v = { x: (q.x2 + q.x1) / 2, y: (q.y2 + q.y1) / 2 }, z3 = 0;
            a = false;
            for (var A = 0; A < l.length; A++)
              z3 += Math.abs(l[A].y), !a && ("undefined" !== typeof l[A].indexLabel && null !== l[A].indexLabel && 0 < l[A].indexLabel.toString().length) && (a = true), !a && ("undefined" !== typeof l[A].label && null !== l[A].label && 0 < l[A].label.toString().length) && (a = true);
            if (0 !== z3) {
              a = a || "undefined" !== typeof k.indexLabel && null !== k.indexLabel && 0 < k.indexLabel.toString().length;
              var C = "inside" !== k.indexLabelPlacement && a ? 0.75 * Math.min(q.width, q.height) / 2 : 0.92 * Math.min(q.width, q.height) / 2;
              k.radius && (C = Ta(k.radius, C));
              var D2 = "undefined" !== typeof k.innerRadius && null !== k.innerRadius ? Ta(k.innerRadius, C) : 0.7 * C;
              k.radius = C;
              "doughnut" === k.type && (k.innerRadius = D2);
              var E3 = Math.min(D2 / C, (C - 1) / C);
              this.pieDoughnutClickHandler = function(a2) {
                n2.isAnimating || !m(a2.dataSeries.explodeOnClick) && !a2.dataSeries.explodeOnClick || (a2 = a2.dataPoint, a2.exploded = a2.exploded ? false : true, 1 < this.dataPoints.length && n2._animator.animate(0, 500, function(a3) {
                  c(a3, true);
                  h2();
                  n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                  n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
                }));
              };
              d();
              r();
              r();
              r();
              r();
              this.disableToolTip = true;
              this._animator.animate(0, this.animatedRender ? this.animationDuration : 0, function(a2) {
                var b2 = n2.plotArea.ctx;
                b2.clearRect(q.x1, q.y1, q.width, q.height);
                b2.fillStyle = n2.backgroundColor;
                b2.fillRect(q.x1, q.y1, q.width, q.height);
                for (var b2 = f[0].startAngle + 2 * Math.PI * a2, c2 = 0; c2 < l.length; c2++) {
                  var e2 = 0 === c2 ? f[c2].startAngle : d2, d2 = e2 + (f[c2].endAngle - f[c2].startAngle), g2 = false;
                  d2 > b2 && (d2 = b2, g2 = true);
                  var r2 = l[c2].color ? l[c2].color : k._colorSet[c2 % k._colorSet.length];
                  d2 > e2 && ra2(n2.plotArea.ctx, f[c2].center, f[c2].radius, r2, k.type, e2, d2, k.fillOpacity, f[c2].percentInnerRadius);
                  if (g2)
                    break;
                }
                h2();
                n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                1 <= a2 && n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
              }, function() {
                n2.disableToolTip = false;
                n2._animator.animate(
                  0,
                  n2.animatedRender ? 500 : 0,
                  function(a2) {
                    c(a2, false);
                    h2();
                    n2.dispatchEvent("dataAnimationIterationEnd", { chart: n2 });
                  }
                );
                n2.dispatchEvent("dataAnimationEnd", { chart: n2 });
              });
            }
          }
        };
        var ta2 = function(a, d, c, b) {
          "undefined" === typeof c && (c = 1);
          0 >= Math.round(d.y4 - d.y1) || (a.save(), a.globalAlpha = c, a.beginPath(), a.moveTo(Math.round(d.x1), Math.round(d.y1)), a.lineTo(Math.round(d.x2), Math.round(d.y2)), a.lineTo(Math.round(d.x3), Math.round(d.y3)), a.lineTo(Math.round(d.x4), Math.round(d.y4)), "undefined" !== d.x5 && (a.lineTo(Math.round(d.x5), Math.round(d.y5)), a.lineTo(Math.round(d.x6), Math.round(d.y6))), a.closePath(), a.fillStyle = b ? b : d.color, a.fill(), a.globalAplha = 1, a.restore());
        };
        n.prototype.renderFunnel = function(a) {
          function d() {
            for (var a2 = 0, b2 = [], c2 = 0; c2 < y.length; c2++) {
              if ("undefined" === typeof y[c2].y)
                return -1;
              y[c2].y = "number" === typeof y[c2].y ? y[c2].y : 0;
              a2 += Math.abs(y[c2].y);
            }
            if (0 === a2)
              return -1;
            for (c2 = b2[0] = 0; c2 < y.length; c2++)
              b2.push(Math.abs(y[c2].y) * D2 / a2);
            return b2;
          }
          function c() {
            var a2 = U2, b2 = Y2, c2 = M, e2 = $, d2, f2;
            d2 = O2;
            f2 = S2 - Q3;
            e2 = Math.abs((f2 - d2) * (b2 - a2 + (e2 - c2)) / 2);
            c2 = $ - M;
            d2 = f2 - d2;
            f2 = c2 * (f2 - S2);
            f2 = Math.abs(f2);
            f2 = e2 + f2;
            for (var e2 = [], g2 = 0, r2 = 0; r2 < y.length; r2++) {
              if ("undefined" === typeof y[r2].y)
                return -1;
              y[r2].y = "number" === typeof y[r2].y ? y[r2].y : 0;
              g2 += Math.abs(y[r2].y);
            }
            if (0 === g2)
              return -1;
            for (var h3 = e2[0] = 0, k2 = 0, l2, p2, b2 = b2 - a2, h3 = false, r2 = 0; r2 < y.length; r2++)
              a2 = Math.abs(y[r2].y) * f2 / g2, h3 ? l2 = 0 == Number(c2.toFixed(3)) ? 0 : a2 / c2 : (p2 = da3 * da3 * b2 * b2 - 4 * Math.abs(da3) * a2, 0 > p2 ? (p2 = c2, h3 = (b2 + p2) * (d2 - k2) / 2, a2 -= h3, l2 = d2 - k2, k2 += d2 - k2, l2 += 0 == p2 ? 0 : a2 / p2, k2 += a2 / p2, h3 = true) : (l2 = (Math.abs(da3) * b2 - Math.sqrt(p2)) / 2, p2 = b2 - 2 * l2 / Math.abs(da3), k2 += l2, k2 > d2 && (k2 -= l2, p2 = c2, h3 = (b2 + p2) * (d2 - k2) / 2, a2 -= h3, l2 = d2 - k2, k2 += d2 - k2, l2 += a2 / p2, k2 += a2 / p2, h3 = true), b2 = p2)), e2.push(l2);
            return e2;
          }
          function b() {
            if (s && y) {
              for (var a2, b2, c2, d2, e2, g2, r2, k2, h3, l2, p2, q2, u, n3, v2, B = [], w4 = [], z4 = { percent: null, total: null }, J2 = null, A2 = 0; A2 < y.length; A2++)
                v2 = R[A2], v2 = "undefined" !== typeof v2.x5 ? (v2.y2 + v2.y4) / 2 : (v2.y2 + v2.y3) / 2, v2 = f(v2).x2 + 1, B[A2] = L2 - v2 - Z2;
              v2 = 0.5 * Z2;
              for (var A2 = 0, C2 = y.length - 1; A2 < y.length || 0 <= C2; A2++, C2--) {
                b2 = s.reversed ? y[C2] : y[A2];
                a2 = b2.color ? b2.color : s.reversed ? s._colorSet[(y.length - 1 - A2) % s._colorSet.length] : s._colorSet[A2 % s._colorSet.length];
                c2 = b2.indexLabelPlacement || s.indexLabelPlacement || "outside";
                n3 = b2.indexLabelTextAlign || s.indexLabelTextAlign || "left";
                d2 = b2.indexLabelBackgroundColor || s.indexLabelBackgroundColor || (t ? "transparent" : null);
                e2 = b2.indexLabelFontColor || s.indexLabelFontColor || "#979797";
                g2 = m(b2.indexLabelFontSize) ? s.indexLabelFontSize : b2.indexLabelFontSize;
                r2 = b2.indexLabelFontStyle || s.indexLabelFontStyle || "normal";
                k2 = b2.indexLabelFontFamily || s.indexLabelFontFamily || "arial";
                h3 = b2.indexLabelFontWeight || s.indexLabelFontWeight || "normal";
                a2 = b2.indexLabelLineColor || s.options.indexLabelLineColor || a2;
                l2 = "number" === typeof b2.indexLabelLineThickness ? b2.indexLabelLineThickness : "number" === typeof s.indexLabelLineThickness ? s.indexLabelLineThickness : 2;
                p2 = b2.indexLabelLineDashType || s.indexLabelLineDashType || "solid";
                q2 = "undefined" !== typeof b2.indexLabelWrap ? b2.indexLabelWrap : "undefined" !== typeof s.indexLabelWrap ? s.indexLabelWrap : true;
                u = s.dataPointIds[A2];
                x._eventManager.objectMap[u] = { id: u, objectType: "dataPoint", dataPointIndex: A2, dataSeriesIndex: 0, funnelSection: R[s.reversed ? y.length - 1 - A2 : A2] };
                "inside" === s.indexLabelPlacement && (B[A2] = A2 !== ea3 ? s.reversed ? R[A2].x2 - R[A2].x1 : R[A2].x3 - R[A2].x4 : R[A2].x3 - R[A2].x6, 20 > B[A2] && (B[A2] = A2 !== ea3 ? s.reversed ? R[A2].x3 - R[A2].x4 : R[A2].x2 - R[A2].x1 : R[A2].x2 - R[A2].x1, B[A2] /= 2));
                u = b2.indexLabelMaxWidth ? b2.indexLabelMaxWidth : s.options.indexLabelMaxWidth ? s.indexLabelMaxWidth : B[A2];
                if (u > B[A2] || 0 > u)
                  u = B[A2];
                w4[A2] = "inside" === s.indexLabelPlacement ? q2 ? Math.max(R[A2].height, g2) : 1.5 * g2 : false;
                z4 = x.getPercentAndTotal(s, b2);
                if (s.indexLabelFormatter || b2.indexLabelFormatter)
                  J2 = { chart: x.options, dataSeries: s, dataPoint: b2, total: z4.total, percent: z4.percent };
                b2 = b2.indexLabelFormatter ? b2.indexLabelFormatter(J2) : b2.indexLabel ? x.replaceKeywordsWithValue(b2.indexLabel, b2, s, A2) : s.indexLabelFormatter ? s.indexLabelFormatter(J2) : s.indexLabel ? x.replaceKeywordsWithValue(s.indexLabel, b2, s, A2) : b2.label ? b2.label : "";
                0 >= l2 && (l2 = 0);
                1e3 > u && 1e3 - u < v2 && (u += 1e3 - u);
                m(s.options.indexLabelMaxWidth) && (s.indexLabelMaxWidth = m(s.indexLabelMaxWidth) ? u : Math.max(u, s.indexLabelMaxWidth));
                P.roundRect || Aa(P);
                c2 = new la(P, { fontSize: g2, fontFamily: k2, fontColor: e2, fontStyle: r2, fontWeight: h3, horizontalAlign: c2, textAlign: n3, backgroundColor: d2, maxWidth: u, maxHeight: false === w4[A2] ? q2 ? 4.28571429 * g2 : 1.5 * g2 : w4[A2], text: b2, padding: fa3, textBaseline: "middle" });
                c2.measureText();
                c2.height = c2.height === 2 * c2.padding ? 0 : c2.height;
                c2.width = c2.width === 2 * c2.padding ? 0 : c2.width;
                G.push({ textBlock: c2, id: s.reversed ? C2 : A2, isDirty: false, lineColor: a2, lineThickness: l2, lineDashType: p2, height: c2.height < c2.maxHeight ? c2.height : c2.maxHeight, width: c2.width < c2.maxWidth ? c2.width : c2.maxWidth });
              }
            }
          }
          function e() {
            var a2, b2, c2, d2, e2, f2 = [];
            e2 = false;
            c2 = 0;
            for (var g2, r2 = L2 - Y2 - Z2 / 2, r2 = s.options.indexLabelMaxWidth ? s.indexLabelMaxWidth > r2 ? r2 : s.indexLabelMaxWidth : r2, k2 = G.length - 1; 0 <= k2; k2--) {
              g2 = y[G[k2].id];
              c2 = G[k2];
              d2 = c2.textBlock;
              b2 = (a2 = q(k2) < R.length ? G[q(k2)] : null) ? a2.textBlock : null;
              c2 = c2.height;
              a2 && d2.y + c2 + fa3 > b2.y && (e2 = true);
              c2 = g2.indexLabelMaxWidth || r2;
              if (c2 > r2 || 0 > c2)
                c2 = r2;
              f2.push(c2);
            }
            if (e2)
              for (k2 = G.length - 1; 0 <= k2; k2--)
                a2 = R[k2], G[k2].textBlock.maxWidth = f2[f2.length - (k2 + 1)], G[k2].textBlock.measureText(), G[k2].textBlock.height = G[k2].textBlock.height === 2 * G[k2].textBlock.padding ? 0 : G[k2].textBlock.height, G[k2].textBlock.width = G[k2].textBlock.width === 2 * G[k2].textBlock.padding ? 0 : G[k2].textBlock.width, G[k2].textBlock.x = L2 - r2, c2 = G[k2].textBlock.height < G[k2].textBlock.maxHeight ? G[k2].textBlock.height : G[k2].textBlock.maxHeight, e2 = G[k2].textBlock.width < G[k2].textBlock.maxWidth ? G[k2].textBlock.width : G[k2].textBlock.maxWidth, G[k2].height = c2, G[k2].width = e2, c2 = "undefined" !== typeof a2.x5 ? (a2.y2 + a2.y4) / 2 : (a2.y2 + a2.y3) / 2, G[k2].textBlock.y = c2 - G[k2].height / 2, s.reversed ? (G[k2].textBlock.y + G[k2].height > W3 + z3 && (G[k2].textBlock.y = W3 + z3 - G[k2].height), G[k2].textBlock.y < va - z3 && (G[k2].textBlock.y = va - z3)) : (G[k2].textBlock.y < W3 - z3 && (G[k2].textBlock.y = W3 - z3), G[k2].textBlock.y + G[k2].height > va + z3 && (G[k2].textBlock.y = va + z3 - G[k2].height));
          }
          function g() {
            var a2, b2, c2, e2;
            if ("inside" !== s.indexLabelPlacement)
              for (var d2 = 0; d2 < R.length; d2++)
                0 == G[d2].textBlock.text.length ? G[d2].isDirty = true : (a2 = R[d2], c2 = "undefined" !== typeof a2.x5 ? (a2.y2 + a2.y4) / 2 : (a2.y2 + a2.y3) / 2, b2 = s.reversed ? "undefined" !== typeof a2.x5 ? c2 > X2 ? f(c2).x2 + 1 : (a2.x2 + a2.x3) / 2 + 1 : (a2.x2 + a2.x3) / 2 + 1 : "undefined" !== typeof a2.x5 ? c2 < X2 ? f(c2).x2 + 1 : (a2.x4 + a2.x3) / 2 + 1 : (a2.x2 + a2.x3) / 2 + 1, G[d2].textBlock.x = b2 + Z2, G[d2].textBlock.y = c2 - G[d2].height / 2, s.reversed ? (G[d2].textBlock.y + G[d2].height > W3 + z3 && (G[d2].textBlock.y = W3 + z3 - G[d2].height), G[d2].textBlock.y < va - z3 && (G[d2].textBlock.y = va - z3)) : (G[d2].textBlock.y < W3 - z3 && (G[d2].textBlock.y = W3 - z3), G[d2].textBlock.y + G[d2].height > va + z3 && (G[d2].textBlock.y = va + z3 - G[d2].height)));
            else
              for (d2 = 0; d2 < R.length; d2++)
                0 == G[d2].textBlock.text.length ? G[d2].isDirty = true : (a2 = R[d2], b2 = a2.height, c2 = G[d2].height, e2 = G[d2].width, b2 >= c2 ? (b2 = d2 != ea3 ? (a2.x4 + a2.x3) / 2 - e2 / 2 : (a2.x5 + a2.x4) / 2 - e2 / 2, c2 = d2 != ea3 ? (a2.y1 + a2.y3) / 2 - c2 / 2 : (a2.y1 + a2.y4) / 2 - c2 / 2, G[d2].textBlock.x = b2, G[d2].textBlock.y = c2) : G[d2].isDirty = true);
          }
          function r() {
            function a2(b3, c3) {
              var d3;
              if (0 > b3 || b3 >= G.length)
                return 0;
              var e3, f3 = G[b3].textBlock;
              if (0 > c3) {
                c3 *= -1;
                e3 = p(b3);
                d3 = h2(e3, b3);
                if (d3 >= c3)
                  return f3.y -= c3, c3;
                if (0 == b3)
                  return 0 < d3 && (f3.y -= d3), d3;
                d3 += a2(e3, -(c3 - d3));
                0 < d3 && (f3.y -= d3);
                return d3;
              }
              e3 = q(b3);
              d3 = h2(b3, e3);
              if (d3 >= c3)
                return f3.y += c3, c3;
              if (b3 == R.length - 1)
                return 0 < d3 && (f3.y += d3), d3;
              d3 += a2(e3, c3 - d3);
              0 < d3 && (f3.y += d3);
              return d3;
            }
            function b2() {
              var a3, d3, e3, f3, g3 = 0, k3;
              f3 = (S2 - O2 + 2 * z3) / l2;
              k3 = l2;
              for (var r3, h3 = 1; h3 < k3; h3++) {
                e3 = h3 * f3;
                for (var m3 = G.length - 1; 0 <= m3; m3--)
                  !G[m3].isDirty && (G[m3].textBlock.y < e3 && G[m3].textBlock.y + G[m3].height > e3) && (r3 = q(m3), !(r3 >= G.length - 1) && G[m3].textBlock.y + G[m3].height + fa3 > G[r3].textBlock.y && (G[m3].textBlock.y = G[m3].textBlock.y + G[m3].height - e3 > e3 - G[m3].textBlock.y ? e3 + 1 : e3 - G[m3].height - 1));
              }
              for (r3 = R.length - 1; 0 < r3; r3--)
                if (!G[r3].isDirty) {
                  e3 = p(r3);
                  if (0 > e3 && (e3 = 0, G[e3].isDirty))
                    break;
                  if (G[r3].textBlock.y < G[e3].textBlock.y + G[e3].height) {
                    d3 = d3 || r3;
                    f3 = r3;
                    for (k3 = 0; G[f3].textBlock.y < G[e3].textBlock.y + G[e3].height + fa3; ) {
                      a3 = a3 || G[f3].textBlock.y + G[f3].height;
                      k3 += G[f3].height;
                      k3 += fa3;
                      f3 = e3;
                      if (0 >= f3) {
                        f3 = 0;
                        k3 += G[f3].height;
                        break;
                      }
                      e3 = p(f3);
                      if (0 > e3) {
                        f3 = 0;
                        k3 += G[f3].height;
                        break;
                      }
                    }
                    if (f3 != r3) {
                      g3 = G[f3].textBlock.y;
                      a3 -= g3;
                      a3 = k3 - a3;
                      g3 = c2(a3, d3, f3);
                      break;
                    }
                  }
                }
              return g3;
            }
            function c2(a3, b3, d3) {
              var e3 = [], f3 = 0, g3 = 0;
              for (a3 = Math.abs(a3); d3 <= b3; d3++)
                e3.push(R[d3]);
              e3.sort(function(a4, b4) {
                return a4.height - b4.height;
              });
              for (d3 = 0; d3 < e3.length; d3++)
                if (b3 = e3[d3], f3 < a3)
                  g3++, f3 += G[b3.id].height + fa3, G[b3.id].textBlock.text = "", G[b3.id].indexLabelText = "", G[b3.id].isDirty = true, G[b3.id].textBlock.measureText();
                else
                  break;
              return g3;
            }
            for (var d2, e2, f2, g2, k2, r2, l2 = 1, m2 = 0; m2 < 2 * l2; m2++) {
              for (var n3 = G.length - 1; 0 <= n3 && !(0 <= p(n3) && p(n3), f2 = G[n3], g2 = f2.textBlock, r2 = (k2 = q(n3) < R.length ? G[q(n3)] : null) ? k2.textBlock : null, d2 = +f2.height.toFixed(6), e2 = +g2.y.toFixed(6), !f2.isDirty && (k2 && e2 + d2 + fa3 > +r2.y.toFixed(6)) && (d2 = g2.y + d2 + fa3 - r2.y, e2 = a2(n3, -d2), e2 < d2 && (0 < e2 && (d2 -= e2), e2 = a2(q(n3), d2), e2 != d2))); n3--)
                ;
              b2();
            }
          }
          function h2(a2, b2) {
            return (b2 < R.length ? G[b2].textBlock.y : s.reversed ? W3 + z3 : va + z3) - (0 > a2 ? s.reversed ? va - z3 : W3 - z3 : G[a2].textBlock.y + G[a2].height + fa3);
          }
          function n2(a2, b2, c2) {
            var d2, e2, f2, r2 = [], h3 = z3, p2 = [];
            -1 !== b2 && (0 <= aa3.indexOf(b2) ? (e2 = aa3.indexOf(b2), aa3.splice(e2, 1)) : (aa3.push(b2), aa3 = aa3.sort(function(a3, b3) {
              return a3 - b3;
            })));
            if (0 === aa3.length)
              r2 = ka3;
            else {
              e2 = z3 * (1 != aa3.length || 0 != aa3[0] && aa3[0] != R.length - 1 ? 2 : 1) / k();
              for (var m2 = 0; m2 < R.length; m2++) {
                if (1 == aa3.length && 0 == aa3[0]) {
                  if (0 === m2) {
                    r2.push(ka3[m2]);
                    d2 = h3;
                    continue;
                  }
                } else
                  0 === m2 && (d2 = -1 * h3);
                r2.push(ka3[m2] + d2);
                if (0 <= aa3.indexOf(m2) || m2 < R.length && 0 <= aa3.indexOf(m2 + 1))
                  d2 += e2;
              }
            }
            f2 = function() {
              for (var a3 = [], b3 = 0; b3 < R.length; b3++)
                a3.push(r2[b3] - R[b3].y1);
              return a3;
            }();
            var q2 = { startTime: (/* @__PURE__ */ new Date()).getTime(), duration: c2 || 500, easingFunction: function(a3, b3, c3, d3) {
              return N.easing.easeOutQuart(a3, b3, c3, d3);
            }, changeSection: function(a3) {
              for (var b3, c3, d3 = 0; d3 < R.length; d3++)
                b3 = f2[d3], c3 = R[d3], b3 *= a3, "undefined" === typeof p2[d3] && (p2[d3] = 0), 0 > p2 && (p2 *= -1), c3.y1 += b3 - p2[d3], c3.y2 += b3 - p2[d3], c3.y3 += b3 - p2[d3], c3.y4 += b3 - p2[d3], c3.y5 && (c3.y5 += b3 - p2[d3], c3.y6 += b3 - p2[d3]), p2[d3] = b3;
            } };
            a2._animator.animate(0, c2, function(c3) {
              var d3 = a2.plotArea.ctx || a2.ctx;
              ja = true;
              d3.clearRect(v.x1, v.y1, v.x2 - v.x1, v.y2 - v.y1);
              d3.fillStyle = a2.backgroundColor;
              d3.fillRect(v.x1, v.y1, v.width, v.height);
              q2.changeSection(c3, b2);
              var e3 = {};
              e3.dataSeries = s;
              e3.dataPoint = s.reversed ? s.dataPoints[y.length - 1 - b2] : s.dataPoints[b2];
              e3.index = s.reversed ? y.length - 1 - b2 : b2;
              a2.toolTip.highlightObjects([e3]);
              for (e3 = 0; e3 < R.length; e3++)
                ta2(d3, R[e3], s.fillOpacity);
              J(d3);
              K && ("inside" !== s.indexLabelPlacement ? l(d3) : g(), w3(d3));
              1 <= c3 && (ja = false);
            }, null, N.easing.easeOutQuart);
          }
          function k() {
            for (var a2 = 0, b2 = 0; b2 < R.length - 1; b2++)
              (0 <= aa3.indexOf(b2) || 0 <= aa3.indexOf(b2 + 1)) && a2++;
            return a2;
          }
          function l(a2) {
            for (var b2, c2, d2, e2, g2 = 0; g2 < R.length; g2++)
              e2 = 1 === G[g2].lineThickness % 2 ? 0.5 : 0, c2 = ((R[g2].y2 + R[g2].y4) / 2 << 0) + e2, b2 = f(c2).x2 - 1, d2 = G[g2].textBlock.x, e2 = (G[g2].textBlock.y + G[g2].height / 2 << 0) + e2, G[g2].isDirty || 0 == G[g2].lineThickness || (a2.strokeStyle = G[g2].lineColor, a2.lineWidth = G[g2].lineThickness, a2.setLineDash && a2.setLineDash(H(
                G[g2].lineDashType,
                G[g2].lineThickness
              )), a2.beginPath(), a2.moveTo(b2, c2), a2.lineTo(d2, e2), a2.stroke());
          }
          function p(a2) {
            for (a2 -= 1; -1 <= a2 && -1 != a2 && G[a2].isDirty; a2--)
              ;
            return a2;
          }
          function q(a2) {
            for (a2 += 1; a2 <= R.length && a2 != R.length && G[a2].isDirty; a2++)
              ;
            return a2;
          }
          function f(a2) {
            for (var b2, c2 = 0; c2 < y.length; c2++)
              if (R[c2].y1 < a2 && R[c2].y4 > a2) {
                b2 = R[c2];
                break;
              }
            return b2 ? (a2 = b2.y6 ? a2 > b2.y6 ? b2.x3 + (b2.x4 - b2.x3) / (b2.y4 - b2.y3) * (a2 - b2.y3) : b2.x2 + (b2.x3 - b2.x2) / (b2.y3 - b2.y2) * (a2 - b2.y2) : b2.x2 + (b2.x3 - b2.x2) / (b2.y3 - b2.y2) * (a2 - b2.y2), { x1: a2, x2: a2 }) : -1;
          }
          function w3(a2) {
            for (var b2 = 0; b2 < R.length; b2++)
              G[b2].isDirty || (a2 && (G[b2].textBlock.ctx = a2), G[b2].textBlock.y += G[b2].textBlock._lineHeight / 2, G[b2].textBlock.render(true), G[b2].textBlock.y -= G[b2].textBlock._lineHeight / 2);
          }
          function J(a2) {
            x.plotArea.layoutManager.reset();
            a2.roundRect || Aa(a2);
            x.title && (x.title.dockInsidePlotArea || "center" === x.title.horizontalAlign && "center" === x.title.verticalAlign) && (x.title.ctx = a2, x.title.render());
            if (x.subtitles)
              for (var b2 = 0; b2 < x.subtitles.length; b2++) {
                var c2 = x.subtitles[b2];
                if (c2.dockInsidePlotArea || "center" === c2.horizontalAlign && "center" === c2.verticalAlign)
                  x.subtitles.ctx = a2, c2.render();
              }
            x.legend && (x.legend.dockInsidePlotArea || "center" === x.legend.horizontalAlign && "center" === x.legend.verticalAlign) && (x.legend.ctx = a2, x.legend.setLayout(), x.legend.render());
            xa.fNg && xa.fNg(x);
          }
          var x = this;
          if (!(0 >= a.dataSeriesIndexes.length)) {
            for (var s = this.data[a.dataSeriesIndexes[0]], y = s.dataPoints, v = this.plotArea, z3 = 0.025 * v.width, A = 0.01 * v.width, C = 0, D2 = v.height - 2 * z3, E3 = Math.min(v.width - 2 * A, 2.8 * v.height), K = false, T = 0; T < y.length; T++)
              if (!K && ("undefined" !== typeof y[T].indexLabel && null !== y[T].indexLabel && 0 < y[T].indexLabel.toString().length) && (K = true), !K && ("undefined" !== typeof y[T].label && null !== y[T].label && 0 < y[T].label.toString().length) && (K = true), !K && "function" === typeof s.indexLabelFormatter || "function" === typeof y[T].indexLabelFormatter)
                K = true;
            K = K || "undefined" !== typeof s.indexLabel && null !== s.indexLabel && 0 < s.indexLabel.toString().length;
            "inside" !== s.indexLabelPlacement && K || (A = (v.width - 0.75 * E3) / 2);
            var T = v.x1 + A, L2 = v.x2 - A, O2 = v.y1 + z3, S2 = v.y2 - z3, P = a.targetCanvasCtx || this.plotArea.ctx || this.ctx;
            if (0 != s.length && (s.dataPoints && s.visible) && 0 !== y.length) {
              var Q3, F;
              a = 75 * E3 / 100;
              var Z2 = 30 * (L2 - a) / 100;
              "funnel" === s.type ? (Q3 = m(s.options.neckHeight) ? 0.35 * D2 : s.neckHeight, F = m(s.options.neckWidth) ? 0.25 * a : s.neckWidth, "string" === typeof Q3 && Q3.match(/%$/) ? (Q3 = parseInt(Q3), Q3 = Q3 * D2 / 100) : Q3 = parseInt(Q3), "string" === typeof F && F.match(/%$/) ? (F = parseInt(F), F = F * a / 100) : F = parseInt(F), Q3 > D2 ? Q3 = D2 : 0 >= Q3 && (Q3 = 0), F > a ? F = a - 0.5 : 0 >= F && (F = 0)) : "pyramid" === s.type && (F = Q3 = 0, s.reversed = s.reversed ? false : true);
              var A = T + a / 2, U2 = T, Y2 = T + a, W3 = s.reversed ? S2 : O2, M = A - F / 2, $ = A + F / 2, X2 = s.reversed ? O2 + Q3 : S2 - Q3, va = s.reversed ? O2 : S2;
              a = [];
              var A = [], R = [], E3 = [], ba2 = O2, ea3, da3 = (X2 - W3) / (M - U2), ga2 = -da3, T = "area" === (s.valueRepresents ? s.valueRepresents : "height") ? c() : d();
              if (-1 !== T) {
                if (s.reversed)
                  for (E3.push(ba2), F = T.length - 1; 0 < F; F--)
                    ba2 += T[F], E3.push(ba2);
                else
                  for (F = 0; F < T.length; F++)
                    ba2 += T[F], E3.push(ba2);
                if (s.reversed)
                  for (F = 0; F < T.length; F++)
                    E3[F] < X2 ? (a.push(M), A.push($), ea3 = F) : (a.push((E3[F] - W3 + da3 * U2) / da3), A.push((E3[F] - W3 + ga2 * Y2) / ga2));
                else
                  for (F = 0; F < T.length; F++)
                    E3[F] < X2 ? (a.push((E3[F] - W3 + da3 * U2) / da3), A.push((E3[F] - W3 + ga2 * Y2) / ga2), ea3 = F) : (a.push(M), A.push($));
                for (F = 0; F < T.length - 1; F++)
                  ba2 = s.reversed ? y[y.length - 1 - F].color ? y[y.length - 1 - F].color : s._colorSet[(y.length - 1 - F) % s._colorSet.length] : y[F].color ? y[F].color : s._colorSet[F % s._colorSet.length], F === ea3 ? R.push({ x1: a[F], y1: E3[F], x2: A[F], y2: E3[F], x3: $, y3: X2, x4: A[F + 1], y4: E3[F + 1], x5: a[F + 1], y5: E3[F + 1], x6: M, y6: X2, id: F, height: E3[F + 1] - E3[F], color: ba2 }) : R.push({ x1: a[F], y1: E3[F], x2: A[F], y2: E3[F], x3: A[F + 1], y3: E3[F + 1], x4: a[F + 1], y4: E3[F + 1], id: F, height: E3[F + 1] - E3[F], color: ba2 });
                var fa3 = 2, G = [], ja = false, aa3 = [], ka3 = [], T = false;
                a = a = 0;
                Ea(aa3);
                for (F = 0; F < y.length; F++)
                  y[F].exploded && (T = true, s.reversed ? aa3.push(y.length - 1 - F) : aa3.push(F));
                P.clearRect(v.x1, v.y1, v.width, v.height);
                P.fillStyle = x.backgroundColor;
                P.fillRect(v.x1, v.y1, v.width, v.height);
                if (K && s.visible && (b(), g(), "inside" !== s.indexLabelPlacement)) {
                  e();
                  r();
                  for (F = 0; F < y.length; F++)
                    G[F].isDirty || (a = G[F].textBlock.x + G[F].width, a = (L2 - a) / 2, 0 == F && (C = a), C > a && (C = a));
                  for (F = 0; F < R.length; F++)
                    R[F].x1 += C, R[F].x2 += C, R[F].x3 += C, R[F].x4 += C, R[F].x5 && (R[F].x5 += C, R[F].x6 += C), G[F].textBlock.x += C;
                }
                for (F = 0; F < R.length; F++)
                  C = R[F], ta2(P, C, s.fillOpacity), ka3.push(C.y1);
                J(P);
                K && s.visible && ("inside" === s.indexLabelPlacement || x.animationEnabled || l(P), x.animationEnabled || w3());
                if (!K)
                  for (F = 0; F < y.length; F++)
                    C = s.dataPointIds[F], a = { id: C, objectType: "dataPoint", dataPointIndex: F, dataSeriesIndex: 0, funnelSection: R[s.reversed ? y.length - 1 - F : F] }, x._eventManager.objectMap[C] = a;
                !x.animationEnabled && T ? n2(x, -1, 0) : x.animationEnabled && !x.animatedRender && n2(x, -1, 0);
                this.funnelPyramidClickHandler = function(a2) {
                  var b2 = -1;
                  if (!ja && !x.isAnimating && (m(a2.dataSeries.explodeOnClick) || a2.dataSeries.explodeOnClick) && (b2 = s.reversed ? y.length - 1 - a2.dataPointIndex : a2.dataPointIndex, 0 <= b2)) {
                    a2 = b2;
                    if ("funnel" === s.type || "pyramid" === s.type)
                      s.reversed ? y[y.length - 1 - a2].exploded = y[y.length - 1 - a2].exploded ? false : true : y[a2].exploded = y[a2].exploded ? false : true;
                    n2(x, b2, 500);
                  }
                };
                return { source: P, dest: this.plotArea.ctx, animationCallback: function(a2, b2) {
                  N.fadeInAnimation(a2, b2);
                  1 <= a2 && (n2(x, -1, 500), J(x.plotArea.ctx || x.ctx));
                }, easingFunction: N.easing.easeInQuad, animationBase: 0 };
              }
            }
          }
        };
        n.prototype.requestAnimFrame = function() {
          return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(a) {
            window.setTimeout(a, 1e3 / 60);
          };
        }();
        n.prototype.cancelRequestAnimFrame = window.cancelAnimationFrame || window.webkitCancelRequestAnimationFrame || window.mozCancelRequestAnimationFrame || window.oCancelRequestAnimationFrame || window.msCancelRequestAnimationFrame || clearTimeout;
        n.prototype.set = function(a, d, c) {
          c = "undefined" === typeof c ? true : c;
          "options" === a ? (this.options = d, c && this.render()) : n.base.set.call(this, a, d, c);
        };
        n.prototype.exportChart = function(a) {
          a = "undefined" === typeof a ? {} : a;
          var d = a.format ? a.format : "png", c = a.fileName ? a.fileName : this.exportFileName;
          if (a.toDataURL)
            return this.canvas.toDataURL("image/" + d);
          var b = this.canvas;
          if (b && d && c) {
            c = c + "." + d;
            a = "image/" + d;
            var b = b.toDataURL(a), e = false, g = document.createElement("a");
            g.download = c;
            g.href = b;
            if ("undefined" !== typeof Blob && new Blob()) {
              for (var r = b.replace(/^data:[a-z\/]*;base64,/, ""), r = atob(r), h2 = new ArrayBuffer(r.length), h2 = new Uint8Array(h2), m2 = 0; m2 < r.length; m2++)
                h2[m2] = r.charCodeAt(m2);
              d = new Blob([h2.buffer], { type: "image/" + d });
              try {
                window.navigator.msSaveBlob(d, c), e = true;
              } catch (k) {
                g.dataset.downloadurl = [a, g.download, g.href].join(":"), g.href = window.URL.createObjectURL(d);
              }
            }
            if (!e)
              try {
                event = document.createEvent("MouseEvents"), event.initMouseEvent("click", true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null), g.dispatchEvent ? g.dispatchEvent(event) : g.fireEvent && g.fireEvent("onclick");
              } catch (l) {
                d = window.open(), d.document.write("<img src='" + b + "'></img><div>Please right click on the image and save it to your device</div>"), d.document.close();
              }
          }
        };
        n.prototype.print = function() {
          var a = this.exportChart({ toDataURL: true }), d = document.createElement("iframe");
          d.setAttribute("class", "canvasjs-chart-print-frame");
          Y(d, { position: "absolute", width: "100%", border: "0px", margin: "0px 0px 0px 0px", padding: "0px 0px 0px 0px" });
          d.style.height = this.height + "px";
          this._canvasJSContainer.appendChild(d);
          var c = this, b = d.contentWindow || d.contentDocument.document || d.contentDocument;
          b.document.open();
          b.document.write('<!DOCTYPE HTML>\n<html><body><img src="' + a + '"/><body/></html>');
          b.document.body && b.document.body.style && (b.document.body.style.margin = "0px 0px 0px 0px", b.document.body.style.padding = "0px 0px 0px 0px");
          b.document.close();
          setTimeout(function() {
            b.focus();
            b.print();
            setTimeout(function() {
              c._canvasJSContainer.removeChild(d);
            }, 1e3);
          }, 500);
        };
        n.prototype.getPercentAndTotal = function(a, d) {
          var c = null, b = null, e = c = null;
          if (0 <= a.type.indexOf("stacked"))
            b = 0, c = d.x.getTime ? d.x.getTime() : d.x, c in a.plotUnit.yTotals && (b = a.plotUnit.yTotals[c], c = a.plotUnit.yAbsTotals[c], e = isNaN(d.y) ? 0 : 0 === c ? 0 : 100 * (d.y / c));
          else if ("pie" === a.type || "doughnut" === a.type || "funnel" === a.type || "pyramid" === a.type) {
            for (c = b = 0; c < a.dataPoints.length; c++)
              isNaN(a.dataPoints[c].y) || (b += a.dataPoints[c].y);
            e = isNaN(d.y) ? 0 : 100 * (d.y / b);
          }
          return { percent: e, total: b };
        };
        n.prototype.replaceKeywordsWithValue = function(a, d, c, b, e) {
          var g = this;
          e = "undefined" === typeof e ? 0 : e;
          if ((0 <= c.type.indexOf("stacked") || "pie" === c.type || "doughnut" === c.type || "funnel" === c.type || "pyramid" === c.type) && (0 <= a.indexOf("#percent") || 0 <= a.indexOf("#total"))) {
            var r = "#percent", h2 = "#total", m2 = this.getPercentAndTotal(c, d), h2 = isNaN(m2.total) ? h2 : m2.total, r = isNaN(m2.percent) ? r : m2.percent;
            do {
              m2 = "";
              if (c.percentFormatString)
                m2 = c.percentFormatString;
              else {
                var m2 = "#,##0.", k = Math.max(Math.ceil(Math.log(1 / Math.abs(r)) / Math.LN10), 2);
                if (isNaN(k) || !isFinite(k))
                  k = 2;
                for (var l = 0; l < k; l++)
                  m2 += "#";
                c.percentFormatString = m2;
              }
              a = a.replace("#percent", ga(r, m2, g._cultureInfo));
              a = a.replace("#total", ga(h2, c.yValueFormatString ? c.yValueFormatString : "#,##0.########", g._cultureInfo));
            } while (0 <= a.indexOf("#percent") || 0 <= a.indexOf("#total"));
          }
          return a.replace(/\{.*?\}|"[^"]*"|'[^']*'/g, function(a2) {
            if ('"' === a2[0] && '"' === a2[a2.length - 1] || "'" === a2[0] && "'" === a2[a2.length - 1])
              return a2.slice(1, a2.length - 1);
            a2 = Ha(a2.slice(1, a2.length - 1));
            a2 = a2.replace("#index", e);
            var k2 = null;
            try {
              var f = a2.match(/(.*?)\s*\[\s*(.*?)\s*\]/);
              f && 0 < f.length && (k2 = Ha(f[2]), a2 = Ha(f[1]));
            } catch (r2) {
            }
            f = null;
            if ("color" === a2)
              return "waterfall" === c.type ? d.color ? d.color : 0 < d.y ? c.risingColor : c.fallingColor : "error" === c.type ? c.color ? c.color : c._colorSet[k2 % c._colorSet.length] : d.color ? d.color : c.color ? c.color : c._colorSet[b % c._colorSet.length];
            if (d.hasOwnProperty(a2))
              f = d;
            else if (c.hasOwnProperty(a2))
              f = c;
            else
              return "";
            f = f[a2];
            null !== k2 && (f = f[k2]);
            return "x" === a2 ? (c.axisX && "dateTime" === c.axisX.valueType || "dateTime" === c.xValueType || d.x && d.x.getTime) && !c.axisX.logarithmic ? Da(f, d.xValueFormatString ? d.xValueFormatString : c.xValueFormatString ? c.xValueFormatString : c.xValueFormatString = g.axisX && g.axisX.autoValueFormatString ? g.axisX.autoValueFormatString : "DD MMM YY", g._cultureInfo) : ga(f, d.xValueFormatString ? d.xValueFormatString : c.xValueFormatString ? c.xValueFormatString : c.xValueFormatString = "#,##0.########", g._cultureInfo) : "y" === a2 ? ga(f, d.yValueFormatString ? d.yValueFormatString : c.yValueFormatString ? c.yValueFormatString : c.yValueFormatString = "#,##0.########", g._cultureInfo) : "z" === a2 ? ga(f, d.zValueFormatString ? d.zValueFormatString : c.zValueFormatString ? c.zValueFormatString : c.zValueFormatString = "#,##0.########", g._cultureInfo) : f;
          });
        };
        qa(E2, L);
        E2.prototype.setLayout = function() {
          var a = this.dockInsidePlotArea ? this.chart.plotArea : this.chart, d = a.layoutManager.getFreeSpace(), c = null, b = 0, e = 0, g = 0, r = 0, h2 = this.markerMargin = this.chart.options.legend && !m(this.chart.options.legend.markerMargin) ? this.chart.options.legend.markerMargin : 0.3 * this.fontSize;
          this.height = 0;
          var n2 = [], k = [];
          if ("top" === this.verticalAlign || "bottom" === this.verticalAlign)
            this.orientation = "horizontal", c = this.verticalAlign, g = this.maxWidth = null !== this.maxWidth ? this.maxWidth : d.width, r = this.maxHeight = null !== this.maxHeight ? this.maxHeight : 0.5 * d.height;
          else if ("center" === this.verticalAlign) {
            this.orientation = "vertical";
            if ("left" === this.horizontalAlign || "center" === this.horizontalAlign || "right" === this.horizontalAlign)
              c = this.horizontalAlign;
            g = this.maxWidth = null !== this.maxWidth ? this.maxWidth : 0.5 * d.width;
            r = this.maxHeight = null !== this.maxHeight ? this.maxHeight : d.height;
          }
          this.errorMarkerColor = [];
          for (var l = 0; l < this.dataSeries.length; l++) {
            var p = this.dataSeries[l];
            if (p.dataPoints && p.dataPoints.length)
              if ("pie" !== p.type && "doughnut" !== p.type && "funnel" !== p.type && "pyramid" !== p.type) {
                var q = p.legendMarkerType = p.legendMarkerType ? p.legendMarkerType : "line" !== p.type && "stepLine" !== p.type && "spline" !== p.type && "scatter" !== p.type && "bubble" !== p.type || !p.markerType ? "error" === p.type && p._linkedSeries ? p._linkedSeries.legendMarkerType ? p._linkedSeries.legendMarkerType : Q2.getDefaultLegendMarker(p._linkedSeries.type) : Q2.getDefaultLegendMarker(p.type) : p.markerType, f = p.legendText ? p.legendText : this.itemTextFormatter ? this.itemTextFormatter({ chart: this.chart, legend: this.options, dataSeries: p, dataPoint: null }) : p.name, t2 = p.legendMarkerColor = p.legendMarkerColor ? p.legendMarkerColor : p.markerColor ? p.markerColor : "error" === p.type ? m(p.whiskerColor) ? p._colorSet[0] : p.whiskerColor : p._colorSet[0], w3 = p.markerSize || "line" !== p.type && "stepLine" !== p.type && "spline" !== p.type ? 0.75 * this.lineHeight : 0, x = p.legendMarkerBorderColor ? p.legendMarkerBorderColor : p.markerBorderColor, s = p.legendMarkerBorderThickness ? p.legendMarkerBorderThickness : p.markerBorderThickness ? Math.max(1, Math.round(0.2 * w3)) : 0;
                "error" === p.type && this.errorMarkerColor.push(t2);
                f = this.chart.replaceKeywordsWithValue(
                  f,
                  p.dataPoints[0],
                  p,
                  l
                );
                q = { markerType: q, markerColor: t2, text: f, textBlock: null, chartType: p.type, markerSize: w3, lineColor: p._colorSet[0], dataSeriesIndex: p.index, dataPointIndex: null, markerBorderColor: x, markerBorderThickness: s };
                n2.push(q);
              } else
                for (var y = 0; y < p.dataPoints.length; y++) {
                  var v = p.dataPoints[y], q = v.legendMarkerType ? v.legendMarkerType : p.legendMarkerType ? p.legendMarkerType : Q2.getDefaultLegendMarker(p.type), f = v.legendText ? v.legendText : p.legendText ? p.legendText : this.itemTextFormatter ? this.itemTextFormatter({
                    chart: this.chart,
                    legend: this.options,
                    dataSeries: p,
                    dataPoint: v
                  }) : v.name ? v.name : "DataPoint: " + (y + 1), t2 = v.legendMarkerColor ? v.legendMarkerColor : p.legendMarkerColor ? p.legendMarkerColor : v.color ? v.color : p.color ? p.color : p._colorSet[y % p._colorSet.length], w3 = 0.75 * this.lineHeight, x = v.legendMarkerBorderColor ? v.legendMarkerBorderColor : p.legendMarkerBorderColor ? p.legendMarkerBorderColor : v.markerBorderColor ? v.markerBorderColor : p.markerBorderColor, s = v.legendMarkerBorderThickness ? v.legendMarkerBorderThickness : p.legendMarkerBorderThickness ? p.legendMarkerBorderThickness : v.markerBorderThickness || p.markerBorderThickness ? Math.max(1, Math.round(0.2 * w3)) : 0, f = this.chart.replaceKeywordsWithValue(f, v, p, y), q = { markerType: q, markerColor: t2, text: f, textBlock: null, chartType: p.type, markerSize: w3, dataSeriesIndex: l, dataPointIndex: y, markerBorderColor: x, markerBorderThickness: s };
                  (v.showInLegend || p.showInLegend && false !== v.showInLegend) && n2.push(q);
                }
          }
          true === this.reversed && n2.reverse();
          if (0 < n2.length) {
            p = null;
            f = v = y = 0;
            v = null !== this.itemWidth ? null !== this.itemMaxWidth ? Math.min(
              this.itemWidth,
              this.itemMaxWidth,
              g
            ) : this.itemMaxWidth = Math.min(this.itemWidth, g) : null !== this.itemMaxWidth ? Math.min(this.itemMaxWidth, g) : this.itemMaxWidth = g;
            w3 = 0 === w3 ? 0.75 * this.lineHeight : w3;
            v = (this.itemMaxWidth ? this.itemMaxWidth : v) - (w3 + h2);
            for (l = 0; l < n2.length; l++) {
              q = n2[l];
              t2 = v;
              if ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType)
                t2 -= 2 * 0.1 * this.lineHeight;
              if (!(0 >= r || "undefined" === typeof r || 0 >= t2 || "undefined" === typeof t2))
                if ("horizontal" === this.orientation) {
                  q.textBlock = new la(this.ctx, {
                    x: 0,
                    y: 0,
                    maxWidth: t2,
                    maxHeight: this.itemWrap ? r : this.lineHeight,
                    angle: 0,
                    text: q.text,
                    horizontalAlign: "left",
                    fontSize: this.fontSize,
                    fontFamily: this.fontFamily,
                    fontWeight: this.fontWeight,
                    fontColor: this.fontColor,
                    fontStyle: this.fontStyle,
                    textBaseline: "middle"
                  });
                  q.textBlock.measureText();
                  null !== this.itemWidth && (q.textBlock.width = this.itemWidth - (w3 + h2 + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)));
                  if (!p || p.width + Math.round(q.textBlock.width + w3 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)) > g)
                    p = { items: [], width: 0 }, k.push(p), this.height += f, f = 0;
                  f = Math.max(f, q.textBlock.height ? q.textBlock.height : this.lineHeight);
                  q.textBlock.x = p.width;
                  q.textBlock.y = 0;
                  p.width += Math.round(q.textBlock.width + w3 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0));
                  p.items.push(q);
                  this.width = Math.max(p.width, this.width);
                } else
                  q.textBlock = new la(this.ctx, { x: 0, y: 0, maxWidth: v, maxHeight: true === this.itemWrap ? r : 1.5 * this.fontSize, angle: 0, text: q.text, horizontalAlign: "left", fontSize: this.fontSize, fontFamily: this.fontFamily, fontWeight: this.fontWeight, fontColor: this.fontColor, fontStyle: this.fontStyle, textBaseline: "middle" }), q.textBlock.measureText(), null !== this.itemWidth && (q.textBlock.width = this.itemWidth - (w3 + h2 + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0))), this.height < r - this.lineHeight ? (p = {
                    items: [],
                    width: 0
                  }, k.push(p)) : (p = k[y], y = (y + 1) % k.length), p && (this.height += q.textBlock.height ? q.textBlock.height : this.lineHeight, q.textBlock.x = p.width, q.textBlock.y = 0, p.width += Math.round(q.textBlock.width + w3 + h2 + (0 === p.width ? 0 : this.horizontalSpacing) + ("line" === q.chartType || "spline" === q.chartType || "stepLine" === q.chartType ? 2 * 0.1 * this.lineHeight : 0)), p.items.push(q), this.width = Math.max(p.width, this.width));
            }
            this.height = false === this.itemWrap ? k.length * this.lineHeight : this.height + f;
            this.height = Math.min(r, this.height);
            this.width = Math.min(g, this.width);
          }
          "top" === this.verticalAlign ? (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y1) : "center" === this.verticalAlign ? (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y1 + d.height / 2 - this.height / 2) : "bottom" === this.verticalAlign && (e = "left" === this.horizontalAlign ? d.x1 : "right" === this.horizontalAlign ? d.x2 - this.width : d.x1 + d.width / 2 - this.width / 2, b = d.y2 - this.height);
          this.items = n2;
          for (l = 0; l < this.items.length; l++)
            q = n2[l], q.id = ++this.chart._eventManager.lastObjectId, this.chart._eventManager.objectMap[q.id] = { id: q.id, objectType: "legendItem", legendItemIndex: l, dataSeriesIndex: q.dataSeriesIndex, dataPointIndex: q.dataPointIndex };
          this.markerSize = w3;
          this.rows = k;
          0 < n2.length && a.layoutManager.registerSpace(c, { width: this.width + 2 + 2, height: this.height + 5 + 5 });
          this.bounds = { x1: e, y1: b, x2: e + this.width, y2: b + this.height };
        };
        E2.prototype.render = function() {
          var a = this.bounds.x1, d = this.bounds.y1, c = this.markerMargin, b = this.maxWidth, e = this.maxHeight, g = this.markerSize, r = this.rows;
          (0 < this.borderThickness && this.borderColor || this.backgroundColor) && this.ctx.roundRect(a, d, this.width, this.height, this.cornerRadius, this.borderThickness, this.backgroundColor, this.borderColor);
          for (var h2 = 0, m2 = 0; m2 < r.length; m2++) {
            for (var k = r[m2], l = 0, p = 0; p < k.items.length; p++) {
              var q = k.items[p], f = q.textBlock.x + a + (0 === p ? 0.2 * g : this.horizontalSpacing), n2 = d + h2, t2 = f;
              this.chart.data[q.dataSeriesIndex].visible || (this.ctx.globalAlpha = 0.5);
              this.ctx.save();
              this.ctx.beginPath();
              this.ctx.rect(a, d, b, Math.max(e - e % this.lineHeight, 0));
              this.ctx.clip();
              if ("line" === q.chartType || "stepLine" === q.chartType || "spline" === q.chartType)
                this.ctx.strokeStyle = q.lineColor, this.ctx.lineWidth = Math.ceil(this.lineHeight / 8), this.ctx.beginPath(), this.ctx.moveTo(f - 0.1 * this.lineHeight, n2 + this.lineHeight / 2), this.ctx.lineTo(f + 0.85 * this.lineHeight, n2 + this.lineHeight / 2), this.ctx.stroke(), t2 -= 0.1 * this.lineHeight;
              if ("error" === q.chartType) {
                this.ctx.strokeStyle = this.errorMarkerColor[0];
                this.ctx.lineWidth = g / 8;
                this.ctx.beginPath();
                var x = f - 0.08 * this.lineHeight + 0.1 * this.lineHeight, s = n2 + 0.15 * this.lineHeight, y = 0.7 * this.lineHeight, v = y + 0.02 * this.lineHeight;
                this.ctx.moveTo(x, s);
                this.ctx.lineTo(x + y, s);
                this.ctx.stroke();
                this.ctx.beginPath();
                this.ctx.moveTo(x + y / 2, s);
                this.ctx.lineTo(x + y / 2, s + v);
                this.ctx.stroke();
                this.ctx.beginPath();
                this.ctx.moveTo(x, s + v);
                this.ctx.lineTo(x + y, s + v);
                this.ctx.stroke();
                this.errorMarkerColor.shift();
              }
              X.drawMarker(f + g / 2, n2 + this.lineHeight / 2, this.ctx, q.markerType, "error" === q.chartType || "line" === q.chartType || "spline" === q.chartType ? q.markerSize / 2 : q.markerSize, q.markerColor, q.markerBorderColor, q.markerBorderThickness);
              q.textBlock.x = f + c + g;
              if ("line" === q.chartType || "stepLine" === q.chartType || "spline" === q.chartType)
                q.textBlock.x += 0.1 * this.lineHeight;
              q.textBlock.y = Math.round(n2 + this.lineHeight / 2);
              q.textBlock.render(true);
              this.ctx.restore();
              l = 0 < p ? Math.max(l, q.textBlock.height ? q.textBlock.height : this.lineHeight) : q.textBlock.height ? q.textBlock.height : this.lineHeight;
              this.chart.data[q.dataSeriesIndex].visible || (this.ctx.globalAlpha = 1);
              f = Z(q.id);
              this.ghostCtx.fillStyle = f;
              this.ghostCtx.beginPath();
              this.ghostCtx.fillRect(t2, q.textBlock.y - this.lineHeight / 2, q.textBlock.x + q.textBlock.width - t2, q.textBlock.height ? q.textBlock.height : this.lineHeight);
              q.x1 = this.chart._eventManager.objectMap[q.id].x1 = t2;
              q.y1 = this.chart._eventManager.objectMap[q.id].y1 = q.textBlock.y - this.lineHeight / 2;
              q.x2 = this.chart._eventManager.objectMap[q.id].x2 = q.textBlock.x + q.textBlock.width;
              q.y2 = this.chart._eventManager.objectMap[q.id].y2 = q.textBlock.y + (q.textBlock.height ? q.textBlock.height : this.lineHeight) - this.lineHeight / 2;
            }
            h2 += l;
          }
        };
        qa(Q2, L);
        Q2.prototype.getDefaultAxisPlacement = function() {
          var a = this.type;
          if ("column" === a || "line" === a || "stepLine" === a || "spline" === a || "area" === a || "stepArea" === a || "splineArea" === a || "stackedColumn" === a || "stackedLine" === a || "bubble" === a || "scatter" === a || "stackedArea" === a || "stackedColumn100" === a || "stackedLine100" === a || "stackedArea100" === a || "candlestick" === a || "ohlc" === a || "rangeColumn" === a || "rangeArea" === a || "rangeSplineArea" === a || "boxAndWhisker" === a || "waterfall" === a)
            return "normal";
          if ("bar" === a || "stackedBar" === a || "stackedBar100" === a || "rangeBar" === a)
            return "xySwapped";
          if ("pie" === a || "doughnut" === a || "funnel" === a || "pyramid" === a)
            return "none";
          "error" !== a && window.console.log("Unknown Chart Type: " + a);
          return null;
        };
        Q2.getDefaultLegendMarker = function(a) {
          if ("column" === a || "stackedColumn" === a || "stackedLine" === a || "bar" === a || "stackedBar" === a || "stackedBar100" === a || "bubble" === a || "scatter" === a || "stackedColumn100" === a || "stackedLine100" === a || "stepArea" === a || "candlestick" === a || "ohlc" === a || "rangeColumn" === a || "rangeBar" === a || "rangeArea" === a || "rangeSplineArea" === a || "boxAndWhisker" === a || "waterfall" === a)
            return "square";
          if ("line" === a || "stepLine" === a || "spline" === a || "pie" === a || "doughnut" === a)
            return "circle";
          if ("area" === a || "splineArea" === a || "stackedArea" === a || "stackedArea100" === a || "funnel" === a || "pyramid" === a)
            return "triangle";
          if ("error" === a)
            return "none";
          window.console.log("Unknown Chart Type: " + a);
          return null;
        };
        Q2.prototype.getDataPointAtX = function(a, d) {
          if (!this.dataPoints || 0 === this.dataPoints.length)
            return null;
          var c = { dataPoint: null, distance: Infinity, index: NaN }, b = null, e = 0, g = 0, r = 1, h2 = Infinity, m2 = 0, k = 0, l = 0;
          "none" !== this.chart.plotInfo.axisPlacement && (this.axisX.logarithmic ? (l = Math.log(this.dataPoints[this.dataPoints.length - 1].x / this.dataPoints[0].x), l = 1 < l ? Math.min(Math.max((this.dataPoints.length - 1) / l * Math.log(a / this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0) : (l = this.dataPoints[this.dataPoints.length - 1].x - this.dataPoints[0].x, l = 0 < l ? Math.min(Math.max((this.dataPoints.length - 1) / l * (a - this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0));
          for (; ; ) {
            g = 0 < r ? l + e : l - e;
            if (0 <= g && g < this.dataPoints.length) {
              var b = this.dataPoints[g], p = this.axisX.logarithmic ? b.x > a ? b.x / a : a / b.x : Math.abs(b.x - a);
              p < c.distance && (c.dataPoint = b, c.distance = p, c.index = g);
              b = p;
              b <= h2 ? h2 = b : 0 < r ? m2++ : k++;
              if (1e3 < m2 && 1e3 < k)
                break;
            } else if (0 > l - e && l + e >= this.dataPoints.length)
              break;
            -1 === r ? (e++, r = 1) : r = -1;
          }
          return d || (c.dataPoint.x.getTime ? c.dataPoint.x.getTime() : c.dataPoint.x) !== (a.getTime ? a.getTime() : a) ? d && null !== c.dataPoint ? c : null : c;
        };
        Q2.prototype.getDataPointAtXY = function(a, d, c) {
          if (!this.dataPoints || 0 === this.dataPoints.length || a < this.chart.plotArea.x1 || a > this.chart.plotArea.x2 || d < this.chart.plotArea.y1 || d > this.chart.plotArea.y2)
            return null;
          c = c || false;
          var b = [], e = 0, g = 0, r = 1, h2 = false, n2 = Infinity, k = 0, l = 0, p = 0;
          if ("none" !== this.chart.plotInfo.axisPlacement)
            if (p = (this.chart.axisX[0] ? this.chart.axisX[0] : this.chart.axisX2[0]).getXValueAt({ x: a, y: d }), this.axisX.logarithmic)
              var q = Math.log(this.dataPoints[this.dataPoints.length - 1].x / this.dataPoints[0].x), p = 1 < q ? Math.min(Math.max((this.dataPoints.length - 1) / q * Math.log(p / this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0;
            else
              q = this.dataPoints[this.dataPoints.length - 1].x - this.dataPoints[0].x, p = 0 < q ? Math.min(Math.max((this.dataPoints.length - 1) / q * (p - this.dataPoints[0].x) >> 0, 0), this.dataPoints.length) : 0;
          for (; ; ) {
            g = 0 < r ? p + e : p - e;
            if (0 <= g && g < this.dataPoints.length) {
              var q = this.chart._eventManager.objectMap[this.dataPointIds[g]], f = this.dataPoints[g], t2 = null;
              if (q) {
                switch (this.type) {
                  case "column":
                  case "stackedColumn":
                  case "stackedColumn100":
                  case "bar":
                  case "stackedBar":
                  case "stackedBar100":
                  case "rangeColumn":
                  case "rangeBar":
                  case "waterfall":
                  case "error":
                    a >= q.x1 && (a <= q.x2 && d >= q.y1 && d <= q.y2) && (b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y1 - d), Math.abs(q.y2 - d)) }), h2 = true);
                    break;
                  case "line":
                  case "stepLine":
                  case "spline":
                  case "area":
                  case "stepArea":
                  case "stackedArea":
                  case "stackedArea100":
                  case "splineArea":
                  case "scatter":
                    var w3 = oa("markerSize", f, this) || 4, x = c ? 20 : w3, t2 = Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2));
                    t2 <= x && b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: t2 });
                    q = Math.abs(q.x1 - a);
                    q <= n2 ? n2 = q : 0 < r ? k++ : l++;
                    t2 <= w3 / 2 && (h2 = true);
                    break;
                  case "rangeArea":
                  case "rangeSplineArea":
                    w3 = oa("markerSize", f, this) || 4;
                    x = c ? 20 : w3;
                    t2 = Math.min(Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2)), Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y2 - d, 2)));
                    t2 <= x && b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: t2 });
                    q = Math.abs(q.x1 - a);
                    q <= n2 ? n2 = q : 0 < r ? k++ : l++;
                    t2 <= w3 / 2 && (h2 = true);
                    break;
                  case "bubble":
                    w3 = q.size;
                    t2 = Math.sqrt(Math.pow(q.x1 - a, 2) + Math.pow(q.y1 - d, 2));
                    t2 <= w3 / 2 && (b.push({
                      dataPoint: f,
                      dataPointIndex: g,
                      dataSeries: this,
                      distance: t2
                    }), h2 = true);
                    break;
                  case "pie":
                  case "doughnut":
                    w3 = q.center;
                    x = "doughnut" === this.type ? q.percentInnerRadius * q.radius : 0;
                    t2 = Math.sqrt(Math.pow(w3.x - a, 2) + Math.pow(w3.y - d, 2));
                    t2 < q.radius && t2 > x && (t2 = Math.atan2(d - w3.y, a - w3.x), 0 > t2 && (t2 += 2 * Math.PI), t2 = Number(((180 * (t2 / Math.PI) % 360 + 360) % 360).toFixed(12)), w3 = Number(((180 * (q.startAngle / Math.PI) % 360 + 360) % 360).toFixed(12)), x = Number(((180 * (q.endAngle / Math.PI) % 360 + 360) % 360).toFixed(12)), 0 === x && 1 < q.endAngle && (x = 360), w3 >= x && (0 !== f.y && !m(f.y)) && (x += 360, t2 < w3 && (t2 += 360)), t2 > w3 && t2 < x && (b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: 0 }), h2 = true));
                    break;
                  case "funnel":
                  case "pyramid":
                    t2 = q.funnelSection;
                    d > t2.y1 && d < t2.y4 && (t2.y6 ? d > t2.y6 ? (g = t2.x6 + (t2.x5 - t2.x6) / (t2.y5 - t2.y6) * (d - t2.y6), t2 = t2.x3 + (t2.x4 - t2.x3) / (t2.y4 - t2.y3) * (d - t2.y3)) : (g = t2.x1 + (t2.x6 - t2.x1) / (t2.y6 - t2.y1) * (d - t2.y1), t2 = t2.x2 + (t2.x3 - t2.x2) / (t2.y3 - t2.y2) * (d - t2.y2)) : (g = t2.x1 + (t2.x4 - t2.x1) / (t2.y4 - t2.y1) * (d - t2.y1), t2 = t2.x2 + (t2.x3 - t2.x2) / (t2.y3 - t2.y2) * (d - t2.y2)), a > g && a < t2 && (b.push({ dataPoint: f, dataPointIndex: q.dataPointIndex, dataSeries: this, distance: 0 }), h2 = true));
                    break;
                  case "boxAndWhisker":
                    if (a >= q.x1 - q.borderThickness / 2 && a <= q.x2 + q.borderThickness / 2 && d >= q.y4 - q.borderThickness / 2 && d <= q.y1 + q.borderThickness / 2 || Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y1 && d <= q.y4)
                      b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y2 - d), Math.abs(q.y3 - d)) }), h2 = true;
                    break;
                  case "candlestick":
                    if (a >= q.x1 - q.borderThickness / 2 && a <= q.x2 + q.borderThickness / 2 && d >= q.y2 - q.borderThickness / 2 && d <= q.y3 + q.borderThickness / 2 || Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y1 && d <= q.y4)
                      b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y2 - d), Math.abs(q.y3 - d)) }), h2 = true;
                    break;
                  case "ohlc":
                    if (Math.abs(q.x2 - a + q.x1 - a) < q.borderThickness && d >= q.y2 && d <= q.y3 || a >= q.x1 && a <= (q.x2 + q.x1) / 2 && d >= q.y1 - q.borderThickness / 2 && d <= q.y1 + q.borderThickness / 2 || a >= (q.x1 + q.x2) / 2 && a <= q.x2 && d >= q.y4 - q.borderThickness / 2 && d <= q.y4 + q.borderThickness / 2)
                      b.push({ dataPoint: f, dataPointIndex: g, dataSeries: this, distance: Math.min(Math.abs(q.x1 - a), Math.abs(q.x2 - a), Math.abs(q.y2 - d), Math.abs(q.y3 - d)) }), h2 = true;
                }
                if (h2 || 1e3 < k && 1e3 < l)
                  break;
              }
            } else if (0 > p - e && p + e >= this.dataPoints.length)
              break;
            -1 === r ? (e++, r = 1) : r = -1;
          }
          a = null;
          for (d = 0; d < b.length; d++)
            a ? b[d].distance <= a.distance && (a = b[d]) : a = b[d];
          return a;
        };
        Q2.prototype.getMarkerProperties = function(a, d, c, b) {
          var e = this.dataPoints, g = e[a].markerColor ? e[a].markerColor : this.markerColor ? this.markerColor : e[a].color ? e[a].color : this.color ? this.color : this._colorSet[a % this._colorSet.length], r = e[a].markerBorderColor ? e[a].markerBorderColor : this.markerBorderColor ? this.markerBorderColor : null, h2 = m(e[a].markerBorderThickness) ? this.markerBorderThickness ? this.markerBorderThickness : null : e[a].markerBorderThickness, n2 = e[a].markerType ? e[a].markerType : this.markerType;
          a = m(e[a].markerSize) ? this.markerSize : e[a].markerSize;
          return { x: d, y: c, ctx: b, type: n2, size: a, color: g, borderColor: r, borderThickness: h2 };
        };
        qa(D, L);
        D.prototype.createExtraLabelsForLog = function(a) {
          a = (a || 0) + 1;
          if (!(5 < a)) {
            var d = this.logLabelValues[0] || this.intervalStartPosition;
            if (Math.log(this.range) / Math.log(d / this.viewportMinimum) < this.noTicks - 1) {
              for (var c = D.getNiceNumber((d - this.viewportMinimum) / Math.min(Math.max(2, this.noTicks - this.logLabelValues.length), 3), true), b = Math.ceil(this.viewportMinimum / c) * c; b < d; b += c)
                b < this.viewportMinimum || this.logLabelValues.push(b);
              this.logLabelValues.sort(Ra);
              this.createExtraLabelsForLog(a);
            }
          }
        };
        D.prototype.createLabels = function() {
          var a, d, c = 0, b = 0, e, g = 0, r = 0, b = 0, b = this.interval, h2 = 0, n2, k = 0.6 * this.chart.height, l;
          a = false;
          var p = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], q = p.length ? m(this.scaleBreaks.firstBreakIndex) ? 0 : this.scaleBreaks.firstBreakIndex : 0;
          if ("axisX" !== this.type || "dateTime" !== this.valueType || this.logarithmic) {
            e = this.viewportMaximum;
            if (this.labels) {
              a = Math.ceil(b);
              for (var b = Math.ceil(this.intervalStartPosition), f = false, c = b; c < this.viewportMaximum; c += a)
                if (this.labels[c])
                  f = true;
                else {
                  f = false;
                  break;
                }
              f && (this.interval = a, this.intervalStartPosition = b);
            }
            if (this.logarithmic && !this.equidistantInterval)
              for (this.logLabelValues || (this.logLabelValues = [], this.createExtraLabelsForLog()), b = 0, f = q; b < this.logLabelValues.length; b++)
                if (c = this.logLabelValues[b], c < this.viewportMinimum)
                  b++;
                else {
                  for (; f < p.length && c > p[f].endValue; f++)
                    ;
                  a = f < p.length && c >= p[f].startValue && c <= p[f].endValue;
                  l = c;
                  a || (a = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.options, value: l, label: this.labels[l] ? this.labels[l] : null }) : "axisX" === this.type && this.labels[l] ? this.labels[l] : ga(l, this.valueFormatString, this.chart._cultureInfo), a = new la(this.ctx, {
                    x: 0,
                    y: 0,
                    maxWidth: g,
                    maxHeight: r,
                    angle: this.labelAngle,
                    text: this.prefix + a + this.suffix,
                    backgroundColor: this.labelBackgroundColor,
                    borderColor: this.labelBorderColor,
                    cornerRadius: this.labelCornerRadius,
                    textAlign: this.labelTextAlign,
                    fontSize: this.labelFontSize,
                    fontFamily: this.labelFontFamily,
                    fontWeight: this.labelFontWeight,
                    fontColor: this.labelFontColor,
                    fontStyle: this.labelFontStyle,
                    textBaseline: "middle",
                    borderThickness: 0
                  }), this._labels.push({ position: l, textBlock: a, effectiveHeight: null }));
                }
            f = q;
            for (c = this.intervalStartPosition; c <= e; c = parseFloat(1e-12 > this.interval ? this.logarithmic && this.equidistantInterval ? c * Math.pow(this.logarithmBase, this.interval) : c + this.interval : (this.logarithmic && this.equidistantInterval ? c * Math.pow(this.logarithmBase, this.interval) : c + this.interval).toFixed(12))) {
              for (; f < p.length && c > p[f].endValue; f++)
                ;
              a = f < p.length && c >= p[f].startValue && c <= p[f].endValue;
              l = c;
              a || (a = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.options, value: l, label: this.labels[l] ? this.labels[l] : null }) : "axisX" === this.type && this.labels[l] ? this.labels[l] : ga(l, this.valueFormatString, this.chart._cultureInfo), a = new la(this.ctx, { x: 0, y: 0, maxWidth: g, maxHeight: r, angle: this.labelAngle, text: this.prefix + a + this.suffix, textAlign: this.labelTextAlign, backgroundColor: this.labelBackgroundColor, borderColor: this.labelBorderColor, borderThickness: this.labelBorderThickness, cornerRadius: this.labelCornerRadius, fontSize: this.labelFontSize, fontFamily: this.labelFontFamily, fontWeight: this.labelFontWeight, fontColor: this.labelFontColor, fontStyle: this.labelFontStyle, textBaseline: "middle" }), this._labels.push({ position: l, textBlock: a, effectiveHeight: null }));
            }
          } else
            for (this.intervalStartPosition = this.getLabelStartPoint(new Date(this.viewportMinimum), this.intervalType, this.interval), e = Xa(new Date(this.viewportMaximum), this.interval, this.intervalType), f = q, c = this.intervalStartPosition; c < e; Xa(c, b, this.intervalType)) {
              for (a = c.getTime(); f < p.length && a > p[f].endValue; f++)
                ;
              l = a;
              a = f < p.length && a >= p[f].startValue && a <= p[f].endValue;
              a || (a = this.labelFormatter ? this.labelFormatter({
                chart: this.chart,
                axis: this.options,
                value: new Date(l),
                label: this.labels[l] ? this.labels[l] : null
              }) : "axisX" === this.type && this.labels[l] ? this.labels[l] : Da(l, this.valueFormatString, this.chart._cultureInfo), a = new la(this.ctx, {
                x: 0,
                y: 0,
                maxWidth: g,
                backgroundColor: this.labelBackgroundColor,
                borderColor: this.labelBorderColor,
                borderThickness: this.labelBorderThickness,
                cornerRadius: this.labelCornerRadius,
                maxHeight: r,
                angle: this.labelAngle,
                text: this.prefix + a + this.suffix,
                textAlign: this.labelTextAlign,
                fontSize: this.labelFontSize,
                fontFamily: this.labelFontFamily,
                fontWeight: this.labelFontWeight,
                fontColor: this.labelFontColor,
                fontStyle: this.labelFontStyle,
                textBaseline: "middle"
              }), this._labels.push({ position: l, textBlock: a, effectiveHeight: null, breaksLabelType: void 0 }));
            }
          if ("bottom" === this._position || "top" === this._position)
            h2 = this.logarithmic && !this.equidistantInterval && 2 <= this._labels.length ? this.lineCoordinates.width * Math.log(Math.min(this._labels[this._labels.length - 1].position / this._labels[this._labels.length - 2].position, this._labels[1].position / this._labels[0].position)) / Math.log(this.range) : this.lineCoordinates.width / (this.logarithmic && this.equidistantInterval ? Math.log(this.range) / Math.log(this.logarithmBase) : Math.abs(this.range)) * U[this.intervalType + "Duration"] * this.interval, g = "undefined" === typeof this.options.labelMaxWidth ? 0.5 * this.chart.width >> 0 : this.options.labelMaxWidth, this.chart.panEnabled || (r = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize);
          else if ("left" === this._position || "right" === this._position)
            h2 = this.logarithmic && !this.equidistantInterval && 2 <= this._labels.length ? this.lineCoordinates.height * Math.log(Math.min(this._labels[this._labels.length - 1].position / this._labels[this._labels.length - 2].position, this._labels[1].position / this._labels[0].position)) / Math.log(this.range) : this.lineCoordinates.height / (this.logarithmic && this.equidistantInterval ? Math.log(this.range) / Math.log(this.logarithmBase) : Math.abs(this.range)) * U[this.intervalType + "Duration"] * this.interval, this.chart.panEnabled || (g = "undefined" === typeof this.options.labelMaxWidth ? 0.3 * this.chart.width >> 0 : this.options.labelMaxWidth), r = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.3 * this.chart.height >> 0 : 1.5 * this.labelFontSize;
          for (b = 0; b < this._labels.length; b++) {
            a = this._labels[b].textBlock;
            a.maxWidth = g;
            a.maxHeight = r;
            var w3 = a.measureText();
            n2 = w3.height;
          }
          e = [];
          q = p = 0;
          if (this.labelAutoFit || this.options.labelAutoFit) {
            if (m(this.labelAngle) || (this.labelAngle = (this.labelAngle % 360 + 360) % 360, 90 < this.labelAngle && 270 > this.labelAngle ? this.labelAngle -= 180 : 270 <= this.labelAngle && 360 >= this.labelAngle && (this.labelAngle -= 360)), "bottom" === this._position || "top" === this._position)
              if (g = 0.9 * h2 >> 0, q = 0, !this.chart.panEnabled && 1 <= this._labels.length) {
                this.sessionVariables.labelFontSize = this.labelFontSize;
                this.sessionVariables.labelMaxWidth = g;
                this.sessionVariables.labelMaxHeight = r;
                this.sessionVariables.labelAngle = this.labelAngle;
                this.sessionVariables.labelWrap = this.labelWrap;
                for (c = 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    for (var z3, f = a.text.split(" "), b = 0; b < f.length; b++)
                      l = f[b], this.ctx.font = a.fontStyle + " " + a.fontWeight + " " + a.fontSize + "px " + a.fontFamily, l = this.ctx.measureText(l), l.width > q && (z3 = c, q = l.width);
                  }
                c = 0;
                for (c = this.intervalStartPosition < this.viewportMinimum ? 1 : 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    w3 = a.measureText();
                    for (f = c + 1; f < this._labels.length; f++)
                      if (!this._labels[f].breaksLabelType) {
                        d = this._labels[f].textBlock;
                        d = d.measureText();
                        break;
                      }
                    e.push(a.height);
                    this.sessionVariables.labelMaxHeight = Math.max.apply(Math, e);
                    Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                    b = g * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (r - a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    if (m(this.options.labelAngle) && isNaN(this.options.labelAngle) && 0 !== this.options.labelAngle)
                      if (this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? r : Math.min((b - g * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), b), l = (k - (n2 + a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(-25))) / Math.sin(Math.PI / 180 * Math.abs(-25)), !m(this.options.labelWrap))
                        this.labelWrap ? m(this.options.labelMaxWidth) ? (this.sessionVariables.labelMaxWidth = Math.min(Math.max(g, q), l), this.sessionVariables.labelWrap = this.labelWrap, d && w3.width + d.width >> 0 > 2 * g && (this.sessionVariables.labelAngle = -25)) : (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelAngle = this.sessionVariables.labelMaxWidth > g ? -25 : this.sessionVariables.labelAngle) : m(this.options.labelMaxWidth) ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelMaxWidth = g, d && w3.width + d.width >> 0 > 2 * g && (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = l)) : (this.sessionVariables.labelAngle = this.sessionVariables.labelMaxWidth > g ? -25 : this.sessionVariables.labelAngle, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelWrap = this.labelWrap);
                      else {
                        if (m(this.options.labelWrap)) {
                          if (!m(this.options.labelMaxWidth))
                            this.options.labelMaxWidth < g ? (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = b) : (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth, this.sessionVariables.labelMaxHeight = r);
                          else if (!m(d)) {
                            if (b = w3.width + d.width >> 0, f = this.labelFontSize, q < g)
                              b - 2 * g > p && (p = b - 2 * g, b >= 2 * g && b < 2.2 * g ? (this.sessionVariables.labelMaxWidth = g, m(this.options.labelFontSize) && 12 < f && (f = Math.floor(12 / 13 * f), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? f : this.options.labelFontSize, this.sessionVariables.labelAngle = this.labelAngle) : b >= 2.2 * g && b < 2.8 * g ? (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = l, this.sessionVariables.labelFontSize = f) : b >= 2.8 * g && b < 3.2 * g ? (this.sessionVariables.labelMaxWidth = Math.max(g, q), this.sessionVariables.labelWrap = true, m(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? f : this.options.labelFontSize, this.sessionVariables.labelAngle = this.labelAngle) : b >= 3.2 * g && b < 3.6 * g ? (this.sessionVariables.labelAngle = -25, this.sessionVariables.labelWrap = true, this.sessionVariables.labelMaxWidth = l, this.sessionVariables.labelFontSize = this.labelFontSize) : b > 3.6 * g && b < 5 * g ? (m(this.options.labelFontSize) && 12 < f && (f = Math.floor(12 / 13 * f), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? f : this.options.labelFontSize, this.sessionVariables.labelWrap = true, this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = l) : b > 5 * g && (this.sessionVariables.labelWrap = true, this.sessionVariables.labelMaxWidth = g, this.sessionVariables.labelFontSize = f, this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelAngle = this.labelAngle));
                            else if (z3 === c && (0 === z3 && q + this._labels[z3 + 1].textBlock.measureText().width - 2 * g > p || z3 === this._labels.length - 1 && q + this._labels[z3 - 1].textBlock.measureText().width - 2 * g > p || 0 < z3 && z3 < this._labels.length - 1 && q + this._labels[z3 + 1].textBlock.measureText().width - 2 * g > p && q + this._labels[z3 - 1].textBlock.measureText().width - 2 * g > p))
                              p = 0 === z3 ? q + this._labels[z3 + 1].textBlock.measureText().width - 2 * g : q + this._labels[z3 - 1].textBlock.measureText().width - 2 * g, this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? f : this.options.labelFontSize, this.sessionVariables.labelWrap = true, this.sessionVariables.labelAngle = -25, this.sessionVariables.labelMaxWidth = l;
                            else if (0 === p)
                              for (this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? f : this.options.labelFontSize, this.sessionVariables.labelWrap = true, b = 0; b < this._labels.length; b++)
                                a = this._labels[b].textBlock, a.maxWidth = this.sessionVariables.labelMaxWidth = Math.min(Math.max(g, q), l), w3 = a.measureText(), b < this._labels.length - 1 && (f = b + 1, d = this._labels[f].textBlock, d.maxWidth = this.sessionVariables.labelMaxWidth = Math.min(Math.max(g, q), l), d = d.measureText(), w3.width + d.width >> 0 > 2 * g && (this.sessionVariables.labelAngle = -25));
                          }
                        }
                      }
                    else
                      (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? r : Math.min((b - g * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), b), l = 0 != this.labelAngle ? (k - (n2 + a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) : g, this.sessionVariables.labelMaxHeight = this.labelWrap ? (k - l * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) : 1.5 * this.labelFontSize, m(this.options.labelWrap)) ? m(this.options.labelWrap) && (this.labelWrap && !m(this.options.labelMaxWidth) ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : l, this.sessionVariables.labelMaxHeight = r) : (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxWidth = l, this.sessionVariables.labelMaxHeight = b < 0.9 * h2 ? 0.9 * h2 : b, this.sessionVariables.labelWrap = this.labelWrap)) : (this.options.labelWrap ? (this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : l) : (m(this.options.labelMaxWidth), this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : l, this.sessionVariables.labelWrap = this.labelWrap), this.sessionVariables.labelMaxHeight = r);
                  }
                for (b = 0; b < this._labels.length; b++)
                  a = this._labels[b].textBlock, a.maxWidth = this.labelMaxWidth = this.sessionVariables.labelMaxWidth, a.fontSize = this.sessionVariables.labelFontSize, a.angle = this.labelAngle = this.sessionVariables.labelAngle, a.wrap = this.labelWrap = this.sessionVariables.labelWrap, a.maxHeight = this.sessionVariables.labelMaxHeight, a.measureText();
              } else
                for (c = 0; c < this._labels.length; c++)
                  a = this._labels[c].textBlock, a.maxWidth = this.labelMaxWidth = m(this.options.labelMaxWidth) ? m(this.sessionVariables.labelMaxWidth) ? this.sessionVariables.labelMaxWidth = g : this.sessionVariables.labelMaxWidth : this.options.labelMaxWidth, a.fontSize = this.labelFontSize = m(this.options.labelFontSize) ? m(this.sessionVariables.labelFontSize) ? this.sessionVariables.labelFontSize = this.labelFontSize : this.sessionVariables.labelFontSize : this.options.labelFontSize, a.angle = this.labelAngle = m(this.options.labelAngle) ? m(this.sessionVariables.labelAngle) ? this.sessionVariables.labelAngle = this.labelAngle : this.sessionVariables.labelAngle : this.labelAngle, a.wrap = this.labelWrap = m(this.options.labelWrap) ? m(this.sessionVariables.labelWrap) ? this.sessionVariables.labelWrap = this.labelWrap : this.sessionVariables.labelWrap : this.options.labelWrap, a.maxHeight = m(this.sessionVariables.labelMaxHeight) ? this.sessionVariables.labelMaxHeight = r : this.sessionVariables.labelMaxHeight, a.measureText();
            else if ("left" === this._position || "right" === this._position)
              if (g = m(this.options.labelMaxWidth) ? 0.3 * this.chart.width >> 0 : this.options.labelMaxWidth, r = "undefined" === typeof this.options.labelWrap || this.labelWrap ? 0.3 * this.chart.height >> 0 : 1.5 * this.labelFontSize, !this.chart.panEnabled && 1 <= this._labels.length) {
                this.sessionVariables.labelFontSize = this.labelFontSize;
                this.sessionVariables.labelMaxWidth = g;
                this.sessionVariables.labelMaxHeight = r;
                this.sessionVariables.labelAngle = m(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle;
                this.sessionVariables.labelWrap = this.labelWrap;
                for (c = 0; c < this._labels.length; c++)
                  if (!this._labels[c].breaksLabelType) {
                    a = this._labels[c].textBlock;
                    w3 = a.measureText();
                    for (f = c + 1; f < this._labels.length; f++)
                      if (!this._labels[f].breaksLabelType) {
                        d = this._labels[f].textBlock;
                        d = d.measureText();
                        break;
                      }
                    e.push(a.height);
                    this.sessionVariables.labelMaxHeight = Math.max.apply(Math, e);
                    b = g * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (r - a.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                    Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                    m(this.options.labelAngle) && isNaN(this.options.labelAngle) && 0 !== this.options.labelAngle ? m(this.options.labelWrap) ? m(this.options.labelWrap) && (m(this.options.labelMaxWidth) ? m(d) || (h2 = w3.height + d.height >> 0, h2 - 2 * r > q && (q = h2 - 2 * r, h2 >= 2 * r && h2 < 2.4 * r ? (m(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize) : h2 >= 2.4 * r && h2 < 2.8 * r ? (this.sessionVariables.labelMaxHeight = b, this.sessionVariables.labelFontSize = this.labelFontSize, this.sessionVariables.labelWrap = true) : h2 >= 2.8 * r && h2 < 3.2 * r ? (this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelWrap = true, m(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelAngle = m(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle) : h2 >= 3.2 * r && h2 < 3.6 * r ? (this.sessionVariables.labelMaxHeight = b, this.sessionVariables.labelWrap = true, this.sessionVariables.labelFontSize = this.labelFontSize) : h2 > 3.6 * r && h2 < 10 * r ? (m(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelMaxWidth = g, this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelAngle = m(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle) : h2 > 10 * r && h2 < 50 * r && (m(this.options.labelFontSize) && 12 < this.labelFontSize && (this.labelFontSize = Math.floor(12 / 13 * this.labelFontSize), a.measureText()), this.sessionVariables.labelFontSize = m(this.options.labelFontSize) ? this.labelFontSize : this.options.labelFontSize, this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelMaxWidth = g, this.sessionVariables.labelAngle = m(this.sessionVariables.labelAngle) ? 0 : this.sessionVariables.labelAngle))) : (this.sessionVariables.labelMaxHeight = r, this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth)) : (this.sessionVariables.labelMaxWidth = this.labelWrap ? this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth : this.labelMaxWidth ? this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth : g, this.sessionVariables.labelMaxHeight = r) : (this.sessionVariables.labelAngle = this.labelAngle, this.sessionVariables.labelMaxWidth = 0 === this.labelAngle ? g : Math.min(
                      (b - r * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle))) / Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)),
                      r
                    ), m(this.options.labelWrap)) ? m(this.options.labelWrap) && (this.labelWrap && !m(this.options.labelMaxWidth) ? (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth, this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxHeight = b) : (this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : g, this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? r : b, m(this.options.labelMaxWidth) && (this.sessionVariables.labelAngle = this.labelAngle))) : this.options.labelWrap ? (this.sessionVariables.labelMaxHeight = 0 === this.labelAngle ? r : b, this.sessionVariables.labelWrap = this.labelWrap, this.sessionVariables.labelMaxWidth = g) : (this.sessionVariables.labelMaxHeight = r, m(this.options.labelMaxWidth), this.sessionVariables.labelMaxWidth = this.options.labelMaxWidth ? this.options.labelMaxWidth : this.sessionVariables.labelMaxWidth, this.sessionVariables.labelWrap = this.labelWrap);
                  }
                for (b = 0; b < this._labels.length; b++)
                  a = this._labels[b].textBlock, a.maxWidth = this.labelMaxWidth = this.sessionVariables.labelMaxWidth, a.fontSize = this.labelFontSize = this.sessionVariables.labelFontSize, a.angle = this.labelAngle = this.sessionVariables.labelAngle, a.wrap = this.labelWrap = this.sessionVariables.labelWrap, a.maxHeight = this.sessionVariables.labelMaxHeight, a.measureText();
              } else
                for (c = 0; c < this._labels.length; c++)
                  a = this._labels[c].textBlock, a.maxWidth = this.labelMaxWidth = m(this.options.labelMaxWidth) ? m(this.sessionVariables.labelMaxWidth) ? this.sessionVariables.labelMaxWidth = g : this.sessionVariables.labelMaxWidth : this.options.labelMaxWidth, a.fontSize = this.labelFontSize = m(this.options.labelFontSize) ? m(this.sessionVariables.labelFontSize) ? this.sessionVariables.labelFontSize = this.labelFontSize : this.sessionVariables.labelFontSize : this.options.labelFontSize, a.angle = this.labelAngle = m(this.options.labelAngle) ? m(this.sessionVariables.labelAngle) ? this.sessionVariables.labelAngle = this.labelAngle : this.sessionVariables.labelAngle : this.labelAngle, a.wrap = this.labelWrap = m(this.options.labelWrap) ? m(this.sessionVariables.labelWrap) ? this.sessionVariables.labelWrap = this.labelWrap : this.sessionVariables.labelWrap : this.options.labelWrap, a.maxHeight = m(this.sessionVariables.labelMaxHeight) ? this.sessionVariables.labelMaxHeight = r : this.sessionVariables.labelMaxHeight, a.measureText();
          }
          for (c = 0; c < this.stripLines.length; c++) {
            var g = this.stripLines[c], x;
            if ("outside" === g.labelPlacement) {
              r = this.sessionVariables.labelMaxWidth;
              if ("bottom" === this._position || "top" === this._position)
                m(g.options.labelWrap) && !m(this.sessionVariables.stripLineLabelMaxHeight) ? x = this.sessionVariables.stripLineLabelMaxHeight : this.sessionVariables.stripLineLabelMaxHeight = x = g.labelWrap ? 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize;
              if ("left" === this._position || "right" === this._position)
                m(g.options.labelWrap) && !m(this.sessionVariables.stripLineLabelMaxHeight) ? x = this.sessionVariables.stripLineLabelMaxHeight : this.sessionVariables.stripLineLabelMaxHeight = x = g.labelWrap ? 0.8 * this.chart.width >> 0 : 1.5 * this.labelFontSize;
              m(g.labelBackgroundColor) && (g.labelBackgroundColor = "#EEEEEE");
            } else
              r = "bottom" === this._position || "top" === this._position ? 0.9 * this.chart.width >> 0 : 0.9 * this.chart.height >> 0, x = m(g.options.labelWrap) || g.labelWrap ? "bottom" === this._position || "top" === this._position ? 0.8 * this.chart.width >> 0 : 0.8 * this.chart.height >> 0 : 1.5 * this.labelFontSize, m(g.labelBackgroundColor) && (m(g.startValue) && 0 !== g.startValue ? g.labelBackgroundColor = t ? "transparent" : null : g.labelBackgroundColor = "#EEEEEE");
            a = new la(this.ctx, {
              x: 0,
              y: 0,
              backgroundColor: g.labelBackgroundColor,
              borderColor: g.labelBorderColor,
              borderThickness: g.labelBorderThickness,
              cornerRadius: g.labelCornerRadius,
              maxWidth: g.options.labelMaxWidth ? g.options.labelMaxWidth : r,
              maxHeight: x,
              angle: this.labelAngle,
              text: g.labelFormatter ? g.labelFormatter({ chart: this.chart, axis: this, stripLine: g }) : g.label,
              textAlign: this.labelTextAlign,
              fontSize: "outside" === g.labelPlacement ? g.options.labelFontSize ? g.labelFontSize : this.labelFontSize : g.labelFontSize,
              fontFamily: "outside" === g.labelPlacement ? g.options.labelFontFamily ? g.labelFontFamily : this.labelFontFamily : g.labelFontFamily,
              fontWeight: "outside" === g.labelPlacement ? g.options.labelFontWeight ? g.labelFontWeight : this.labelFontWeight : g.labelFontWeight,
              fontColor: g.labelFontColor || g.color,
              fontStyle: "outside" === g.labelPlacement ? g.options.labelFontStyle ? g.labelFontStyle : this.fontWeight : g.labelFontStyle,
              textBaseline: "middle"
            });
            this._stripLineLabels.push({ position: g.value, textBlock: a, effectiveHeight: null, stripLine: g });
          }
        };
        D.prototype.createLabelsAndCalculateWidth = function() {
          var a = 0, d = 0;
          this._labels = [];
          this._stripLineLabels = [];
          var c = this.chart.isNavigator ? 0 : 5;
          if ("left" === this._position || "right" === this._position) {
            this.createLabels();
            if ("inside" != this.labelPlacement || "inside" === this.labelPlacement && 0 < this._index)
              for (d = 0; d < this._labels.length; d++) {
                var b = this._labels[d].textBlock, e = b.measureText(), g = 0, g = 0 === this.labelAngle ? e.width : e.width * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - b.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle));
                a < g && (this.labelEffectiveWidth = a = g);
                this._labels[d].effectiveWidth = g;
              }
            for (d = 0; d < this._stripLineLabels.length; d++)
              "outside" === this._stripLineLabels[d].stripLine.labelPlacement && (this._stripLineLabels[d].stripLine.value >= this.viewportMinimum && this._stripLineLabels[d].stripLine.value <= this.viewportMaximum) && (b = this._stripLineLabels[d].textBlock, e = b.measureText(), g = 0 === this.labelAngle ? e.width : e.width * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - b.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)), "inside" === this.tickPlacement && (g += this.tickLength), "inside" === this.labelPlacement && (a += 0 < this._index ? g : 0), a < g && (a = g), this.stripLineLabelEffectiveWidth = this._stripLineLabels[d].effectiveWidth = g);
          }
          return (this.title ? this._titleTextBlock.measureText().height + 2 : 0) + a + ("inside" === this.tickPlacement ? 0 < this._index ? this.tickLength : 0 : this.tickLength) + c;
        };
        D.prototype.createLabelsAndCalculateHeight = function() {
          var a = 0;
          this._labels = [];
          this._stripLineLabels = [];
          var d, c = 0, b = this.chart.isNavigator ? 0 : 5;
          if ("bottom" === this._position || "top" === this._position) {
            this.createLabels();
            if ("inside" != this.labelPlacement || "inside" === this.labelPlacement && 0 < this._index)
              for (c = 0; c < this._labels.length; c++) {
                d = this._labels[c].textBlock;
                var e = d.measureText(), g = 0, g = 0 === this.labelAngle ? e.height : e.width * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - d.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle));
                a < g && (this.labelEffectiveHeight = a = g);
                this._labels[c].effectiveHeight = g;
              }
            for (c = 0; c < this._stripLineLabels.length; c++)
              "outside" === this._stripLineLabels[c].stripLine.labelPlacement && (this._stripLineLabels[c].stripLine.value >= this.viewportMinimum && this._stripLineLabels[c].stripLine.value <= this.viewportMaximum) && (d = this._stripLineLabels[c].textBlock, e = d.measureText(), g = 0 === this.labelAngle ? e.height : e.width * Math.sin(Math.PI / 180 * Math.abs(this.labelAngle)) + (e.height - d.fontSize / 2) * Math.cos(Math.PI / 180 * Math.abs(this.labelAngle)), "inside" === this.tickPlacement && (g += this.tickLength), "inside" === this.labelPlacement && (a += 0 < this._index ? g : 0), a < g && (a = g), this.stripLineLabelEffectiveHeight = this._stripLineLabels[c].effectiveHeight = g);
          }
          return (this.title ? this._titleTextBlock.measureText().height + 2 : 0) + a + ("inside" === this.tickPlacement ? 0 < this._index ? this.tickLength : 0 : this.tickLength) + b;
        };
        D.setLayout = function(a, d, c, b, e, g) {
          var h2, n2, t2, k, l = a[0] ? a[0].chart : d[0].chart, p = l.isNavigator ? 0 : 10, q = l._axes;
          if (a && 0 < a.length)
            for (var f = 0; f < a.length; f++)
              a[f] && a[f].calculateAxisParameters();
          if (d && 0 < d.length)
            for (f = 0; f < d.length; f++)
              d[f].calculateAxisParameters();
          if (c && 0 < c.length)
            for (f = 0; f < c.length; f++)
              c[f].calculateAxisParameters();
          if (b && 0 < b.length)
            for (f = 0; f < b.length; f++)
              b[f].calculateAxisParameters();
          for (f = 0; f < q.length; f++)
            if (q[f] && q[f].scaleBreaks && q[f].scaleBreaks._appliedBreaks.length)
              for (var w3 = q[f].scaleBreaks._appliedBreaks, z3 = 0; z3 < w3.length && !(w3[z3].startValue > q[f].viewportMaximum); z3++)
                w3[z3].endValue < q[f].viewportMinimum || (m(q[f].scaleBreaks.firstBreakIndex) && (q[f].scaleBreaks.firstBreakIndex = z3), w3[z3].startValue >= q[f].viewPortMinimum && (q[f].scaleBreaks.lastBreakIndex = z3));
          for (var x = z3 = 0, s = 0, y = 0, v = 0, D2 = 0, A = 0, C, E3, H2 = n2 = 0, K, L2, N2, w3 = K = L2 = N2 = false, f = 0; f < q.length; f++)
            q[f] && q[f].title && (q[f]._titleTextBlock = new la(q[f].ctx, {
              text: q[f].title,
              horizontalAlign: "center",
              fontSize: q[f].titleFontSize,
              fontFamily: q[f].titleFontFamily,
              fontWeight: q[f].titleFontWeight,
              fontColor: q[f].titleFontColor,
              fontStyle: q[f].titleFontStyle,
              borderColor: q[f].titleBorderColor,
              borderThickness: q[f].titleBorderThickness,
              backgroundColor: q[f].titleBackgroundColor,
              cornerRadius: q[f].titleCornerRadius,
              textBaseline: "middle"
            }));
          for (f = 0; f < q.length; f++)
            if (q[f].title)
              switch (q[f]._position) {
                case "left":
                  q[f]._titleTextBlock.maxWidth = q[f].titleMaxWidth || g.height;
                  q[f]._titleTextBlock.maxHeight = q[f].titleWrap ? 0.8 * g.width : 1.5 * q[f].titleFontSize;
                  q[f]._titleTextBlock.angle = -90;
                  break;
                case "right":
                  q[f]._titleTextBlock.maxWidth = q[f].titleMaxWidth || g.height;
                  q[f]._titleTextBlock.maxHeight = q[f].titleWrap ? 0.8 * g.width : 1.5 * q[f].titleFontSize;
                  q[f]._titleTextBlock.angle = 90;
                  break;
                default:
                  q[f]._titleTextBlock.maxWidth = q[f].titleMaxWidth || g.width, q[f]._titleTextBlock.maxHeight = q[f].titleWrap ? 0.8 * g.height : 1.5 * q[f].titleFontSize, q[f]._titleTextBlock.angle = 0;
              }
          if ("normal" === e) {
            for (var y = [], v = [], D2 = [], A = [], O2 = [], Q3 = [], P = [], S2 = []; 4 > z3; ) {
              var F = 0, Z2 = 0, U2 = 0, W3 = 0, Y2 = e = 0, M = 0, aa3 = 0, X2 = 0, $ = 0, R = 0, ba2 = 0;
              if (c && 0 < c.length)
                for (D2 = [], f = R = 0; f < c.length; f++)
                  D2.push(Math.ceil(c[f] ? c[f].createLabelsAndCalculateWidth() : 0)), R += D2[f], M += c[f] && !l.isNavigator ? c[f].margin : 0;
              else
                D2.push(Math.ceil(c[0] ? c[0].createLabelsAndCalculateWidth() : 0));
              P.push(D2);
              if (b && 0 < b.length)
                for (A = [], f = ba2 = 0; f < b.length; f++)
                  A.push(Math.ceil(b[f] ? b[f].createLabelsAndCalculateWidth() : 0)), ba2 += A[f], aa3 += b[f] ? b[f].margin : 0;
              else
                A.push(Math.ceil(b[0] ? b[0].createLabelsAndCalculateWidth() : 0));
              S2.push(A);
              h2 = Math.round(g.x1 + R + M);
              t2 = Math.round(g.x2 - ba2 - aa3 > l.width - p ? l.width - p : g.x2 - ba2 - aa3);
              if (a && 0 < a.length)
                for (y = [], f = X2 = 0; f < a.length; f++)
                  a[f] && (a[f].lineCoordinates = {}), a[f].lineCoordinates.width = Math.abs(t2 - h2), a[f].title && (a[f]._titleTextBlock.maxWidth = 0 < a[f].titleMaxWidth && a[f].titleMaxWidth < a[f].lineCoordinates.width ? a[f].titleMaxWidth : a[f].lineCoordinates.width), y.push(Math.ceil(a[f] ? a[f].createLabelsAndCalculateHeight() : 0)), X2 += y[f], e += a[f] && !l.isNavigator ? a[f].margin : 0;
              else
                y.push(Math.ceil(a[0] ? a[0].createLabelsAndCalculateHeight() : 0));
              O2.push(y);
              if (d && 0 < d.length)
                for (v = [], f = $ = 0; f < d.length; f++)
                  d[f] && (d[f].lineCoordinates = {}), d[f].lineCoordinates.width = Math.abs(t2 - h2), d[f].title && (d[f]._titleTextBlock.maxWidth = 0 < d[f].titleMaxWidth && d[f].titleMaxWidth < d[f].lineCoordinates.width ? d[f].titleMaxWidth : d[f].lineCoordinates.width), v.push(Math.ceil(d[f] ? d[f].createLabelsAndCalculateHeight() : 0)), $ += v[f], Y2 += d[f] && !l.isNavigator ? d[f].margin : 0;
              else
                v.push(Math.ceil(d[0] ? d[0].createLabelsAndCalculateHeight() : 0));
              Q3.push(v);
              if (a && 0 < a.length)
                for (f = 0; f < a.length; f++)
                  a[f] && (a[f].lineCoordinates.x1 = h2, t2 = Math.round(g.x2 - ba2 - aa3 > l.width - p ? l.width - p : g.x2 - ba2 - aa3), a[f]._labels && 1 < a[f]._labels.length && (n2 = k = 0, k = a[f]._labels[1], n2 = "dateTime" === a[f].valueType ? a[f]._labels[a[f]._labels.length - 2] : a[f]._labels[a[f]._labels.length - 1], x = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), s = n2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(n2.textBlock.angle)) + (n2.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(n2.textBlock.angle))), !a[f] || (!a[f].labelAutoFit || m(C) || m(E3) || l.isNavigator || l.stockChart) || (n2 = 0, 0 < a[f].labelAngle ? E3 + s > t2 && (n2 += 0 < a[f].labelAngle ? E3 + s - t2 - ba2 : 0) : 0 > a[f].labelAngle ? C - x < h2 && C - x < a[f].viewportMinimum && (H2 = h2 - (M + a[f].tickLength + D2 + C - x + a[f].labelFontSize / 2)) : 0 === a[f].labelAngle && (E3 + s > t2 && (n2 = E3 + s / 2 - t2 - ba2), C - x < h2 && C - x < a[f].viewportMinimum && (H2 = h2 - M - a[f].tickLength - D2 - C + x / 2)), a[f].viewportMaximum === a[f].maximum && a[f].viewportMinimum === a[f].minimum && 0 < a[f].labelAngle && 0 < n2 ? t2 -= n2 : a[f].viewportMaximum === a[f].maximum && a[f].viewportMinimum === a[f].minimum && 0 > a[f].labelAngle && 0 < H2 ? h2 += H2 : a[f].viewportMaximum === a[f].maximum && a[f].viewportMinimum === a[f].minimum && 0 === a[f].labelAngle && (0 < H2 && (h2 += H2), 0 < n2 && (t2 -= n2))), l.panEnabled ? X2 = m(l.sessionVariables.axisX.height) ? l.sessionVariables.axisX.height = X2 : l.sessionVariables.axisX.height : l.sessionVariables.axisX.height = X2, n2 = Math.round(g.y2 - X2 - e + F), k = Math.round(g.y2), a[f].lineCoordinates.x2 = t2, a[f].lineCoordinates.width = t2 - h2, a[f].lineCoordinates.y1 = n2, a[f].lineCoordinates.y2 = n2, "inside" === a[f].labelPlacement && 0 < f && (a[f].lineCoordinates.y1 = a[f - 1].lineCoordinates.y2 + F + (a[f].labelEffectiveHeight || 0), a[f].lineCoordinates.y2 = a[f].lineCoordinates.y1 + a[f].lineThickness / 2), "inside" === a[f].tickPlacement && 0 < f && (a[f].lineCoordinates.y1 += a[f].tickLength, a[f].lineCoordinates.y2 = a[f].lineCoordinates.y1 + a[f].lineThickness / 2), a[f].bounds = { x1: h2, y1: n2, x2: t2, y2: k - (X2 + e - y[f] - F), width: t2 - h2 }, a[f].bounds.height = a[f].bounds.y2 - a[f].bounds.y1), F += y[f] + a[f].margin;
              if (d && 0 < d.length)
                for (f = 0; f < d.length; f++)
                  d[f].lineCoordinates.x1 = Math.round(g.x1 + R + M), d[f].lineCoordinates.x2 = Math.round(g.x2 - ba2 - aa3 > l.width - p ? l.width - p : g.x2 - ba2 - aa3), d[f].lineCoordinates.width = Math.abs(t2 - h2), d[f]._labels && 1 < d[f]._labels.length && (k = d[f]._labels[1], n2 = "dateTime" === d[f].valueType ? d[f]._labels[d[f]._labels.length - 2] : d[f]._labels[d[f]._labels.length - 1], x = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), s = n2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(n2.textBlock.angle)) + (n2.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(n2.textBlock.angle))), l.panEnabled ? $ = m(l.sessionVariables.axisX2.height) ? l.sessionVariables.axisX2.height = $ : l.sessionVariables.axisX2.height : l.sessionVariables.axisX2.height = $, n2 = Math.round(g.y1), k = d[f].lineCoordinates.y1 = n2 + $ + Y2 - Z2, d[f].lineCoordinates.y2 = n2, "inside" === d[f].labelPlacement && 0 < f && (d[f].lineCoordinates.y1 = d[f - 1].lineCoordinates.y1 - Z2 - (d[f].labelEffectiveHeight || 0)), "inside" === d[f].tickPlacement && 0 < f && (d[f].lineCoordinates.y1 -= d[f].tickLength), d[f].bounds = { x1: h2, y1: n2 + ($ + Y2 - v[f] - Z2), x2: t2, y2: k, width: t2 - h2 }, d[f].bounds.height = d[f].bounds.y2 - d[f].bounds.y1, Z2 += v[f] + d[f].margin;
              if (c && 0 < c.length)
                for (f = 0; f < c.length; f++)
                  M = l.isNavigator ? 0 : 10, c[f] && (h2 = Math.round(a[0] ? a[0].lineCoordinates.x1 : d[0].lineCoordinates.x1), M = c[f]._labels && 0 < c[f]._labels.length ? c[f]._labels[c[f]._labels.length - 1].textBlock.height / 2 : p, n2 = Math.round(g.y1 + $ + Y2 < Math.max(M, p) ? Math.max(M, p) : g.y1 + $ + Y2), t2 = Math.round(a[0] ? a[0].lineCoordinates.x1 : d[0].lineCoordinates.x1), M = 0 < a.length ? 0 : c[f]._labels && 0 < c[f]._labels.length ? c[f]._labels[0].textBlock.height / 2 : p, k = Math.round(g.y2 - X2 - e - M), c[f].lineCoordinates = { x1: h2 - U2, y1: n2, x2: t2 - U2, y2: k, height: Math.abs(k - n2) }, "inside" === c[f].labelPlacement && 0 < f && (c[f].lineCoordinates.x1 = c[f - 1].lineCoordinates.x1 - U2 - (c[f].labelEffectiveWidth || 0), c[f].lineCoordinates.x2 = c[f].lineCoordinates.x1 + c[f].lineThickness / 2), "inside" === c[f].tickPlacement && 0 < f && (c[f].lineCoordinates.x1 -= c[f].tickLength, c[f].lineCoordinates.x2 = c[f].lineCoordinates.x1 + c[f].lineThickness / 2), c[f].bounds = { x1: h2 - (D2[f] + U2), y1: n2, x2: t2 - U2, y2: k, height: k - n2 }, c[f].bounds.width = c[f].bounds.x2 - c[f].bounds.x1, c[f].title && (c[f]._titleTextBlock.maxWidth = 0 < c[f].titleMaxWidth && c[f].titleMaxWidth < c[f].lineCoordinates.height ? c[f].titleMaxWidth : c[f].lineCoordinates.height), U2 += D2[f] + c[f].margin);
              if (b && 0 < b.length)
                for (f = 0; f < b.length; f++)
                  b[f] && (h2 = Math.round(a[0] ? a[0].lineCoordinates.x2 : d[0].lineCoordinates.x2), t2 = Math.round(h2), M = b[f]._labels && 0 < b[f]._labels.length ? b[f]._labels[b[f]._labels.length - 1].textBlock.height / 2 : 0, n2 = Math.round(g.y1 + $ + Y2 < Math.max(M, p) ? Math.max(M, p) : g.y1 + $ + Y2), M = 0 < a.length ? 0 : b[f]._labels && 0 < b[f]._labels.length ? b[f]._labels[0].textBlock.height / 2 : 0, k = Math.round(g.y2 - (X2 + e + M)), b[f].lineCoordinates = { x1: h2 + W3, y1: n2, x2: h2 + W3, y2: k, height: Math.abs(k - n2) }, "inside" === b[f].labelPlacement && 0 < f && (b[f].lineCoordinates.x1 = b[f - 1].lineCoordinates.x2 + W3 + (b[f].labelEffectiveWidth || 0), b[f].lineCoordinates.x2 = b[f].lineCoordinates.x1 + b[f].lineThickness / 2), "inside" === b[f].tickPlacement && 0 < f && (b[f].lineCoordinates.x1 += b[f].tickLength, b[f].lineCoordinates.x2 = b[f].lineCoordinates.x1 + b[f].lineThickness / 2), b[f].bounds = { x1: h2 + W3, y1: n2, x2: t2 + (A[f] + W3), y2: k, height: k - n2 }, b[f].bounds.width = b[f].bounds.x2 - b[f].bounds.x1, b[f].title && (b[f]._titleTextBlock.maxWidth = 0 < b[f].titleMaxWidth && b[f].titleMaxWidth < b[f].lineCoordinates.height ? b[f].titleMaxWidth : b[f].lineCoordinates.height), W3 += A[f] + b[f].margin);
              if (a && 0 < a.length)
                for (f = 0; f < a.length; f++)
                  a[f] && (a[f].calculateValueToPixelConversionParameters(), a[f].calculateBreaksSizeInValues(), a[f]._labels && 1 < a[f]._labels.length && (C = (a[f].logarithmic ? Math.log(a[f]._labels[1].position / a[f].viewportMinimum) / a[f].conversionParameters.lnLogarithmBase : a[f]._labels[1].position - a[f].viewportMinimum) * Math.abs(a[f].conversionParameters.pixelPerUnit) + a[f].lineCoordinates.x1, h2 = a[f]._labels[a[f]._labels.length - ("dateTime" === a[f].valueType ? 2 : 1)].position, h2 = a[f].getApparentDifference(a[f].viewportMinimum, h2), E3 = a[f].logarithmic ? (1 < h2 ? Math.log(h2) / a[f].conversionParameters.lnLogarithmBase * Math.abs(a[f].conversionParameters.pixelPerUnit) : 0) + a[f].lineCoordinates.x1 : (0 < h2 ? h2 * Math.abs(a[f].conversionParameters.pixelPerUnit) : 0) + a[f].lineCoordinates.x1));
              if (d && 0 < d.length)
                for (f = 0; f < d.length; f++)
                  d[f].calculateValueToPixelConversionParameters(), d[f].calculateBreaksSizeInValues(), d[f]._labels && 1 < d[f]._labels.length && (C = (d[f].logarithmic ? Math.log(d[f]._labels[1].position / d[f].viewportMinimum) / d[f].conversionParameters.lnLogarithmBase : d[f]._labels[1].position - d[f].viewportMinimum) * Math.abs(d[f].conversionParameters.pixelPerUnit) + d[f].lineCoordinates.x1, h2 = d[f]._labels[d[f]._labels.length - ("dateTime" === d[f].valueType ? 2 : 1)].position, h2 = d[f].getApparentDifference(d[f].viewportMinimum, h2), E3 = d[f].logarithmic ? (1 < h2 ? Math.log(h2) / d[f].conversionParameters.lnLogarithmBase * Math.abs(d[f].conversionParameters.pixelPerUnit) : 0) + d[f].lineCoordinates.x1 : (0 < h2 ? h2 * Math.abs(d[f].conversionParameters.pixelPerUnit) : 0) + d[f].lineCoordinates.x1);
              for (f = 0; f < q.length; f++)
                "axisY" === q[f].type && (q[f].calculateValueToPixelConversionParameters(), q[f].calculateBreaksSizeInValues());
              if (0 < z3) {
                if (a && 0 < a.length)
                  for (f = 0; f < a.length; f++)
                    w3 = O2[z3 - 1][f] === O2[z3][f] ? true : false;
                else
                  w3 = true;
                if (d && 0 < d.length)
                  for (f = 0; f < d.length; f++)
                    K = Q3[z3 - 1][f] === Q3[z3][f] ? true : false;
                else
                  K = true;
                if (c && 0 < c.length)
                  for (f = 0; f < c.length; f++)
                    L2 = P[z3 - 1][f] === P[z3][f] ? true : false;
                else
                  L2 = true;
                if (b && 0 < b.length)
                  for (f = 0; f < b.length; f++)
                    N2 = S2[z3 - 1][f] === S2[z3][f] ? true : false;
                else
                  N2 = true;
              }
              if (w3 && K && L2 && N2)
                break;
              z3++;
            }
            if (a && 0 < a.length)
              for (f = 0; f < a.length; f++)
                a[f].calculateStripLinesThicknessInValues(), a[f].calculateBreaksInPixels();
            if (d && 0 < d.length)
              for (f = 0; f < d.length; f++)
                d[f].calculateStripLinesThicknessInValues(), d[f].calculateBreaksInPixels();
            if (c && 0 < c.length)
              for (f = 0; f < c.length; f++)
                c[f].calculateStripLinesThicknessInValues(), c[f].calculateBreaksInPixels();
            if (b && 0 < b.length)
              for (f = 0; f < b.length; f++)
                b[f].calculateStripLinesThicknessInValues(), b[f].calculateBreaksInPixels();
          } else {
            p = [];
            C = [];
            H2 = [];
            x = [];
            E3 = [];
            s = [];
            O2 = [];
            for (Q3 = []; 4 > z3; ) {
              X2 = W3 = U2 = aa3 = M = Y2 = e = S2 = P = F = $ = 0;
              if (a && 0 < a.length)
                for (H2 = [], f = W3 = 0; f < a.length; f++)
                  H2.push(Math.ceil(a[f] ? a[f].createLabelsAndCalculateWidth() : 0)), W3 += H2[f], e += a[f] && !l.isNavigator ? a[f].margin : 0;
              else
                H2.push(Math.ceil(a[0] ? a[0].createLabelsAndCalculateWidth() : 0));
              O2.push(H2);
              if (d && 0 < d.length)
                for (x = [], f = X2 = 0; f < d.length; f++)
                  x.push(Math.ceil(d[f] ? d[f].createLabelsAndCalculateWidth() : 0)), X2 += x[f], Y2 += d[f] ? d[f].margin : 0;
              else
                x.push(Math.ceil(d[0] ? d[0].createLabelsAndCalculateWidth() : 0));
              Q3.push(x);
              if (c && 0 < c.length)
                for (f = 0; f < c.length; f++)
                  c[f].lineCoordinates = {}, h2 = Math.round(g.x1 + W3 + e), t2 = Math.round(g.x2 - X2 - Y2 > l.width - 10 ? l.width - 10 : g.x2 - X2 - Y2), c[f].labelAutoFit && !m(y) && (0 < !a.length && (h2 = 0 > c[f].labelAngle ? Math.max(h2, y) : 0 === c[f].labelAngle ? Math.max(h2, y / 2) : h2), 0 < !d.length && (t2 = 0 < c[f].labelAngle ? t2 - v / 2 : 0 === c[f].labelAngle ? t2 - v / 2 : t2)), c[f].lineCoordinates.x1 = h2, c[f].lineCoordinates.x2 = t2, c[f].lineCoordinates.width = Math.abs(t2 - h2), c[f].title && (c[f]._titleTextBlock.maxWidth = 0 < c[f].titleMaxWidth && c[f].titleMaxWidth < c[f].lineCoordinates.width ? c[f].titleMaxWidth : c[f].lineCoordinates.width);
              if (b && 0 < b.length)
                for (f = 0; f < b.length; f++)
                  b[f].lineCoordinates = {}, h2 = Math.round(g.x1 + W3 + e), t2 = Math.round(g.x2 - X2 - Y2 > b[f].chart.width - 10 ? b[f].chart.width - 10 : g.x2 - X2 - Y2), b[f] && b[f].labelAutoFit && !m(D2) && (0 < !a.length && (h2 = 0 < b[f].labelAngle ? Math.max(h2, D2) : 0 === b[f].labelAngle ? Math.max(h2, D2 / 2) : h2), 0 < !d.length && (t2 -= A / 2)), b[f].lineCoordinates.x1 = h2, b[f].lineCoordinates.x2 = t2, b[f].lineCoordinates.width = Math.abs(t2 - h2), b[f].title && (b[f]._titleTextBlock.maxWidth = 0 < b[f].titleMaxWidth && b[f].titleMaxWidth < b[f].lineCoordinates.width ? b[f].titleMaxWidth : b[f].lineCoordinates.width);
              if (c && 0 < c.length)
                for (p = [], f = U2 = 0; f < c.length; f++)
                  p.push(Math.ceil(c[f] ? c[f].createLabelsAndCalculateHeight() : 0)), U2 += p[f] + c[f].margin, M += c[f].margin;
              else
                p.push(Math.ceil(c[0] ? c[0].createLabelsAndCalculateHeight() : 0));
              E3.push(p);
              if (b && 0 < b.length)
                for (C = [], f = 0; f < b.length; f++)
                  C.push(Math.ceil(b[f] ? b[f].createLabelsAndCalculateHeight() : 0)), aa3 += b[f].margin;
              else
                C.push(Math.ceil(b[0] ? b[0].createLabelsAndCalculateHeight() : 0));
              s.push(C);
              if (c && 0 < c.length)
                for (f = 0; f < c.length; f++)
                  0 < c[f]._labels.length && (k = c[f]._labels[0], n2 = c[f]._labels[c[f]._labels.length - 1], y = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), v = n2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(n2.textBlock.angle)) + (n2.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(n2.textBlock.angle)));
              if (b && 0 < b.length)
                for (f = 0; f < b.length; f++)
                  b[f] && 0 < b[f]._labels.length && (k = b[f]._labels[0], n2 = b[f]._labels[b[f]._labels.length - 1], D2 = k.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(k.textBlock.angle)) + (k.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(k.textBlock.angle)), A = n2.textBlock.width * Math.cos(Math.PI / 180 * Math.abs(n2.textBlock.angle)) + (n2.textBlock.height - n2.textBlock.fontSize / 2) * Math.sin(Math.PI / 180 * Math.abs(n2.textBlock.angle)));
              if (l.panEnabled)
                for (f = 0; f < c.length; f++)
                  p[f] = m(l.sessionVariables.axisY[f].height) ? l.sessionVariables.axisY[f].height = p[f] : l.sessionVariables.axisY[f].height;
              else
                for (f = 0; f < c.length; f++)
                  l.sessionVariables.axisY[f].height = p[f];
              if (c && 0 < c.length)
                for (f = c.length - 1; 0 <= f; f--)
                  n2 = Math.round(g.y2), k = Math.round(g.y2 > c[f].chart.height ? c[f].chart.height : g.y2), c[f].lineCoordinates.y1 = n2 - (p[f] + c[f].margin + $), c[f].lineCoordinates.y2 = n2 - (p[f] + c[f].margin + $), "inside" === c[f].labelPlacement && 0 < f && (c[f].lineCoordinates.y1 = c[f].lineCoordinates.y1 + p[f] - (c[f]._titleTextBlock ? c[f]._titleTextBlock.height : 0) - c[f].tickLength - (c[f].stripLineLabelEffectiveHeight || 0) - 5, c[f].lineCoordinates.y2 = c[f].lineCoordinates.y1 + c[f].lineThickness / 2), "inside" === c[f].tickPlacement && 0 < f && (c[f].lineCoordinates.y1 += c[f].tickLength, c[f].lineCoordinates.y2 = c[f].lineCoordinates.y1 + c[f].lineThickness / 2), c[f].bounds = { x1: h2, y1: n2 - (p[f] + $ + c[f].margin), x2: t2, y2: k - ($ + c[f].margin), width: t2 - h2, height: p[f] }, c[f].title && (c[f]._titleTextBlock.maxWidth = 0 < c[f].titleMaxWidth && c[f].titleMaxWidth < c[f].lineCoordinates.width ? c[f].titleMaxWidth : c[f].lineCoordinates.width), $ += p[f] + c[f].margin;
              if (b && 0 < b.length)
                for (f = b.length - 1; 0 <= f; f--)
                  b[f] && (n2 = Math.round(g.y1), k = Math.round(g.y1 + (C[f] + b[f].margin + F)), b[f].lineCoordinates.y1 = k, b[f].lineCoordinates.y2 = k, "inside" === b[f].labelPlacement && 0 < f && (b[f].lineCoordinates.y1 = k - C[f] + (b[f]._titleTextBlock ? b[f]._titleTextBlock.height : 0) + b[f].tickLength + (b[f].stripLineLabelEffectiveHeight || 0), b[f].lineCoordinates.y2 = b[f].lineCoordinates.y1 - b[f].lineThickness / 2), "inside" === b[f].tickPlacement && 0 < f && (b[f].lineCoordinates.y1 -= b[f].tickLength, b[f].lineCoordinates.y2 = b[f].lineCoordinates.y1 - b[f].lineThickness / 2), b[f].bounds = { x1: h2, y1: n2 + (b[f].margin + F), x2: t2, y2: k, width: t2 - h2 }, b[f].bounds.height = b[f].bounds.y2 - b[f].bounds.y1, b[f].title && (b[f]._titleTextBlock.maxWidth = 0 < b[f].titleMaxWidth && b[f].titleMaxWidth < b[f].lineCoordinates.width ? b[f].titleMaxWidth : b[f].lineCoordinates.width), F += C[f] + b[f].margin);
              if (a && 0 < a.length)
                for (f = 0; f < a.length; f++) {
                  M = a[f]._labels && 0 < a[f]._labels.length ? a[f]._labels[0].textBlock.fontSize / 2 : 0;
                  h2 = Math.round(g.x1 + e);
                  n2 = b && 0 < b.length ? Math.round(b[0] ? b[0].lineCoordinates.y2 : g.y1 < Math.max(M, 10) ? Math.max(M, 10) : g.y1) : g.y1 < Math.max(M, 10) ? Math.max(M, 10) : g.y1;
                  t2 = Math.round(g.x1 + W3 + e);
                  k = c && 0 < c.length ? Math.round(c[0] ? c[0].lineCoordinates.y1 : g.y2 - U2 > l.height - Math.max(M, 10) ? l.height - Math.max(M, 10) : g.y2 - U2) : g.y2 > l.height - Math.max(M, 10) ? l.height - Math.max(M, 10) : g.y2;
                  if (c && 0 < c.length)
                    for (M = 0; M < c.length; M++)
                      c[M] && c[M].labelAutoFit && (t2 = c[M].lineCoordinates.x1, h2 = 0 > c[M].labelAngle || 0 === c[M].labelAngle ? t2 - W3 : h2);
                  if (b && 0 < b.length)
                    for (M = 0; M < b.length; M++)
                      b[M] && b[M].labelAutoFit && (t2 = b[M].lineCoordinates.x1, h2 = t2 - W3);
                  a[f].lineCoordinates = { x1: t2 - P, y1: n2, x2: t2 - P, y2: k, height: Math.abs(k - n2) };
                  "inside" === a[f].labelPlacement && 0 < f && (a[f].lineCoordinates.x1 = a[f].lineCoordinates.x1 - (H2[f] - (a[f]._titleTextBlock ? a[f]._titleTextBlock.height : 0)) + a[f].tickLength + (a[f].stripLineLabelEffectiveWidth || 0), a[f].lineCoordinates.x2 = a[f].lineCoordinates.x1 + a[f].lineThickness / 2);
                  "inside" === a[f].tickPlacement && 0 < f && (a[f].lineCoordinates.x1 -= a[f].tickLength, a[f].lineCoordinates.x2 = a[f].lineCoordinates.x1 + a[f].lineThickness / 2);
                  a[f].bounds = { x1: t2 - (H2[f] + P), y1: n2, x2: t2 - P, y2: k, height: k - n2 };
                  a[f].bounds.width = a[f].bounds.x2 - a[f].bounds.x1;
                  a[f].title && (a[f]._titleTextBlock.maxWidth = 0 < a[f].titleMaxWidth && a[f].titleMaxWidth < a[f].lineCoordinates.height ? a[f].titleMaxWidth : a[f].lineCoordinates.height);
                  a[f].calculateValueToPixelConversionParameters();
                  a[f].calculateBreaksSizeInValues();
                  P += H2[f] + a[f].margin;
                }
              if (d && 0 < d.length)
                for (f = 0; f < d.length; f++) {
                  M = d[f]._labels && 0 < d[f]._labels.length ? d[f]._labels[0].textBlock.fontSize / 2 : 0;
                  h2 = Math.round(g.x1 - e);
                  n2 = b && 0 < b.length ? Math.round(b[0] ? b[0].lineCoordinates.y2 : g.y1 < Math.max(M, 10) ? Math.max(M, 10) : g.y1) : g.y1 < Math.max(
                    M,
                    10
                  ) ? Math.max(M, 10) : g.y1;
                  t2 = Math.round(g.x2 - X2 - Y2);
                  k = c && 0 < c.length ? Math.round(c[0] ? c[0].lineCoordinates.y1 : g.y2 - U2 > l.height - Math.max(M, 10) ? l.height - Math.max(M, 10) : g.y2 - U2) : g.y2 > l.height - Math.max(M, 10) ? l.height - Math.max(M, 10) : g.y2;
                  if (c && 0 < c.length)
                    for (M = 0; M < c.length; M++)
                      c[M] && c[M].labelAutoFit && (t2 = 0 > c[M].labelAngle ? Math.max(t2, y) : 0 === c[M].labelAngle ? Math.max(t2, y / 2) : t2, h2 = 0 > c[M].labelAngle || 0 === c[M].labelAngle ? t2 - X2 : h2);
                  if (b && 0 < b.length)
                    for (M = 0; M < b.length; M++)
                      b[M] && b[M].labelAutoFit && (t2 = b[M].lineCoordinates.x2, h2 = t2 - X2);
                  d[f].lineCoordinates = { x1: t2 + S2, y1: n2, x2: t2 + S2, y2: k, height: Math.abs(k - n2) };
                  "inside" === d[f].labelPlacement && 0 < f && (d[f].lineCoordinates.x1 = d[f].lineCoordinates.x1 + (x[f] - (d[f]._titleTextBlock ? d[f]._titleTextBlock.height : 0) - 2) - d[f].tickLength - (d[f].stripLineLabelEffectiveWidth || 0), d[f].lineCoordinates.x2 = d[f].lineCoordinates.x1 + d[f].lineThickness / 2);
                  "inside" === d[f].tickPlacement && 0 < f && (d[f].lineCoordinates.x1 += d[f].tickLength, d[f].lineCoordinates.x2 = d[f].lineCoordinates.x1 + d[f].lineThickness / 2);
                  d[f].bounds = { x1: d[f].lineCoordinates.x1, y1: n2, x2: t2 + x[f] + S2, y2: k, width: t2 - h2, height: k - n2 };
                  d[f].bounds.width = d[f].bounds.x2 - d[f].bounds.x1;
                  d[f].title && (d[f]._titleTextBlock.maxWidth = 0 < d[f].titleMaxWidth && d[f].titleMaxWidth < d[f].lineCoordinates.height ? d[f].titleMaxWidth : d[f].lineCoordinates.height);
                  d[f].calculateValueToPixelConversionParameters();
                  d[f].calculateBreaksSizeInValues();
                  S2 += x[f] + d[f].margin;
                }
              for (f = 0; f < q.length; f++)
                "axisY" === q[f].type && (q[f].calculateValueToPixelConversionParameters(), q[f].calculateBreaksSizeInValues());
              if (0 < z3) {
                if (a && 0 < a.length)
                  for (f = 0; f < a.length; f++)
                    w3 = O2[z3 - 1][f] === O2[z3][f] ? true : false;
                else
                  w3 = true;
                if (d && 0 < d.length)
                  for (f = 0; f < d.length; f++)
                    K = Q3[z3 - 1][f] === Q3[z3][f] ? true : false;
                else
                  K = true;
                if (c && 0 < c.length)
                  for (f = 0; f < c.length; f++)
                    L2 = E3[z3 - 1][f] === E3[z3][f] ? true : false;
                else
                  L2 = true;
                if (b && 0 < b.length)
                  for (f = 0; f < b.length; f++)
                    N2 = s[z3 - 1][f] === s[z3][f] ? true : false;
                else
                  N2 = true;
              }
              if (w3 && K && L2 && N2)
                break;
              z3++;
            }
            if (c && 0 < c.length)
              for (f = 0; f < c.length; f++)
                c[f].calculateStripLinesThicknessInValues(), c[f].calculateBreaksInPixels();
            if (b && 0 < b.length)
              for (f = 0; f < b.length; f++)
                b[f].calculateStripLinesThicknessInValues(), b[f].calculateBreaksInPixels();
            if (a && 0 < a.length)
              for (f = 0; f < a.length; f++)
                a[f].calculateStripLinesThicknessInValues(), a[f].calculateBreaksInPixels();
            if (d && 0 < d.length)
              for (f = 0; f < d.length; f++)
                d[f].calculateStripLinesThicknessInValues(), d[f].calculateBreaksInPixels();
          }
        };
        D.render = function(a, d, c, b, e) {
          var g = a[0] ? a[0].chart : d[0].chart;
          e = g.ctx;
          g.alignVerticalAxes && g.alignVerticalAxes();
          e.save();
          e.beginPath();
          a && a.length && e.rect(5, a[0].bounds.y1, a[0].chart.width - 10, a[a.length - 1].bounds.y2);
          d && d.length && e.rect(
            5,
            d[d.length - 1].bounds.y1,
            d[0].chart.width - 10,
            d[0].bounds.y2
          );
          e.clip();
          if (a && 0 < a.length)
            for (var h2 = 0; h2 < a.length; h2++)
              a[h2].renderLabelsTicksAndTitle();
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderLabelsTicksAndTitle();
          e.restore();
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderLabelsTicksAndTitle();
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderLabelsTicksAndTitle();
          g.preparePlotArea();
          g = g.plotArea;
          e.save();
          e.beginPath();
          e.rect(g.x1, g.y1, Math.abs(g.x2 - g.x1), Math.abs(g.y2 - g.y1));
          e.clip();
          if (a && 0 < a.length)
            for (h2 = 0; h2 < a.length; h2++)
              a[h2].renderStripLinesOfThicknessType("value");
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderStripLinesOfThicknessType("value");
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderStripLinesOfThicknessType("value");
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderStripLinesOfThicknessType("value");
          if (a && 0 < a.length)
            for (h2 = 0; h2 < a.length; h2++)
              a[h2].renderInterlacedColors();
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderInterlacedColors();
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderInterlacedColors();
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderInterlacedColors();
          e.restore();
          if (a && 0 < a.length)
            for (h2 = 0; h2 < a.length; h2++)
              a[h2].renderGrid(), t && (a[h2].createMask(), a[h2].renderBreaksBackground());
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderGrid(), t && (d[h2].createMask(), d[h2].renderBreaksBackground());
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderGrid(), t && (c[h2].createMask(), c[h2].renderBreaksBackground());
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderGrid(), t && (b[h2].createMask(), b[h2].renderBreaksBackground());
          if (a && 0 < a.length)
            for (h2 = 0; h2 < a.length; h2++)
              a[h2].renderAxisLine();
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderAxisLine();
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderAxisLine();
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderAxisLine();
          if (a && 0 < a.length)
            for (h2 = 0; h2 < a.length; h2++)
              a[h2].renderStripLinesOfThicknessType("pixel");
          if (d && 0 < d.length)
            for (h2 = 0; h2 < d.length; h2++)
              d[h2].renderStripLinesOfThicknessType("pixel");
          if (c && 0 < c.length)
            for (h2 = 0; h2 < c.length; h2++)
              c[h2].renderStripLinesOfThicknessType("pixel");
          if (b && 0 < b.length)
            for (h2 = 0; h2 < b.length; h2++)
              b[h2].renderStripLinesOfThicknessType("pixel");
        };
        D.prototype.calculateStripLinesThicknessInValues = function() {
          for (var a = 0; a < this.stripLines.length; a++)
            if (null !== this.stripLines[a].startValue && null !== this.stripLines[a].endValue) {
              var d = Math.min(this.stripLines[a].startValue, this.stripLines[a].endValue), c = Math.max(this.stripLines[a].startValue, this.stripLines[a].endValue), b = this.getApparentDifference(d, c);
              this.stripLines[a].value = this.convertPixelToValue(Math.abs(this.convertValueToPixel(d) + this.convertValueToPixel(c)) / 2);
              this.stripLines[a].thickness = b;
              this.stripLines[a]._thicknessType = "value";
            }
        };
        D.prototype.calculateBreaksSizeInValues = function() {
          for (var a = "left" === this._position || "right" === this._position ? this.lineCoordinates.height || this.chart.height : this.lineCoordinates.width || this.chart.width, d = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], c = this.conversionParameters.pixelPerUnit || a / (this.logarithmic ? this.conversionParameters.maximum / this.conversionParameters.minimum : this.conversionParameters.maximum - this.conversionParameters.minimum), b = this.scaleBreaks && !m(this.scaleBreaks.options.spacing), e, g = 0; g < d.length; g++)
            e = b || !m(d[g].options.spacing), d[g].spacing = Ta(d[g].spacing, a, 8, e ? 0.1 * a : 8, e ? 0 : 3) << 0, d[g].size = 0 > d[g].spacing ? 0 : Math.abs(d[g].spacing / c), this.logarithmic && (d[g].size = Math.pow(this.logarithmBase, d[g].size));
        };
        D.prototype.calculateBreaksInPixels = function() {
          if (!(this.scaleBreaks && 0 >= this.scaleBreaks._appliedBreaks.length)) {
            var a = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
            a.length && (this.scaleBreaks.firstBreakIndex = this.scaleBreaks.lastBreakIndex = null);
            for (var d = 0; d < a.length && !(a[d].startValue > this.conversionParameters.maximum); d++)
              a[d].endValue < this.conversionParameters.minimum || (m(this.scaleBreaks.firstBreakIndex) && (this.scaleBreaks.firstBreakIndex = d), a[d].startValue >= this.conversionParameters.minimum && (a[d].startPixel = this.convertValueToPixel(a[d].startValue), this.scaleBreaks.lastBreakIndex = d), a[d].endValue <= this.conversionParameters.maximum && (a[d].endPixel = this.convertValueToPixel(a[d].endValue)));
          }
        };
        D.prototype.renderLabelsTicksAndTitle = function() {
          var a = this, d = false, c = 0, b = 0, e = 1, g = 0;
          0 !== this.labelAngle && 360 !== this.labelAngle && (e = 1.2);
          if ("undefined" === typeof this.options.interval) {
            if ("bottom" === this._position || "top" === this._position)
              if (this.logarithmic && !this.equidistantInterval && this.labelAutoFit) {
                for (var c = [], e = 0 !== this.labelAngle && 360 !== this.labelAngle ? 1 : 1.2, h2, m2 = this.viewportMaximum, n2 = this.lineCoordinates.width / Math.log(this.range), k = this._labels.length - 1; 0 <= k; k--) {
                  p = this._labels[k];
                  if (p.position < this.viewportMinimum)
                    break;
                  p.position > this.viewportMaximum || !(k === this._labels.length - 1 || h2 < Math.log(m2 / p.position) * n2 / e) || (c.push(p), m2 = p.position, h2 = p.textBlock.width * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.height * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)));
                }
                this._labels = c;
              } else {
                for (k = 0; k < this._labels.length; k++)
                  p = this._labels[k], p.position < this.viewportMinimum || (h2 = p.textBlock.width * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.height * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)), c += h2);
                c > this.lineCoordinates.width * e && this.labelAutoFit && (d = true);
              }
            if ("left" === this._position || "right" === this._position)
              if (this.logarithmic && !this.equidistantInterval && this.labelAutoFit) {
                for (var c = [], l, m2 = this.viewportMaximum, n2 = this.lineCoordinates.height / Math.log(this.range), k = this._labels.length - 1; 0 <= k; k--) {
                  p = this._labels[k];
                  if (p.position < this.viewportMinimum)
                    break;
                  p.position > this.viewportMaximum || !(k === this._labels.length - 1 || l < Math.log(m2 / p.position) * n2) || (c.push(p), m2 = p.position, l = p.textBlock.height * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.width * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)));
                }
                this._labels = c;
              } else {
                for (k = 0; k < this._labels.length; k++)
                  p = this._labels[k], p.position < this.viewportMinimum || (l = p.textBlock.height * Math.abs(Math.cos(Math.PI / 180 * this.labelAngle)) + p.textBlock.width * Math.abs(Math.sin(Math.PI / 180 * this.labelAngle)), b += l);
                b > this.lineCoordinates.height * e && this.labelAutoFit && (d = true);
              }
          }
          this.logarithmic && (!this.equidistantInterval && this.labelAutoFit) && this._labels.sort(function(a2, b2) {
            return a2.position - b2.position;
          });
          var k = 0, p, q;
          if ("bottom" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0, this.ctx.beginPath(), this.ctx.moveTo(b, q.y << 0), this.ctx.lineTo(b, q.y + this.tickLength << 0), this.ctx.stroke()), d && 0 !== g++ % 2 && this.labelAutoFit || (0 === p.textBlock.angle ? (q.x -= p.textBlock.width / 2, q.y = "inside" === this.labelPlacement ? q.y - (("inside" === this.tickPlacement ? this.tickLength : 0) + p.textBlock.height - p.textBlock.fontSize / 2) : q.y + ("inside" === this.tickPlacement ? 0 : this.tickLength) + p.textBlock.fontSize / 2 + 5) : (q.x = "inside" === this.labelPlacement ? 0 > this.labelAngle ? q.x : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : q.x - (0 > this.labelAngle ? p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), q.y = "inside" === this.labelPlacement ? 0 > this.labelAngle ? q.y - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : q.y - ("inside" === this.tickPlacement ? this.tickLength : 0) - Math.abs(p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) + 5) : q.y + ("inside" === this.tickPlacement ? 0 : this.tickLength) + Math.abs(0 > this.labelAngle ? p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) - 5 : 5)), p.textBlock.x = q.x, p.textBlock.y = q.y));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(b2, q.y << 0);
                  a.ctx.lineTo(b2, q.y - a.tickLength << 0);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.lineCoordinates.x1 + this.lineCoordinates.width / 2 - this._titleTextBlock.width / 2, this._titleTextBlock.y = this.bounds.y2 - this._titleTextBlock.height + this._titleTextBlock.fontSize / 2 - 1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("top" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0, this.ctx.beginPath(), this.ctx.moveTo(b, q.y << 0), this.ctx.lineTo(b, q.y - this.tickLength << 0), this.ctx.stroke()), d && 0 !== g++ % 2 && this.labelAutoFit || (0 === p.textBlock.angle ? (q.x -= p.textBlock.width / 2, q.y = "inside" === this.labelPlacement ? q.y + this.labelFontSize / 2 + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - (("inside" === this.tickPlacement ? 0 : this.tickLength) + p.textBlock.height - p.textBlock.fontSize / 2)) : (q.x = "inside" === this.labelPlacement ? 0 < this.labelAngle ? q.x : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : q.x + (p.textBlock.height - this.labelFontSize) * Math.sin(Math.PI / 180 * this.labelAngle) - (0 < this.labelAngle ? p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), q.y = "inside" === this.labelPlacement ? 0 < this.labelAngle ? q.y + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.y - (("inside" === this.tickPlacement ? 0 : this.tickLength) + ((p.textBlock.height - p.textBlock.fontSize / 2) * Math.cos(Math.PI / 180 * this.labelAngle) + (0 < this.labelAngle ? p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0)))), p.textBlock.x = q.x, p.textBlock.y = q.y));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.x << 0) + 0.5 : q.x << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(b2, q.y << 0);
                  a.ctx.lineTo(b2, q.y + a.tickLength << 0);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.lineCoordinates.x1 + this.lineCoordinates.width / 2 - this._titleTextBlock.width / 2, this._titleTextBlock.y = this.bounds.y1 + this._titleTextBlock.fontSize / 2 + 1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("left" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0, this.ctx.beginPath(), this.ctx.moveTo(q.x << 0, b), this.ctx.lineTo(q.x - this.tickLength << 0, b), this.ctx.stroke()), d && 0 !== g++ % 2 && this.labelAutoFit || (0 === this.labelAngle ? (p.textBlock.y = q.y, p.textBlock.x = "inside" === this.labelPlacement ? q.x + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength) - 5) : (p.textBlock.y = "inside" === this.labelPlacement ? q.y : q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle), p.textBlock.x = "inside" === this.labelPlacement ? q.x + ("inside" === this.tickPlacement ? this.tickLength : 0) + 5 : 0 < this.labelAngle ? q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength) - 5 : q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) + (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? 0 : this.tickLength))));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(q.x << 0, b2);
                  a.ctx.lineTo(q.x + a.tickLength << 0, b2);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.bounds.x1 + this._titleTextBlock.fontSize / 2 + 1, this._titleTextBlock.y = this.lineCoordinates.height / 2 + this._titleTextBlock.width / 2 + this.lineCoordinates.y1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          } else if ("right" === this._position) {
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || p.position > this.viewportMaximum || (q = this.getPixelCoordinatesOnAxis(p.position), this.tickThickness && "inside" != this.tickPlacement && (this.ctx.lineWidth = this.tickThickness, this.ctx.strokeStyle = this.tickColor, b = 1 === this.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0, this.ctx.beginPath(), this.ctx.moveTo(q.x << 0, b), this.ctx.lineTo(q.x + this.tickLength << 0, b), this.ctx.stroke()), d && 0 !== g++ % 2 && this.labelAutoFit || (0 === this.labelAngle ? (p.textBlock.y = q.y, p.textBlock.x = "inside" === this.labelPlacement ? q.x - p.textBlock.width - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : q.x + ("inside" === this.tickPlacement ? 0 : this.tickLength) + 5) : (p.textBlock.y = "inside" === this.labelPlacement ? q.y - p.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0 > this.labelAngle ? q.y : q.y - (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.cos(Math.PI / 180 * this.labelAngle), p.textBlock.x = "inside" === this.labelPlacement ? q.x - p.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - ("inside" === this.tickPlacement ? this.tickLength : 0) - 5 : 0 < this.labelAngle ? q.x + (p.textBlock.height - p.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) + ("inside" === this.tickPlacement ? 0 : this.tickLength) : q.x + ("inside" === this.tickPlacement ? 0 : this.tickLength) + 5)));
            "inside" === this.tickPlacement && this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                if (p = a._labels[k], !(p.position < a.viewportMinimum || p.position > a.viewportMaximum) && (q = a.getPixelCoordinatesOnAxis(p.position), a.tickThickness)) {
                  a.ctx.lineWidth = a.tickThickness;
                  a.ctx.strokeStyle = a.tickColor;
                  var b2 = 1 === a.ctx.lineWidth % 2 ? (q.y << 0) + 0.5 : q.y << 0;
                  a.ctx.save();
                  a.ctx.beginPath();
                  a.ctx.moveTo(q.x << 0, b2);
                  a.ctx.lineTo(q.x - a.tickLength << 0, b2);
                  a.ctx.stroke();
                  a.ctx.restore();
                }
            }, this);
            this.title && (this._titleTextBlock.measureText(), this._titleTextBlock.x = this.bounds.x2 - this._titleTextBlock.fontSize / 2 - 1, this._titleTextBlock.y = this.lineCoordinates.height / 2 - this._titleTextBlock.width / 2 + this.lineCoordinates.y1, this.titleMaxWidth = this._titleTextBlock.maxWidth, this._titleTextBlock.render(true));
          }
          g = 0;
          if ("inside" === this.labelPlacement)
            this.chart.addEventListener("dataAnimationIterationEnd", function() {
              for (k = 0; k < a._labels.length; k++)
                p = a._labels[k], p.position < a.viewportMinimum || (p.position > a.viewportMaximum || d && 0 !== g++ % 2 && a.labelAutoFit) || (a.ctx.save(), a.ctx.beginPath(), p.textBlock.render(true), a.ctx.restore());
            }, this);
          else
            for (k = 0; k < this._labels.length; k++)
              p = this._labels[k], p.position < this.viewportMinimum || (p.position > this.viewportMaximum || d && 0 !== g++ % 2 && this.labelAutoFit) || p.textBlock.render(true);
        };
        D.prototype.renderInterlacedColors = function() {
          var a = this.chart.plotArea.ctx, d, c, b = this.chart.plotArea, e = 0;
          d = true;
          if (("bottom" === this._position || "top" === this._position) && this.interlacedColor)
            for (a.fillStyle = this.interlacedColor, e = 0; e < this._labels.length; e++)
              d ? (d = this.getPixelCoordinatesOnAxis(this._labels[e].position), c = e + 1 > this._labels.length - 1 ? this.getPixelCoordinatesOnAxis(this.viewportMaximum) : this.getPixelCoordinatesOnAxis(this._labels[e + 1].position), a.fillRect(Math.min(c.x, d.x), b.y1, Math.abs(c.x - d.x), Math.abs(b.y1 - b.y2)), d = false) : d = true;
          else if (("left" === this._position || "right" === this._position) && this.interlacedColor)
            for (a.fillStyle = this.interlacedColor, e = 0; e < this._labels.length; e++)
              d ? (c = this.getPixelCoordinatesOnAxis(this._labels[e].position), d = e + 1 > this._labels.length - 1 ? this.getPixelCoordinatesOnAxis(this.viewportMaximum) : this.getPixelCoordinatesOnAxis(this._labels[e + 1].position), a.fillRect(b.x1, Math.min(c.y, d.y), Math.abs(b.x1 - b.x2), Math.abs(d.y - c.y)), d = false) : d = true;
          a.beginPath();
        };
        D.prototype.renderStripLinesOfThicknessType = function(a) {
          if (this.stripLines && 0 < this.stripLines.length && a) {
            var d = this, c, b, e = 0, g = 0, h2 = false;
            b = false;
            for (var n2 = [], t2 = [], k = false, e = 0; e < this.stripLines.length; e++) {
              var l = this.stripLines[e];
              l._thicknessType === a && ("pixel" === a && (l.value < this.viewportMinimum || l.value > this.viewportMaximum || m(l.value) || isNaN(this.range)) || "value" === a && (l.startValue <= this.viewportMinimum && l.endValue <= this.viewportMinimum || l.startValue >= this.viewportMaximum && l.endValue >= this.viewportMaximum || m(l.startValue) || m(l.endValue) || isNaN(this.range)) || n2.push(l));
            }
            for (e = 0; e < this._stripLineLabels.length; e++)
              if (l = this.stripLines[e], c = this._stripLineLabels[e], !(c.position < this.viewportMinimum || c.position > this.viewportMaximum || isNaN(this.range)))
                if (b = this.getPixelCoordinatesOnAxis(c.position), "outside" === c.stripLine.labelPlacement) {
                  l && (this.ctx.strokeStyle = l.color, this.ctx.lineWidth = "pixel" === l._thicknessType ? l.thickness : this.tickThickness);
                  if ("bottom" === this._position) {
                    var p = 1 === this.ctx.lineWidth % 2 ? (b.x << 0) + 0.5 : b.x << 0;
                    this.ctx.beginPath();
                    this.ctx.moveTo(p, b.y << 0);
                    this.ctx.lineTo(p, b.y + this.tickLength << 0);
                    this.ctx.stroke();
                    0 === this.labelAngle ? (b.x -= c.textBlock.width / 2, b.y += this.tickLength + c.textBlock.fontSize / 2 + 5) : (b.x -= 0 > this.labelAngle ? c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0, b.y += this.tickLength + Math.abs(0 > this.labelAngle ? c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) - 5 : 5));
                  } else
                    "top" === this._position ? (p = 1 === this.ctx.lineWidth % 2 ? (b.x << 0) + 0.5 : b.x << 0, this.ctx.beginPath(), this.ctx.moveTo(p, b.y << 0), this.ctx.lineTo(p, b.y - this.tickLength << 0), this.ctx.stroke(), 0 === this.labelAngle ? (b.x -= c.textBlock.width / 2, b.y -= this.tickLength + c.textBlock.height - c.textBlock.fontSize / 2) : (b.x += (c.textBlock.height - this.tickLength - this.labelFontSize / 2) * Math.sin(Math.PI / 180 * this.labelAngle) - (0 < this.labelAngle ? c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) : 0), b.y -= this.tickLength + (c.textBlock.height * Math.cos(Math.PI / 180 * this.labelAngle) + (0 < this.labelAngle ? c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle) : 0)))) : "left" === this._position ? (p = 1 === this.ctx.lineWidth % 2 ? (b.y << 0) + 0.5 : b.y << 0, this.ctx.beginPath(), this.ctx.moveTo(b.x << 0, p), this.ctx.lineTo(b.x - this.tickLength << 0, p), this.ctx.stroke(), 0 === this.labelAngle ? b.x = b.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - this.tickLength - 5 : (b.y -= c.textBlock.width * Math.sin(Math.PI / 180 * this.labelAngle), b.x = 0 < this.labelAngle ? b.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) - this.tickLength - 5 : b.x - c.textBlock.width * Math.cos(Math.PI / 180 * this.labelAngle) + (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) - this.tickLength)) : "right" === this._position && (p = 1 === this.ctx.lineWidth % 2 ? (b.y << 0) + 0.5 : b.y << 0, this.ctx.beginPath(), this.ctx.moveTo(b.x << 0, p), this.ctx.lineTo(b.x + this.tickLength << 0, p), this.ctx.stroke(), 0 === this.labelAngle ? b.x = b.x + this.tickLength + 5 : (b.y = 0 > this.labelAngle ? b.y : b.y - (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.cos(Math.PI / 180 * this.labelAngle), b.x = 0 < this.labelAngle ? b.x + (c.textBlock.height - c.textBlock.fontSize / 2 - 5) * Math.sin(Math.PI / 180 * this.labelAngle) + this.tickLength : b.x + this.tickLength + 5));
                  c.textBlock.x = b.x;
                  c.textBlock.y = b.y;
                  t2.push(c);
                } else
                  l._thicknessType === a && (c.textBlock.angle = -90, "bottom" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[e].labelMaxWidth ? this.options.stripLines[e].labelMaxWidth : this.chart.plotArea.height - 3, c.textBlock.measureText(), b.x - c.textBlock.height - l.thickness / 2 > this.chart.plotArea.x1 ? m(l.startValue) ? b.x -= c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.x -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : (c.textBlock.angle = 90, m(l.startValue) ? b.x += c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.x += c.textBlock.height / 2 - c.textBlock.fontSize / 2), b.y = -90 === c.textBlock.angle ? "near" === c.stripLine.labelAlign ? this.chart.plotArea.y2 - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 + c.textBlock.width) / 2 : this.chart.plotArea.y1 + c.textBlock.width + 3 : "near" === c.stripLine.labelAlign ? this.chart.plotArea.y2 - c.textBlock.width - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 - c.textBlock.width) / 2 : this.chart.plotArea.y1 + 3) : "top" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[e].labelMaxWidth ? this.options.stripLines[e].labelMaxWidth : this.chart.plotArea.height - 3, c.textBlock.measureText(), b.x - c.textBlock.height - l.thickness / 2 > this.chart.plotArea.x1 ? m(l.startValue) ? b.x -= c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.x -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : (c.textBlock.angle = 90, m(l.startValue) ? b.x += c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.x += c.textBlock.height / 2 - c.textBlock.fontSize / 2), b.y = -90 === c.textBlock.angle ? "near" === c.stripLine.labelAlign ? this.chart.plotArea.y1 + c.textBlock.width + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 + c.textBlock.width) / 2 : this.chart.plotArea.y2 - 3 : "near" === c.stripLine.labelAlign ? this.chart.plotArea.y1 + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.y2 + this.chart.plotArea.y1 - c.textBlock.width) / 2 : this.chart.plotArea.y2 - c.textBlock.width - 3) : "left" === this._position ? (c.textBlock.maxWidth = this.options.stripLines[e].labelMaxWidth ? this.options.stripLines[e].labelMaxWidth : this.chart.plotArea.width - 3, c.textBlock.angle = 0, c.textBlock.measureText(), b.y - c.textBlock.height - l.thickness / 2 > this.chart.plotArea.y1 ? m(l.startValue) ? b.y -= c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : m(l.startValue) ? b.y += c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.y += c.textBlock.height / 2 - c.textBlock.fontSize + 3, b.x = "near" === c.stripLine.labelAlign ? this.chart.plotArea.x1 + 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.x2 + this.chart.plotArea.x1) / 2 - c.textBlock.width / 2 : this.chart.plotArea.x2 - c.textBlock.width - 3) : "right" === this._position && (c.textBlock.maxWidth = this.options.stripLines[e].labelMaxWidth ? this.options.stripLines[e].labelMaxWidth : this.chart.plotArea.width - 3, c.textBlock.angle = 0, c.textBlock.measureText(), b.y - c.textBlock.height - l.thickness / 2 > this.chart.plotArea.y1 ? m(l.startValue) ? b.y -= c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 : m(l.startValue) ? b.y += c.textBlock.height - c.textBlock.fontSize / 2 + l.thickness / 2 : b.y -= c.textBlock.height / 2 - c.textBlock.fontSize / 2 + 3, b.x = "near" === c.stripLine.labelAlign ? this.chart.plotArea.x2 - c.textBlock.width - 3 : "center" === c.stripLine.labelAlign ? (this.chart.plotArea.x2 + this.chart.plotArea.x1) / 2 - c.textBlock.width / 2 : this.chart.plotArea.x1 + 3), c.textBlock.x = b.x, c.textBlock.y = b.y, t2.push(c));
            if (!k) {
              b = false;
              this.ctx.save();
              this.ctx.beginPath();
              this.ctx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
              this.ctx.clip();
              for (e = 0; e < n2.length; e++)
                l = n2[e], l.showOnTop ? h2 || (h2 = true, this.chart.addEventListener("dataAnimationIterationEnd", function() {
                  this.ctx.save();
                  this.ctx.beginPath();
                  this.ctx.rect(
                    this.chart.plotArea.x1,
                    this.chart.plotArea.y1,
                    this.chart.plotArea.width,
                    this.chart.plotArea.height
                  );
                  this.ctx.clip();
                  for (g = 0; g < n2.length; g++)
                    l = n2[g], l.showOnTop && l.render();
                  this.ctx.restore();
                }, l)) : l.render();
              for (e = 0; e < t2.length; e++)
                c = t2[e], c.stripLine.showOnTop ? b || (b = true, this.chart.addEventListener("dataAnimationIterationEnd", function() {
                  for (g = 0; g < t2.length; g++)
                    c = t2[g], "inside" === c.stripLine.labelPlacement && c.stripLine.showOnTop && (d.ctx.save(), d.ctx.beginPath(), d.ctx.rect(d.chart.plotArea.x1, d.chart.plotArea.y1, d.chart.plotArea.width, d.chart.plotArea.height), d.ctx.clip(), c.textBlock.render(true), d.ctx.restore());
                }, c.textBlock)) : "inside" === c.stripLine.labelPlacement && c.textBlock.render(true);
              this.ctx.restore();
              k = true;
            }
            if (k)
              for (b = false, e = 0; e < t2.length; e++)
                c = t2[e], "outside" === c.stripLine.labelPlacement && c.textBlock.render(true);
          }
        };
        D.prototype.renderBreaksBackground = function() {
          this.chart._breaksCanvas && (this.scaleBreaks && 0 < this.scaleBreaks._appliedBreaks.length && this.maskCanvas) && (this.chart._breaksCanvasCtx.save(), this.chart._breaksCanvasCtx.beginPath(), this.chart._breaksCanvasCtx.rect(
            this.chart.plotArea.x1,
            this.chart.plotArea.y1,
            this.chart.plotArea.width,
            this.chart.plotArea.height
          ), this.chart._breaksCanvasCtx.clip(), this.chart._breaksCanvasCtx.drawImage(this.maskCanvas, 0, 0, this.chart.width, this.chart.height), this.chart._breaksCanvasCtx.restore());
        };
        D.prototype.createMask = function() {
          if (this.scaleBreaks && 0 < this.scaleBreaks._appliedBreaks.length) {
            var a = this.scaleBreaks._appliedBreaks;
            t ? (this.maskCanvas = wa(this.chart.width, this.chart.height), this.maskCtx = this.maskCanvas.getContext("2d")) : (this.maskCanvas = this.chart.plotArea.canvas, this.maskCtx = this.chart.plotArea.ctx);
            this.maskCtx.save();
            this.maskCtx.beginPath();
            this.maskCtx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
            this.maskCtx.clip();
            for (var d = 0; d < a.length; d++)
              a[d].endValue < this.viewportMinimum || (a[d].startValue > this.viewportMaximum || isNaN(this.range)) || a[d].render(this.maskCtx);
            this.maskCtx.restore();
          }
        };
        D.prototype.renderCrosshair = function(a, d) {
          isFinite(this.minimum) && isFinite(this.maximum) && this.crosshair.render(a, d);
        };
        D.prototype.showCrosshair = function(a) {
          m(a) || (a < this.viewportMinimum || a > this.viewportMaximum) || ("top" === this._position || "bottom" === this._position ? this.crosshair.render(this.convertValueToPixel(a), null, a) : this.crosshair.render(null, this.convertValueToPixel(a), a));
        };
        D.prototype.renderGrid = function() {
          if (this.gridThickness && 0 < this.gridThickness) {
            var a = this.chart.ctx;
            a.save();
            var d, c = this.chart.plotArea;
            a.lineWidth = this.gridThickness;
            a.strokeStyle = this.gridColor;
            a.setLineDash && a.setLineDash(H(this.gridDashType, this.gridThickness));
            if ("bottom" === this._position || "top" === this._position)
              for (b = 0; b < this._labels.length; b++)
                this._labels[b].position < this.viewportMinimum || (this._labels[b].position > this.viewportMaximum || this._labels[b].breaksLabelType) || (a.beginPath(), d = this.getPixelCoordinatesOnAxis(this._labels[b].position), d = 1 === a.lineWidth % 2 ? (d.x << 0) + 0.5 : d.x << 0, a.moveTo(d, c.y1 << 0), a.lineTo(d, c.y2 << 0), a.stroke());
            else if ("left" === this._position || "right" === this._position)
              for (var b = 0; b < this._labels.length; b++)
                this._labels[b].position < this.viewportMinimum || (this._labels[b].position > this.viewportMaximum || this._labels[b].breaksLabelType) || (a.beginPath(), d = this.getPixelCoordinatesOnAxis(this._labels[b].position), d = 1 === a.lineWidth % 2 ? (d.y << 0) + 0.5 : d.y << 0, a.moveTo(c.x1 << 0, d), a.lineTo(c.x2 << 0, d), a.stroke());
            a.restore();
          }
        };
        D.prototype.renderAxisLine = function() {
          var a = this.chart.ctx, d = t ? this.chart._preRenderCtx : a, c = Math.ceil(this.tickThickness / (this.reversed ? -2 : 2)), b = Math.ceil(this.tickThickness / (this.reversed ? 2 : -2)), e, g;
          d.save();
          if ("bottom" === this._position || "top" === this._position) {
            if (this.lineThickness) {
              this.reversed ? (e = this.lineCoordinates.x2, g = this.lineCoordinates.x1) : (e = this.lineCoordinates.x1, g = this.lineCoordinates.x2);
              d.lineWidth = this.lineThickness;
              d.strokeStyle = this.lineColor ? this.lineColor : "black";
              d.setLineDash && d.setLineDash(H(this.lineDashType, this.lineThickness));
              var h2 = 1 === this.lineThickness % 2 ? (this.lineCoordinates.y1 << 0) + 0.5 : this.lineCoordinates.y1 << 0;
              d.beginPath();
              if (this.scaleBreaks && !m(this.scaleBreaks.firstBreakIndex))
                if (m(this.scaleBreaks.lastBreakIndex))
                  e = this.scaleBreaks._appliedBreaks[this.scaleBreaks.firstBreakIndex].endPixel + b;
                else
                  for (var n2 = this.scaleBreaks.firstBreakIndex; n2 <= this.scaleBreaks.lastBreakIndex; n2++)
                    d.moveTo(e, h2), d.lineTo(this.scaleBreaks._appliedBreaks[n2].startPixel + c, h2), e = this.scaleBreaks._appliedBreaks[n2].endPixel + b;
              e && (d.moveTo(e, h2), d.lineTo(g, h2));
              d.stroke();
            }
          } else if (("left" === this._position || "right" === this._position) && this.lineThickness) {
            this.reversed ? (e = this.lineCoordinates.y1, g = this.lineCoordinates.y2) : (e = this.lineCoordinates.y2, g = this.lineCoordinates.y1);
            d.lineWidth = this.lineThickness;
            d.strokeStyle = this.lineColor;
            d.setLineDash && d.setLineDash(H(this.lineDashType, this.lineThickness));
            h2 = 1 === this.lineThickness % 2 ? (this.lineCoordinates.x1 << 0) + 0.5 : this.lineCoordinates.x1 << 0;
            d.beginPath();
            if (this.scaleBreaks && !m(this.scaleBreaks.firstBreakIndex))
              if (m(this.scaleBreaks.lastBreakIndex))
                e = this.scaleBreaks._appliedBreaks[this.scaleBreaks.firstBreakIndex].endPixel + c;
              else
                for (n2 = this.scaleBreaks.firstBreakIndex; n2 <= this.scaleBreaks.lastBreakIndex; n2++)
                  d.moveTo(h2, e), d.lineTo(h2, this.scaleBreaks._appliedBreaks[n2].startPixel + b), e = this.scaleBreaks._appliedBreaks[n2].endPixel + c;
            e && (d.moveTo(h2, e), d.lineTo(h2, g));
            d.stroke();
          }
          t && (a.drawImage(this.chart._preRenderCanvas, 0, 0, this.chart.width, this.chart.height), this.chart._breaksCanvasCtx && this.chart._breaksCanvasCtx.drawImage(this.chart._preRenderCanvas, 0, 0, this.chart.width, this.chart.height), d.clearRect(
            0,
            0,
            this.chart.width,
            this.chart.height
          ));
          d.restore();
        };
        D.prototype.getPixelCoordinatesOnAxis = function(a) {
          var d = {};
          if ("bottom" === this._position || "top" === this._position)
            d.x = this.convertValueToPixel(a), d.y = this.lineCoordinates.y1;
          if ("left" === this._position || "right" === this._position)
            d.y = this.convertValueToPixel(a), d.x = this.lineCoordinates.x2;
          return d;
        };
        D.prototype.convertPixelToValue = function(a) {
          if ("undefined" === typeof a)
            return null;
          var d = 0, c = 0, b, d = true, e = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [], c = "number" === typeof a ? a : "left" === this._position || "right" === this._position ? a.y : a.x;
          if (this.logarithmic) {
            a = b = Math.pow(this.logarithmBase, (c - this.conversionParameters.reference) / this.conversionParameters.pixelPerUnit);
            if (c <= this.conversionParameters.reference === ("left" === this._position || "right" === this._position) !== this.reversed)
              for (c = 0; c < e.length; c++) {
                if (!(e[c].endValue < this.conversionParameters.minimum))
                  if (d)
                    if (e[c].startValue < this.conversionParameters.minimum) {
                      if (1 < e[c].size && this.conversionParameters.minimum * Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size)) < e[c].endValue) {
                        a = Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size));
                        break;
                      } else
                        a *= e[c].endValue / this.conversionParameters.minimum / Math.pow(e[c].size, Math.log(e[c].endValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue)), b /= Math.pow(e[c].size, Math.log(e[c].endValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue));
                      d = false;
                    } else if (b > e[c].startValue / this.conversionParameters.minimum) {
                      b /= e[c].startValue / this.conversionParameters.minimum;
                      if (b < e[c].size) {
                        a *= Math.pow(e[c].endValue / e[c].startValue, 1 === e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) / b;
                        break;
                      } else
                        a *= e[c].endValue / e[c].startValue / e[c].size;
                      b /= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b > e[c].startValue / e[c - 1].endValue) {
                    b /= e[c].startValue / e[c - 1].endValue;
                    if (b < e[c].size) {
                      a *= Math.pow(e[c].endValue / e[c].startValue, 1 === e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) / b;
                      break;
                    } else
                      a *= e[c].endValue / e[c].startValue / e[c].size;
                    b /= e[c].size;
                  } else
                    break;
              }
            else
              for (c = e.length - 1; 0 <= c; c--)
                if (!(e[c].startValue > this.conversionParameters.minimum))
                  if (d)
                    if (e[c].endValue > this.conversionParameters.minimum) {
                      if (1 < e[c].size && this.conversionParameters.minimum * Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size)) > e[c].startValue) {
                        a = Math.pow(e[c].endValue / e[c].startValue, Math.log(b) / Math.log(e[c].size));
                        break;
                      } else
                        a *= e[c].startValue / this.conversionParameters.minimum * Math.pow(e[c].size, Math.log(e[c].startValue / this.conversionParameters.minimum) / Math.log(e[c].endValue / e[c].startValue)) * b, b *= Math.pow(e[c].size, Math.log(this.conversionParameters.minimum / e[c].startValue) / Math.log(e[c].endValue / e[c].startValue));
                      d = false;
                    } else if (b < e[c].endValue / this.conversionParameters.minimum) {
                      b /= e[c].endValue / this.conversionParameters.minimum;
                      if (b > 1 / e[c].size) {
                        a *= Math.pow(e[c].endValue / e[c].startValue, 1 >= e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) * b;
                        break;
                      } else
                        a /= e[c].endValue / e[c].startValue / e[c].size;
                      b *= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b < e[c].endValue / e[c + 1].startValue) {
                    b /= e[c].endValue / e[c + 1].startValue;
                    if (b > 1 / e[c].size) {
                      a *= Math.pow(e[c].endValue / e[c].startValue, 1 >= e[c].size ? 1 : Math.log(b) / Math.log(e[c].size)) * b;
                      break;
                    } else
                      a /= e[c].endValue / e[c].startValue / e[c].size;
                    b *= e[c].size;
                  } else
                    break;
            d = a * this.viewportMinimum;
          } else {
            a = b = (c - this.conversionParameters.reference) / this.conversionParameters.pixelPerUnit;
            if (c <= this.conversionParameters.reference === ("left" === this._position || "right" === this._position) !== this.reversed)
              for (c = 0; c < e.length; c++) {
                if (!(e[c].endValue < this.conversionParameters.minimum))
                  if (d)
                    if (e[c].startValue < this.conversionParameters.minimum) {
                      if (e[c].size && this.conversionParameters.minimum + b * (e[c].endValue - e[c].startValue) / e[c].size < e[c].endValue) {
                        a = 0 >= e[c].size ? 0 : b * (e[c].endValue - e[c].startValue) / e[c].size;
                        break;
                      } else
                        a += e[c].endValue - this.conversionParameters.minimum - e[c].size * (e[c].endValue - this.conversionParameters.minimum) / (e[c].endValue - e[c].startValue), b -= e[c].size * (e[c].endValue - this.conversionParameters.minimum) / (e[c].endValue - e[c].startValue);
                      d = false;
                    } else if (b > e[c].startValue - this.conversionParameters.minimum) {
                      b -= e[c].startValue - this.conversionParameters.minimum;
                      if (b < e[c].size) {
                        a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) - b;
                        break;
                      } else
                        a += e[c].endValue - e[c].startValue - e[c].size;
                      b -= e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b > e[c].startValue - e[c - 1].endValue) {
                    b -= e[c].startValue - e[c - 1].endValue;
                    if (b < e[c].size) {
                      a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) - b;
                      break;
                    } else
                      a += e[c].endValue - e[c].startValue - e[c].size;
                    b -= e[c].size;
                  } else
                    break;
              }
            else
              for (c = e.length - 1; 0 <= c; c--)
                if (!(e[c].startValue > this.conversionParameters.minimum))
                  if (d)
                    if (e[c].endValue > this.conversionParameters.minimum)
                      if (e[c].size && this.conversionParameters.minimum + b * (e[c].endValue - e[c].startValue) / e[c].size > e[c].startValue) {
                        a = 0 >= e[c].size ? 0 : b * (e[c].endValue - e[c].startValue) / e[c].size;
                        break;
                      } else
                        a += e[c].startValue - this.conversionParameters.minimum + e[c].size * (this.conversionParameters.minimum - e[c].startValue) / (e[c].endValue - e[c].startValue), b += e[c].size * (this.conversionParameters.minimum - e[c].startValue) / (e[c].endValue - e[c].startValue), d = false;
                    else if (b < e[c].endValue - this.conversionParameters.minimum) {
                      b -= e[c].endValue - this.conversionParameters.minimum;
                      if (b > -1 * e[c].size) {
                        a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) + b;
                        break;
                      } else
                        a -= e[c].endValue - e[c].startValue - e[c].size;
                      b += e[c].size;
                      d = false;
                    } else
                      break;
                  else if (b < e[c].endValue - e[c + 1].startValue) {
                    b -= e[c].endValue - e[c + 1].startValue;
                    if (b > -1 * e[c].size) {
                      a += (e[c].endValue - e[c].startValue) * (0 === e[c].size ? 1 : b / e[c].size) + b;
                      break;
                    } else
                      a -= e[c].endValue - e[c].startValue - e[c].size;
                    b += e[c].size;
                  } else
                    break;
            d = this.conversionParameters.minimum + a;
          }
          return d;
        };
        D.prototype.convertValueToPixel = function(a) {
          a = this.getApparentDifference(this.conversionParameters.minimum, a, a);
          return this.logarithmic ? this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * Math.log(a / this.conversionParameters.minimum) / this.conversionParameters.lnLogarithmBase + 0.5 << 0 : "axisX" === this.type ? this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * (a - this.conversionParameters.minimum) + 0.5 << 0 : this.conversionParameters.reference + this.conversionParameters.pixelPerUnit * (a - this.conversionParameters.minimum) + 0.5;
        };
        D.prototype.getApparentDifference = function(a, d, c, b) {
          var e = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
          if (this.logarithmic) {
            c = m(c) ? d / a : c;
            for (var g = 0; g < e.length && !(d < e[g].startValue); g++)
              a > e[g].endValue || (a <= e[g].startValue && d >= e[g].endValue ? c = c / e[g].endValue * e[g].startValue * e[g].size : a >= e[g].startValue && d >= e[g].endValue ? c = c / e[g].endValue * a * Math.pow(e[g].size, Math.log(e[g].endValue / a) / Math.log(e[g].endValue / e[g].startValue)) : a <= e[g].startValue && d <= e[g].endValue ? c = c / d * e[g].startValue * Math.pow(e[g].size, Math.log(d / e[g].startValue) / Math.log(e[g].endValue / e[g].startValue)) : !b && (a > e[g].startValue && d < e[g].endValue) && (c = a * Math.pow(e[g].size, Math.log(d / a) / Math.log(e[g].endValue / e[g].startValue))));
          } else
            for (c = m(c) ? Math.abs(d - a) : c, g = 0; g < e.length && !(d < e[g].startValue); g++)
              a > e[g].endValue || (a <= e[g].startValue && d >= e[g].endValue ? c = c - e[g].endValue + e[g].startValue + e[g].size : a > e[g].startValue && d >= e[g].endValue ? c = c - e[g].endValue + a + e[g].size * (e[g].endValue - a) / (e[g].endValue - e[g].startValue) : a <= e[g].startValue && d < e[g].endValue ? c = c - d + e[g].startValue + e[g].size * (d - e[g].startValue) / (e[g].endValue - e[g].startValue) : !b && (a > e[g].startValue && d < e[g].endValue) && (c = a + e[g].size * (d - a) / (e[g].endValue - e[g].startValue)));
          return c;
        };
        D.prototype.setViewPortRange = function(a, d) {
          this.sessionVariables.newViewportMinimum = this.viewportMinimum = Math.min(a, d);
          this.sessionVariables.newViewportMaximum = this.viewportMaximum = Math.max(a, d);
        };
        D.prototype.getXValueAt = function(a) {
          if (!a)
            return null;
          var d = null;
          "left" === this._position ? d = this.convertPixelToValue(a.y) : "bottom" === this._position && (d = this.convertPixelToValue(a.x));
          return d;
        };
        D.prototype.calculateValueToPixelConversionParameters = function(a) {
          a = this.scaleBreaks ? this.scaleBreaks._appliedBreaks : [];
          var d = { pixelPerUnit: null, minimum: null, reference: null }, c = this.lineCoordinates.width, b = this.lineCoordinates.height, c = "bottom" === this._position || "top" === this._position ? c : b, b = Math.abs(this.range);
          if (this.logarithmic)
            for (var e = 0; e < a.length && !(this.viewportMaximum < a[e].startValue); e++)
              this.viewportMinimum > a[e].endValue || (this.viewportMinimum >= a[e].startValue && this.viewportMaximum <= a[e].endValue ? c = 0 : this.viewportMinimum <= a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b / a[e].endValue * a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100) : c - Math.min(a[e].spacing, 0.1 * c)) : this.viewportMinimum > a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b / a[e].endValue * this.viewportMinimum, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * Math.log(a[e].endValue / this.viewportMinimum) / Math.log(a[e].endValue / a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * Math.log(a[e].endValue / this.viewportMinimum) / Math.log(a[e].endValue / a[e].startValue)) : this.viewportMinimum <= a[e].startValue && this.viewportMaximum < a[e].endValue && (b = b / this.viewportMaximum * a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * Math.log(this.viewportMaximum / a[e].startValue) / Math.log(a[e].endValue / a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * Math.log(this.viewportMaximum / a[e].startValue) / Math.log(a[e].endValue / a[e].startValue)));
          else
            for (e = 0; e < a.length && !(this.viewportMaximum < a[e].startValue); e++)
              this.viewportMinimum > a[e].endValue || (this.viewportMinimum >= a[e].startValue && this.viewportMaximum <= a[e].endValue ? c = 0 : this.viewportMinimum <= a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b - a[e].endValue + a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100) : c - Math.min(a[e].spacing, 0.1 * c)) : this.viewportMinimum > a[e].startValue && this.viewportMaximum >= a[e].endValue ? (b = b - a[e].endValue + this.viewportMinimum, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * (a[e].endValue - this.viewportMinimum) / (a[e].endValue - a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * (a[e].endValue - this.viewportMinimum) / (a[e].endValue - a[e].startValue)) : this.viewportMinimum <= a[e].startValue && this.viewportMaximum < a[e].endValue && (b = b - this.viewportMaximum + a[e].startValue, c = 0 < a[e].spacing.toString().indexOf("%") ? c * (1 - parseFloat(a[e].spacing) / 100 * (this.viewportMaximum - a[e].startValue) / (a[e].endValue - a[e].startValue)) : c - Math.min(a[e].spacing, 0.1 * c) * (this.viewportMaximum - a[e].startValue) / (a[e].endValue - a[e].startValue)));
          d.minimum = this.viewportMinimum;
          d.maximum = this.viewportMaximum;
          d.range = b;
          if ("bottom" === this._position || "top" === this._position)
            this.logarithmic ? (d.lnLogarithmBase = Math.log(this.logarithmBase), d.pixelPerUnit = (this.reversed ? -1 : 1) * c * d.lnLogarithmBase / Math.log(Math.abs(b))) : d.pixelPerUnit = (this.reversed ? -1 : 1) * c / Math.abs(b), d.reference = this.reversed ? this.lineCoordinates.x2 : this.lineCoordinates.x1;
          if ("left" === this._position || "right" === this._position)
            this.logarithmic ? (d.lnLogarithmBase = Math.log(this.logarithmBase), d.pixelPerUnit = (this.reversed ? 1 : -1) * c * d.lnLogarithmBase / Math.log(Math.abs(b))) : d.pixelPerUnit = (this.reversed ? 1 : -1) * c / Math.abs(b), d.reference = this.reversed ? this.lineCoordinates.y1 : this.lineCoordinates.y2;
          this.conversionParameters = d;
        };
        D.prototype.calculateAxisParameters = function() {
          if (this.logarithmic)
            this.calculateLogarithmicAxisParameters();
          else {
            var a = this.chart.layoutManager.getFreeSpace(), d = false, c = false;
            "bottom" === this._position || "top" === this._position ? (this.maxWidth = a.width, this.maxHeight = a.height) : (this.maxWidth = a.height, this.maxHeight = a.width);
            var a = "axisX" === this.type ? "xySwapped" === this.chart.plotInfo.axisPlacement ? 62 : 70 : "xySwapped" === this.chart.plotInfo.axisPlacement ? 50 : 40, b = 4;
            "axisX" === this.type && (b = 600 > this.maxWidth ? 8 : 6);
            var a = Math.max(b, Math.floor(this.maxWidth / a)), e, g, h2, b = 0;
            !m(this.options.viewportMinimum) && (!m(this.options.viewportMaximum) && this.options.viewportMinimum >= this.options.viewportMaximum) && (this.viewportMinimum = this.viewportMaximum = null);
            if (m(this.options.viewportMinimum) && !m(this.sessionVariables.newViewportMinimum) && !isNaN(this.sessionVariables.newViewportMinimum))
              this.viewportMinimum = this.sessionVariables.newViewportMinimum;
            else if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
              this.viewportMinimum = this.minimum;
            if (m(this.options.viewportMaximum) && !m(this.sessionVariables.newViewportMaximum) && !isNaN(this.sessionVariables.newViewportMaximum))
              this.viewportMaximum = this.sessionVariables.newViewportMaximum;
            else if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
              this.viewportMaximum = this.maximum;
            if (this.scaleBreaks) {
              for (b = 0; b < this.scaleBreaks._appliedBreaks.length; b++)
                if ((!m(this.sessionVariables.newViewportMinimum) && this.sessionVariables.newViewportMinimum >= this.scaleBreaks._appliedBreaks[b].startValue || !m(this.options.minimum) && this.options.minimum >= this.scaleBreaks._appliedBreaks[b].startValue || !m(this.options.viewportMinimum) && this.viewportMinimum >= this.scaleBreaks._appliedBreaks[b].startValue) && (!m(this.sessionVariables.newViewportMaximum) && this.sessionVariables.newViewportMaximum <= this.scaleBreaks._appliedBreaks[b].endValue || !m(this.options.maximum) && this.options.maximum <= this.scaleBreaks._appliedBreaks[b].endValue || !m(this.options.viewportMaximum) && this.viewportMaximum <= this.scaleBreaks._appliedBreaks[b].endValue)) {
                  this.scaleBreaks._appliedBreaks.splice(
                    b,
                    1
                  );
                  break;
                }
            }
            if ("axisX" === this.type) {
              if (this.dataSeries && 0 < this.dataSeries.length)
                for (e = 0; e < this.dataSeries.length; e++)
                  "dateTime" === this.dataSeries[e].xValueType && (c = true);
              e = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin;
              g = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax;
              0 === g - e && (b = "undefined" === typeof this.options.interval ? 0.4 : this.options.interval, g += b, e -= b);
              Infinity !== this.dataInfo.minDiff ? h2 = this.dataInfo.minDiff : 1 < g - e ? h2 = 0.5 * Math.abs(g - e) : (h2 = 1, c && (d = true));
            } else
              "axisY" === this.type && (e = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, g = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, isFinite(e) || isFinite(g) ? isFinite(e) ? isFinite(g) || (g = e) : e = g : (g = "undefined" === typeof this.options.interval ? -Infinity : this.options.interval, e = "undefined" !== typeof this.options.interval || isFinite(this.dataInfo.minDiff) ? 0 : Infinity), 0 === e && 0 === g ? (g += 9, e = 0) : 0 === g - e ? (b = Math.min(Math.abs(0.01 * Math.abs(g)), 5), g += b, e -= b) : e > g ? (b = Math.min(0.01 * Math.abs(this.getApparentDifference(g, e, null, true)), 5), 0 <= g ? e = g - b : g = isFinite(e) ? e + b : 0) : (b = Math.min(0.01 * Math.abs(this.getApparentDifference(e, g, null, true)), 0.05), 0 !== g && (g += b), 0 !== e && (e -= b)), h2 = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < g - e ? 0.5 * Math.abs(g - e) : 1, this.includeZero && (null === this.viewportMinimum || isNaN(this.viewportMinimum)) && 0 < e && (e = 0), this.includeZero && (null === this.viewportMaximum || isNaN(this.viewportMaximum)) && 0 > g && (g = 0));
            b = this.getApparentDifference(isNaN(this.viewportMinimum) || null === this.viewportMinimum ? e : this.viewportMinimum, isNaN(this.viewportMaximum) || null === this.viewportMaximum ? g : this.viewportMaximum, null, true);
            if ("axisX" === this.type && c) {
              this.valueType = "dateTime";
              this.intervalType || (b / 1 <= a ? (this.interval = 1, this.intervalType = "millisecond") : b / 2 <= a ? (this.interval = 2, this.intervalType = "millisecond") : b / 5 <= a ? (this.interval = 5, this.intervalType = "millisecond") : b / 10 <= a ? (this.interval = 10, this.intervalType = "millisecond") : b / 20 <= a ? (this.interval = 20, this.intervalType = "millisecond") : b / 50 <= a ? (this.interval = 50, this.intervalType = "millisecond") : b / 100 <= a ? (this.interval = 100, this.intervalType = "millisecond") : b / 200 <= a ? (this.interval = 200, this.intervalType = "millisecond") : b / 250 <= a ? (this.interval = 250, this.intervalType = "millisecond") : b / 300 <= a ? (this.interval = 300, this.intervalType = "millisecond") : b / 400 <= a ? (this.interval = 400, this.intervalType = "millisecond") : b / 500 <= a ? (this.interval = 500, this.intervalType = "millisecond") : b / (1 * U.secondDuration) <= a ? (this.interval = 1, this.intervalType = "second") : b / (2 * U.secondDuration) <= a ? (this.interval = 2, this.intervalType = "second") : b / (5 * U.secondDuration) <= a ? (this.interval = 5, this.intervalType = "second") : b / (10 * U.secondDuration) <= a ? (this.interval = 10, this.intervalType = "second") : b / (15 * U.secondDuration) <= a ? (this.interval = 15, this.intervalType = "second") : b / (20 * U.secondDuration) <= a ? (this.interval = 20, this.intervalType = "second") : b / (30 * U.secondDuration) <= a ? (this.interval = 30, this.intervalType = "second") : b / (1 * U.minuteDuration) <= a ? (this.interval = 1, this.intervalType = "minute") : b / (2 * U.minuteDuration) <= a ? (this.interval = 2, this.intervalType = "minute") : b / (5 * U.minuteDuration) <= a ? (this.interval = 5, this.intervalType = "minute") : b / (10 * U.minuteDuration) <= a ? (this.interval = 10, this.intervalType = "minute") : b / (15 * U.minuteDuration) <= a ? (this.interval = 15, this.intervalType = "minute") : b / (20 * U.minuteDuration) <= a ? (this.interval = 20, this.intervalType = "minute") : b / (30 * U.minuteDuration) <= a ? (this.interval = 30, this.intervalType = "minute") : b / (1 * U.hourDuration) <= a ? (this.interval = 1, this.intervalType = "hour") : b / (2 * U.hourDuration) <= a ? (this.interval = 2, this.intervalType = "hour") : b / (3 * U.hourDuration) <= a ? (this.interval = 3, this.intervalType = "hour") : b / (6 * U.hourDuration) <= a ? (this.interval = 6, this.intervalType = "hour") : b / (1 * U.dayDuration) <= a ? (this.interval = 1, this.intervalType = "day") : b / (2 * U.dayDuration) <= a ? (this.interval = 2, this.intervalType = "day") : b / (4 * U.dayDuration) <= a ? (this.interval = 4, this.intervalType = "day") : b / (1 * U.weekDuration) <= a ? (this.interval = 1, this.intervalType = "week") : b / (2 * U.weekDuration) <= a ? (this.interval = 2, this.intervalType = "week") : b / (3 * U.weekDuration) <= a ? (this.interval = 3, this.intervalType = "week") : b / (1 * U.monthDuration) <= a ? (this.interval = 1, this.intervalType = "month") : b / (2 * U.monthDuration) <= a ? (this.interval = 2, this.intervalType = "month") : b / (3 * U.monthDuration) <= a ? (this.interval = 3, this.intervalType = "month") : b / (6 * U.monthDuration) <= a ? (this.interval = 6, this.intervalType = "month") : (this.interval = b / (1 * U.yearDuration) <= a ? 1 : b / (2 * U.yearDuration) <= a ? 2 : b / (4 * U.yearDuration) <= a ? 4 : Math.floor(D.getNiceNumber(b / (a - 1), true) / U.yearDuration), this.intervalType = "year"));
              if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
                this.viewportMinimum = e - h2 / 2;
              if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
                this.viewportMaximum = g + h2 / 2;
              d ? this.autoValueFormatString = "MMM DD YYYY HH:mm" : "year" === this.intervalType ? this.autoValueFormatString = "YYYY" : "month" === this.intervalType ? this.autoValueFormatString = "MMM YYYY" : "week" === this.intervalType ? this.autoValueFormatString = "MMM DD YYYY" : "day" === this.intervalType ? this.autoValueFormatString = "MMM DD YYYY" : "hour" === this.intervalType ? this.autoValueFormatString = "hh:mm TT" : "minute" === this.intervalType ? this.autoValueFormatString = "hh:mm TT" : "second" === this.intervalType ? this.autoValueFormatString = "hh:mm:ss TT" : "millisecond" === this.intervalType && (this.autoValueFormatString = "fff'ms'");
              this.valueFormatString || (this.valueFormatString = this.autoValueFormatString);
            } else {
              this.intervalType = "number";
              b = D.getNiceNumber(b, false);
              this.interval = this.options && 0 < this.options.interval ? this.options.interval : D.getNiceNumber(b / (a - 1), true);
              if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
                this.viewportMinimum = "axisX" === this.type ? e - h2 / 2 : Math.floor(e / this.interval) * this.interval;
              if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
                this.viewportMaximum = "axisX" === this.type ? g + h2 / 2 : Math.ceil(g / this.interval) * this.interval;
              0 === this.viewportMaximum && 0 === this.viewportMinimum && (0 === this.options.viewportMinimum ? this.viewportMaximum += 10 : 0 === this.options.viewportMaximum && (this.viewportMinimum -= 10), this.options && "undefined" === typeof this.options.interval && (this.interval = D.getNiceNumber((this.viewportMaximum - this.viewportMinimum) / (a - 1), true)));
            }
            if (null === this.minimum || null === this.maximum)
              if ("axisX" === this.type ? (e = null !== this.minimum ? this.minimum : this.dataInfo.min, g = null !== this.maximum ? this.maximum : this.dataInfo.max, 0 === g - e && (b = "undefined" === typeof this.options.interval ? 0.4 : this.options.interval, g += b, e -= b), h2 = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < g - e ? 0.5 * Math.abs(g - e) : 1) : "axisY" === this.type && (e = null !== this.minimum ? this.minimum : this.dataInfo.min, g = null !== this.maximum ? this.maximum : this.dataInfo.max, isFinite(e) || isFinite(g) ? 0 === e && 0 === g ? (g += 9, e = 0) : 0 === g - e ? (b = Math.min(Math.abs(0.01 * Math.abs(g)), 5), g += b, e -= b) : e > g ? (b = Math.min(0.01 * Math.abs(this.getApparentDifference(g, e, null, true)), 5), 0 <= g ? e = g - b : g = isFinite(e) ? e + b : 0) : (b = Math.min(0.01 * Math.abs(this.getApparentDifference(e, g, null, true)), 0.05), 0 !== g && (g += b), 0 !== e && (e -= b)) : (g = "undefined" === typeof this.options.interval ? -Infinity : this.options.interval, e = "undefined" !== typeof this.options.interval || isFinite(this.dataInfo.minDiff) ? 0 : Infinity), h2 = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : 1 < g - e ? 0.5 * Math.abs(g - e) : 1, this.includeZero && (null === this.minimum || isNaN(this.minimum)) && 0 < e && (e = 0), this.includeZero && (null === this.maximum || isNaN(this.maximum)) && 0 > g && (g = 0)), Math.abs(this.getApparentDifference(e, g, null, true)), "axisX" === this.type && c) {
                this.valueType = "dateTime";
                if (null === this.minimum || isNaN(this.minimum))
                  this.minimum = e - h2 / 2, this.minimum = Math.min(this.minimum, null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? Infinity : this.sessionVariables.viewportMinimum);
                if (null === this.maximum || isNaN(this.maximum))
                  this.maximum = g + h2 / 2, this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? -Infinity : this.sessionVariables.viewportMaximum);
              } else
                this.intervalType = this.valueType = "number", null === this.minimum && (this.minimum = "axisX" === this.type ? e - h2 / 2 : Math.floor(e / this.interval) * this.interval, this.minimum = Math.min(
                  this.minimum,
                  null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? Infinity : this.sessionVariables.viewportMinimum
                )), null === this.maximum && (this.maximum = "axisX" === this.type ? g + h2 / 2 : Math.ceil(g / this.interval) * this.interval, this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? -Infinity : this.sessionVariables.viewportMaximum)), 0 === this.maximum && 0 === this.minimum && (0 === this.options.minimum ? this.maximum += 10 : 0 === this.options.maximum && (this.minimum -= 10));
            m(this.sessionVariables.newViewportMinimum) && (this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum));
            m(this.sessionVariables.newViewportMaximum) && (this.viewportMaximum = Math.min(this.viewportMaximum, this.maximum));
            this.range = this.viewportMaximum - this.viewportMinimum;
            this.intervalStartPosition = "axisX" === this.type && c ? this.getLabelStartPoint(new Date(this.viewportMinimum), this.intervalType, this.interval) : Math.floor((this.viewportMinimum + 0.2 * this.interval) / this.interval) * this.interval;
            this.valueFormatString || (this.valueFormatString = D.generateValueFormatString(this.range, 2));
          }
        };
        D.prototype.calculateLogarithmicAxisParameters = function() {
          var a = this.chart.layoutManager.getFreeSpace(), d = Math.log(this.logarithmBase), c;
          "bottom" === this._position || "top" === this._position ? (this.maxWidth = a.width, this.maxHeight = a.height) : (this.maxWidth = a.height, this.maxHeight = a.width);
          var a = "axisX" === this.type ? 500 > this.maxWidth ? 7 : Math.max(7, Math.floor(this.maxWidth / 100)) : Math.max(Math.floor(this.maxWidth / 50), 3), b, e, g, h2;
          h2 = 1;
          if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
            this.viewportMinimum = this.minimum;
          if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
            this.viewportMaximum = this.maximum;
          if (this.scaleBreaks) {
            for (h2 = 0; h2 < this.scaleBreaks._appliedBreaks.length; h2++)
              if ((!m(this.sessionVariables.newViewportMinimum) && this.sessionVariables.newViewportMinimum >= this.scaleBreaks._appliedBreaks[h2].startValue || !m(this.options.minimum) && this.options.minimum >= this.scaleBreaks._appliedBreaks[h2].startValue || !m(this.options.viewportMinimum) && this.viewportMinimum >= this.scaleBreaks._appliedBreaks[h2].startValue) && (!m(this.sessionVariables.newViewportMaximum) && this.sessionVariables.newViewportMaximum <= this.scaleBreaks._appliedBreaks[h2].endValue || !m(this.options.maximum) && this.options.maximum <= this.scaleBreaks._appliedBreaks[h2].endValue || !m(this.options.viewportMaximum) && this.viewportMaximum <= this.scaleBreaks._appliedBreaks[h2].endValue)) {
                this.scaleBreaks._appliedBreaks.splice(h2, 1);
                break;
              }
          }
          "axisX" === this.type ? (b = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, e = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, 1 === e / b && (h2 = Math.pow(this.logarithmBase, "undefined" === typeof this.options.interval ? 0.4 : this.options.interval), e *= h2, b /= h2), g = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase) : "axisY" === this.type && (b = null !== this.viewportMinimum ? this.viewportMinimum : this.dataInfo.viewPortMin, e = null !== this.viewportMaximum ? this.viewportMaximum : this.dataInfo.viewPortMax, 0 >= b && !isFinite(e) ? (e = "undefined" === typeof this.options.interval ? 0 : this.options.interval, b = 1) : 0 >= b ? b = e : isFinite(e) || (e = b), 1 === b && 1 === e ? (e *= this.logarithmBase - 1 / this.logarithmBase, b = 1) : 1 === e / b ? (h2 = Math.min(e * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 5)), e *= h2, b /= h2) : b > e ? (h2 = Math.min(b / e * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 5)), 1 <= e ? b = e / h2 : e = b * h2) : (h2 = Math.min(e / b * Math.pow(
            this.logarithmBase,
            0.01
          ), Math.pow(this.logarithmBase, 0.04)), 1 !== e && (e *= h2), 1 !== b && (b /= h2)), g = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase, this.includeZero && (null === this.viewportMinimum || isNaN(this.viewportMinimum)) && 1 < b && (b = 1), this.includeZero && (null === this.viewportMaximum || isNaN(this.viewportMaximum)) && 1 > e && (e = 1));
          h2 = (isNaN(this.viewportMaximum) || null === this.viewportMaximum ? e : this.viewportMaximum) / (isNaN(this.viewportMinimum) || null === this.viewportMinimum ? b : this.viewportMinimum);
          var n2 = (isNaN(this.viewportMaximum) || null === this.viewportMaximum ? e : this.viewportMaximum) - (isNaN(this.viewportMinimum) || null === this.viewportMinimum ? b : this.viewportMinimum);
          this.intervalType = "number";
          h2 = Math.pow(this.logarithmBase, D.getNiceNumber(Math.abs(Math.log(h2) / d), false));
          this.options && 0 < this.options.interval ? this.interval = this.options.interval : (this.interval = D.getNiceExponent(Math.log(h2) / d / (a - 1), true), c = D.getNiceNumber(n2 / (a - 1), true));
          if (null === this.viewportMinimum || isNaN(this.viewportMinimum))
            this.viewportMinimum = "axisX" === this.type ? b / Math.sqrt(g) : Math.pow(this.logarithmBase, this.interval * Math.floor(Math.log(b) / d / this.interval));
          if (null === this.viewportMaximum || isNaN(this.viewportMaximum))
            this.viewportMaximum = "axisX" === this.type ? e * Math.sqrt(g) : Math.pow(this.logarithmBase, this.interval * Math.ceil(Math.log(e) / d / this.interval));
          1 === this.viewportMaximum && 1 === this.viewportMinimum && (1 === this.options.viewportMinimum ? this.viewportMaximum *= this.logarithmBase - 1 / this.logarithmBase : 1 === this.options.viewportMaximum && (this.viewportMinimum /= this.logarithmBase - 1 / this.logarithmBase), this.options && "undefined" === typeof this.options.interval && (this.interval = D.getNiceExponent(Math.ceil(Math.log(h2) / d) / (a - 1)), c = D.getNiceNumber((this.viewportMaximum - this.viewportMinimum) / (a - 1), true)));
          if (null === this.minimum || null === this.maximum)
            "axisX" === this.type ? (b = null !== this.minimum ? this.minimum : this.dataInfo.min, e = null !== this.maximum ? this.maximum : this.dataInfo.max, 1 === e / b && (h2 = Math.pow(
              this.logarithmBase,
              "undefined" === typeof this.options.interval ? 0.4 : this.options.interval
            ), e *= h2, b /= h2), g = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase) : "axisY" === this.type && (b = null !== this.minimum ? this.minimum : this.dataInfo.min, e = null !== this.maximum ? this.maximum : this.dataInfo.max, isFinite(b) || isFinite(e) ? 1 === b && 1 === e ? (e *= this.logarithmBase, b /= this.logarithmBase) : 1 === e / b ? (h2 = Math.pow(this.logarithmBase, this.interval), e *= h2, b /= h2) : b > e ? (h2 = Math.min(0.01 * (b / e), 5), 1 <= e ? b = e / h2 : e = b * h2) : (h2 = Math.min(e / b * Math.pow(this.logarithmBase, 0.01), Math.pow(this.logarithmBase, 0.04)), 1 !== e && (e *= h2), 1 !== b && (b /= h2)) : (e = "undefined" === typeof this.options.interval ? 0 : this.options.interval, b = 1), g = Infinity !== this.dataInfo.minDiff ? this.dataInfo.minDiff : e / b > this.logarithmBase ? e / b * Math.pow(this.logarithmBase, 0.5) : this.logarithmBase, this.includeZero && (null === this.minimum || isNaN(this.minimum)) && 1 < b && (b = 1), this.includeZero && (null === this.maximum || isNaN(this.maximum)) && 1 > e && (e = 1)), this.intervalType = "number", null === this.minimum && (this.minimum = "axisX" === this.type ? b / Math.sqrt(g) : Math.pow(this.logarithmBase, this.interval * Math.floor(Math.log(b) / d / this.interval)), m(null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? "undefined" === typeof this.sessionVariables.newViewportMinimum ? Infinity : this.sessionVariables.newViewportMinimum : this.sessionVariables.viewportMinimum) || (this.minimum = Math.min(this.minimum, null === this.sessionVariables.viewportMinimum || isNaN(this.sessionVariables.viewportMinimum) ? "undefined" === typeof this.sessionVariables.newViewportMinimum ? Infinity : this.sessionVariables.newViewportMinimum : this.sessionVariables.viewportMinimum))), null === this.maximum && (this.maximum = "axisX" === this.type ? e * Math.sqrt(g) : Math.pow(this.logarithmBase, this.interval * Math.ceil(Math.log(e) / d / this.interval)), m(null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? "undefined" === typeof this.sessionVariables.newViewportMaximum ? 0 : this.sessionVariables.newViewportMaximum : this.sessionVariables.viewportMaximum) || (this.maximum = Math.max(this.maximum, null === this.sessionVariables.viewportMaximum || isNaN(this.sessionVariables.viewportMaximum) ? "undefined" === typeof this.sessionVariables.newViewportMaximum ? 0 : this.sessionVariables.newViewportMaximum : this.sessionVariables.viewportMaximum))), 1 === this.maximum && 1 === this.minimum && (1 === this.options.minimum ? this.maximum *= this.logarithmBase - 1 / this.logarithmBase : 1 === this.options.maximum && (this.minimum /= this.logarithmBase - 1 / this.logarithmBase));
          this.viewportMinimum = Math.max(this.viewportMinimum, this.minimum);
          this.viewportMaximum = Math.min(this.viewportMaximum, this.maximum);
          this.viewportMinimum > this.viewportMaximum && (!this.options.viewportMinimum && !this.options.minimum || this.options.viewportMaximum || this.options.maximum ? this.options.viewportMinimum || this.options.minimum || !this.options.viewportMaximum && !this.options.maximum || (this.viewportMinimum = this.minimum = (this.options.viewportMaximum || this.options.maximum) / Math.pow(this.logarithmBase, 2 * Math.ceil(this.interval))) : this.viewportMaximum = this.maximum = this.options.viewportMinimum || this.options.minimum);
          b = Math.pow(this.logarithmBase, Math.floor(Math.log(this.viewportMinimum) / (d * this.interval) + 0.2) * this.interval);
          this.range = this.viewportMaximum / this.viewportMinimum;
          this.noTicks = a;
          if (!this.options.interval && this.range < Math.pow(this.logarithmBase, 8 > this.viewportMaximum || 3 > a ? 2 : 3)) {
            for (d = Math.floor(this.viewportMinimum / c + 0.5) * c; d < this.viewportMinimum; )
              d += c;
            this.equidistantInterval = false;
            this.intervalStartPosition = d;
            this.interval = c;
          } else
            this.options.interval || (c = Math.ceil(this.interval), this.range > this.interval && (this.interval = c, b = Math.pow(this.logarithmBase, Math.floor(Math.log(this.viewportMinimum) / (d * this.interval) + 0.2) * this.interval))), this.equidistantInterval = true, this.intervalStartPosition = b;
          if (!this.valueFormatString && (this.valueFormatString = "#,##0.##", 1 > this.viewportMinimum)) {
            d = Math.floor(Math.abs(Math.log(this.viewportMinimum) / Math.LN10)) + 2;
            if (isNaN(d) || !isFinite(d))
              d = 2;
            if (2 < d)
              for (h2 = 0; h2 < d - 2; h2++)
                this.valueFormatString += "#";
          }
        };
        D.generateValueFormatString = function(a, d) {
          var c = "#,##0.", b = d;
          1 > a && (b += Math.floor(Math.abs(Math.log(a) / Math.LN10)), isNaN(b) || !isFinite(b)) && (b = d);
          for (var e = 0; e < b; e++)
            c += "#";
          return c;
        };
        D.getNiceExponent = function(a, d) {
          var c = Math.floor(Math.log(a) / Math.LN10), b = a / Math.pow(10, c), b = 0 > c ? 1 >= b ? 1 : 5 >= b ? 5 : 10 : Math.max(Math.floor(b), 1);
          return -20 > c ? Number(b * Math.pow(10, c)) : Number((b * Math.pow(10, c)).toFixed(20));
        };
        D.getNiceNumber = function(a, d) {
          var c = Math.floor(Math.log(a) / Math.LN10), b = a / Math.pow(10, c), b = d ? 1.5 > b ? 1 : 3 > b ? 2 : 7 > b ? 5 : 10 : 1 >= b ? 1 : 2 >= b ? 2 : 5 >= b ? 5 : 10;
          return -20 > c ? Number(b * Math.pow(10, c)) : Number((b * Math.pow(10, c)).toFixed(20));
        };
        D.prototype.getLabelStartPoint = function() {
          var a = U[this.intervalType + "Duration"] * this.interval, a = new Date(Math.floor(this.viewportMinimum / a) * a);
          if ("millisecond" !== this.intervalType)
            if ("second" === this.intervalType)
              0 < a.getMilliseconds() && (a.setSeconds(a.getSeconds() + 1), a.setMilliseconds(0));
            else if ("minute" === this.intervalType) {
              if (0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setMinutes(a.getMinutes() + 1), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("hour" === this.intervalType) {
              if (0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setHours(a.getHours() + 1), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("day" === this.intervalType) {
              if (0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setDate(a.getDate() + 1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("week" === this.intervalType) {
              if (0 < a.getDay() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setDate(a.getDate() + (7 - a.getDay())), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else if ("month" === this.intervalType) {
              if (1 < a.getDate() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds())
                a.setMonth(a.getMonth() + 1), a.setDate(1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0);
            } else
              "year" === this.intervalType && (0 < a.getMonth() || 1 < a.getDate() || 0 < a.getHours() || 0 < a.getMinutes() || 0 < a.getSeconds() || 0 < a.getMilliseconds()) && (a.setFullYear(a.getFullYear() + 1), a.setMonth(0), a.setDate(1), a.setHours(0), a.setMinutes(0), a.setSeconds(0), a.setMilliseconds(0));
          return a;
        };
        qa(fa2, L);
        qa(da2, L);
        da2.prototype.createUserOptions = function(a) {
          if ("undefined" !== typeof a || this.options._isPlaceholder) {
            var d = 0;
            this.parent.options._isPlaceholder && this.parent.createUserOptions();
            this.options._isPlaceholder || (Ea(this.parent[this.optionsName]), d = this.parent.options[this.optionsName].indexOf(this.options));
            this.options = "undefined" === typeof a ? {} : a;
            this.parent.options[this.optionsName][d] = this.options;
          }
        };
        da2.prototype.render = function(a) {
          if (0 !== this.spacing || 0 !== this.options.lineThickness && ("undefined" !== typeof this.options.lineThickness || 0 !== this.parent.lineThickness)) {
            var d = this.ctx, c = this.ctx.globalAlpha;
            this.ctx = a || this.ctx;
            this.ctx.save();
            this.ctx.beginPath();
            this.ctx.rect(this.chart.plotArea.x1, this.chart.plotArea.y1, this.chart.plotArea.width, this.chart.plotArea.height);
            this.ctx.clip();
            var b = this.scaleBreaks.parent.getPixelCoordinatesOnAxis(this.startValue), e = this.scaleBreaks.parent.getPixelCoordinatesOnAxis(this.endValue);
            this.ctx.strokeStyle = this.lineColor;
            this.ctx.fillStyle = this.color;
            this.ctx.beginPath();
            this.ctx.globalAlpha = 1;
            Z(this.id);
            var g, h2, m2, n2, k, l;
            a = Math.max(this.spacing, 3);
            var p = Math.max(0, this.lineThickness);
            this.ctx.lineWidth = p;
            this.ctx.setLineDash && this.ctx.setLineDash(H(this.lineDashType, p));
            if ("bottom" === this.scaleBreaks.parent._position || "top" === this.scaleBreaks.parent._position)
              if (b = 1 === p % 2 ? (b.x << 0) + 0.5 : b.x << 0, h2 = 1 === p % 2 ? (e.x << 0) + 0.5 : e.x << 0, "top" === this.scaleBreaks.parent._position ? (e = this.chart.plotArea.y1, m2 = this.chart.plotArea.y2 + p / 2 + 0.5 << 0) : (e = this.chart.plotArea.y2, m2 = this.chart.plotArea.y1 - p / 2 + 0.5 << 0, a *= -1), this.bounds = { x1: b - p / 2, y1: e, x2: h2 + p / 2, y2: m2 }, this.ctx.moveTo(b, e), "straight" === this.type || "top" === this.scaleBreaks.parent._position && 0 >= a || "bottom" === this.scaleBreaks.parent._position && 0 <= a)
                this.ctx.lineTo(b, m2), this.ctx.lineTo(h2, m2), this.ctx.lineTo(h2, e);
              else if ("wavy" === this.type) {
                n2 = b;
                k = e;
                g = 0.5;
                l = (m2 - k) / a / 3;
                for (var q = 0; q < l; q++)
                  this.ctx.bezierCurveTo(n2 + g * a, k + a, n2 + g * a, k + 2 * a, n2, k + 3 * a), k += 3 * a, g *= -1;
                this.ctx.bezierCurveTo(n2 + g * a, k + a, n2 + g * a, k + 2 * a, n2, k + 3 * a);
                n2 = h2;
                g *= -1;
                this.ctx.lineTo(n2, k);
                for (q = 0; q < l; q++)
                  this.ctx.bezierCurveTo(n2 + g * a, k - a, n2 + g * a, k - 2 * a, n2, k - 3 * a), k -= 3 * a, g *= -1;
              } else {
                if ("zigzag" === this.type) {
                  g = -1;
                  k = e + a;
                  n2 = b + a;
                  l = (m2 - k) / a / 2;
                  for (q = 0; q < l; q++)
                    this.ctx.lineTo(n2, k), n2 += 2 * g * a, k += 2 * a, g *= -1;
                  this.ctx.lineTo(n2, k);
                  n2 += h2 - b;
                  for (q = 0; q < l + 1; q++)
                    this.ctx.lineTo(n2, k), n2 += 2 * g * a, k -= 2 * a, g *= -1;
                  this.ctx.lineTo(n2 + g * a, k + a);
                }
              }
            else if ("left" === this.scaleBreaks.parent._position || "right" === this.scaleBreaks.parent._position) {
              if (e = 1 === p % 2 ? (e.y << 0) + 0.5 : e.y << 0, m2 = 1 === p % 2 ? (b.y << 0) + 0.5 : b.y << 0, "left" === this.scaleBreaks.parent._position ? (b = this.chart.plotArea.x1, h2 = this.chart.plotArea.x2 + p / 2 + 0.5 << 0) : (b = this.chart.plotArea.x2, h2 = this.chart.plotArea.x1 - p / 2 + 0.5 << 0, a *= -1), this.bounds = { x1: b, y1: e - p / 2, x2: h2, y2: m2 + p / 2 }, this.ctx.moveTo(b, e), "straight" === this.type || "left" === this.scaleBreaks.parent._position && 0 >= a || "right" === this.scaleBreaks.parent._position && 0 <= a)
                this.ctx.lineTo(h2, e), this.ctx.lineTo(h2, m2), this.ctx.lineTo(b, m2);
              else if ("wavy" === this.type) {
                n2 = b;
                k = e;
                g = 0.5;
                l = (h2 - n2) / a / 3;
                for (q = 0; q < l; q++)
                  this.ctx.bezierCurveTo(n2 + a, k + g * a, n2 + 2 * a, k + g * a, n2 + 3 * a, k), n2 += 3 * a, g *= -1;
                this.ctx.bezierCurveTo(n2 + a, k + g * a, n2 + 2 * a, k + g * a, n2 + 3 * a, k);
                k = m2;
                g *= -1;
                this.ctx.lineTo(n2, k);
                for (q = 0; q < l; q++)
                  this.ctx.bezierCurveTo(n2 - a, k + g * a, n2 - 2 * a, k + g * a, n2 - 3 * a, k), n2 -= 3 * a, g *= -1;
              } else if ("zigzag" === this.type) {
                g = 1;
                k = e - a;
                n2 = b + a;
                l = (h2 - n2) / a / 2;
                for (q = 0; q < l; q++)
                  this.ctx.lineTo(n2, k), k += 2 * g * a, n2 += 2 * a, g *= -1;
                this.ctx.lineTo(n2, k);
                k += m2 - e;
                for (q = 0; q < l + 1; q++)
                  this.ctx.lineTo(
                    n2,
                    k
                  ), k += 2 * g * a, n2 -= 2 * a, g *= -1;
                this.ctx.lineTo(n2 + a, k + g * a);
              }
            }
            0 < p && this.ctx.stroke();
            this.ctx.closePath();
            this.ctx.globalAlpha = this.fillOpacity;
            this.ctx.globalCompositeOperation = "destination-over";
            this.ctx.fill();
            this.ctx.restore();
            this.ctx.globalAlpha = c;
            this.ctx = d;
          }
        };
        qa(O, L);
        O.prototype.createUserOptions = function(a) {
          if ("undefined" !== typeof a || this.options._isPlaceholder) {
            var d = 0;
            this.parent.options._isPlaceholder && this.parent.createUserOptions();
            this.options._isPlaceholder || (Ea(this.parent.stripLines), d = this.parent.options.stripLines.indexOf(this.options));
            this.options = "undefined" === typeof a ? {} : a;
            this.parent.options.stripLines[d] = this.options;
          }
        };
        O.prototype.render = function() {
          this.ctx.save();
          var a = this.parent.getPixelCoordinatesOnAxis(this.value), d = Math.abs("pixel" === this._thicknessType ? this.thickness : Math.abs(this.parent.convertValueToPixel(this.endValue) - this.parent.convertValueToPixel(this.startValue)));
          if (0 < d) {
            var c = null === this.opacity ? 1 : this.opacity;
            this.ctx.strokeStyle = this.color;
            this.ctx.beginPath();
            var b = this.ctx.globalAlpha;
            this.ctx.globalAlpha = c;
            Z(this.id);
            var e, g, h2, m2;
            this.ctx.lineWidth = d;
            this.ctx.setLineDash && this.ctx.setLineDash(H(this.lineDashType, d));
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              e = g = 1 === this.ctx.lineWidth % 2 ? (a.x << 0) + 0.5 : a.x << 0, h2 = this.chart.plotArea.y1, m2 = this.chart.plotArea.y2, this.bounds = { x1: e - d / 2, y1: h2, x2: g + d / 2, y2: m2 };
            else if ("left" === this.parent._position || "right" === this.parent._position)
              h2 = m2 = 1 === this.ctx.lineWidth % 2 ? (a.y << 0) + 0.5 : a.y << 0, e = this.chart.plotArea.x1, g = this.chart.plotArea.x2, this.bounds = { x1: e, y1: h2 - d / 2, x2: g, y2: m2 + d / 2 };
            this.ctx.moveTo(e, h2);
            this.ctx.lineTo(g, m2);
            this.ctx.stroke();
            this.ctx.globalAlpha = b;
          }
          this.ctx.restore();
        };
        qa(ea2, L);
        ea2.prototype.showAt = function(a) {
          if (!this.enabled)
            return false;
          var d = this.chart, c = false;
          d.resetOverlayedCanvas();
          d.clearedOverlayedCanvas = this.parent.type;
          this.chart.renderCrosshairs(this.parent);
          if ("xySwapped" === d.plotInfo.axisPlacement)
            if ("bottom" === this.parent._position)
              for (var b = 0; b < d.axisY.length; b++)
                this.parent === d.axisY[b] && (d.axisY[b]._crosshairValue = a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum ? a : null);
            else if ("top" === this.parent._position)
              for (b = 0; b < d.axisY2.length; b++)
                this.parent === d.axisY2[b] && (d.axisY2[b]._crosshairValue = a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum ? a : null);
            else if ("left" === this.parent._position)
              for (b = 0; b < d.axisX.length; b++)
                this.parent === d.axisX[b] && (d.axisX[b]._crosshairValue = a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum ? a : null);
            else {
              if ("right" === this.parent._position)
                for (b = 0; b < d.axisX2.length; b++)
                  this.parent === d.axisX2[b] && (d.axisX2[b]._crosshairValue = a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum ? a : null);
            }
          else if ("bottom" === this.parent._position)
            for (b = 0; b < d.axisX.length; b++)
              this.parent === d.axisX[b] && (d.axisX[b]._crosshairValue = a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum ? a : null);
          else if ("top" === this.parent._position)
            for (b = 0; b < d.axisX2.length; b++)
              this.parent === d.axisX2[b] && (d.axisX2[b]._crosshairValue = a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum ? a : null);
          else if ("left" === this.parent._position)
            for (b = 0; b < d.axisY.length; b++)
              this.parent === d.axisY[b] && (d.axisY[b]._crosshairValue = a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum ? a : null);
          else if ("right" === this.parent._position)
            for (b = 0; b < d.axisY2.length; b++)
              this.parent === d.axisY2[b] && (d.axisY2[b]._crosshairValue = a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum ? a : null);
          for (b = 0; b < d.axisX.length; b++)
            a = d.axisX[b]._crosshairValue, d.axisX[b].crosshair && (d.axisX[b].crosshair.enabled && !m(a) && a >= d.axisX[b].viewportMinimum && a <= d.axisX[b].viewportMaximum) && (d.axisX[b].showCrosshair(a), d.axisX[b].crosshair._updatedValue = a, this === d.axisX[b].crosshair && (c = true));
          for (b = 0; b < d.axisX2.length; b++)
            a = d.axisX2[b]._crosshairValue, d.axisX2[b].crosshair && (d.axisX2[b].crosshair.enabled && !m(a) && a >= d.axisX2[b].viewportMinimum && a <= d.axisX2[b].viewportMaximum) && (d.axisX2[b].showCrosshair(a), d.axisX2[b].crosshair._updatedValue = a, this === d.axisX2[b].crosshair && (c = true));
          for (b = 0; b < d.axisY.length; b++)
            a = d.axisY[b]._crosshairValue, d.axisY[b].crosshair && (d.axisY[b].crosshair.enabled && !m(a) && a >= d.axisY[b].viewportMinimum && a <= d.axisY[b].viewportMaximum) && (d.axisY[b].showCrosshair(a), d.axisY[b].crosshair._updatedValue = a, this === d.axisY[b].crosshair && (c = true));
          for (b = 0; b < d.axisY2.length; b++)
            a = d.axisY2[b]._crosshairValue, d.axisY2[b].crosshair && (d.axisY2[b].crosshair.enabled && !m(a) && a >= d.axisY2[b].viewportMinimum && a <= d.axisY2[b].viewportMaximum) && (d.axisY2[b].showCrosshair(a), d.axisY2[b].crosshair._updatedValue = a, this === d.axisY2[b].crosshair && (c = true));
          this.chart.toolTip && this.chart.toolTip._entries && this.chart.toolTip.highlightObjects(this.chart.toolTip._entries);
          return c;
        };
        ea2.prototype.hide = function() {
          this.chart.resetOverlayedCanvas();
          this.chart.renderCrosshairs(this.parent);
          this._hidden = true;
        };
        ea2.prototype.render = function(a, d, c) {
          var b, e, g, h2, n2 = null, t2 = null, k = null, l = "";
          this.valueFormatString || ("dateTime" === this.parent.valueType ? this.valueFormatString = this.parent.valueFormatString : (k = 0, k = "xySwapped" === this.chart.plotInfo.axisPlacement ? 50 < this.parent.range ? 0 : 500 < this.chart.width && 25 > this.parent.range ? 2 : Math.floor(Math.abs(Math.log(this.parent.range) / Math.LN10)) + (5 > this.parent.range ? 2 : 10 > this.parent.range ? 1 : 0) : 50 < this.parent.range ? 0 : Math.floor(Math.abs(Math.log(this.parent.range) / Math.LN10)) + (5 > this.parent.range ? 2 : 10 > this.parent.range ? 1 : 0), this.valueFormatString = D.generateValueFormatString(this.parent.range, k)));
          var p = null === this.opacity ? 1 : this.opacity, q = Math.abs("pixel" === this._thicknessType ? this.thickness : this.parent.conversionParameters.pixelPerUnit * this.thickness), f = this.chart.overlaidCanvasCtx, w3 = f.globalAlpha;
          f.beginPath();
          f.strokeStyle = this.color;
          f.lineWidth = q;
          f.save();
          this.labelFontSize = Math.abs(m(this.options.labelFontSize) ? this.parent.labelFontSize : this.labelFontSize);
          this.labelMaxWidth = m(this.options.labelMaxWidth) ? 0.3 * this.chart.width : this.labelMaxWidth;
          this.labelMaxHeight = m(this.options.labelWrap) || this.labelWrap ? 0.3 * this.chart.height : 2 * this.labelFontSize;
          0 < q && f.setLineDash && f.setLineDash(H(this.lineDashType, q));
          k = new la(f, {
            x: 0,
            y: 0,
            padding: { top: 2, right: 3, bottom: 2, left: 4 },
            backgroundColor: this.labelBackgroundColor,
            borderColor: this.labelBorderColor,
            borderThickness: this.labelBorderThickness,
            cornerRadius: this.labelCornerRadius,
            maxWidth: this.labelMaxWidth,
            maxHeight: this.labelMaxHeight,
            angle: this.labelAngle,
            text: l,
            horizontalAlign: "left",
            fontSize: this.labelFontSize,
            fontFamily: this.labelFontFamily,
            fontWeight: this.labelFontWeight,
            fontColor: this.labelFontColor,
            fontStyle: this.labelFontStyle,
            textBaseline: "middle"
          });
          if (this.snapToDataPoint) {
            var z3 = 0, l = [];
            if ("xySwapped" === this.chart.plotInfo.axisPlacement) {
              var x = null;
              if ("bottom" === this.parent._position || "top" === this.parent._position)
                z3 = this.parent.dataSeries[0].axisX.convertPixelToValue({ y: d });
              else if ("left" === this.parent._position || "right" === this.parent._position)
                z3 = this.parent.convertPixelToValue({ y: d });
              for (var s = 0; s < this.parent.dataSeries.length; s++)
                (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (x.dataSeries = this.parent.dataSeries[s], null !== x.dataPoint.y && x.dataSeries.visible && l.push(x));
              x = null;
              if (0 === l.length)
                return;
              l.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              var y = x = 0;
              yPercent = cumulativeY = 0;
              for (var z3 = Infinity, v, s = 0; s < l.length; s++) {
                if ("rangeBar" === l[s].dataSeries.type || "error" === l[s].dataSeries.type) {
                  if (l[s].dataPoint.y)
                    for (var E3 = 0; E3 < l[s].dataPoint.y.length; E3++)
                      y = Math.abs(a - this.parent.convertValueToPixel(l[s].dataPoint.y[E3])), y <= z3 && (z3 = y, x = s);
                } else
                  "stackedBar" === l[s].dataSeries.type ? (cumulativeY = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = Math.abs(a - this.parent.convertValueToPixel(cumulativeY)), y <= z3 && (z3 = y, x = s)) : "stackedBar100" === l[s].dataSeries.type ? (y = l[0].dataPoint.x.getTime ? l[0].dataPoint.x.getTime() : l[0].dataPoint.x, m(v) && (v = Math.abs(a - this.parent.convertValueToPixel(100 * (l[0].dataSeries.dataPointEOs[l[0].index].cumulativeY / l[0].dataSeries.plotUnit.dataPointYSums[y])))), cumulativeY = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = l[s].dataPoint.x.getTime ? l[s].dataPoint.x.getTime() : l[s].dataPoint.x, yPercent = 100 * (cumulativeY / l[s].dataSeries.plotUnit.dataPointYSums[y]), y = Math.abs(a - this.parent.convertValueToPixel(yPercent)), y <= v && (v = y, x = s)) : (y = Math.abs(a - this.parent.convertValueToPixel(l[s].dataPoint.y)), y <= z3 && (z3 = y, x = s));
                m(v) || (z3 = Math.min(z3, v));
              }
              v = l[x];
              s = 0;
              if ("bottom" === this.parent._position || "top" === this.parent._position) {
                if ("rangeBar" === v.dataSeries.type || "error" === v.dataSeries.type) {
                  z3 = Math.abs(a - this.parent.convertValueToPixel(v.dataPoint.y[0]));
                  for (l = 0; l < v.dataPoint.y.length; l++)
                    y = Math.abs(a - this.parent.convertValueToPixel(v.dataPoint.y[l])), y < z3 && (z3 = y, s = l);
                  n2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataPoint.y[s]) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataPoint.y[s]) << 0;
                  this.value = v.dataPoint.y[s];
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.y[s] }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y[s] : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                } else
                  "stackedBar" === v.dataSeries.type ? (z3 = Math.abs(a - this.parent.convertValueToPixel(l[0].dataPoint.y)), cumulativeY = v.dataSeries.dataPointEOs[v.index].cumulativeY, n2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(cumulativeY) << 0) + 0.5 : this.parent.convertValueToPixel(cumulativeY) << 0, this.value = cumulativeY, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.y }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label) : "stackedBar100" === v.dataSeries.type ? (z3 = Math.abs(a - this.parent.convertValueToPixel(l[0].dataPoint.y)), cumulativeY = v.dataSeries.dataPointEOs[v.index].cumulativeY, y = v.dataPoint.x.getTime ? v.dataPoint.x.getTime() : v.dataPoint.x, yPercent = 100 * (cumulativeY / v.dataSeries.plotUnit.dataPointYSums[y]), n2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(yPercent) << 0) + 0.5 : this.parent.convertValueToPixel(yPercent) << 0, this.value = yPercent, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: yPercent }) : m(this.options.label) ? ga(
                    m(c) ? yPercent : c,
                    this.valueFormatString,
                    this.chart._cultureInfo
                  ) : this.label) : (n2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataPoint.y) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataPoint.y) << 0, this.value = v.dataPoint.y, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.y }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label);
                b = e = n2;
                g = this.chart.plotArea.y1;
                h2 = this.chart.plotArea.y2;
                this.bounds = { x1: b - q / 2, y1: g, x2: e + q / 2, y2: h2 };
                k.x = b - k.measureText().width / 2;
                k.x + k.width > this.chart.bounds.x2 ? k.x = this.chart.bounds.x2 - k.width : k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
                k.y = this.parent.lineCoordinates.y2 + ("top" === this.parent._position ? -k.height + this.parent.tickLength : k.fontSize / 2) + 2;
                k.y + k.height > this.chart.bounds.y2 ? k.y = this.chart.bounds.y2 - k.height : k.y < this.chart.bounds.y1 && (k.y = this.chart.bounds.y1);
              } else if ("left" === this.parent._position || "right" === this.parent._position) {
                g = h2 = t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataPoint.x) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataPoint.x) << 0;
                b = this.chart.plotArea.x1;
                e = this.chart.plotArea.x2;
                this.bounds = { x1: b, y1: g - q / 2, x2: e, y2: h2 + q / 2 };
                s = false;
                if (this.parent.labels)
                  for (z3 = Math.ceil(this.parent.interval), l = 0; l < this.parent.viewportMaximum; l += z3)
                    if (this.parent.labels[l])
                      s = true;
                    else {
                      s = false;
                      break;
                    }
                if (s) {
                  if ("axisX" === this.parent.type)
                    for (z3 = this.parent.convertPixelToValue({ y: d }), x = null, s = 0; s < this.parent.dataSeries.length; s++)
                      (x = this.parent.dataSeries[s].getDataPointAtX(
                        z3,
                        true
                      )) && 0 <= x.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? x.dataPoint.label : this.label);
                } else
                  k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? ga(v.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? Da(v.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label;
                this.value = v.dataPoint.x;
                k.y = h2 + k.fontSize / 2 - k.measureText().height / 2 + 2;
                k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
                "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
              }
            } else if ("bottom" === this.parent._position || "top" === this.parent._position) {
              z3 = this.parent.convertPixelToValue({ x: a });
              for (s = 0; s < this.parent.dataSeries.length; s++)
                (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (x.dataSeries = this.parent.dataSeries[s], null !== x.dataPoint.y && x.dataSeries.visible && l.push(x));
              if (0 === l.length)
                return;
              l.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              v = l[0];
              b = e = n2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataPoint.x) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataPoint.x) << 0;
              g = this.chart.plotArea.y1;
              h2 = this.chart.plotArea.y2;
              this.bounds = { x1: b - q / 2, y1: g, x2: e + q / 2, y2: h2 };
              s = false;
              if (this.parent.labels)
                for (z3 = Math.ceil(this.parent.interval), l = 0; l < this.parent.viewportMaximum; l += z3)
                  if (this.parent.labels[l])
                    s = true;
                  else {
                    s = false;
                    break;
                  }
              if (s) {
                if ("axisX" === this.parent.type)
                  for (z3 = this.parent.convertPixelToValue({ x: a }), x = null, s = 0; s < this.parent.dataSeries.length; s++)
                    (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? x.dataPoint.label : this.label);
              } else
                k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? ga(v.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.x }) : m(this.options.label) ? Da(v.dataPoint.x, this.valueFormatString, this.chart._cultureInfo) : this.label;
              this.value = v.dataPoint.x;
              k.x = b - k.measureText().width / 2;
              k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width);
              k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
              "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
            } else if ("left" === this.parent._position || "right" === this.parent._position) {
              !m(this.parent.dataSeries) && 0 < this.parent.dataSeries.length && (z3 = this.parent.dataSeries[0].axisX.convertPixelToValue({ x: a }));
              for (s = 0; s < this.parent.dataSeries.length; s++)
                (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (x.dataSeries = this.parent.dataSeries[s], null !== x.dataPoint.y && x.dataSeries.visible && l.push(x));
              if (0 === l.length)
                return;
              l.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              y = x = 0;
              z3 = Infinity;
              for (s = 0; s < l.length; s++) {
                if ("rangeColumn" === l[s].dataSeries.type || "rangeArea" === l[s].dataSeries.type || "error" === l[s].dataSeries.type || "rangeSplineArea" === l[s].dataSeries.type || "candlestick" === l[s].dataSeries.type || "ohlc" === l[s].dataSeries.type || "boxAndWhisker" === l[s].dataSeries.type) {
                  if (l[s].dataPoint.y)
                    for (E3 = 0; E3 < l[s].dataPoint.y.length; E3++)
                      y = Math.abs(d - this.parent.convertValueToPixel(l[s].dataPoint.y[E3])), y <= z3 && (z3 = y, x = s);
                } else
                  "stackedColumn" === l[s].dataSeries.type ? (b = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = Math.abs(d - this.parent.convertValueToPixel(b)), y <= z3 && (z3 = y, x = s)) : "stackedArea" === l[s].dataSeries.type ? (b = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = Math.abs(d - this.parent.convertValueToPixel(b)), y <= z3 && (z3 = y, x = s)) : "stackedColumn100" === l[s].dataSeries.type || "stackedArea100" === l[s].dataSeries.type ? (y = l[0].dataPoint.x.getTime ? l[0].dataPoint.x.getTime() : l[0].dataPoint.x, m(v) && (v = Math.abs(d - this.parent.convertValueToPixel(100 * (l[0].dataSeries.dataPointEOs[l[0].index].cumulativeY / l[0].dataSeries.plotUnit.dataPointYSums[y])))), "stackedColumn100" === l[s].dataSeries.type ? (t2 = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = l[s].dataPoint.x.getTime ? l[s].dataPoint.x.getTime() : l[s].dataPoint.x, b = 100 * (t2 / l[s].dataSeries.plotUnit.dataPointYSums[y]), y = Math.abs(d - this.parent.convertValueToPixel(b)), y <= v && (v = y, x = s)) : "stackedArea100" === l[s].dataSeries.type && (t2 = l[s].dataSeries.dataPointEOs[l[s].index].cumulativeY, y = l[s].dataPoint.x.getTime ? l[s].dataPoint.x.getTime() : l[s].dataPoint.x, b = 100 * (t2 / l[s].dataSeries.plotUnit.dataPointYSums[y]), y = Math.abs(d - this.parent.convertValueToPixel(b)), y <= v && (v = y, x = s))) : "waterfall" === l[s].dataSeries.type ? (y = Math.abs(d - this.parent.convertValueToPixel(l[s].dataSeries.dataPointEOs[l[s].index].cumulativeSum)), y <= z3 && (v = z3 = y, x = s)) : (y = Math.abs(d - this.parent.convertValueToPixel(l[s].dataPoint.y)), y <= z3 && (z3 = y, x = s));
                m(v) || (z3 = Math.min(z3, v));
              }
              v = l[x];
              s = 0;
              if ("rangeColumn" === v.dataSeries.type || "rangeArea" === v.dataSeries.type || "error" === v.dataSeries.type || "rangeSplineArea" === v.dataSeries.type || "candlestick" === v.dataSeries.type || "ohlc" === v.dataSeries.type || "boxAndWhisker" === v.dataSeries.type) {
                z3 = Math.abs(d - this.parent.convertValueToPixel(v.dataPoint.y[0]));
                for (l = 0; l < v.dataPoint.y.length; l++)
                  y = Math.abs(d - this.parent.convertValueToPixel(v.dataPoint.y[l])), y < z3 && (z3 = y, s = l);
                t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataPoint.y[s]) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataPoint.y[s]) << 0;
                k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.y[s] }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y[s] : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                this.value = v.dataPoint.y[s];
              } else
                "stackedColumn" === v.dataSeries.type ? (b = v.dataSeries.dataPointEOs[v.index].cumulativeY, t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(b) << 0) + 0.5 : this.parent.convertValueToPixel(b) << 0, k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: v.dataPoint.y
                }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = b) : "stackedArea" === v.dataSeries.type ? (b = v.dataSeries.dataPointEOs[v.index].cumulativeY, t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(b) << 0) + 0.5 : this.parent.convertValueToPixel(b) << 0, k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: v.dataPoint.y }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = b) : "stackedColumn100" === v.dataSeries.type ? (t2 = v.dataSeries.dataPointEOs[v.index].cumulativeY, y = v.dataPoint.x.getTime ? v.dataPoint.x.getTime() : v.dataPoint.x, b = 100 * (t2 / v.dataSeries.plotUnit.dataPointYSums[y]), t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(b) << 0) + 0.5 : this.parent.convertValueToPixel(b) << 0, k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: b
                }) : m(this.options.label) ? ga(m(c) ? b : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = b) : "stackedArea100" === v.dataSeries.type ? (t2 = v.dataSeries.dataPointEOs[v.index].cumulativeY, y = v.dataPoint.x.getTime ? v.dataPoint.x.getTime() : v.dataPoint.x, b = 100 * (t2 / v.dataSeries.plotUnit.dataPointYSums[y]), t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(b) << 0) + 0.5 : this.parent.convertValueToPixel(b) << 0, k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: b
                }) : m(this.options.label) ? ga(m(c) ? b : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = b) : "waterfall" === v.dataSeries.type ? (t2 = 1 === f.lineWidth % 2 ? (this.parent.convertValueToPixel(v.dataSeries.dataPointEOs[v.index].cumulativeSum) << 0) + 0.5 : this.parent.convertValueToPixel(v.dataSeries.dataPointEOs[v.index].cumulativeSum) << 0, k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: v.dataSeries.dataPointEOs[v.index].cumulativeSum
                }) : m(this.options.label) ? ga(m(c) ? v.dataSeries.dataPointEOs[v.index].cumulativeSum : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = v.dataSeries.dataPointEOs[v.index].cumulativeSum) : (t2 = 1 === f.lineWidth % 2 ? (m(a) ? d : this.parent.convertValueToPixel(v.dataPoint.y) << 0) + 0.5 : m(a) ? d : this.parent.convertValueToPixel(v.dataPoint.y) << 0, k.text = this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: m(c) ? v.dataPoint.y : c
                }) : m(this.options.label) ? ga(m(c) ? v.dataPoint.y : c, this.valueFormatString, this.chart._cultureInfo) : this.label, this.value = v.dataPoint.y);
              g = h2 = t2;
              b = this.chart.plotArea.x1;
              e = this.chart.plotArea.x2;
              this.bounds = { x1: b, y1: g - q / 2, x2: e, y2: h2 + q / 2 };
              k.y = h2 + k.fontSize / 2 - k.measureText().height / 2 + 2;
              k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
              "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
            }
            l = null;
            f.globalAlpha = p;
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              "top" === this.parent._position && k.y - k.fontSize / 2 < this.chart.bounds.y1 && (k.y = this.chart.bounds.y1 + k.fontSize / 2), "bottom" === this.parent._position && this.parent.lineCoordinates.y2 - k.fontSize / 2 + k.measureText().height > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.height + k.fontSize / 2 + 2), this.value >= Math.min(this.parent.viewportMinimum, this.parent.viewportMaximum) && this.value <= Math.max(this.parent.viewportMinimum, this.parent.viewportMaximum) && 0 < q && (f.moveTo(b, g), f.lineTo(e, h2), f.stroke(), this._hidden = false);
            if ("left" === this.parent._position || "right" === this.parent._position)
              "left" === this.parent._position && k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1), "right" === this.parent._position && k.x + k.measureText().width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.measureText().width), this.value >= Math.min(this.parent.viewportMinimum, this.parent.viewportMaximum) && this.value <= Math.max(this.parent.viewportMinimum, this.parent.viewportMaximum) && 0 < q && (f.moveTo(b, g), f.lineTo(e, h2), f.stroke(), this._hidden = false);
          } else {
            if ("bottom" === this.parent._position || "top" === this.parent._position)
              b = e = n2 = 1 === f.lineWidth % 2 ? (a << 0) + 0.5 : a << 0, g = this.chart.plotArea.y1, h2 = this.chart.plotArea.y2, this.bounds = { x1: b - q / 2, y1: g, x2: e + q / 2, y2: h2 };
            else if ("left" === this.parent._position || "right" === this.parent._position)
              g = h2 = t2 = 1 === f.lineWidth % 2 ? (d << 0) + 0.5 : d << 0, b = this.chart.plotArea.x1, e = this.chart.plotArea.x2, this.bounds = { x1: b, y1: g - q / 2, x2: e, y2: h2 + q / 2 };
            if ("xySwapped" === this.chart.plotInfo.axisPlacement)
              if ("left" === this.parent._position || "right" === this.parent._position) {
                s = false;
                if (this.parent.labels)
                  for (z3 = Math.ceil(this.parent.interval), l = 0; l < this.parent.viewportMaximum; l += z3)
                    if (this.parent.labels[l])
                      s = true;
                    else {
                      s = false;
                      break;
                    }
                if (s) {
                  if ("axisX" === this.parent.type)
                    for (z3 = this.parent.convertPixelToValue({ y: d }), x = null, s = 0; s < this.parent.dataSeries.length; s++)
                      (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(a) : c }) : m(this.options.label) ? x.dataPoint.label : this.label);
                } else
                  k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(d) : c }) : m(this.options.label) ? ga(m(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(d) : c }) : m(this.options.label) ? Da(m(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
                k.y = d + k.fontSize / 2 - k.measureText().height / 2 + 2;
                k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2);
                "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x1 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
              } else {
                if ("bottom" === this.parent._position || "top" === this.parent._position)
                  k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(a) : c }) : m(this.options.label) ? ga(m(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label, k.x = b - k.measureText().width / 2, k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width), k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1), "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
              }
            else if ("bottom" === this.parent._position || "top" === this.parent._position) {
              s = false;
              l = "";
              if (this.parent.labels)
                for (z3 = Math.ceil(this.parent.interval), l = 0; l < this.parent.viewportMaximum; l += z3)
                  if (this.parent.labels[l])
                    s = true;
                  else {
                    s = false;
                    break;
                  }
              if (s) {
                if ("axisX" === this.parent.type)
                  for (z3 = this.parent.convertPixelToValue({ x: a }), x = null, s = 0; s < this.parent.dataSeries.length; s++)
                    (x = this.parent.dataSeries[s].getDataPointAtX(z3, true)) && 0 <= x.index && (k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(a) : c }) : m(this.options.label) ? m(c) ? x.dataPoint.label : c : this.label);
              } else
                k.text = "dateTime" !== this.parent.valueType || this.parent.logarithmic ? this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? 0 < this.parent.dataSeries.length ? this.parent.convertPixelToValue(a) : "" : c }) : m(this.options.label) ? ga(m(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label : this.labelFormatter ? this.labelFormatter({
                  chart: this.chart,
                  axis: this.parent.options,
                  crosshair: this.options,
                  value: m(c) ? this.parent.convertPixelToValue(a) : c
                }) : m(this.options.label) ? Da(m(c) ? this.parent.convertPixelToValue(a) : c, this.valueFormatString, this.chart._cultureInfo) : this.label;
              k.x = b - k.measureText().width / 2;
              k.x + k.width > this.chart.bounds.x2 && (k.x = this.chart.bounds.x2 - k.width);
              k.x < this.chart.bounds.x1 && (k.x = this.chart.bounds.x1);
              "bottom" === this.parent._position ? k.y = this.parent.lineCoordinates.y2 + k.fontSize / 2 + 2 : "top" === this.parent._position && (k.y = this.parent.lineCoordinates.y1 - k.height + k.fontSize / 2 + 2);
            } else if ("left" === this.parent._position || "right" === this.parent._position)
              k.text = this.labelFormatter ? this.labelFormatter({ chart: this.chart, axis: this.parent.options, crosshair: this.options, value: m(c) ? this.parent.convertPixelToValue(d) : c }) : m(this.options.label) ? ga(m(c) ? this.parent.convertPixelToValue(d) : c, this.valueFormatString, this.chart._cultureInfo) : this.label, k.y = d + k.fontSize / 2 - k.measureText().height / 2 + 2, k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 + 2 : k.y + k.measureText().height - k.fontSize / 2 > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.measureText().height + k.fontSize / 2), "left" === this.parent._position ? k.x = this.parent.lineCoordinates.x2 - k.measureText().width : "right" === this.parent._position && (k.x = this.parent.lineCoordinates.x2);
            "left" === this.parent._position && k.x < this.chart.bounds.x1 ? k.x = this.chart.bounds.x1 : "right" === this.parent._position && k.x + k.measureText().width > this.chart.bounds.x2 ? k.x = this.chart.bounds.x2 - k.measureText().width : "top" === this.parent._position && k.y - k.fontSize / 2 < this.chart.bounds.y1 ? k.y = this.chart.bounds.y1 + k.fontSize / 2 : "bottom" === this.parent._position && this.parent.lineCoordinates.y2 - k.fontSize / 2 + k.measureText().height > this.chart.bounds.y2 && (k.y = this.chart.bounds.y2 - k.height + k.fontSize / 2 + 2);
            f.globalAlpha = p;
            0 < q && (f.moveTo(b, g), f.lineTo(e, h2), f.stroke(), this._hidden = false);
            this.value = "bottom" === this.parent._position || "top" === this.parent._position ? this.parent.convertPixelToValue(a) : this.parent.convertPixelToValue(d);
          }
          if ("bottom" === this.parent._position || "top" === this.parent._position)
            this._updatedValue = this.parent.convertPixelToValue(n2);
          if ("left" === this.parent._position || "right" === this.parent._position)
            this._updatedValue = this.parent.convertPixelToValue(t2);
          this._textBlock = k;
          this._label = c;
          m(c) || this.renderLabel();
          f.restore();
          f.globalAlpha = w3;
        };
        ea2.prototype.renderLabel = function() {
          this.value >= Math.min(this.parent.viewportMinimum, this.parent.viewportMaximum) && this.value <= Math.max(this.parent.viewportMinimum, this.parent.viewportMaximum) && (m(this._textBlock) || (m(this._textBlock.text) || !("number" === typeof this._textBlock.text.valueOf() || 0 < this._textBlock.text.length) || this._hidden) || this._textBlock.render(true), m(this._label) && this.dispatchEvent("updated", { chart: this.chart, crosshair: this.options, axis: this.parent, value: this.value }, this.parent));
        };
        qa(W2, L);
        W2.prototype._initialize = function() {
          this.updateOption("updated");
          this.updateOption("hidden");
          if (this.enabled) {
            this.container = document.createElement("div");
            this.container.setAttribute(
              "class",
              "canvasjs-chart-tooltip"
            );
            this.container.style.position = "absolute";
            this.container.style.height = "auto";
            this.container.style.boxShadow = "1px 1px 2px 2px rgba(0,0,0,0.1)";
            this.container.style.zIndex = "1000";
            this.container.style.pointerEvents = "none";
            this.container.style.display = "none";
            var a = document.createElement("div");
            a.style.width = "auto";
            a.style.height = "auto";
            a.style.minWidth = "50px";
            a.style.lineHeight = "normal";
            a.style.margin = "0px 0px 0px 0px";
            a.style.padding = "5px";
            a.style.fontFamily = "Calibri, Arial, Georgia, serif";
            a.style.fontWeight = "normal";
            a.style.fontStyle = t ? "italic" : "normal";
            a.style.fontSize = "14px";
            a.style.color = "#000000";
            a.style.textShadow = "1px 1px 1px rgba(0, 0, 0, 0.1)";
            a.style.textAlign = "left";
            a.style.border = "2px solid gray";
            a.style.background = t ? "rgba(255,255,255,.9)" : "rgb(255,255,255)";
            a.style.textIndent = "0px";
            a.style.whiteSpace = "nowrap";
            a.style.borderRadius = "5px";
            a.style.MozUserSelect = "none";
            a.style.WebkitUserSelect = "none";
            a.style.msUserSelect = "none";
            a.style.userSelect = "none";
            t || (a.style.filter = "alpha(opacity = 90)", a.style.filter = "progid:DXImageTransform.Microsoft.Shadow(Strength=3, Direction=135, Color='#666666')");
            a.innerText = "Sample Tooltip";
            this.container.appendChild(a);
            this.contentDiv = this.container.firstChild;
            this.container.style.borderRadius = this.contentDiv.style.borderRadius;
            this.chart._canvasJSContainer.appendChild(this.container);
          }
        };
        W2.prototype.mouseMoveHandler = function(a, d) {
          this._lastUpdated && 4 > (/* @__PURE__ */ new Date()).getTime() - this._lastUpdated || (this._lastUpdated = (/* @__PURE__ */ new Date()).getTime(), this.chart.resetOverlayedCanvas(), this._updateToolTip(a, d), !this._updatedEventParameters || (isNaN(this._prevX) || isNaN(this._prevY)) || this.dispatchEvent("updated", this._updatedEventParameters, this));
        };
        W2.prototype._updateToolTip = function(a, d, c) {
          c = "undefined" === typeof c ? true : c;
          this.container || this._initialize();
          this.enabled || this.hide();
          if (!this.chart.disableToolTip) {
            if ("undefined" === typeof a || "undefined" === typeof d) {
              if (isNaN(this._prevX) || isNaN(this._prevY))
                return;
              a = this._prevX;
              d = this._prevY;
            } else
              this._prevX = a, this._prevY = d;
            var b = null, e = null, g = [], h2 = 0;
            if (this.shared && this.enabled && "none" !== this.chart.plotInfo.axisPlacement) {
              var n2 = [];
              if (this.chart.axisX)
                for (var w3 = 0; w3 < this.chart.axisX.length; w3++) {
                  for (var h2 = "xySwapped" === this.chart.plotInfo.axisPlacement ? this.chart.axisX[w3].convertPixelToValue({ y: d }) : this.chart.axisX[w3].convertPixelToValue({ x: a }), k = null, b = 0; b < this.chart.axisX[w3].dataSeries.length; b++)
                    (k = this.chart.axisX[w3].dataSeries[b].getDataPointAtX(h2, c)) && 0 <= k.index && (k.dataSeries = this.chart.axisX[w3].dataSeries[b], null !== k.dataPoint.y && k.dataSeries.visible && n2.push(k));
                  k = null;
                }
              if (this.chart.axisX2)
                for (w3 = 0; w3 < this.chart.axisX2.length; w3++) {
                  h2 = "xySwapped" === this.chart.plotInfo.axisPlacement ? this.chart.axisX2[w3].convertPixelToValue({ y: d }) : this.chart.axisX2[w3].convertPixelToValue({ x: a });
                  k = null;
                  for (b = 0; b < this.chart.axisX2[w3].dataSeries.length; b++)
                    (k = this.chart.axisX2[w3].dataSeries[b].getDataPointAtX(h2, c)) && 0 <= k.index && (k.dataSeries = this.chart.axisX2[w3].dataSeries[b], null !== k.dataPoint.y && k.dataSeries.visible && n2.push(k));
                  k = null;
                }
              if (0 === n2.length)
                return;
              n2.sort(function(a2, b2) {
                return a2.distance - b2.distance;
              });
              c = n2[0];
              for (b = 0; b < n2.length; b++)
                n2[b].dataPoint.x.valueOf() === c.dataPoint.x.valueOf() && g.push(n2[b]);
              n2 = null;
            } else {
              if (b = this.chart.getDataPointAtXY(a, d, c))
                this.currentDataPointIndex = b.dataPointIndex, this.currentSeriesIndex = b.dataSeries.index;
              else if (t)
                if (b = $a(a, d, this.chart._eventManager.ghostCtx), 0 < b && "undefined" !== typeof this.chart._eventManager.objectMap[b]) {
                  b = this.chart._eventManager.objectMap[b];
                  if ("legendItem" === b.objectType)
                    return;
                  this.currentSeriesIndex = b.dataSeriesIndex;
                  this.currentDataPointIndex = 0 <= b.dataPointIndex ? b.dataPointIndex : -1;
                } else
                  this.currentDataPointIndex = -1;
              else
                this.currentDataPointIndex = -1;
              if (0 <= this.currentSeriesIndex) {
                e = this.chart.data[this.currentSeriesIndex];
                k = {};
                if (0 <= this.currentDataPointIndex)
                  b = e.dataPoints[this.currentDataPointIndex], k.dataSeries = e, k.dataPoint = b, k.index = this.currentDataPointIndex, k.distance = Math.abs(b.x - h2), "waterfall" === e.type && (k.cumulativeSumYStartValue = e.dataPointEOs[this.currentDataPointIndex].cumulativeSumYStartValue, k.cumulativeSum = e.dataPointEOs[this.currentDataPointIndex].cumulativeSum);
                else {
                  if (!this.enabled || "line" !== e.type && "stepLine" !== e.type && "spline" !== e.type && "area" !== e.type && "stepArea" !== e.type && "splineArea" !== e.type && "stackedArea" !== e.type && "stackedArea100" !== e.type && "rangeArea" !== e.type && "rangeSplineArea" !== e.type && "candlestick" !== e.type && "ohlc" !== e.type && "boxAndWhisker" !== e.type)
                    return;
                  h2 = e.axisX.convertPixelToValue({ x: a });
                  k = e.getDataPointAtX(h2, c);
                  m(k) || (k.dataSeries = e, this.currentDataPointIndex = k.index, b = k.dataPoint);
                }
                if (!m(k) && !m(k.dataPoint) && !m(k.dataPoint.y))
                  if (k.dataSeries.axisY)
                    if (0 < k.dataPoint.y.length) {
                      for (b = c = 0; b < k.dataPoint.y.length; b++)
                        k.dataPoint.y[b] < k.dataSeries.axisY.viewportMinimum ? c-- : k.dataPoint.y[b] > k.dataSeries.axisY.viewportMaximum && c++;
                      c < k.dataPoint.y.length && c > -k.dataPoint.y.length && g.push(k);
                    } else
                      "column" === e.type || "bar" === e.type ? 0 > k.dataPoint.y ? 0 > k.dataSeries.axisY.viewportMinimum && k.dataSeries.axisY.viewportMaximum >= k.dataPoint.y && g.push(k) : k.dataSeries.axisY.viewportMinimum <= k.dataPoint.y && 0 <= k.dataSeries.axisY.viewportMaximum && g.push(k) : "bubble" === e.type ? (c = this.chart._eventManager.objectMap[e.dataPointIds[k.index]].size / 2, k.dataPoint.y >= k.dataSeries.axisY.viewportMinimum - c && k.dataPoint.y <= k.dataSeries.axisY.viewportMaximum + c && g.push(k)) : "waterfall" === e.type ? (c = 0, k.cumulativeSumYStartValue < k.dataSeries.axisY.viewportMinimum ? c-- : k.cumulativeSumYStartValue > k.dataSeries.axisY.viewportMaximum && c++, k.cumulativeSum < k.dataSeries.axisY.viewportMinimum ? c-- : k.cumulativeSum > k.dataSeries.axisY.viewportMaximum && c++, 2 > c && -2 < c && g.push(k)) : (0 <= k.dataSeries.type.indexOf("100") || "stackedColumn" === e.type || "stackedBar" === e.type || k.dataPoint.y >= k.dataSeries.axisY.viewportMinimum && k.dataPoint.y <= k.dataSeries.axisY.viewportMaximum) && g.push(k);
                  else
                    g.push(k);
              }
            }
            if (0 < g.length) {
              if (this.highlightObjects(g), this.enabled) {
                c = "";
                c = this.getToolTipInnerHTML({ entries: g });
                if (null !== c) {
                  this.contentDiv.innerHTML = c;
                  if (this.isToolTipDefinedInData && m(this.options.content) && m(this.options.contentFormatter))
                    for (h2 = this.contentDiv.getElementsByTagName("span"), b = 0; b < h2.length; b++)
                      h2[b] && (h2[b].style.color = h2[b].getAttribute("data-color"));
                  h2 = false;
                  "none" === this.container.style.display && (h2 = true, this.container.style.display = "block");
                  try {
                    this.contentDiv.style.background = this.backgroundColor ? this.backgroundColor : t ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", this.borderColor = "waterfall" === g[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataPoint.color ? g[0].dataPoint.color : 0 < g[0].dataPoint.y ? g[0].dataSeries.risingColor : g[0].dataSeries.fallingColor : "error" === g[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataSeries.color ? g[0].dataSeries.color : g[0].dataSeries._colorSet[e.index % g[0].dataSeries._colorSet.length] : this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataPoint.color ? g[0].dataPoint.color : g[0].dataSeries.color ? g[0].dataSeries.color : g[0].dataSeries._colorSet[g[0].index % g[0].dataSeries._colorSet.length], this.contentDiv.style.borderWidth = this.borderThickness || 0 === this.borderThickness ? this.borderThickness + "px" : "2px", this.contentDiv.style.borderRadius = this.cornerRadius || 0 === this.cornerRadius ? this.cornerRadius + "px" : "5px", this.container.style.borderRadius = this.contentDiv.style.borderRadius, this.contentDiv.style.fontSize = this.fontSize || 0 === this.fontSize ? this.fontSize + "px" : "14px", this.contentDiv.style.color = this.fontColor ? this.fontColor : "#000000", this.contentDiv.style.fontFamily = this.fontFamily ? this.fontFamily : "Calibri, Arial, Georgia, serif;", this.contentDiv.style.fontWeight = this.fontWeight ? this.fontWeight : "normal", this.contentDiv.style.fontStyle = this.fontStyle ? this.fontStyle : t ? "italic" : "normal";
                  } catch (l) {
                  }
                  "pie" === g[0].dataSeries.type || "doughnut" === g[0].dataSeries.type || "funnel" === g[0].dataSeries.type || "pyramid" === g[0].dataSeries.type || "bar" === g[0].dataSeries.type || "rangeBar" === g[0].dataSeries.type || "stackedBar" === g[0].dataSeries.type || "stackedBar100" === g[0].dataSeries.type ? a = a - 10 - this.container.clientWidth : (a = g[0].dataSeries.axisX.convertValueToPixel(g[0].dataPoint.x) - this.container.clientWidth << 0, a -= 10);
                  0 > a && (a += this.container.clientWidth + 20);
                  a + this.container.clientWidth > Math.max(this.chart.container.clientWidth, this.chart.width) && (a = Math.max(0, Math.max(this.chart.container.clientWidth, this.chart.width) - this.container.clientWidth));
                  d = 1 !== g.length || this.shared || "line" !== g[0].dataSeries.type && "stepLine" !== g[0].dataSeries.type && "spline" !== g[0].dataSeries.type && "area" !== g[0].dataSeries.type && "stepArea" !== g[0].dataSeries.type && "splineArea" !== g[0].dataSeries.type ? "bar" === g[0].dataSeries.type || "rangeBar" === g[0].dataSeries.type || "stackedBar" === g[0].dataSeries.type || "stackedBar100" === g[0].dataSeries.type ? g[0].dataSeries.axisX.convertValueToPixel(g[0].dataPoint.x) : d : g[0].dataSeries.axisY.convertValueToPixel(g[0].dataPoint.y);
                  d = -d + 10;
                  0 < d + this.container.clientHeight + 5 && (d -= d + this.container.clientHeight + 5 - 0);
                  this.fixMozTransitionDelay(a, d);
                  !this.animationEnabled || h2 ? this.disableAnimation() : (this.enableAnimation(), this.container.style.MozTransition = this.mozContainerTransition);
                  this.positionLeft = a;
                  this.positionBottom = d;
                  this.container.style.left = a + "px";
                  this.container.style.bottom = d + "px";
                } else
                  this.hide(false), this.enabled && this.dispatchEvent("hidden", { chart: this.chart, toolTip: this }, this);
                d = [];
                for (b = 0; b < g.length; b++)
                  d.push({
                    xValue: g[b].dataPoint.x,
                    dataPoint: g[b].dataPoint,
                    dataSeries: g[b].dataSeries,
                    dataPointIndex: g[b].index,
                    dataSeriesIndex: g[b].dataSeries._index
                  });
                this._updatedEventParameters = { chart: this.chart, toolTip: this.options, content: c, entries: d };
                this._entries = g;
              }
            } else
              this.hide(), this.enabled && this.dispatchEvent("hidden", { chart: this.chart, toolTip: this }, this);
          }
        };
        W2.prototype.highlightObjects = function(a) {
          var d = this.chart.overlaidCanvasCtx;
          m(this.chart.clearedOverlayedCanvas) || "toolTip" === this.chart.clearedOverlayedCanvas ? (this.chart.resetOverlayedCanvas(), d.clearRect(0, 0, this.chart.width, this.chart.height), this.chart.clearedOverlayedCanvas = "toolTip") : this.chart.clearedOverlayedCanvas = null;
          d.save();
          var c = this.chart.plotArea, b = 0;
          d.beginPath();
          d.rect(c.x1, c.y1, c.x2 - c.x1, c.y2 - c.y1);
          d.clip();
          for (c = 0; c < a.length; c++) {
            var e = a[c];
            if ((e = this.chart._eventManager.objectMap[e.dataSeries.dataPointIds[e.index]]) && e.objectType && "dataPoint" === e.objectType) {
              var b = this.chart.data[e.dataSeriesIndex], g = b.dataPoints[e.dataPointIndex], h2 = e.dataPointIndex;
              false === g.highlightEnabled || true !== b.highlightEnabled && true !== g.highlightEnabled || ("line" === b.type || "stepLine" === b.type || "spline" === b.type || "scatter" === b.type || "area" === b.type || "stepArea" === b.type || "splineArea" === b.type || "stackedArea" === b.type || "stackedArea100" === b.type || "rangeArea" === b.type || "rangeSplineArea" === b.type ? (g = b.getMarkerProperties(h2, e.x1, e.y1, this.chart.overlaidCanvasCtx), g.size = Math.max(1.5 * g.size << 0, 10), g.borderColor = g.borderColor || "#FFFFFF", g.borderThickness = g.borderThickness || Math.ceil(0.1 * g.size), X.drawMarkers([g]), "undefined" !== typeof e.y2 && (g = b.getMarkerProperties(h2, e.x1, e.y2, this.chart.overlaidCanvasCtx), g.size = Math.max(1.5 * g.size << 0, 10), g.borderColor = g.borderColor || "#FFFFFF", g.borderThickness = g.borderThickness || Math.ceil(0.1 * g.size), X.drawMarkers([g]))) : "bubble" === b.type ? (g = b.getMarkerProperties(h2, e.x1, e.y1, this.chart.overlaidCanvasCtx), g.size = e.size, g.color = "white", g.borderColor = "white", d.globalAlpha = 0.3, X.drawMarkers([g]), d.globalAlpha = 1) : "column" === b.type || "stackedColumn" === b.type || "stackedColumn100" === b.type || "bar" === b.type || "rangeBar" === b.type || "stackedBar" === b.type || "stackedBar100" === b.type || "rangeColumn" === b.type || "waterfall" === b.type ? ba(d, e.x1, e.y1, e.x2, e.y2, "white", 0, null, false, false, false, false, 0.3) : "pie" === b.type || "doughnut" === b.type ? ra2(d, e.center, e.radius, "white", b.type, e.startAngle, e.endAngle, 0.3, e.percentInnerRadius) : "funnel" === b.type || "pyramid" === b.type ? ta2(d, e.funnelSection, 0.3, "white") : "candlestick" === b.type ? (d.globalAlpha = 1, d.strokeStyle = e.color, d.lineWidth = 2 * e.borderThickness, b = 0 === d.lineWidth % 2 ? 0 : 0.5, d.beginPath(), d.moveTo(e.x3 - b, Math.min(e.y2, e.y3)), d.lineTo(e.x3 - b, Math.min(e.y1, e.y4)), d.stroke(), d.beginPath(), d.moveTo(e.x3 - b, Math.max(e.y1, e.y4)), d.lineTo(e.x3 - b, Math.max(e.y2, e.y3)), d.stroke(), ba(d, e.x1, Math.min(e.y1, e.y4), e.x2, Math.max(e.y1, e.y4), "transparent", 2 * e.borderThickness, e.color, false, false, false, false), d.globalAlpha = 1) : "ohlc" === b.type ? (d.globalAlpha = 1, d.strokeStyle = e.color, d.lineWidth = 2 * e.borderThickness, b = 0 === d.lineWidth % 2 ? 0 : 0.5, d.beginPath(), d.moveTo(e.x3 - b, e.y2), d.lineTo(e.x3 - b, e.y3), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y1), d.lineTo(e.x1, e.y1), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y4), d.lineTo(e.x2, e.y4), d.stroke(), d.globalAlpha = 1) : "boxAndWhisker" === b.type ? (d.save(), d.globalAlpha = 1, d.strokeStyle = e.stemColor, d.lineWidth = 2 * e.stemThickness, 0 < e.stemThickness && (d.beginPath(), d.moveTo(e.x3, e.y2 + e.borderThickness / 2), d.lineTo(e.x3, e.y1 + e.whiskerThickness / 2), d.stroke(), d.beginPath(), d.moveTo(e.x3, e.y4 - e.whiskerThickness / 2), d.lineTo(e.x3, e.y3 - e.borderThickness / 2), d.stroke()), d.beginPath(), ba(d, e.x1, Math.max(e.y2, e.y3), e.x2, Math.min(e.y2, e.y3), "transparent", 2 * e.borderThickness, e.color, false, false, false, false), d.globalAlpha = 1, d.strokeStyle = e.whiskerColor, d.lineWidth = 2 * e.whiskerThickness, 0 < e.whiskerThickness && (d.beginPath(), d.moveTo(Math.floor(e.x3 - e.whiskerLength / 2), e.y4), d.lineTo(Math.ceil(e.x3 + e.whiskerLength / 2), e.y4), d.stroke(), d.beginPath(), d.moveTo(Math.floor(e.x3 - e.whiskerLength / 2), e.y1), d.lineTo(Math.ceil(e.x3 + e.whiskerLength / 2), e.y1), d.stroke()), d.globalAlpha = 1, d.strokeStyle = e.lineColor, d.lineWidth = 2 * e.lineThickness, 0 < e.lineThickness && (d.beginPath(), d.moveTo(e.x1, e.y5), d.lineTo(e.x2, e.y5), d.stroke()), d.restore(), d.globalAlpha = 1) : "error" === b.type && z2(d, e.x1, e.y1, e.x2, e.y2, "white", e.whiskerProperties, e.stemProperties, e.isXYSwapped, 0.3));
            }
          }
          d.restore();
          d.globalAlpha = 1;
          d.beginPath();
        };
        W2.prototype.getToolTipInnerHTML = function(a) {
          a = a.entries;
          var d = null, c = null, b = null, e = 0, g = "";
          this.isToolTipDefinedInData = true;
          for (var h2 = 0; h2 < a.length; h2++)
            if (a[h2].dataSeries.toolTipContent || a[h2].dataPoint.toolTipContent) {
              this.isToolTipDefinedInData = false;
              break;
            }
          if (this.isToolTipDefinedInData && (this.content && "function" === typeof this.content || this.contentFormatter))
            a = { chart: this.chart, toolTip: this.options, entries: a }, d = this.contentFormatter ? this.contentFormatter(a) : this.content(a);
          else if (this.shared && "none" !== this.chart.plotInfo.axisPlacement) {
            for (var m2 = null, n2 = "", h2 = 0; h2 < a.length; h2++) {
              c = a[h2].dataSeries;
              b = a[h2].dataPoint;
              e = a[h2].index;
              g = "";
              if (0 === h2 && this.isToolTipDefinedInData && !this.content) {
                this.chart.axisX && 0 < this.chart.axisX.length ? n2 += "undefined" !== typeof this.chart.axisX[0].labels[b.x] ? this.chart.axisX[0].labels[b.x] : "{x}" : this.chart.axisX2 && 0 < this.chart.axisX2.length && (n2 += "undefined" !== typeof this.chart.axisX2[0].labels[b.x] ? this.chart.axisX2[0].labels[b.x] : "{x}");
                n2 += "</br>";
                if (!c.visible)
                  continue;
                n2 = this.chart.replaceKeywordsWithValue(n2, b, c, e);
              }
              null === b.toolTipContent || "undefined" === typeof b.toolTipContent && null === c.options.toolTipContent || ("line" === c.type || "stepLine" === c.type || "spline" === c.type || "area" === c.type || "stepArea" === c.type || "splineArea" === c.type || "column" === c.type || "bar" === c.type || "scatter" === c.type || "stackedColumn" === c.type || "stackedColumn100" === c.type || "stackedBar" === c.type || "stackedBar100" === c.type || "stackedArea" === c.type || "stackedArea100" === c.type || "waterfall" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (g += m2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), g += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y}`, m2 = c.axisXIndex) : "bubble" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (g += m2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), g += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y}, &nbsp;&nbsp;{z}`) : "rangeColumn" === c.type || "rangeBar" === c.type || "rangeArea" === c.type || "rangeSplineArea" === c.type || "error" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (g += m2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), g += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span>&nbsp;&nbsp;{y[0]},&nbsp;{y[1]}`) : "candlestick" === c.type || "ohlc" === c.type ? (this.chart.axisX && 1 < this.chart.axisX.length && (g += m2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), g += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span><br/>Open: &nbsp;&nbsp;{y[0]}<br/>High: &nbsp;&nbsp;&nbsp;{y[1]}<br/>Low:&nbsp;&nbsp;&nbsp;{y[2]}<br/>Close: &nbsp;&nbsp;{y[3]}`) : "boxAndWhisker" === c.type && (this.chart.axisX && 1 < this.chart.axisX.length && (g += m2 != c.axisXIndex ? c.axisX.title ? c.axisX.title + "<br/>" : "X:{axisXIndex}<br/>" : ""), g += b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>{name}:</span><br/>Minimum: &nbsp;{y[0]}<br/>Q1:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[1]}<br/>Q2:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[4]}<br/>Q3:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Maximum: &nbsp;{y[3]}`), null === d && (d = ""), c.visible && (true === this.reversed ? (d = this.chart.replaceKeywordsWithValue(g, b, c, e) + d, h2 < a.length - 1 && (d = "</br>" + d)) : (d += this.chart.replaceKeywordsWithValue(g, b, c, e), h2 < a.length - 1 && (d += "</br>"))));
            }
            null !== d && (d = n2 + d);
          } else {
            c = a[0].dataSeries;
            b = a[0].dataPoint;
            e = a[0].index;
            if (null === b.toolTipContent || "undefined" === typeof b.toolTipContent && null === c.options.toolTipContent)
              return null;
            "line" === c.type || "stepLine" === c.type || "spline" === c.type || "area" === c.type || "stepArea" === c.type || "splineArea" === c.type || "column" === c.type || "bar" === c.type || "scatter" === c.type || "stackedColumn" === c.type || "stackedColumn100" === c.type || "stackedBar" === c.type || "stackedBar100" === c.type || "stackedArea" === c.type || "stackedArea100" === c.type || "waterfall" === c.type ? g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + ":</span>&nbsp;&nbsp;{y}" : "bubble" === c.type ? g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + ":</span>&nbsp;&nbsp;{y}, &nbsp;&nbsp;{z}" : "pie" === c.type || "doughnut" === c.type || "funnel" === c.type || "pyramid" === c.type ? g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.name ? "{name}:</span>&nbsp;&nbsp;" : b.label ? "{label}:</span>&nbsp;&nbsp;" : "</span>") + "{y}" : "rangeColumn" === c.type || "rangeBar" === c.type || "rangeArea" === c.type || "rangeSplineArea" === c.type || "error" === c.type ? g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + " :</span>&nbsp;&nbsp;{y[0]}, &nbsp;{y[1]}" : "candlestick" === c.type || "ohlc" === c.type ? g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + "</span><br/>Open: &nbsp;&nbsp;{y[0]}<br/>High: &nbsp;&nbsp;&nbsp;{y[1]}<br/>Low: &nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Close: &nbsp;&nbsp;{y[3]}" : "boxAndWhisker" === c.type && (g = b.toolTipContent ? b.toolTipContent : c.toolTipContent ? c.toolTipContent : this.content && "function" !== typeof this.content ? this.content : `<span data-color='"` + (this.options.fontColor ? "" : "'{color}'") + `"'>` + (b.label ? "{label}" : "{x}") + "</span><br/>Minimum: &nbsp;{y[0]}<br/>Q1:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[1]}<br/>Q2:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[4]}<br/>Q3:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{y[2]}<br/>Maximum: &nbsp;{y[3]}");
            null === d && (d = "");
            d += this.chart.replaceKeywordsWithValue(
              g,
              b,
              c,
              e
            );
          }
          return d;
        };
        W2.prototype.enableAnimation = function() {
          if (!this.container.style.WebkitTransition) {
            var a = this.getContainerTransition(this.containerTransitionDuration);
            this.container.style.WebkitTransition = a;
            this.container.style.MsTransition = a;
            this.container.style.transition = a;
            this.container.style.MozTransition = this.mozContainerTransition;
          }
        };
        W2.prototype.disableAnimation = function() {
          this.container.style.WebkitTransition && (this.container.style.WebkitTransition = "", this.container.style.MozTransition = "", this.container.style.MsTransition = "", this.container.style.transition = "");
        };
        W2.prototype.hide = function(a) {
          this.container && (this.container.style.display = "none", this.currentSeriesIndex = -1, this._prevY = this._prevX = NaN, ("undefined" === typeof a || a) && this.chart.resetOverlayedCanvas());
        };
        W2.prototype.show = function(a, d, c) {
          this._updateToolTip(a, d, "undefined" === typeof c ? false : c);
        };
        W2.prototype.showAtIndex = function(a, d) {
        };
        W2.prototype.showAtX = function(a, d) {
          if (!this.enabled)
            return false;
          this.chart.clearedOverlayedCanvas = null;
          var c, b, e, g = [];
          e = false;
          d = !m(d) && 0 <= d && d < this.chart.data.length ? d : 0;
          if (this.shared)
            for (var h2 = 0; h2 < this.chart.data.length; h2++)
              c = this.chart.data[h2], (b = c.getDataPointAtX(a, false)) && (b.dataPoint && !m(b.dataPoint.y) && c.visible) && (b.dataSeries = c, g.push(b));
          else
            c = this.chart.data[d], (b = c.getDataPointAtX(a, false)) && (b.dataPoint && !m(b.dataPoint.y) && c.visible) && (b.dataSeries = c, g.push(b));
          if (0 < g.length) {
            for (h2 = 0; h2 < g.length; h2++)
              if (b = g[h2], (this.shared || 0 <= b.dataSeries.type.indexOf("100")) && b.dataPoint.x >= b.dataSeries.axisX.viewportMinimum && b.dataPoint.x <= b.dataSeries.axisX.viewportMaximum) {
                e = false;
                break;
              } else if (b.dataPoint.x < b.dataSeries.axisX.viewportMinimum || b.dataPoint.x > b.dataSeries.axisX.viewportMaximum || b.dataPoint.y < b.dataSeries.axisY.viewportMinimum || b.dataPoint.y > b.dataSeries.axisY.viewportMaximum)
                e = true;
              else {
                e = false;
                break;
              }
            if (e)
              return this.hide(), false;
            this.highlightObjects(g);
            this._entries = g;
            h2 = "";
            h2 = this.getToolTipInnerHTML({ entries: g });
            if (null !== h2) {
              this.contentDiv.innerHTML = h2;
              if (this.isToolTipDefinedInData && m(this.options.content) && m(this.options.contentFormatter))
                for (b = this.contentDiv.getElementsByTagName("span"), h2 = 0; h2 < b.length; h2++)
                  b[h2] && (b[h2].style.color = b[h2].getAttribute("data-color"));
              h2 = false;
              "none" === this.container.style.display && (h2 = true, this.container.style.display = "block");
              try {
                this.contentDiv.style.background = this.backgroundColor ? this.backgroundColor : t ? "rgba(255,255,255,.9)" : "rgb(255,255,255)", this.borderColor = "waterfall" === g[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataPoint.color ? g[0].dataPoint.color : 0 < g[0].dataPoint.y ? g[0].dataSeries.risingColor : g[0].dataSeries.fallingColor : "error" === g[0].dataSeries.type ? this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataSeries.color ? g[0].dataSeries.color : g[0].dataSeries._colorSet[c.index % g[0].dataSeries._colorSet.length] : this.contentDiv.style.borderRightColor = this.contentDiv.style.borderLeftColor = this.contentDiv.style.borderColor = this.options.borderColor ? this.options.borderColor : g[0].dataPoint.color ? g[0].dataPoint.color : g[0].dataSeries.color ? g[0].dataSeries.color : g[0].dataSeries._colorSet[g[0].index % g[0].dataSeries._colorSet.length], this.contentDiv.style.borderWidth = this.borderThickness || 0 === this.borderThickness ? this.borderThickness + "px" : "2px", this.contentDiv.style.borderRadius = this.cornerRadius || 0 === this.cornerRadius ? this.cornerRadius + "px" : "5px", this.container.style.borderRadius = this.contentDiv.style.borderRadius, this.contentDiv.style.fontSize = this.fontSize || 0 === this.fontSize ? this.fontSize + "px" : "14px", this.contentDiv.style.color = this.fontColor ? this.fontColor : "#000000", this.contentDiv.style.fontFamily = this.fontFamily ? this.fontFamily : "Calibri, Arial, Georgia, serif;", this.contentDiv.style.fontWeight = this.fontWeight ? this.fontWeight : "normal", this.contentDiv.style.fontStyle = this.fontStyle ? this.fontStyle : t ? "italic" : "normal";
              } catch (n2) {
              }
              "pie" === g[0].dataSeries.type || "doughnut" === g[0].dataSeries.type || "funnel" === g[0].dataSeries.type || "pyramid" === g[0].dataSeries.type ? c = mouseX - 10 - this.container.clientWidth : (c = "bar" === g[0].dataSeries.type || "rangeBar" === g[0].dataSeries.type || "stackedBar" === g[0].dataSeries.type || "stackedBar100" === g[0].dataSeries.type ? g[0].dataSeries.axisY.convertValueToPixel(g[0].dataPoint.y) - this.container.clientWidth << 0 : g[0].dataSeries.axisX.convertValueToPixel(g[0].dataPoint.x) - this.container.clientWidth << 0, c -= 10);
              0 > c && (c += this.container.clientWidth + 20);
              c + this.container.clientWidth > Math.max(this.chart.container.clientWidth, this.chart.width) && (c = Math.max(0, Math.max(this.chart.container.clientWidth, this.chart.width) - this.container.clientWidth));
              g = 1 !== g.length || this.shared || "line" !== g[0].dataSeries.type && "stepLine" !== g[0].dataSeries.type && "spline" !== g[0].dataSeries.type && "area" !== g[0].dataSeries.type && "stepArea" !== g[0].dataSeries.type && "splineArea" !== g[0].dataSeries.type ? "bar" === g[0].dataSeries.type || "rangeBar" === g[0].dataSeries.type || "stackedBar" === g[0].dataSeries.type || "stackedBar100" === g[0].dataSeries.type ? g[0].dataSeries.axisX.convertValueToPixel(g[0].dataPoint.x) : g[0].dataSeries.axisY.convertValueToPixel(g[0].dataPoint.y) : g[0].dataSeries.axisY.convertValueToPixel(g[0].dataPoint.y);
              g = -g + 10;
              0 < g + this.container.clientHeight + 5 && (g -= g + this.container.clientHeight + 5 - 0);
              this.fixMozTransitionDelay(c, g);
              !this.animationEnabled || h2 ? this.disableAnimation() : (this.enableAnimation(), this.container.style.MozTransition = this.mozContainerTransition);
              this.container.style.left = c + "px";
              this.container.style.bottom = g + "px";
            } else
              return this.hide(false), false;
          } else
            return this.hide(), false;
          return true;
        };
        W2.prototype.fixMozTransitionDelay = function(a, d) {
          if (20 < this.chart._eventManager.lastObjectId)
            this.mozContainerTransition = this.getContainerTransition(0);
          else {
            var c = parseFloat(this.container.style.left), c = isNaN(c) ? 0 : c, b = parseFloat(this.container.style.bottom), b = isNaN(b) ? 0 : b;
            10 < Math.sqrt(Math.pow(c - a, 2) + Math.pow(b - d, 2)) ? this.mozContainerTransition = this.getContainerTransition(0.1) : this.mozContainerTransition = this.getContainerTransition(0);
          }
        };
        W2.prototype.getContainerTransition = function(a) {
          return "left " + a + "s ease-out 0s, bottom " + a + "s ease-out 0s";
        };
        aa2.prototype.reset = function() {
          this.lastObjectId = 0;
          this.objectMap = [];
          this.rectangularRegionEventSubscriptions = [];
          this.previousDataPointEventObject = null;
          this.eventObjects = [];
          t && (this.ghostCtx.clearRect(0, 0, this.chart.width, this.chart.height), this.ghostCtx.beginPath());
        };
        aa2.prototype.getNewObjectTrackingId = function() {
          return ++this.lastObjectId;
        };
        aa2.prototype.mouseEventHandler = function(a) {
          if ("mousemove" === a.type || "click" === a.type) {
            var d = [], c = Pa(a), b = null;
            if ((b = this.chart.getObjectAtXY(c.x, c.y, false)) && "undefined" !== typeof this.objectMap[b])
              if (b = this.objectMap[b], "dataPoint" === b.objectType) {
                var e = this.chart.data[b.dataSeriesIndex], g = e.dataPoints[b.dataPointIndex], h2 = b.dataPointIndex;
                b.eventParameter = { x: c.x, y: c.y, dataPoint: g, dataSeries: e.options, dataPointIndex: h2, dataSeriesIndex: e.index, chart: this.chart };
                b.eventContext = {
                  context: g,
                  userContext: g,
                  mouseover: "mouseover",
                  mousemove: "mousemove",
                  mouseout: "mouseout",
                  click: "click"
                };
                d.push(b);
                b = this.objectMap[e.id];
                b.eventParameter = { x: c.x, y: c.y, dataPoint: g, dataSeries: e.options, dataPointIndex: h2, dataSeriesIndex: e.index, chart: this.chart };
                b.eventContext = { context: e, userContext: e.options, mouseover: "mouseover", mousemove: "mousemove", mouseout: "mouseout", click: "click" };
                d.push(this.objectMap[e.id]);
              } else
                "legendItem" === b.objectType && (e = this.chart.data[b.dataSeriesIndex], g = null !== b.dataPointIndex ? e.dataPoints[b.dataPointIndex] : null, b.eventParameter = {
                  x: c.x,
                  y: c.y,
                  dataSeries: e.options,
                  dataPoint: g,
                  dataPointIndex: b.dataPointIndex,
                  dataSeriesIndex: b.dataSeriesIndex,
                  chart: this.chart
                }, b.eventContext = { context: this.chart.legend, userContext: this.chart.legend.options, mouseover: "itemmouseover", mousemove: "itemmousemove", mouseout: "itemmouseout", click: "itemclick" }, d.push(b));
            e = [];
            for (c = 0; c < this.mouseoveredObjectMaps.length; c++) {
              g = true;
              for (b = 0; b < d.length; b++)
                if (d[b].id === this.mouseoveredObjectMaps[c].id) {
                  g = false;
                  break;
                }
              g ? this.fireEvent(this.mouseoveredObjectMaps[c], "mouseout", a) : e.push(this.mouseoveredObjectMaps[c]);
            }
            this.mouseoveredObjectMaps = e;
            for (c = 0; c < d.length; c++) {
              e = false;
              for (b = 0; b < this.mouseoveredObjectMaps.length; b++)
                if (d[c].id === this.mouseoveredObjectMaps[b].id) {
                  e = true;
                  break;
                }
              e || (this.fireEvent(d[c], "mouseover", a), this.mouseoveredObjectMaps.push(d[c]));
              "click" === a.type ? this.fireEvent(d[c], "click", a) : "mousemove" === a.type && this.fireEvent(d[c], "mousemove", a);
            }
          }
        };
        aa2.prototype.fireEvent = function(a, d, c) {
          if (a && d) {
            var b = a.eventParameter, e = a.eventContext, g = a.eventContext.userContext;
            g && (e && g[e[d]]) && g[e[d]].call(g, b);
            "mouseout" !== d ? g.cursor && g.cursor !== c.target.style.cursor && (c.target.style.cursor = g.cursor) : (c.target.style.cursor = this.chart.panEnabled ? "itemmouseout" !== e.mouseout || g.dockInsidePlotArea ? "move" : this.chart._defaultCursor : this.chart._defaultCursor, delete a.eventParameter, delete a.eventContext);
            "click" === d && ("dataPoint" === a.objectType && this.chart.pieDoughnutClickHandler) && this.chart.pieDoughnutClickHandler.call(this.chart.data[a.dataSeriesIndex], b);
            "click" === d && ("dataPoint" === a.objectType && this.chart.funnelPyramidClickHandler) && this.chart.funnelPyramidClickHandler.call(
              this.chart.data[a.dataSeriesIndex],
              b
            );
          }
        };
        ka2.prototype.animate = function(a, d, c, b, e) {
          var g = this;
          this.chart.isAnimating = true;
          e = e || N.easing.linear;
          c && this.animations.push({ startTime: (/* @__PURE__ */ new Date()).getTime() + (a ? a : 0), duration: d, animationCallback: c, onComplete: b });
          for (a = []; 0 < this.animations.length; )
            if (d = this.animations.shift(), c = (/* @__PURE__ */ new Date()).getTime(), b = 0, d.startTime <= c && (b = e(Math.min(c - d.startTime, d.duration), 0, 1, d.duration), b = Math.min(b, 1), isNaN(b) || !isFinite(b)) && (b = 1), 1 > b && a.push(d), d.animationCallback(b), 1 <= b && d.onComplete)
              d.onComplete();
          this.animations = a;
          0 < this.animations.length ? this.animationRequestId = this.chart.requestAnimFrame.call(window, function() {
            g.animate.call(g);
          }) : this.chart.isAnimating = false;
        };
        ka2.prototype.cancelAllAnimations = function() {
          this.animations = [];
          this.animationRequestId && this.chart.cancelRequestAnimFrame.call(window, this.animationRequestId);
          this.animationRequestId = null;
          this.chart.isAnimating = false;
        };
        var N = { yScaleAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas, e = d.animationBase;
            c.drawImage(b, 0, 0, b.width, b.height, 0, e - e * a, c.canvas.width / na, a * c.canvas.height / na);
          }
        }, xScaleAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas, e = d.animationBase;
            c.drawImage(b, 0, 0, b.width, b.height, e - e * a, 0, a * c.canvas.width / na, c.canvas.height / na);
          }
        }, xClipAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas;
            c.save();
            0 < a && c.drawImage(b, 0, 0, b.width * a, b.height, 0, 0, b.width * a / na, b.height / na);
            c.restore();
          }
        }, fadeInAnimation: function(a, d) {
          if (0 !== a) {
            var c = d.dest, b = d.source.canvas;
            c.save();
            c.globalAlpha = a;
            c.drawImage(
              b,
              0,
              0,
              b.width,
              b.height,
              0,
              0,
              c.canvas.width / na,
              c.canvas.height / na
            );
            c.restore();
          }
        }, easing: { linear: function(a, d, c, b) {
          return c * a / b + d;
        }, easeOutQuad: function(a, d, c, b) {
          return -c * (a /= b) * (a - 2) + d;
        }, easeOutQuart: function(a, d, c, b) {
          return -c * ((a = a / b - 1) * a * a * a - 1) + d;
        }, easeInQuad: function(a, d, c, b) {
          return c * (a /= b) * a + d;
        }, easeInQuart: function(a, d, c, b) {
          return c * (a /= b) * a * a * a + d;
        } } }, X = { drawMarker: function(a, d, c, b, e, g, h2, m2) {
          if (c) {
            var n2 = 1;
            c.fillStyle = g ? g : "#000000";
            c.strokeStyle = h2 ? h2 : "#000000";
            c.lineWidth = m2 ? m2 : 0;
            c.setLineDash && c.setLineDash(H(
              "solid",
              m2
            ));
            "circle" === b ? (c.moveTo(a, d), c.beginPath(), c.arc(a, d, e / 2, 0, 2 * Math.PI, false), g && c.fill(), m2 && (h2 ? c.stroke() : (n2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = n2))) : "square" === b ? (c.beginPath(), c.rect(a - e / 2, d - e / 2, e, e), g && c.fill(), m2 && (h2 ? c.stroke() : (n2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = n2))) : "triangle" === b ? (c.beginPath(), c.moveTo(a - e / 2, d + e / 2), c.lineTo(a + e / 2, d + e / 2), c.lineTo(a, d - e / 2), c.closePath(), g && c.fill(), m2 && (h2 ? c.stroke() : (n2 = c.globalAlpha, c.globalAlpha = 0.15, c.strokeStyle = "black", c.stroke(), c.globalAlpha = n2)), c.beginPath()) : "cross" === b && (c.strokeStyle = g, c.lineWidth = e / 4, c.beginPath(), c.moveTo(a - e / 2, d - e / 2), c.lineTo(a + e / 2, d + e / 2), c.stroke(), c.moveTo(a + e / 2, d - e / 2), c.lineTo(a - e / 2, d + e / 2), c.stroke());
          }
        }, drawMarkers: function(a) {
          for (var d = 0; d < a.length; d++) {
            var c = a[d];
            X.drawMarker(c.x, c.y, c.ctx, c.type, c.size, c.color, c.borderColor, c.borderThickness);
          }
        } };
        return n;
      }();
      z.version = "v3.7.44 GA";
      window.CanvasJS && (z && !window.CanvasJS.Chart) && (window.CanvasJS.Chart = z);
    })();
    document.createElement("canvas").getContext || function() {
      function V() {
        return this.context_ || (this.context_ = new C(this));
      }
      function W(a, b, c) {
        var g = M.call(arguments, 2);
        return function() {
          return a.apply(b, g.concat(M.call(arguments)));
        };
      }
      function N(a) {
        return String(a).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
      }
      function O(a) {
        a.namespaces.g_vml_ || a.namespaces.add("g_vml_", "urn:schemas-microsoft-com:vml", "#default#VML");
        a.namespaces.g_o_ || a.namespaces.add("g_o_", "urn:schemas-microsoft-com:office:office", "#default#VML");
        a.styleSheets.ex_canvas_ || (a = a.createStyleSheet(), a.owningElement.id = "ex_canvas_", a.cssText = "canvas{display:inline-block;overflow:hidden;text-align:left;width:300px;height:150px}");
      }
      function X(a) {
        var b = a.srcElement;
        switch (a.propertyName) {
          case "width":
            b.getContext().clearRect();
            b.style.width = b.attributes.width.nodeValue + "px";
            b.firstChild.style.width = b.clientWidth + "px";
            break;
          case "height":
            b.getContext().clearRect(), b.style.height = b.attributes.height.nodeValue + "px", b.firstChild.style.height = b.clientHeight + "px";
        }
      }
      function Y(a) {
        a = a.srcElement;
        a.firstChild && (a.firstChild.style.width = a.clientWidth + "px", a.firstChild.style.height = a.clientHeight + "px");
      }
      function D() {
        return [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
      }
      function t(a, b) {
        for (var c = D(), g = 0; 3 > g; g++)
          for (var e = 0; 3 > e; e++) {
            for (var f = 0, d2 = 0; 3 > d2; d2++)
              f += a[g][d2] * b[d2][e];
            c[g][e] = f;
          }
        return c;
      }
      function P(a, b) {
        b.fillStyle = a.fillStyle;
        b.lineCap = a.lineCap;
        b.lineJoin = a.lineJoin;
        b.lineWidth = a.lineWidth;
        b.miterLimit = a.miterLimit;
        b.shadowBlur = a.shadowBlur;
        b.shadowColor = a.shadowColor;
        b.shadowOffsetX = a.shadowOffsetX;
        b.shadowOffsetY = a.shadowOffsetY;
        b.strokeStyle = a.strokeStyle;
        b.globalAlpha = a.globalAlpha;
        b.font = a.font;
        b.textAlign = a.textAlign;
        b.textBaseline = a.textBaseline;
        b.arcScaleX_ = a.arcScaleX_;
        b.arcScaleY_ = a.arcScaleY_;
        b.lineScale_ = a.lineScale_;
      }
      function Q(a) {
        var b = a.indexOf("(", 3), c = a.indexOf(")", b + 1), b = a.substring(b + 1, c).split(",");
        if (4 != b.length || "a" != a.charAt(3))
          b[3] = 1;
        return b;
      }
      function E(a, b, c) {
        return Math.min(c, Math.max(b, a));
      }
      function F(a, b, c) {
        0 > c && c++;
        1 < c && c--;
        return 1 > 6 * c ? a + 6 * (b - a) * c : 1 > 2 * c ? b : 2 > 3 * c ? a + 6 * (b - a) * (2 / 3 - c) : a;
      }
      function G(a) {
        if (a in H)
          return H[a];
        var b, c = 1;
        a = String(a);
        if ("#" == a.charAt(0))
          b = a;
        else if (/^rgb/.test(a)) {
          c = Q(a);
          b = "#";
          for (var g, e = 0; 3 > e; e++)
            g = -1 != c[e].indexOf("%") ? Math.floor(255 * (parseFloat(c[e]) / 100)) : +c[e], b += v[E(g, 0, 255)];
          c = +c[3];
        } else if (/^hsl/.test(a)) {
          e = c = Q(a);
          b = parseFloat(e[0]) / 360 % 360;
          0 > b && b++;
          g = E(parseFloat(e[1]) / 100, 0, 1);
          e = E(parseFloat(e[2]) / 100, 0, 1);
          if (0 == g)
            g = e = b = e;
          else {
            var f = 0.5 > e ? e * (1 + g) : e + g - e * g, d2 = 2 * e - f;
            g = F(d2, f, b + 1 / 3);
            e = F(d2, f, b);
            b = F(d2, f, b - 1 / 3);
          }
          b = "#" + v[Math.floor(255 * g)] + v[Math.floor(255 * e)] + v[Math.floor(255 * b)];
          c = c[3];
        } else
          b = Z[a] || a;
        return H[a] = { color: b, alpha: c };
      }
      function C(a) {
        this.m_ = D();
        this.mStack_ = [];
        this.aStack_ = [];
        this.currentPath_ = [];
        this.fillStyle = this.strokeStyle = "#000";
        this.lineWidth = 1;
        this.lineJoin = "miter";
        this.lineCap = "butt";
        this.miterLimit = 1 * q;
        this.globalAlpha = 1;
        this.font = "10px sans-serif";
        this.textAlign = "left";
        this.textBaseline = "alphabetic";
        this.canvas = a;
        var b = "width:" + a.clientWidth + "px;height:" + a.clientHeight + "px;overflow:hidden;position:absolute", c = a.ownerDocument.createElement("div");
        c.style.cssText = b;
        a.appendChild(c);
        b = c.cloneNode(false);
        b.style.backgroundColor = "red";
        b.style.filter = "alpha(opacity=0)";
        a.appendChild(b);
        this.element_ = c;
        this.lineScale_ = this.arcScaleY_ = this.arcScaleX_ = 1;
      }
      function R(a, b, c, g) {
        a.currentPath_.push({ type: "bezierCurveTo", cp1x: b.x, cp1y: b.y, cp2x: c.x, cp2y: c.y, x: g.x, y: g.y });
        a.currentX_ = g.x;
        a.currentY_ = g.y;
      }
      function S(a, b) {
        var c = G(a.strokeStyle), g = c.color, c = c.alpha * a.globalAlpha, e = a.lineScale_ * a.lineWidth;
        1 > e && (c *= e);
        b.push(
          "<g_vml_:stroke",
          ' opacity="',
          c,
          '"',
          ' joinstyle="',
          a.lineJoin,
          '"',
          ' miterlimit="',
          a.miterLimit,
          '"',
          ' endcap="',
          $[a.lineCap] || "square",
          '"',
          ' weight="',
          e,
          'px"',
          ' color="',
          g,
          '" />'
        );
      }
      function T(a, b, c, g) {
        var e = a.fillStyle, f = a.arcScaleX_, d2 = a.arcScaleY_, k2 = g.x - c.x, n = g.y - c.y;
        if (e instanceof w) {
          var h = 0, l = g = 0, u = 0, m = 1;
          if ("gradient" == e.type_) {
            h = e.x1_ / f;
            c = e.y1_ / d2;
            var p = s(a, e.x0_ / f, e.y0_ / d2), h = s(a, h, c), h = 180 * Math.atan2(h.x - p.x, h.y - p.y) / Math.PI;
            0 > h && (h += 360);
            1e-6 > h && (h = 0);
          } else
            p = s(a, e.x0_, e.y0_), g = (p.x - c.x) / k2, l = (p.y - c.y) / n, k2 /= f * q, n /= d2 * q, m = x.max(k2, n), u = 2 * e.r0_ / m, m = 2 * e.r1_ / m - u;
          f = e.colors_;
          f.sort(function(a2, b2) {
            return a2.offset - b2.offset;
          });
          d2 = f.length;
          p = f[0].color;
          c = f[d2 - 1].color;
          k2 = f[0].alpha * a.globalAlpha;
          a = f[d2 - 1].alpha * a.globalAlpha;
          for (var n = [], r2 = 0; r2 < d2; r2++) {
            var t2 = f[r2];
            n.push(t2.offset * m + u + " " + t2.color);
          }
          b.push('<g_vml_:fill type="', e.type_, '"', ' method="none" focus="100%"', ' color="', p, '"', ' color2="', c, '"', ' colors="', n.join(","), '"', ' opacity="', a, '"', ' g_o_:opacity2="', k2, '"', ' angle="', h, '"', ' focusposition="', g, ",", l, '" />');
        } else
          e instanceof I ? k2 && n && b.push("<g_vml_:fill", ' position="', -c.x / k2 * f * f, ",", -c.y / n * d2 * d2, '"', ' type="tile"', ' src="', e.src_, '" />') : (e = G(a.fillStyle), b.push('<g_vml_:fill color="', e.color, '" opacity="', e.alpha * a.globalAlpha, '" />'));
      }
      function s(a, b, c) {
        a = a.m_;
        return { x: q * (b * a[0][0] + c * a[1][0] + a[2][0]) - r, y: q * (b * a[0][1] + c * a[1][1] + a[2][1]) - r };
      }
      function z(a, b, c) {
        isFinite(b[0][0]) && (isFinite(b[0][1]) && isFinite(b[1][0]) && isFinite(b[1][1]) && isFinite(b[2][0]) && isFinite(b[2][1])) && (a.m_ = b, c && (a.lineScale_ = aa(ba(b[0][0] * b[1][1] - b[0][1] * b[1][0]))));
      }
      function w(a) {
        this.type_ = a;
        this.r1_ = this.y1_ = this.x1_ = this.r0_ = this.y0_ = this.x0_ = 0;
        this.colors_ = [];
      }
      function I(a, b) {
        if (!a || 1 != a.nodeType || "IMG" != a.tagName)
          throw new A("TYPE_MISMATCH_ERR");
        if ("complete" != a.readyState)
          throw new A("INVALID_STATE_ERR");
        switch (b) {
          case "repeat":
          case null:
          case "":
            this.repetition_ = "repeat";
            break;
          case "repeat-x":
          case "repeat-y":
          case "no-repeat":
            this.repetition_ = b;
            break;
          default:
            throw new A("SYNTAX_ERR");
        }
        this.src_ = a.src;
        this.width_ = a.width;
        this.height_ = a.height;
      }
      function A(a) {
        this.code = this[a];
        this.message = a + ": DOM Exception " + this.code;
      }
      var x = Math, k = x.round, J = x.sin, K = x.cos, ba = x.abs, aa = x.sqrt, q = 10, r = q / 2;
      navigator.userAgent.match(/MSIE ([\d.]+)?/);
      var M = Array.prototype.slice;
      O(document);
      var U = { init: function(a) {
        a = a || document;
        a.createElement("canvas");
        a.attachEvent("onreadystatechange", W(this.init_, this, a));
      }, init_: function(a) {
        a = a.getElementsByTagName("canvas");
        for (var b = 0; b < a.length; b++)
          this.initElement(a[b]);
      }, initElement: function(a) {
        if (!a.getContext) {
          a.getContext = V;
          O(a.ownerDocument);
          a.innerHTML = "";
          a.attachEvent("onpropertychange", X);
          a.attachEvent("onresize", Y);
          var b = a.attributes;
          b.width && b.width.specified ? a.style.width = b.width.nodeValue + "px" : a.width = a.clientWidth;
          b.height && b.height.specified ? a.style.height = b.height.nodeValue + "px" : a.height = a.clientHeight;
        }
        return a;
      } };
      U.init();
      for (var v = [], d = 0; 16 > d; d++)
        for (var B = 0; 16 > B; B++)
          v[16 * d + B] = d.toString(16) + B.toString(16);
      var Z = {
        aliceblue: "#F0F8FF",
        antiquewhite: "#FAEBD7",
        aquamarine: "#7FFFD4",
        azure: "#F0FFFF",
        beige: "#F5F5DC",
        bisque: "#FFE4C4",
        black: "#000000",
        blanchedalmond: "#FFEBCD",
        blueviolet: "#8A2BE2",
        brown: "#A52A2A",
        burlywood: "#DEB887",
        cadetblue: "#5F9EA0",
        chartreuse: "#7FFF00",
        chocolate: "#D2691E",
        coral: "#FF7F50",
        cornflowerblue: "#6495ED",
        cornsilk: "#FFF8DC",
        crimson: "#DC143C",
        cyan: "#00FFFF",
        darkblue: "#00008B",
        darkcyan: "#008B8B",
        darkgoldenrod: "#B8860B",
        darkgray: "#A9A9A9",
        darkgreen: "#006400",
        darkgrey: "#A9A9A9",
        darkkhaki: "#BDB76B",
        darkmagenta: "#8B008B",
        darkolivegreen: "#556B2F",
        darkorange: "#FF8C00",
        darkorchid: "#9932CC",
        darkred: "#8B0000",
        darksalmon: "#E9967A",
        darkseagreen: "#8FBC8F",
        darkslateblue: "#483D8B",
        darkslategray: "#2F4F4F",
        darkslategrey: "#2F4F4F",
        darkturquoise: "#00CED1",
        darkviolet: "#9400D3",
        deeppink: "#FF1493",
        deepskyblue: "#00BFFF",
        dimgray: "#696969",
        dimgrey: "#696969",
        dodgerblue: "#1E90FF",
        firebrick: "#B22222",
        floralwhite: "#FFFAF0",
        forestgreen: "#228B22",
        gainsboro: "#DCDCDC",
        ghostwhite: "#F8F8FF",
        gold: "#FFD700",
        goldenrod: "#DAA520",
        grey: "#808080",
        greenyellow: "#ADFF2F",
        honeydew: "#F0FFF0",
        hotpink: "#FF69B4",
        indianred: "#CD5C5C",
        indigo: "#4B0082",
        ivory: "#FFFFF0",
        khaki: "#F0E68C",
        lavender: "#E6E6FA",
        lavenderblush: "#FFF0F5",
        lawngreen: "#7CFC00",
        lemonchiffon: "#FFFACD",
        lightblue: "#ADD8E6",
        lightcoral: "#F08080",
        lightcyan: "#E0FFFF",
        lightgoldenrodyellow: "#FAFAD2",
        lightgreen: "#90EE90",
        lightgrey: "#D3D3D3",
        lightpink: "#FFB6C1",
        lightsalmon: "#FFA07A",
        lightseagreen: "#20B2AA",
        lightskyblue: "#87CEFA",
        lightslategray: "#778899",
        lightslategrey: "#778899",
        lightsteelblue: "#B0C4DE",
        lightyellow: "#FFFFE0",
        limegreen: "#32CD32",
        linen: "#FAF0E6",
        magenta: "#FF00FF",
        mediumaquamarine: "#66CDAA",
        mediumblue: "#0000CD",
        mediumorchid: "#BA55D3",
        mediumpurple: "#9370DB",
        mediumseagreen: "#3CB371",
        mediumslateblue: "#7B68EE",
        mediumspringgreen: "#00FA9A",
        mediumturquoise: "#48D1CC",
        mediumvioletred: "#C71585",
        midnightblue: "#191970",
        mintcream: "#F5FFFA",
        mistyrose: "#FFE4E1",
        moccasin: "#FFE4B5",
        navajowhite: "#FFDEAD",
        oldlace: "#FDF5E6",
        olivedrab: "#6B8E23",
        orange: "#FFA500",
        orangered: "#FF4500",
        orchid: "#DA70D6",
        palegoldenrod: "#EEE8AA",
        palegreen: "#98FB98",
        paleturquoise: "#AFEEEE",
        palevioletred: "#DB7093",
        papayawhip: "#FFEFD5",
        peachpuff: "#FFDAB9",
        peru: "#CD853F",
        pink: "#FFC0CB",
        plum: "#DDA0DD",
        powderblue: "#B0E0E6",
        rosybrown: "#BC8F8F",
        royalblue: "#4169E1",
        saddlebrown: "#8B4513",
        salmon: "#FA8072",
        sandybrown: "#F4A460",
        seagreen: "#2E8B57",
        seashell: "#FFF5EE",
        sienna: "#A0522D",
        skyblue: "#87CEEB",
        slateblue: "#6A5ACD",
        slategray: "#708090",
        slategrey: "#708090",
        snow: "#FFFAFA",
        springgreen: "#00FF7F",
        steelblue: "#4682B4",
        tan: "#D2B48C",
        thistle: "#D8BFD8",
        tomato: "#FF6347",
        turquoise: "#40E0D0",
        violet: "#EE82EE",
        wheat: "#F5DEB3",
        whitesmoke: "#F5F5F5",
        yellowgreen: "#9ACD32"
      }, H = {}, L = {}, $ = { butt: "flat", round: "round" }, d = C.prototype;
      d.clearRect = function() {
        this.textMeasureEl_ && (this.textMeasureEl_.removeNode(true), this.textMeasureEl_ = null);
        this.element_.innerHTML = "";
      };
      d.beginPath = function() {
        this.currentPath_ = [];
      };
      d.moveTo = function(a, b) {
        var c = s(this, a, b);
        this.currentPath_.push({ type: "moveTo", x: c.x, y: c.y });
        this.currentX_ = c.x;
        this.currentY_ = c.y;
      };
      d.lineTo = function(a, b) {
        var c = s(this, a, b);
        this.currentPath_.push({ type: "lineTo", x: c.x, y: c.y });
        this.currentX_ = c.x;
        this.currentY_ = c.y;
      };
      d.bezierCurveTo = function(a, b, c, g, e, f) {
        e = s(this, e, f);
        a = s(this, a, b);
        c = s(this, c, g);
        R(this, a, c, e);
      };
      d.quadraticCurveTo = function(a, b, c, g) {
        a = s(this, a, b);
        c = s(this, c, g);
        g = { x: this.currentX_ + 2 / 3 * (a.x - this.currentX_), y: this.currentY_ + 2 / 3 * (a.y - this.currentY_) };
        R(this, g, { x: g.x + (c.x - this.currentX_) / 3, y: g.y + (c.y - this.currentY_) / 3 }, c);
      };
      d.arc = function(a, b, c, g, e, f) {
        c *= q;
        var d2 = f ? "at" : "wa", k2 = a + K(g) * c - r, n = b + J(g) * c - r;
        g = a + K(e) * c - r;
        e = b + J(e) * c - r;
        k2 != g || f || (k2 += 0.125);
        a = s(this, a, b);
        k2 = s(this, k2, n);
        g = s(this, g, e);
        this.currentPath_.push({
          type: d2,
          x: a.x,
          y: a.y,
          radius: c,
          xStart: k2.x,
          yStart: k2.y,
          xEnd: g.x,
          yEnd: g.y
        });
      };
      d.rect = function(a, b, c, g) {
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
      };
      d.strokeRect = function(a, b, c, g) {
        var e = this.currentPath_;
        this.beginPath();
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
        this.stroke();
        this.currentPath_ = e;
      };
      d.fillRect = function(a, b, c, g) {
        var e = this.currentPath_;
        this.beginPath();
        this.moveTo(a, b);
        this.lineTo(a + c, b);
        this.lineTo(a + c, b + g);
        this.lineTo(a, b + g);
        this.closePath();
        this.fill();
        this.currentPath_ = e;
      };
      d.createLinearGradient = function(a, b, c, g) {
        var e = new w("gradient");
        e.x0_ = a;
        e.y0_ = b;
        e.x1_ = c;
        e.y1_ = g;
        return e;
      };
      d.createRadialGradient = function(a, b, c, g, e, f) {
        var d2 = new w("gradientradial");
        d2.x0_ = a;
        d2.y0_ = b;
        d2.r0_ = c;
        d2.x1_ = g;
        d2.y1_ = e;
        d2.r1_ = f;
        return d2;
      };
      d.drawImage = function(a, b) {
        var c, g, e, d2, r2, y, n, h;
        e = a.runtimeStyle.width;
        d2 = a.runtimeStyle.height;
        a.runtimeStyle.width = "auto";
        a.runtimeStyle.height = "auto";
        var l = a.width, u = a.height;
        a.runtimeStyle.width = e;
        a.runtimeStyle.height = d2;
        if (3 == arguments.length)
          c = arguments[1], g = arguments[2], r2 = y = 0, n = e = l, h = d2 = u;
        else if (5 == arguments.length)
          c = arguments[1], g = arguments[2], e = arguments[3], d2 = arguments[4], r2 = y = 0, n = l, h = u;
        else if (9 == arguments.length)
          r2 = arguments[1], y = arguments[2], n = arguments[3], h = arguments[4], c = arguments[5], g = arguments[6], e = arguments[7], d2 = arguments[8];
        else
          throw Error("Invalid number of arguments");
        var m = s(this, c, g), p = [];
        p.push(
          " <g_vml_:group",
          ' coordsize="',
          10 * q,
          ",",
          10 * q,
          '"',
          ' coordorigin="0,0"',
          ' style="width:',
          10,
          "px;height:",
          10,
          "px;position:absolute;"
        );
        if (1 != this.m_[0][0] || this.m_[0][1] || 1 != this.m_[1][1] || this.m_[1][0]) {
          var t2 = [];
          t2.push("M11=", this.m_[0][0], ",", "M12=", this.m_[1][0], ",", "M21=", this.m_[0][1], ",", "M22=", this.m_[1][1], ",", "Dx=", k(m.x / q), ",", "Dy=", k(m.y / q), "");
          var v2 = s(this, c + e, g), w2 = s(this, c, g + d2);
          c = s(this, c + e, g + d2);
          m.x = x.max(m.x, v2.x, w2.x, c.x);
          m.y = x.max(m.y, v2.y, w2.y, c.y);
          p.push("padding:0 ", k(m.x / q), "px ", k(m.y / q), "px 0;filter:progid:DXImageTransform.Microsoft.Matrix(", t2.join(""), ", sizingmethod='clip');");
        } else
          p.push(
            "top:",
            k(m.y / q),
            "px;left:",
            k(m.x / q),
            "px;"
          );
        p.push(' ">', '<g_vml_:image src="', a.src, '"', ' style="width:', q * e, "px;", " height:", q * d2, 'px"', ' cropleft="', r2 / l, '"', ' croptop="', y / u, '"', ' cropright="', (l - r2 - n) / l, '"', ' cropbottom="', (u - y - h) / u, '"', " />", "</g_vml_:group>");
        this.element_.insertAdjacentHTML("BeforeEnd", p.join(""));
      };
      d.stroke = function(a) {
        var b = [];
        b.push(
          "<g_vml_:shape",
          ' filled="',
          !!a,
          '"',
          ' style="position:absolute;width:',
          10,
          "px;height:",
          10,
          'px;"',
          ' coordorigin="0,0"',
          ' coordsize="',
          10 * q,
          ",",
          10 * q,
          '"',
          ' stroked="',
          !a,
          '"',
          ' path="'
        );
        for (var c = { x: null, y: null }, d2 = { x: null, y: null }, e = 0; e < this.currentPath_.length; e++) {
          var f = this.currentPath_[e];
          switch (f.type) {
            case "moveTo":
              b.push(" m ", k(f.x), ",", k(f.y));
              break;
            case "lineTo":
              b.push(" l ", k(f.x), ",", k(f.y));
              break;
            case "close":
              b.push(" x ");
              f = null;
              break;
            case "bezierCurveTo":
              b.push(" c ", k(f.cp1x), ",", k(f.cp1y), ",", k(f.cp2x), ",", k(f.cp2y), ",", k(f.x), ",", k(f.y));
              break;
            case "at":
            case "wa":
              b.push(" ", f.type, " ", k(f.x - this.arcScaleX_ * f.radius), ",", k(f.y - this.arcScaleY_ * f.radius), " ", k(f.x + this.arcScaleX_ * f.radius), ",", k(f.y + this.arcScaleY_ * f.radius), " ", k(f.xStart), ",", k(f.yStart), " ", k(f.xEnd), ",", k(f.yEnd));
          }
          if (f) {
            if (null == c.x || f.x < c.x)
              c.x = f.x;
            if (null == d2.x || f.x > d2.x)
              d2.x = f.x;
            if (null == c.y || f.y < c.y)
              c.y = f.y;
            if (null == d2.y || f.y > d2.y)
              d2.y = f.y;
          }
        }
        b.push(' ">');
        a ? T(this, b, c, d2) : S(this, b);
        b.push("</g_vml_:shape>");
        this.element_.insertAdjacentHTML("beforeEnd", b.join(""));
      };
      d.fill = function() {
        this.stroke(true);
      };
      d.closePath = function() {
        this.currentPath_.push({ type: "close" });
      };
      d.save = function() {
        var a = {};
        P(this, a);
        this.aStack_.push(a);
        this.mStack_.push(this.m_);
        this.m_ = t(D(), this.m_);
      };
      d.restore = function() {
        this.aStack_.length && (P(this.aStack_.pop(), this), this.m_ = this.mStack_.pop());
      };
      d.translate = function(a, b) {
        z(this, t([[1, 0, 0], [0, 1, 0], [a, b, 1]], this.m_), false);
      };
      d.rotate = function(a) {
        var b = K(a);
        a = J(a);
        z(this, t([[b, a, 0], [-a, b, 0], [0, 0, 1]], this.m_), false);
      };
      d.scale = function(a, b) {
        this.arcScaleX_ *= a;
        this.arcScaleY_ *= b;
        z(this, t([[a, 0, 0], [0, b, 0], [0, 0, 1]], this.m_), true);
      };
      d.transform = function(a, b, c, d2, e, f) {
        z(this, t([[
          a,
          b,
          0
        ], [c, d2, 0], [e, f, 1]], this.m_), true);
      };
      d.setTransform = function(a, b, c, d2, e, f) {
        z(this, [[a, b, 0], [c, d2, 0], [e, f, 1]], true);
      };
      d.drawText_ = function(a, b, c, d2, e) {
        var f = this.m_;
        d2 = 0;
        var r2 = 1e3, t2 = 0, n = [], h;
        h = this.font;
        if (L[h])
          h = L[h];
        else {
          var l = document.createElement("div").style;
          try {
            l.font = h;
          } catch (u) {
          }
          h = L[h] = { style: l.fontStyle || "normal", variant: l.fontVariant || "normal", weight: l.fontWeight || "normal", size: l.fontSize || 10, family: l.fontFamily || "sans-serif" };
        }
        var l = h, m = this.element_;
        h = {};
        for (var p in l)
          h[p] = l[p];
        p = parseFloat(m.currentStyle.fontSize);
        m = parseFloat(l.size);
        "number" == typeof l.size ? h.size = l.size : -1 != l.size.indexOf("px") ? h.size = m : -1 != l.size.indexOf("em") ? h.size = p * m : -1 != l.size.indexOf("%") ? h.size = p / 100 * m : -1 != l.size.indexOf("pt") ? h.size = m / 0.75 : h.size = p;
        h.size *= 0.981;
        p = h.style + " " + h.variant + " " + h.weight + " " + h.size + "px " + h.family;
        m = this.element_.currentStyle;
        l = this.textAlign.toLowerCase();
        switch (l) {
          case "left":
          case "center":
          case "right":
            break;
          case "end":
            l = "ltr" == m.direction ? "right" : "left";
            break;
          case "start":
            l = "rtl" == m.direction ? "right" : "left";
            break;
          default:
            l = "left";
        }
        switch (this.textBaseline) {
          case "hanging":
          case "top":
            t2 = h.size / 1.75;
            break;
          case "middle":
            break;
          default:
          case null:
          case "alphabetic":
          case "ideographic":
          case "bottom":
            t2 = -h.size / 2.25;
        }
        switch (l) {
          case "right":
            d2 = 1e3;
            r2 = 0.05;
            break;
          case "center":
            d2 = r2 = 500;
        }
        b = s(this, b + 0, c + t2);
        n.push('<g_vml_:line from="', -d2, ' 0" to="', r2, ' 0.05" ', ' coordsize="100 100" coordorigin="0 0"', ' filled="', !e, '" stroked="', !!e, '" style="position:absolute;width:1px;height:1px;">');
        e ? S(this, n) : T(
          this,
          n,
          { x: -d2, y: 0 },
          { x: r2, y: h.size }
        );
        e = f[0][0].toFixed(3) + "," + f[1][0].toFixed(3) + "," + f[0][1].toFixed(3) + "," + f[1][1].toFixed(3) + ",0,0";
        b = k(b.x / q) + "," + k(b.y / q);
        n.push('<g_vml_:skew on="t" matrix="', e, '" ', ' offset="', b, '" origin="', d2, ' 0" />', '<g_vml_:path textpathok="true" />', '<g_vml_:textpath on="true" string="', N(a), '" style="v-text-align:', l, ";font:", N(p), '" /></g_vml_:line>');
        this.element_.insertAdjacentHTML("beforeEnd", n.join(""));
      };
      d.fillText = function(a, b, c, d2) {
        this.drawText_(a, b, c, d2, false);
      };
      d.strokeText = function(a, b, c, d2) {
        this.drawText_(a, b, c, d2, true);
      };
      d.measureText = function(a) {
        this.textMeasureEl_ || (this.element_.insertAdjacentHTML("beforeEnd", '<span style="position:absolute;top:-20000px;left:0;padding:0;margin:0;border:none;white-space:pre;"></span>'), this.textMeasureEl_ = this.element_.lastChild);
        var b = this.element_.ownerDocument;
        this.textMeasureEl_.innerHTML = "";
        this.textMeasureEl_.style.font = this.font;
        this.textMeasureEl_.appendChild(b.createTextNode(a));
        return { width: this.textMeasureEl_.offsetWidth };
      };
      d.clip = function() {
      };
      d.arcTo = function() {
      };
      d.createPattern = function(a, b) {
        return new I(a, b);
      };
      w.prototype.addColorStop = function(a, b) {
        b = G(b);
        this.colors_.push({ offset: a, color: b.color, alpha: b.alpha });
      };
      d = A.prototype = Error();
      d.INDEX_SIZE_ERR = 1;
      d.DOMSTRING_SIZE_ERR = 2;
      d.HIERARCHY_REQUEST_ERR = 3;
      d.WRONG_DOCUMENT_ERR = 4;
      d.INVALID_CHARACTER_ERR = 5;
      d.NO_DATA_ALLOWED_ERR = 6;
      d.NO_MODIFICATION_ALLOWED_ERR = 7;
      d.NOT_FOUND_ERR = 8;
      d.NOT_SUPPORTED_ERR = 9;
      d.INUSE_ATTRIBUTE_ERR = 10;
      d.INVALID_STATE_ERR = 11;
      d.SYNTAX_ERR = 12;
      d.INVALID_MODIFICATION_ERR = 13;
      d.NAMESPACE_ERR = 14;
      d.INVALID_ACCESS_ERR = 15;
      d.VALIDATION_ERR = 16;
      d.TYPE_MISMATCH_ERR = 17;
      G_vmlCanvasManager = U;
      CanvasRenderingContext2D = C;
      CanvasGradient = w;
      CanvasPattern = I;
      DOMException = A;
    }();
  }
});

// node_modules/@canvasjs/angular-charts/fesm2015/canvasjs-angular-charts.js
function CanvasJSChart_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 1);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵpropertyInterpolate("id", ctx_r0.chartContainerId);
    ɵɵproperty("ngStyle", ctx_r0.styles);
  }
}
if (typeof document === "object" && !!document) {
  CanvasJS = require_canvasjs_min();
}
var CanvasJS;
var CanvasJSChart = class _CanvasJSChart {
  constructor() {
    this.shouldUpdateChart = false;
    this.isDOMPresent = typeof document === "object" && !!document;
    this.chartInstance = new EventEmitter();
    this.options = this.options ? this.options : {};
    this.styles = this.styles ? this.styles : {
      width: "100%",
      position: "relative"
    };
    this.styles.height = this.options.height ? this.options.height + "px" : "400px";
    this.chartContainerId = "canvasjs-angular-chart-container-" + _CanvasJSChart._cjsChartContainerId++;
  }
  ngDoCheck() {
    if (this.prevChartOptions != this.options) {
      this.shouldUpdateChart = true;
    }
  }
  ngOnChanges() {
    if (this.shouldUpdateChart && this.chart) {
      this.chart.options = this.options;
      this.chart.render();
      this.shouldUpdateChart = false;
      this.prevChartOptions = this.options;
    }
  }
  ngAfterViewInit() {
    if (this.isDOMPresent) {
      this.chart = new CanvasJS.Chart(this.chartContainerId, this.options);
      this.chart.render();
      this.prevChartOptions = this.options;
      this.chartInstance.emit(this.chart);
    }
  }
  ngOnDestroy() {
    if (this.chart)
      this.chart.destroy();
  }
};
CanvasJSChart._cjsChartContainerId = 0;
CanvasJSChart.ɵfac = function CanvasJSChart_Factory(t) {
  return new (t || CanvasJSChart)();
};
CanvasJSChart.ɵcmp = ɵɵdefineComponent({
  type: CanvasJSChart,
  selectors: [["canvasjs-chart"]],
  inputs: {
    options: "options",
    styles: "styles"
  },
  outputs: {
    chartInstance: "chartInstance"
  },
  features: [ɵɵNgOnChangesFeature],
  decls: 1,
  vars: 1,
  consts: [[3, "id", "ngStyle", 4, "ngIf"], [3, "id", "ngStyle"]],
  template: function CanvasJSChart_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, CanvasJSChart_div_0_Template, 1, 2, "div", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.isDOMPresent);
    }
  },
  dependencies: [NgIf, NgStyle],
  encapsulation: 2
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CanvasJSChart, [{
    type: Component,
    args: [{
      selector: "canvasjs-chart",
      template: '<div *ngIf="isDOMPresent" id="{{chartContainerId}}" [ngStyle]="styles"></div>'
    }]
  }], function() {
    return [];
  }, {
    options: [{
      type: Input
    }],
    styles: [{
      type: Input
    }],
    chartInstance: [{
      type: Output
    }]
  });
})();
var CanvasJSAngularChartsModule = class {
};
CanvasJSAngularChartsModule.ɵfac = function CanvasJSAngularChartsModule_Factory(t) {
  return new (t || CanvasJSAngularChartsModule)();
};
CanvasJSAngularChartsModule.ɵmod = ɵɵdefineNgModule({
  type: CanvasJSAngularChartsModule,
  declarations: [CanvasJSChart],
  imports: [CommonModule],
  exports: [CanvasJSChart]
});
CanvasJSAngularChartsModule.ɵinj = ɵɵdefineInjector({
  imports: [[CommonModule]]
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CanvasJSAngularChartsModule, [{
    type: NgModule,
    args: [{
      declarations: [CanvasJSChart],
      imports: [CommonModule],
      exports: [CanvasJSChart]
    }]
  }], null, null);
})();
export {
  CanvasJS,
  CanvasJSAngularChartsModule,
  CanvasJSChart
};
//# sourceMappingURL=@canvasjs_angular-charts.js.map
